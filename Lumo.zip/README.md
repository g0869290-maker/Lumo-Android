# Lumo Android 2.5

Lumo keeps the supplied HTML/CSS interface as the screen UI, hosted inside an Android WebView. The WebView fills the available phone width and height; only the preview-only phone frame and fake status bar are removed. Native Kotlin code owns link inspection, yt-dlp downloads, MediaStore saving, history, foreground notifications, and settings. The JavaScript bridge is limited to this bundled local HTML asset.

## Build on GitHub Actions

1. Upload `Lumo_Android_Project_For_GitHub.zip` to the repository root.
2. Upload `build-lumo.yml` to `.github/workflows/build-lumo.yml`.
3. Push to `main`/`master`, or start **Build Lumo Android** from the Actions tab.
4. Download the `Lumo-Android-debug-APK` artifact from the successful run.

## Screens and behaviour

- **Download:** video or playlist link inspection, real metadata and thumbnails, resolutions reported by yt-dlp, subtitle tracks, MP4/MKV preference, actual download progress, speed and ETA.
- **Playlist:** flat playlist inspection, per-video sequential downloads, per-item progress/cancel, and a selected quality ceiling.
- **History:** persisted completed/failed/cancelled records, retry/resume, opening a saved file, copying its source URL, and removing history records.
- **Settings:** active/progress colours, download destination, MP4 preference, preferred subtitle language, and yt-dlp engine update.
- **Background:** foreground download service, ongoing notification with cancellation, and a partial wake lock while downloading.
- **Real control wiring:** quality selection is passed to yt-dlp with the selected height as a hard maximum; playlist subtitle errors show the same user decision prompt as single-video subtitle errors.

## Important limitations

- The original HTML preview contained mock video details and timer-based demonstration progress. Those simulation paths were removed; the Android bridge supplies real yt-dlp results and progress.
- Available resolutions and subtitle languages depend on the source and are never fabricated. If a source does not report a size, Lumo labels the estimate unavailable.
- Some YouTube videos currently require sign-in, bot verification, or a Proof of Origin (PO) token. Lumo retries the `android_vr` and `tv` player clients when extraction or download fails with a compatible client/format error. These clients avoid some PO-token requirements, but are not universal: `android_vr` excludes some made-for-kids videos, `tv` may expose fewer formats, and YouTube may require a current PO-token-provider plugin for other client types. No downloader can guarantee extraction for every restricted video.
- Playlist subtitles are requested per item. A selected language may not exist on every playlist entry.
- The GitHub workflow compiles and packages a debug APK; successful compilation does not replace real-device tests of each provider, quality selection, subtitle combination, storage destination, and background download behaviour.

## 2.4 changes

- Subtitle chips now list manual tracks plus the video's original-language auto captions (labelled "(auto)"), instead of YouTube's ~150 auto-translated languages.
- A failed subtitle fetch (yt-dlp only warns, e.g. HTTP 429) now triggers the "Download without them?" prompt instead of silently saving a file with no subtitles.
- Progress no longer resets between the video and audio streams or spikes on subtitle files.

## 2.5 changes

- **Subtitles:** MP4 + subtitles saves separate `.srt` files next to the video (fetched with the default YouTube client, which is the one that carries captions); MKV embeds them. Captions are merged across extraction attempts so they still appear when a fallback client is used. "All languages" requests real tracks only, not YouTube's ~150 auto-translations.
- **Sign-in cookies:** Settings → Engine → *Sign-in cookies* imports a Netscape `cookies.txt` (exported from a browser signed in to YouTube) and passes it to every inspection, download and subtitle request. Use it when you see "Sign in to confirm you're not a bot".
- **UI parity:** history and playlist rows now use the preview's progress rings and single dividers; the colour "+" opens an in-app picker (WebView has no reliable native colour dialog); long-press removes a saved colour.
- **Back button** leaves the app when there is nothing to go back to; failed downloads show the real error.
