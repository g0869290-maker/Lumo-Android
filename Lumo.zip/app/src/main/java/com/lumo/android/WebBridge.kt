package com.lumo.android

import android.webkit.JavascriptInterface
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import kotlinx.coroutines.flow.MutableSharedFlow

/** Events from the Kotlin downloader into the original HTML interface. */
data class LumoWebEvent(val name: String, val payload: JSONObject)

object LumoWebEvents {
    val events = MutableSharedFlow<LumoWebEvent>(extraBufferCapacity = 128)
    fun send(name: String, payload: JSONObject = JSONObject()) {
        events.tryEmit(LumoWebEvent(name, payload))
    }
}

object WebPayload {
    fun video(info: VideoInfo, selected: Set<String>): JSONObject {
        val qualities = JSONArray()
        Quality.options(info.sizesMb, false).forEach { q ->
            qualities.put(JSONObject().put("label", q.label).put("height", q.height).put("sizeText", q.sizeText))
        }
        val subtitles = JSONArray()
        info.subCodes.sorted().forEach { code ->
            val isAuto = code in info.autoSubs
            val baseCode = if (isAuto) code.dropLast(5) else code
            val lang = Locale.forLanguageTag(baseCode).getDisplayLanguage(Locale.ENGLISH)
            val name = if (lang.isBlank() || lang.equals("und", true) || lang.equals(baseCode, true)) baseCode.uppercase(Locale.US) else lang.replaceFirstChar { it.uppercase(Locale.ENGLISH) }
            val label = if (isAuto) "$name (auto)" else name
            subtitles.put(JSONObject().put("code", code).put("label", label))
        }
        return JSONObject()
            .put("url", info.url)
            .put("title", info.title)
            .put("extractor", info.extractor)
            .put("duration", info.duration)
            .put("thumb", info.thumb)
            .put("qualities", qualities)
            .put("subtitles", subtitles)
            .put("selectedSubs", JSONArray(selected.toList()))
            .put("selectedQuality", Lumo.vQuality)
            .put("container", Lumo.vContainer)
    }

    fun playlist(info: PlaylistInfo): JSONObject {
        val entries = JSONArray()
        info.entries.forEach { entry ->
            entries.put(
                JSONObject()
                    .put("url", entry.url)
                    .put("title", entry.title)
                    .put("duration", entry.duration)
                    .put("thumb", entry.thumb)
            )
        }
        return JSONObject()
            .put("url", info.url)
            .put("title", info.title)
            .put("entries", entries)
            .put("selectedSubs", JSONArray(Lumo.pSubs.toList()))
            .put("selectedQuality", Lumo.pQuality)
    }

    fun settings(): JSONObject = JSONObject()
        .put("folder", Lumo.folderName)
        .put("preferMp4", Lumo.preferMp4On)
        .put("prefSub", Lumo.prefSubCode)
        .put("autoUpdate", Lumo.autoUpdateOn)
        .put("indHex", Lumo.indHex)
        .put("progHex", Lumo.progHex)
        .put("savedColors", JSONArray(Lumo.savedColors))
        .put("hasCookies", Lumo.hasCookies())

    fun history(items: List<HistoryRecord>): JSONArray {
        val arr = JSONArray()
        items.forEach { r ->
            arr.put(
                JSONObject()
                    .put("id", r.id)
                    .put("title", r.title)
                    .put("url", r.url)
                    .put("thumb", r.thumb)
                    .put("quality", r.quality)
                    .put("sizeText", r.sizeText)
                    .put("format", r.format)
                    .put("status", r.status)
                    .put("percent", r.percent.toDouble())
                    .put("error", r.error)
                    .put("time", r.time)
            )
        }
        return arr
    }

    fun job(state: JobState): JSONObject {
        val items = JSONArray()
        state.items.forEach { item ->
            items.put(
                JSONObject()
                    .put("title", item.title)
                    .put("thumb", item.thumb)
                    .put("duration", item.duration)
                    .put("status", item.status)
                    .put("percent", item.percent.toDouble())
                    .put("error", item.error)
            )
        }
        return JSONObject()
            .put("jobId", state.jobId)
            .put("kind", state.kind)
            .put("items", items)
            .put("phase", state.phase)
            .put("percent", state.percent.toDouble())
            .put("speed", state.speed)
            .put("eta", state.eta)
            .put("message", state.message)
            .put("folder", state.folder)
            .put("prompt", state.prompt)
            .put("lastUri", state.lastUri)
            .put("lastPath", state.lastPath)
    }

    fun bootstrap(): JSONObject = JSONObject()
        .put("settings", settings())
        .put("engineReady", Lumo.engineReady)
        .put("engineStatus", Lumo.engineStatus)
        .put("playlistMode", Lumo.playlistMode)
        .put("history", history(HistoryStore.items.value))
        .put("download", job(DownloadBus.state.value))
}

/** Only exposed to the bundled, app-owned HTML asset. */
class LumoWebBridge(private val activity: MainActivity) {
    private fun ui(action: () -> Unit) {
        activity.runOnUiThread(action)
    }

    @JavascriptInterface fun setMode(playlist: Boolean) = ui { Lumo.setMode(playlist) }
    @JavascriptInterface fun inspectVideo(url: String) = ui { Lumo.inspectVideo(url.trim()) }
    @JavascriptInterface fun pasteVideo() = ui { Lumo.pasteVideo() }
    @JavascriptInterface fun clearVideo() = ui { Lumo.clearVideo() }
    @JavascriptInterface fun setVideoSelection(qualityIndex: Int, subtitleCodes: String, container: String) = ui {
        Lumo.vQuality = qualityIndex.coerceAtLeast(0)
        Lumo.vSubs = subtitleCodes.split(',').map { it.trim() }.filter { it.isNotBlank() }.toSet()
        Lumo.vContainer = if (container.equals("mkv", true)) "mkv" else "mp4"
    }
    @JavascriptInterface fun startVideo(qualityIndex: Int, subtitleCodes: String, container: String) = ui {
        Lumo.vQuality = qualityIndex.coerceAtLeast(0)
        Lumo.vSubs = subtitleCodes.split(',').map { it.trim() }.filter { it.isNotBlank() }.toSet()
        Lumo.vContainer = if (container.equals("mkv", true)) "mkv" else "mp4"
        Lumo.startVideo()
    }
    @JavascriptInterface fun showOptions() = ui { Lumo.showOptions() }
    @JavascriptInterface fun backToQuality() = ui { Lumo.backToQuality() }
    @JavascriptInterface fun cancelVideo() = ui { Lumo.cancelVideo() }
    @JavascriptInterface fun newVideo() = ui { Lumo.newVideo() }
    @JavascriptInterface fun openFolder() = ui { Lumo.openFolder() }

    @JavascriptInterface fun inspectPlaylist(url: String) = ui { Lumo.inspectPlaylist(url.trim()) }
    @JavascriptInterface fun pastePlaylist() = ui { Lumo.pastePlaylist() }
    @JavascriptInterface fun clearPlaylist() = ui { Lumo.clearPlaylist() }
    @JavascriptInterface fun setPlaylistSelection(qualityIndex: Int, subtitleCodes: String) = ui {
        Lumo.pQuality = qualityIndex.coerceAtLeast(0)
        Lumo.pSubs = subtitleCodes.split(',').map { it.trim() }.filter { it.isNotBlank() }.toSet()
    }
    @JavascriptInterface fun startPlaylist(qualityIndex: Int, subtitleCodes: String) = ui {
        Lumo.pQuality = qualityIndex.coerceAtLeast(0)
        Lumo.pSubs = subtitleCodes.split(',').map { it.trim() }.filter { it.isNotBlank() }.toSet()
        Lumo.startPlaylist()
    }
    @JavascriptInterface fun cancelPlaylist() = ui { Lumo.cancelPlaylist() }
    @JavascriptInterface fun cancelPlaylistItem(index: Int) = ui { Lumo.cancelItem(index) }
    @JavascriptInterface fun removePlaylistEntry(index: Int) = ui { Lumo.removeEntry(index) }
    @JavascriptInterface fun newPlaylist() = ui { Lumo.newPlaylist() }
    @JavascriptInterface fun decideSubtitles(choice: String) = ui { Lumo.decideSubtitles(choice) }

    @JavascriptInterface fun retryHistory(id: String) = ui { HistoryStore.get(id)?.let { Lumo.retry(it) } }
    @JavascriptInterface fun removeHistory(id: String) = ui { HistoryStore.get(id)?.let { Lumo.removeRecord(it) } }
    @JavascriptInterface fun clearHistory() = ui { HistoryStore.clear(); Lumo.toast("History cleared") }
    @JavascriptInterface fun openRecord(id: String) = ui { HistoryStore.get(id)?.let { Lumo.openRecord(it) } }
    @JavascriptInterface fun copyText(value: String) = ui { Lumo.copyText(value); Lumo.toast("Copied to clipboard") }

    @JavascriptInterface fun setFolder(folder: String) = ui { Lumo.setFolderFromWeb(folder) }
    @JavascriptInterface fun setPreferMp4(enabled: Boolean) = ui { Lumo.setPreferMp4(enabled) }
    @JavascriptInterface fun setAutoUpdate(enabled: Boolean) = ui { Lumo.setAutoUpdate(enabled) }
    @JavascriptInterface fun setPrefSub(code: String) = ui {
        val label = when (code) {
            "en" -> "English"
            "hi" -> "Hindi"
            "mr" -> "Marathi"
            else -> "None"
        }
        Lumo.setPrefSub(code, label)
    }
    @JavascriptInterface fun setAccent(target: String, hex: String) = ui { Lumo.pickColor(target, hex) }
    @JavascriptInterface fun saveAccent(target: String, hex: String) = ui { Lumo.saveAccentFromWeb(target, hex) }
    @JavascriptInterface fun removeSavedColor(hex: String) = ui { Lumo.removeSavedColor(hex) }
    @JavascriptInterface fun updateEngine() = ui { Lumo.updateEngine() }
    @JavascriptInterface fun pickCookies() = ui { activity.pickCookieFile() }
    @JavascriptInterface fun removeCookies() = ui { Lumo.removeCookies() }
}
