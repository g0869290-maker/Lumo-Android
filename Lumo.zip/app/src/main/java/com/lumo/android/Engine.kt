package com.lumo.android

import android.content.Context
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale

/** Wraps yt-dlp. All calls here block, so run them off the main thread. */
object YtEngine {
    @Volatile
    var ready = false

    /** Optional cookies.txt imported by the user (Settings → Downloads) for sign-in errors. */
    @Volatile
    var cookieFile: File? = null

    fun withCookies(req: YoutubeDLRequest) {
        cookieFile?.takeIf { it.isFile && it.length() > 0L }?.let { req.addOption("--cookies", it.absolutePath) }
    }

    fun init(context: Context): String = try {
        YoutubeDL.getInstance().init(context.applicationContext)
        FFmpeg.getInstance().init(context.applicationContext)
        ready = true
        "Download engine ready"
    } catch (e: Exception) {
        ready = false
        "Engine failed to start: ${e.message ?: "unknown error"}"
    }

    fun update(context: Context): String = try {
        clearCache()
        "Engine update: " + YoutubeDL.getInstance().updateYoutubeDL(context.applicationContext)
    } catch (e: Exception) {
        "Engine update failed: ${e.message ?: "unknown error"}"
    }

    /**
     * Recent inspection results keyed by URL. Re-pasting or re-opening the same link returns instantly
     * instead of starting another yt-dlp run. Entries expire after 10 minutes, so sizes stay current.
     */
    private const val CACHE_TTL_MS = 10 * 60 * 1000L
    private val videoCache = object : LinkedHashMap<String, Pair<Long, VideoInfo>>(8, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Pair<Long, VideoInfo>>?): Boolean = size > 20
    }

    /** Call after the cookies file changes so cached results don't hide the new sign-in state. */
    fun clearCache() = synchronized(videoCache) { videoCache.clear() }

    private fun cachedVideo(url: String): VideoInfo? = synchronized(videoCache) {
        val hit = videoCache[url] ?: return null
        if (System.currentTimeMillis() - hit.first > CACHE_TTL_MS) {
            videoCache.remove(url)
            null
        } else hit.second
    }

    private fun rememberVideo(url: String, info: VideoInfo) = synchronized(videoCache) {
        videoCache[url] = System.currentTimeMillis() to info
    }

    fun inspectVideo(url: String): VideoInfo {
        cachedVideo(url)?.let { return it }
        val info = inspectVideoUncached(url)
        rememberVideo(url, info)
        return info
    }

    private fun inspectVideoUncached(url: String): VideoInfo {
        val json = dumpJson(url, playlist = false)
        val formats = json.optJSONArray("formats") ?: JSONArray()
        val duration = json.optDouble("duration", 0.0).let { if (it.isNaN()) 0.0 else it }

        // Mirror the download selector: one video format per height (mp4 preferred, then the highest bitrate)
        // plus one audio format (m4a preferred, then the highest bitrate). Exact when the source reports sizes.
        val videoBy = linkedMapOf<Int, MutableList<Pair<JSONObject, Double>>>()
        val muxed = linkedMapOf<Int, Double>()
        val mp4Heights = mutableSetOf<Int>()
        var audioBytes = 0.0
        var audioTbr = -1.0
        var audioIsM4a = false
        for (i in 0 until formats.length()) {
            val f = formats.optJSONObject(i) ?: continue
            val vcodec = f.optString("vcodec", "")
            val acodec = f.optString("acodec", "")
            val height = f.optInt("height", 0)
            val ext = f.optString("ext", "").lowercase(Locale.US)
            val hasAudio = acodec.isNotEmpty() && acodec != "none"
            val hasVideo = (vcodec.isNotEmpty() && vcodec != "none") || (vcodec.isEmpty() && height > 0)
            val tbr = f.optDouble("tbr", 0.0).let { if (it.isNaN()) 0.0 else it }
            val bytes = formatBytes(f, duration)
            if (!hasVideo) {
                if (!hasAudio || bytes <= 0.0) continue
                val isM4a = ext == "m4a"
                if (audioBytes <= 0.0 || (isM4a && !audioIsM4a) || (isM4a == audioIsM4a && tbr > audioTbr)) {
                    audioBytes = bytes
                    audioTbr = tbr
                    audioIsM4a = isM4a
                }
                continue
            }
            if (height <= 0) continue
            if (ext == "mp4") mp4Heights.add(height)
            if (hasAudio) {
                // Muxed file: only used when there is no separate video stream at this height.
                muxed[height] = maxOf(muxed[height] ?: 0.0, bytes)
            } else if (bytes > 0.0) {
                videoBy.getOrPut(height) { mutableListOf() }.add(f to bytes)
            }
        }
        // Audio: exact when reported, otherwise 128 kbps for the duration.
        val audioEst = if (audioBytes > 0.0) audioBytes else if (duration > 0.0) 128_000.0 / 8.0 * duration else 0.0
        val sizes = linkedMapOf<Int, Double>()
        for (h in (videoBy.keys + muxed.keys).toSortedSet()) {
            val candidates = videoBy[h].orEmpty()
            val mp4Cands = candidates.filter { it.first.optString("ext", "").equals("mp4", ignoreCase = true) }
            val pool = mp4Cands.ifEmpty { candidates }
            val video = pool.maxByOrNull { it.first.optDouble("tbr", 0.0).let { t -> if (t.isNaN()) 0.0 else t } }?.second ?: 0.0
            val separate = if (video > 0.0 && audioEst > 0.0) video + audioEst else 0.0
            val total = if (separate > 0.0) separate else (muxed[h] ?: 0.0)
            sizes[h] = total / 1048576.0
        }

        val subs = subtitleInfo(json)
        val title = json.optString("title", "").ifBlank { "Video" }
        val extractor = json.optString("extractor_key", "").ifBlank { json.optString("extractor", "Source") }
        return VideoInfo(
            url = url,
            title = title,
            extractor = extractor,
            duration = if (duration > 0.0) formatDuration(duration.toLong()) else "",
            thumb = pickThumb(json),
            sizesMb = sizes,
            audioMb = audioEst / 1048576.0,
            mp4Heights = mp4Heights,
            subCodes = subs.first,
            autoSubs = subs.second
        )
    }

    fun inspectPlaylist(url: String): PlaylistInfo {
        val json = dumpJson(url, playlist = true)
        val arr = json.optJSONArray("entries") ?: JSONArray()
        val entries = mutableListOf<PlaylistEntry>()
        for (i in 0 until arr.length()) {
            val e = arr.optJSONObject(i) ?: continue
            val eu = entryUrl(e)
            if (eu.isBlank()) continue
            val dur = e.optDouble("duration", 0.0)
            entries.add(
                PlaylistEntry(
                    url = eu,
                    title = e.optString("title", "").ifBlank { "Video ${entries.size + 1}" },
                    duration = if (!dur.isNaN() && dur > 0.0) formatDuration(dur.toLong()) else "",
                    thumb = pickThumb(e)
                )
            )
        }
        if (entries.isEmpty()) throw IllegalStateException("This playlist has no videos Lumo can read.")
        return PlaylistInfo(
            url = url,
            title = json.optString("title", "").ifBlank { "Playlist" },
            entries = entries
        )
    }

    fun friendly(raw: String?): String {
        val msg = raw.orEmpty()
        return when {
            msg.contains("429") -> "The source is rate-limiting requests. Wait a few minutes and try again."
            msg.contains("po token", true) || msg.contains("proof of origin", true) || msg.contains("challenge solving", true) ->
                "The source requires a verification token this build cannot provide. Try another supported link or update the download engine."
            msg.contains("Sign in", true) || msg.contains("confirm you", true) || msg.contains("cookies", true) ->
                if (cookieFile?.let { it.isFile && it.length() > 0L } == true)
                    "Sign-in is still required. Your imported cookies may have expired. Export a fresh cookies.txt and import it again in Settings → Downloads."
                else
                    "The source requires sign-in or bot verification. Import a cookies.txt file in Settings → Downloads, then try again."
            msg.contains("403") || msg.contains("Forbidden", true) ->
                "The source refused the media request (403). This can be caused by an expired or restricted media URL."
            msg.contains("Video unavailable", true) || msg.contains("Private video", true) ->
                "This video is unavailable or private."
            msg.contains("Unsupported URL", true) -> "This link isn't supported."
            msg.contains("older", true) && msg.contains("yt-dlp", true) ->
                "The download engine is out of date. Update it in Settings."
            msg.isBlank() -> "Could not read this link."
            else -> "Could not read this link: ${msg.lineSequence().firstOrNull()?.take(140).orEmpty()}"
        }
    }

    /**
     * Reads every format the source offers. YouTube's default client sometimes returns only the muxed 360p
     * stream, so the fallback clients are asked too and their formats are merged. Fallbacks are skipped once
     * a 720p-or-better stream is already known, which keeps typical inspections to a single yt-dlp run.
     */
    private fun dumpJson(url: String, playlist: Boolean): JSONObject {
        val isYoutube = url.contains("youtube.com", true) || url.contains("youtu.be", true)
        val attempts = mutableListOf<JSONObject>()
        var lastError: Exception? = null
        val clients: List<String?> = if (isYoutube && !playlist) listOf(null, "android_vr", "tv") else listOf(null)
        for (client in clients) {
            try {
                attempts.add(executeDump(url, playlist, playerClient = client))
            } catch (e: Exception) {
                lastError = e
                continue
            }
            if (playlist || maxVideoHeight(mergeFormats(attempts)) >= 720) break
        }
        if (attempts.isEmpty()) throw (lastError ?: IllegalStateException("No video information returned"))
        return withCaptions(mergeFormats(attempts), attempts)
    }

    /** Union of every attempt's formats, de-duplicated by format_id, on the first attempt's metadata. */
    private fun mergeFormats(all: List<JSONObject>): JSONObject {
        val base = all.first()
        val merged = JSONArray()
        val seen = HashSet<String>()
        for (attempt in all) {
            val arr = attempt.optJSONArray("formats") ?: continue
            for (i in 0 until arr.length()) {
                val f = arr.optJSONObject(i) ?: continue
                val id = f.optString("format_id", "")
                val key = if (id.isNotBlank()) id else listOf(
                    f.optInt("height", 0), f.optString("ext", ""), f.optString("vcodec", ""),
                    f.optString("acodec", ""), f.optDouble("tbr", 0.0)
                ).joinToString("|")
                if (seen.add(key)) merged.put(f)
            }
        }
        base.put("formats", merged)
        return base
    }

    private fun maxVideoHeight(json: JSONObject): Int {
        val formats = json.optJSONArray("formats") ?: return 0
        var best = 0
        for (i in 0 until formats.length()) {
            val f = formats.optJSONObject(i) ?: continue
            val vcodec = f.optString("vcodec", "")
            if (vcodec.isNotBlank() && vcodec != "none") best = maxOf(best, f.optInt("height", 0))
        }
        return best
    }

    /** Copies caption tables from another attempt when the chosen one has none. */
    private fun withCaptions(chosen: JSONObject, all: List<JSONObject>): JSONObject {
        for (key in listOf("subtitles", "automatic_captions")) {
            if ((chosen.optJSONObject(key)?.length() ?: 0) > 0) continue
            val donor = all.firstOrNull { (it.optJSONObject(key)?.length() ?: 0) > 0 }?.optJSONObject(key)
            if (donor != null) chosen.put(key, donor)
        }
        return chosen
    }

    private fun executeDump(url: String, playlist: Boolean, playerClient: String?): JSONObject {
        val req = YoutubeDLRequest(url)
        req.addOption("--dump-single-json")
        req.addOption("--skip-download")
        req.addOption("--no-warnings")
        // Lets extraction succeed (with captions) even when a client returns no playable formats.
        req.addOption("--ignore-no-formats-error")
        withCookies(req)
        if (!playerClient.isNullOrBlank()) {
            req.addOption("--extractor-args", "youtube:player_client=$playerClient")
        }
        if (playlist) {
            req.addOption("--flat-playlist")
            req.addOption("--yes-playlist")
        } else {
            req.addOption("--no-playlist")
        }
        val raw = YoutubeDL.getInstance().execute(req).out.orEmpty()
        val start = raw.indexOf('{')
        val end = raw.lastIndexOf('}')
        if (start < 0 || end <= start) throw IllegalStateException("No video information returned")
        return JSONObject(raw.substring(start, end + 1))
    }

    /** Exact size when reported, otherwise bitrate × duration. Returns bytes. */
    private fun formatBytes(f: JSONObject, duration: Double): Double {
        val exact = f.optDouble("filesize", 0.0).takeIf { !it.isNaN() && it > 0.0 }
            ?: f.optDouble("filesize_approx", 0.0).takeIf { !it.isNaN() && it > 0.0 }
        if (exact != null) return exact
        val tbr = f.optDouble("tbr", 0.0).let { if (it.isNaN()) 0.0 else it }
        return if (tbr > 0.0 && duration > 0.0) tbr * 1000.0 / 8.0 * duration else 0.0
    }

    /**
     * Returns (all offered codes, the subset that are automatic captions).
     * Manual tracks keep regional variants (pt-BR, zh-Hans). Of YouTube's ~150 auto-translations only the
     * original-language track ("xx-orig") and translations into the languages Settings offers (en, hi, mr)
     * are listed, so the chip row stays usable.
     */
    private fun subtitleInfo(json: JSONObject): Pair<Set<String>, Set<String>> {
        val manual = linkedSetOf<String>()
        json.optJSONObject("subtitles")?.let { obj ->
            val keys = obj.keys()
            while (keys.hasNext()) {
                val code = keys.next().trim()
                if (code.isNotBlank() && !code.equals("live_chat", true)) manual.add(code)
            }
        }
        val autoKeys = mutableListOf<String>()
        json.optJSONObject("automatic_captions")?.let { obj ->
            val keys = obj.keys()
            while (keys.hasNext()) autoKeys.add(keys.next().trim())
        }
        fun hasManual(base: String) = manual.any { it.equals(base, true) || it.startsWith("$base-", true) }
        val auto = linkedSetOf<String>()
        for (code in autoKeys) {
            if (!code.endsWith("-orig", true)) continue
            if (!hasManual(code.dropLast(5))) auto.add(code)
        }
        for (code in listOf("en", "hi", "mr")) {
            if (code in autoKeys && !hasManual(code) && auto.none { it.startsWith("$code-orig", true) }) auto.add(code)
        }
        return Pair(manual + auto, auto)
    }

    private fun pickThumb(json: JSONObject): String {
        val direct = json.optString("thumbnail", "")
        if (direct.startsWith("http")) return direct
        val arr = json.optJSONArray("thumbnails") ?: return ""
        for (i in arr.length() - 1 downTo 0) {
            val u = arr.optJSONObject(i)?.optString("url", "").orEmpty()
            if (u.startsWith("http")) return u
        }
        return ""
    }

    private fun entryUrl(e: JSONObject): String {
        val web = e.optString("webpage_url", "")
        if (web.startsWith("http")) return web
        val u = e.optString("url", "")
        if (u.startsWith("http")) return u
        val id = e.optString("id", "")
        return if (id.isNotBlank()) "https://www.youtube.com/watch?v=$id" else ""
    }
}
