package com.lumo.android

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Writes a diagnostic report as a .txt file in Download/Lumo on the phone's internal storage. */
object DiagnosticFile {
    fun save(ctx: Context, text: String): String {
        val name = "lumo-diagnostic-" +
            SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date()) + ".txt"
        val bytes = text.toByteArray(Charsets.UTF_8)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            // Android 10+: MediaStore needs no storage permission and the file shows in the Downloads app.
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, name)
                put(MediaStore.Downloads.MIME_TYPE, "text/plain")
                put(MediaStore.Downloads.RELATIVE_PATH, "Download/Lumo")
            }
            val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("could not create file")
            val out = ctx.contentResolver.openOutputStream(uri)
                ?: throw IllegalStateException("could not open file")
            out.use { it.write(bytes) }
            return "Download/Lumo/$name"
        }
        // Android 7 to 9: write directly (WRITE_EXTERNAL_STORAGE is declared for these versions).
        val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "Lumo")
        dir.mkdirs()
        val file = File(dir, name)
        file.writeBytes(bytes)
        return file.absolutePath
    }
}
