package com.lumo.android

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.Executors
import java.util.Locale

enum class VStep { Idle, Inspecting, Quality, Options, Running }
enum class PStep { Idle, Inspecting, Ready, Running }

class SheetOption(val label: String, val onClick: () -> Unit)
class SheetSpec(val title: String, val options: List<SheetOption>)

val FOLDER_CHOICES = listOf("Download/Lumo", "Movies/Lumo", "DCIM/Lumo")

/** App state and actions shared by the native bridge. Mutations are posted to the main thread. */
object Lumo {
    private lateinit var app: Context
    private var initialized = false
    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private var pendingShare: String? = null

    var tab = 0
    var playlistMode = false
    var engineReady = false
    var engineStatus = "Starting download engine…"

    var toastText: String? = null
    var toastSeq = 0
    var sheet: SheetSpec? = null
    var colorTarget: String? = null

    // Settings mirrored into state so the UI repaints when they change.
    var autoUpdateOn = false
    var preferMp4On = true
    var saveSrtOn = false
    var folderName = "Download/Lumo"
    var prefSubCode = "en"
    var indHex = "#FFB45F"
    var progHex = "#8871FF"
    var savedColors: List<String> = emptyList()

    // Video mode
    var vUrl = ""
    var vStep = VStep.Idle
    var vInfo: VideoInfo? = null
    var vError = ""
    var vQuality = 0
    var vSubs = setOf<String>()
    var vContainer = "mp4"
    var vJobId = ""

    // Playlist mode
    var pUrl = ""
    var pStep = PStep.Idle
    var pInfo: PlaylistInfo? = null
    var pError = ""
    var pQuality = 0
    var pSubs = setOf<String>()
    var pJobId = ""

    fun init(context: Context) {
        if (initialized) return
        initialized = true
        app = context.applicationContext
        Prefs.init(app)
        HistoryStore.init(app)
        YtEngine.cookieFile = File(app.filesDir, "cookies.txt")
        autoUpdateOn = Prefs.autoUpdate
        preferMp4On = Prefs.preferMp4
        saveSrtOn = Prefs.saveSrt
        folderName = Prefs.folder
        prefSubCode = Prefs.prefSub
        indHex = Prefs.indHex()
        progHex = Prefs.progHex()
        savedColors = Prefs.savedColors()
        vContainer = if (preferMp4On) "mp4" else "mkv"

        worker.execute {
            val msg = YtEngine.init(app)
            post {
                engineReady = YtEngine.ready
                engineStatus = msg
                LumoWebEvents.send("onEngine", JSONObject().put("ready", engineReady).put("status", engineStatus))
                pendingShare?.let { url ->
                    pendingShare = null
                    inspectVideo(url)
                }
            }
            if (YtEngine.ready && Prefs.autoUpdate) {
                val m = YtEngine.update(app)
                post {
                    engineStatus = m
                    LumoWebEvents.send("onEngine", JSONObject().put("ready", YtEngine.ready).put("status", engineStatus))
                }
            }
        }
    }

    private fun post(block: () -> Unit) {
        main.post { block() }
    }

    fun toast(message: String) {
        toastText = message
        toastSeq++
        LumoWebEvents.send("onToast", JSONObject().put("message", message))
    }

    fun onBack() {
        when {
            sheet != null -> sheet = null
            colorTarget != null -> colorTarget = null
            tab != 0 -> tab = 0
            vStep == VStep.Options -> vStep = VStep.Quality
            vStep == VStep.Quality -> {
                vStep = VStep.Idle
                vInfo = null
            }
        }
    }

    fun clipboardText(): String {
        val cm = app.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        return cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(app)?.toString().orEmpty()
    }

    fun copyText(text: String) {
        val cm = app.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("Lumo", text))
    }

    /** Called when another app shares a link to Lumo. */
    fun handleShare(text: String) {
        val url = Regex("https?://\\S+").find(text)?.value ?: text.trim()
        if (!isHttpUrl(url)) return
        tab = 0
        playlistMode = false
        if (engineReady) inspectVideo(url) else pendingShare = url
    }

    fun setMode(playlist: Boolean) {
        playlistMode = playlist
    }

    private fun isJobActive(jobId: String): Boolean {
        val s = DownloadBus.state.value
        return jobId.isNotEmpty() && s.jobId == jobId && (s.phase == "running" || s.phase == "prompt")
    }

    private fun anyJobActive(): Boolean {
        val s = DownloadBus.state.value
        return s.phase == "running" || s.phase == "prompt"
    }

    private fun clearTerminalJob(jobId: String) {
        val state = DownloadBus.state.value
        if (jobId.isNotBlank() && state.jobId == jobId && state.phase !in setOf("running", "prompt")) {
            DownloadBus.state.value = JobState()
        }
    }

    // ---------- Video ----------

    fun pasteVideo() {
        val text = clipboardText().trim()
        if (!isHttpUrl(text)) {
            toast("Copy a video link first")
            return
        }
        inspectVideo(text)
    }

    fun inspectVideo(url: String) {
        if (!isHttpUrl(url)) {
            toast("Enter a valid http or https video link.")
            return
        }
        if (anyJobActive()) {
            toast("Finish or cancel the active download before inspecting another link.")
            return
        }
        if (!YtEngine.ready) {
            vError = "The download engine is still starting."
            LumoWebEvents.send("onVideoError", JSONObject().put("message", vError))
            return
        }
        clearTerminalJob(vJobId)
        vUrl = url
        vError = ""
        vInfo = null
        vStep = VStep.Inspecting
        LumoWebEvents.send("onVideoInspecting", JSONObject().put("url", url))
        worker.execute {
            try {
                val info = YtEngine.inspectVideo(url)
                post {
                    vInfo = info
                    vQuality = 0
                    vSubs = defaultSubs(info.subCodes)
                    vContainer = if (preferMp4On) "mp4" else "mkv"
                    vStep = VStep.Quality
                    LumoWebEvents.send("onVideoInfo", WebPayload.video(info, vSubs))
                }
            } catch (e: Exception) {
                val msg = YtEngine.friendly(e.message)
                post {
                    vStep = VStep.Idle
                    vError = msg
                    LumoWebEvents.send("onVideoError", JSONObject().put("message", msg))
                }
            }
        }
    }

    private fun defaultSubs(codes: Set<String>): Set<String> {
        if (prefSubCode == "none") return emptySet()
        val preferred = codes.firstOrNull { code ->
            code.equals(prefSubCode, ignoreCase = true) ||
                code.startsWith("$prefSubCode-", ignoreCase = true) ||
                code.startsWith("${prefSubCode}_", ignoreCase = true)
        }
        return preferred?.let(::setOf) ?: emptySet()
    }

    fun clearVideo() {
        if (isJobActive(vJobId)) {
            toast("Cancel the download first.")
            return
        }
        clearTerminalJob(vJobId)
        vUrl = ""
        vError = ""
        vInfo = null
        vSubs = emptySet()
        vStep = VStep.Idle
    }

    fun toggleSub(code: String) {
        vSubs = if (code in vSubs) vSubs - code else vSubs + code
    }

    fun chooseMp4() {
        vSubs = emptySet()
        vContainer = "mp4"
    }

    fun chooseMkv() {
        vContainer = "mkv"
    }

    fun startVideo() {
        val info = vInfo ?: return
        if (anyJobActive()) {
            toast("Another download is running.")
            return
        }
        val opts = Quality.options(info.sizesMb, false)
        val q = opts.getOrNull(vQuality) ?: opts.first()
        val subs = vSubs.sorted().joinToString(",")
        val container = vContainer
        val id = "v" + System.currentTimeMillis()
        vJobId = id
        vStep = VStep.Running
        val item = JSONObject()
            .put("url", info.url)
            .put("title", info.title)
            .put("thumb", info.thumb)
            .put("duration", info.duration)
            .put("size", q.sizeText)
            .put("sizeBytes", q.bytes)
            .put("audioBytes", info.audioMb * 1048576.0)
        launch(id, "video", Quality.selector(q.height, container), container, subs, q.label, listOf(item))
    }

    fun cancelVideo() = sendCancel(-1)

    fun newVideo() {
        clearTerminalJob(vJobId)
        vUrl = ""
        vInfo = null
        vError = ""
        vSubs = emptySet()
        vJobId = ""
        vStep = VStep.Idle
        vContainer = if (preferMp4On) "mp4" else "mkv"
    }

    fun backToQuality() {
        if (vStep == VStep.Options) vStep = VStep.Quality
    }

    fun showOptions() {
        if (vStep == VStep.Quality && vInfo != null) vStep = VStep.Options
    }

    // ---------- Playlist ----------

    fun pastePlaylist() {
        val text = clipboardText().trim()
        if (!isHttpUrl(text)) {
            toast("Copy a playlist link first")
            return
        }
        inspectPlaylist(text)
    }

    fun inspectPlaylist(url: String) {
        if (!isHttpUrl(url)) {
            toast("Enter a valid http or https playlist link.")
            return
        }
        if (anyJobActive()) {
            toast("Finish or cancel the active download before inspecting another link.")
            return
        }
        if (!YtEngine.ready) {
            pError = "The download engine is still starting."
            LumoWebEvents.send("onPlaylistError", JSONObject().put("message", pError))
            return
        }
        clearTerminalJob(pJobId)
        pUrl = url
        pError = ""
        pInfo = null
        pStep = PStep.Inspecting
        LumoWebEvents.send("onPlaylistInspecting", JSONObject().put("url", url))
        worker.execute {
            try {
                val info = YtEngine.inspectPlaylist(url)
                post {
                    pInfo = info
                    pQuality = 0
                    pSubs = if (prefSubCode != "none") setOf(prefSubCode) else emptySet()
                    pStep = PStep.Ready
                    LumoWebEvents.send("onPlaylistInfo", WebPayload.playlist(info))
                }
            } catch (e: Exception) {
                val msg = YtEngine.friendly(e.message)
                post {
                    pStep = PStep.Idle
                    pError = msg
                    LumoWebEvents.send("onPlaylistError", JSONObject().put("message", msg))
                }
            }
        }
    }

    fun togglePlaylistSub(code: String) {
        pSubs = if (code in pSubs) pSubs - code else pSubs + code
    }

    fun removeEntry(index: Int) {
        val info = pInfo ?: return
        val entries = info.entries.filterIndexed { i, _ -> i != index }
        if (entries.isEmpty()) {
            clearPlaylist()
            LumoWebEvents.send("onPlaylistCleared")
            return
        }
        pInfo = info.copy(entries = entries)
        LumoWebEvents.send("onPlaylistEntryRemoved", JSONObject().put("index", index).put("count", entries.size))
    }

    fun startPlaylist() {
        val info = pInfo ?: return
        if (anyJobActive()) {
            toast("Another download is running.")
            return
        }
        val opts = Quality.options(emptyMap(), true)
        val q = opts.getOrNull(pQuality) ?: opts.first()
        val subs = pSubs.sorted().joinToString(",")
        val container = if (preferMp4On) "mp4" else "mkv"
        val id = "p" + System.currentTimeMillis()
        pJobId = id
        pStep = PStep.Running
        val items = info.entries.map { e ->
            JSONObject()
                .put("url", e.url)
                .put("title", e.title)
                .put("thumb", e.thumb)
                .put("duration", e.duration)
                .put("size", "")
        }
        launch(id, "playlist", Quality.selector(q.height, container), container, subs, q.label, items)
    }

    fun cancelPlaylist() = sendCancel(-1)

    fun cancelItem(index: Int) = sendCancel(index)

    fun clearPlaylist() {
        if (isJobActive(pJobId)) {
            toast("Cancel the playlist first.")
            return
        }
        pUrl = ""
        pError = ""
        pInfo = null
        pStep = PStep.Idle
    }

    fun newPlaylist() {
        clearTerminalJob(pJobId)
        pUrl = ""
        pInfo = null
        pError = ""
        pJobId = ""
        pStep = PStep.Idle
    }

    // ---------- Shared job plumbing ----------

    private fun launch(
        jobId: String,
        kind: String,
        format: String,
        container: String,
        subs: String,
        quality: String,
        items: List<JSONObject>
    ) {
        val arr = JSONArray()
        items.forEach { arr.put(it) }
        val payload = JSONObject()
            .put("jobId", jobId)
            .put("kind", kind)
            .put("format", format)
            .put("container", container)
            .put("subs", subs)
            .put("quality", quality)
            .put("folder", folderName)
            .put("saveSrt", saveSrtOn)
            .put("items", arr)

        DownloadBus.state.value = JobState(
            jobId = jobId,
            kind = kind,
            items = items.map {
                ItemState(title = it.optString("title"), thumb = it.optString("thumb"), duration = it.optString("duration"))
            },
            phase = "running",
            folder = folderName,
            message = "Starting…"
        )
        val intent = Intent(app, DownloadService::class.java)
            .setAction(DownloadService.ACTION_START)
            .putExtra(DownloadService.EXTRA_PAYLOAD, payload.toString())
        ContextCompat.startForegroundService(app, intent)
    }

    private fun sendCancel(index: Int) {
        app.startService(
            Intent(app, DownloadService::class.java)
                .setAction(DownloadService.ACTION_CANCEL)
                .putExtra(DownloadService.EXTRA_INDEX, index)
        )
    }

    fun decideSubtitles(choice: String) {
        app.startService(
            Intent(app, DownloadService::class.java)
                .setAction(DownloadService.ACTION_DECIDE)
                .putExtra(DownloadService.EXTRA_CHOICE, choice)
        )
    }

    // ---------- History ----------

    fun retry(rec: HistoryRecord) {
        if (!YtEngine.ready) {
            toast("The download engine is still starting.")
            return
        }
        if (anyJobActive()) {
            toast("Another download is running.")
            return
        }
        val item = JSONObject()
            .put("url", rec.url)
            .put("title", rec.title)
            .put("thumb", rec.thumb)
            .put("duration", "")
            .put("size", rec.sizeText)
            .put("recordId", rec.id)
        val container = rec.container
        toast("Retrying. Partial files are resumed when possible.")
        launch("r" + System.currentTimeMillis(), "video", rec.formatSel, container, rec.subs, rec.quality, listOf(item))
    }

    /**
     * Deletes the saved file, then the history entry. The page asks for confirmation first.
     * (This used to set a Kotlin "sheet" that nothing ever displayed, so Delete did nothing.)
     */
    fun removeRecord(rec: HistoryRecord) {
        if (rec.status == "run") {
            toast("Cancel this download before deleting it.")
            return
        }
        if (deleteSavedFile(rec)) {
            HistoryStore.remove(rec.id)
            toast(if (rec.status == "ok") "Video deleted from your phone" else "Record removed")
        } else {
            toast("Couldn't delete the video. Check file access and try again.")
        }
    }

    private fun deleteSavedFile(rec: HistoryRecord): Boolean {
        if (rec.status != "ok") return true
        // Try the MediaStore URI first, then the stored path.
        if (rec.uri.isNotBlank()) {
            val uri = android.net.Uri.parse(rec.uri)
            try {
                if (app.contentResolver.delete(uri, null, null) > 0) return true
                // Nothing was deleted: either the file is already gone (fine) or it is still there.
                if (!mediaStoreRowExists(uri)) return true
            } catch (_: Exception) {
                // Fall through to the path fallback below.
            }
        }
        if (rec.path.isNotBlank()) {
            return try {
                val file = java.io.File(rec.path)
                !file.exists() || file.delete()
            } catch (_: Exception) {
                false
            }
        }
        return rec.uri.isBlank()
    }

    private fun mediaStoreRowExists(uri: android.net.Uri): Boolean = try {
        app.contentResolver.query(uri, arrayOf(android.provider.MediaStore.MediaColumns._ID), null, null, null)
            ?.use { it.moveToFirst() } ?: false
    } catch (_: Exception) {
        true
    }

    fun askClearHistory() {
        sheet = SheetSpec(
            "Clear all history?",
            listOf(
                SheetOption("Clear history") {
                    HistoryStore.clear()
                    toast("History cleared")
                },
                SheetOption("Cancel") {}
            )
        )
    }

    fun openRecord(rec: HistoryRecord) {
        openUriOrFolder(rec.uri, rec.path)
    }

    private fun openUriOrFolder(uriText: String, path: String) {
        try {
            val uri = if (uriText.isNotBlank()) {
                Uri.parse(uriText)
            } else if (path.isNotBlank() && File(path).exists()) {
                FileProvider.getUriForFile(app, "${app.packageName}.fileprovider", File(path))
            } else {
                null
            }
            if (uri == null) {
                openFolder()
                return
            }
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "video/*")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            app.startActivity(intent)
        } catch (_: Exception) {
            openFolder()
        }
    }

    fun openFolder() {
        val intent = Intent(Intent.ACTION_VIEW)
            .setDataAndType(
                Uri.parse("content://com.android.externalstorage.documents/document/primary%3A" + Uri.encode(folderName)),
                "vnd.android.document/directory"
            )
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            app.startActivity(intent)
        } catch (_: Exception) {
            toast("Open Files → $folderName")
        }
    }

    // ---------- Settings ----------

    fun setAutoUpdate(on: Boolean) {
        Prefs.autoUpdate = on
        autoUpdateOn = on
        LumoWebEvents.send("onSettings", WebPayload.settings())
    }

    fun setPreferMp4(on: Boolean) {
        Prefs.preferMp4 = on
        preferMp4On = on
        LumoWebEvents.send("onSettings", WebPayload.settings())
        toast(if (on) "MP4 preferred" else "Keeping the original container (MKV)")
    }

    fun setSaveSrt(on: Boolean) {
        Prefs.saveSrt = on
        saveSrtOn = on
        LumoWebEvents.send("onSettings", WebPayload.settings())
        toast(if (on) "Separate subtitle files will be saved" else "Subtitles stay inside the video only")
    }

    fun updateEngine() {
        if (anyJobActive()) {
            toast("Finish or cancel the current download before updating the engine.")
            return
        }
        engineStatus = "Updating…"
        LumoWebEvents.send("onEngine", JSONObject().put("ready", YtEngine.ready).put("status", engineStatus))
        worker.execute {
            val m = YtEngine.update(app)
            post {
                engineStatus = m
                LumoWebEvents.send("onEngine", JSONObject().put("ready", YtEngine.ready).put("status", engineStatus))
            }
        }
    }

    fun askFolder() {
        sheet = SheetSpec(
            "Choose download folder",
            FOLDER_CHOICES.map { f ->
                SheetOption("Internal storage/$f") {
                    Prefs.folder = f
                    folderName = f
                    LumoWebEvents.send("onSettings", WebPayload.settings())
                    toast("Download folder updated")
                }
            }
        )
    }

    fun setPrefSub(code: String, label: String) {
        Prefs.prefSub = code
        prefSubCode = code
        LumoWebEvents.send("onSettings", WebPayload.settings())
        toast("Preferred subtitles: $label")
    }

    fun pickColor(target: String, hex: String) {
        if (target == "ind") {
            Prefs.setInd(hex)
            indHex = hex
        } else {
            Prefs.setProg(hex)
            progHex = hex
        }
        LumoWebEvents.send("onSettings", WebPayload.settings())
    }

    fun saveAccentFromWeb(target: String, rawHex: String) {
        val hex = rawHex.trim().uppercase()
        if (!Regex("#[0-9A-F]{6}").matches(hex)) {
            toast("Enter a colour like #3DDC97")
            return
        }
        val list = savedColors.toMutableList()
        if (hex !in list) {
            if (list.size >= 5) {
                toast("Up to 5 saved colours. Long-press one to remove it.")
                return
            }
            list.add(hex)
            savedColors = list
            Prefs.saveColors(list)
        }
        pickColor(target, hex)
    }

    fun setFolderFromWeb(folder: String) {
        if (folder !in FOLDER_CHOICES) return
        Prefs.folder = folder
        folderName = folder
        LumoWebEvents.send("onSettings", WebPayload.settings())
        toast("Download folder updated")
    }

    fun applyCustomColor(target: String, rawHex: String) {
        val hex = rawHex.trim().uppercase()
        if (!Regex("#[0-9A-F]{6}").matches(hex)) {
            toast("Enter a colour like #3DDC97")
            return
        }
        val list = savedColors.toMutableList()
        if (hex !in list) {
            if (list.size >= 5) {
                toast("Up to 5 saved colours. Long-press one to remove it.")
                return
            }
            list.add(hex)
            savedColors = list
            Prefs.saveColors(list)
        }
        pickColor(target, hex)
        colorTarget = null
    }

    // ---------- Sign-in cookies ----------

    fun hasCookies(): Boolean = YtEngine.cookieFile?.let { it.isFile && it.length() > 0L } == true

    fun importCookies(uri: Uri) {
        worker.execute {
            var message = ""
            try {
                val bytes = app.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                    ?: throw IllegalStateException("Cannot read the file")
                if (bytes.size > 8_000_000) throw IllegalStateException("File is too large to be a cookies.txt")
                val lines = String(bytes, Charsets.UTF_8).replace("\r\n", "\n").replace('\r', '\n').split('\n')
                val entries = lines.count { l ->
                    l.isNotBlank() && (!l.startsWith("#") || l.startsWith("#HttpOnly_")) && l.split('\t').size >= 7
                }
                if (entries == 0) {
                    message = "That doesn't look like a cookies.txt file (Netscape format)."
                } else {
                    val header = lines.firstOrNull { it.isNotBlank() }.orEmpty()
                    val hasHeader = header.startsWith("# Netscape HTTP Cookie File") || header.startsWith("# HTTP Cookie File")
                    val body = (if (hasHeader) "" else "# Netscape HTTP Cookie File\n") + lines.joinToString("\n")
                    YtEngine.cookieFile?.writeText(body)
                    YtEngine.clearCache()
                    message = if (lines.any { it.contains("youtube.com") || it.contains("google.com") })
                        "Cookies imported ($entries entries)"
                    else
                        "Imported, but no youtube.com cookies were found in this file"
                }
            } catch (e: Exception) {
                message = "Could not import: ${e.message ?: "unknown error"}"
            }
            post {
                LumoWebEvents.send("onSettings", WebPayload.settings())
                toast(message)
            }
        }
    }

    fun removeCookies() {
        YtEngine.cookieFile?.delete()
        YtEngine.clearCache()
        LumoWebEvents.send("onSettings", WebPayload.settings())
        toast("Cookies removed")
    }

    fun removeSavedColor(hex: String) {
        val list = savedColors.filter { it != hex }
        savedColors = list
        Prefs.saveColors(list)
        LumoWebEvents.send("onSettings", WebPayload.settings())
        toast("Saved colour removed")
    }
}
