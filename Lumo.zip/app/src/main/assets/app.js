(() => {
  'use strict';
  const $ = (s, root = document) => root.querySelector(s);
  const $$ = (s, root = document) => [...root.querySelectorAll(s)];
  const Native = window.LumoNative;
  const show = (el, yes) => { if (el) el.classList.toggle('hide', !yes); };
  const text = (el, value) => { if (el) el.textContent = value == null ? '' : String(value); };
  const esc = value => String(value ?? '');
  const safeImage = url => /^https:\/\//i.test(String(url || '')) ? String(url) : '';
  const parse = raw => { try { return JSON.parse(raw || '{}'); } catch (_) { return {}; } };

  let videoInfo = null;
  let videoQualities = [];
  let videoQualityIndex = 0;
  let videoSubs = new Set();
  let videoFormat = 'mp4';
  let playlistInfo = null;
  let playlistQualities = [];
  let playlistQualityIndex = 0;
  let playlistSubs = new Set();
  let historyItems = [];
  let currentJob = null;
  let engineReady = false;
  let engineStatusText = '';
  let activeNav = 0;
  let settingsTab = 0;
  let settingsState = {
    folder: 'Download/Lumo', preferMp4: true, prefSub: 'en', autoUpdate: false,
    indHex: '#FFB45F', progHex: '#8871FF', savedColors: []
  };
  let toastTimer = 0;

  function toast(message) {
    const el = $('#toast');
    text(el, message);
    el.classList.add('on');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => el.classList.remove('on'), 2400);
  }

  // Gear for the Settings icon: 8 identical teeth, centred on (12,12).
  function gearPath(cx = 12, cy = 12, teeth = 8, ro = 10, ri = 7.6, samples = 360) {
    const pitch = 2 * Math.PI / teeth, topHalf = 0.20 * pitch, baseHalf = 0.32 * pitch;
    let d = '';
    for (let i = 0; i < samples; i++) {
      const a = (i / samples) * 2 * Math.PI - Math.PI / 2;
      const k = Math.round(a / pitch), off = Math.abs(a - k * pitch);
      const r = off <= topHalf ? ro : off >= baseHalf ? ri : ro - (ro - ri) * ((off - topHalf) / (baseHalf - topHalf));
      d += (i === 0 ? 'M' : 'L') + (cx + r * Math.cos(a)).toFixed(2) + ' ' + (cy + r * Math.sin(a)).toFixed(2);
    }
    return d + 'Z';
  }
  const gearEl = $('#gearPath');
  if (gearEl) gearEl.setAttribute('d', gearPath());

  // Each icon plays its animation once per tap: Download arrow bobs, History hands turn, Settings gear bounces and turns.
  function navTo(index) {
    activeNav = index;
    $$('.page').forEach((p, i) => p.classList.toggle('on', i === index));
    const btns = $$('#nav .nb');
    btns.forEach((b, i) => b.classList.toggle('on', i === index));
    const btn = btns[index];
    if (!btn) return;
    btn.classList.remove('navtap'); void btn.offsetWidth; btn.classList.add('navtap');
    const anim = ['navdl', 'navspin', 'navgplay'][index];
    btn.classList.remove('navdl', 'navspin', 'navgplay'); void btn.offsetWidth; btn.classList.add(anim);
    setTimeout(() => btn.classList.remove(anim), 1700);
  }
  $$('#nav .nb').forEach((b, i) => b.addEventListener('click', () => navTo(i)));



  function mode(playlist) {
    $$('#seg button').forEach(b => b.classList.toggle('on', b.dataset.m === (playlist ? 'p' : 'v')));
    $('#seg').classList.toggle('pl', !!playlist);
    Native.setMode(!!playlist);
    show($('#vmode'), !playlist);
    show($('#pmode'), playlist);
  }
  $$('#seg button').forEach(b => b.addEventListener('click', () => mode(b.dataset.m === 'p')));

  function setInput(input, value) {
    input.value = value || '';
    const clearId = input.id === 'url' ? '#vx' : '#px';
    show($(clearId), !!input.value);
  }
  function setThumb(el, url) {
    const image = safeImage(url);
    if (!el) return;
    el.replaceChildren();
    if (image) {
      el.classList.add('has-image');
      const img = document.createElement('img');
      img.className = 'thumb-img';
      img.alt = '';
      img.loading = 'lazy';
      img.referrerPolicy = 'no-referrer';
      img.src = image;
      el.append(img);
    } else {
      el.classList.remove('has-image');
      el.textContent = el.closest('#vq') ? '▶  VIDEO PREVIEW' : 'VIDEO';
    }
  }
  function createChip(label, code, selected, tint, onClick, disabled = false) {
    const b = document.createElement('button');
    b.className = 'chip' + (selected ? ' on' : '') + (disabled ? ' off' : '');
    b.textContent = label;
    if (tint) b.style.setProperty('--t', tint);
    b.disabled = !!disabled;
    b.dataset.code = code || '';
    b.addEventListener('click', onClick);
    return b;
  }

  function buildDropdown(host, options, selected, onChange) {
    host.innerHTML = '';
    const button = document.createElement('button');
    const left = document.createElement('span');
    const right = document.createElement('span');
    right.textContent = '▾';
    button.append(left, right);
    const list = document.createElement('div');
    list.className = 'dl hide';
    options.forEach((option, index) => {
      const item = document.createElement('button');
      const label = document.createElement('span');
      const hint = document.createElement('small');
      label.textContent = option.label;
      hint.textContent = option.sizeText || '';
      item.append(label, hint);
      item.addEventListener('click', e => {
        e.stopPropagation();
        list.classList.add('hide');
        selected = index;
        refresh();
        onChange(index, option);
      });
      list.append(item);
    });
    function refresh() {
      const current = options[selected] || options[0] || { label: 'Best available', sizeText: '' };
      left.textContent = current.label;
      [...list.children].forEach((el, i) => el.classList.toggle('on', i === selected));
    }
    button.addEventListener('click', e => {
      e.stopPropagation();
      $$('.dl').forEach(el => { if (el !== list) el.classList.add('hide'); });
      list.classList.toggle('hide');
    });
    host.append(button, list);
    refresh();
  }
  document.addEventListener('click', () => $$('.dl').forEach(el => el.classList.add('hide')));

  function goVideo(step) {
    ['vinsp', 'vq', 'vo', 'vd'].forEach(id => show($('#' + id), false));
    if (step === 'inspect') show($('#vinsp'), true);
    if (step === 'quality') show($('#vq'), true);
    if (step === 'options') show($('#vo'), true);
    if (step === 'download') show($('#vd'), true);
  }

  function renderVideoInfo(info) {
    videoInfo = info;
    videoQualities = Array.isArray(info.qualities) && info.qualities.length ? info.qualities : [{ label: 'Best available', height: 0, sizeText: 'Size unavailable' }];
    videoQualityIndex = Math.max(0, Math.min(videoQualities.length - 1, Number(info.selectedQuality || 0)));
    videoSubs = new Set(Array.isArray(info.selectedSubs) ? info.selectedSubs : []);
    videoFormat = info.container === 'mkv' ? 'mkv' : info.container === 'mp4' ? 'mp4' : (settingsState.preferMp4 ? 'mp4' : 'mkv');

    const preview = $('#vq .thumb');
    setThumb(preview, info.thumb);
    setThumb($('#vd .thumb'), info.thumb);
    text($('#vq .t'), info.title || 'Video');
    text($('#vq .s'), [info.extractor, info.duration].filter(Boolean).join(' · '));
    buildDropdown($('#vdd'), videoQualities, videoQualityIndex, index => {
      videoQualityIndex = index;
      const q = videoQualities[index] || videoQualities[0];
      text($('#est'), `Estimated size  ·  ${q.sizeText || 'Not reported by source'}`);
      Native.setVideoSelection(videoQualityIndex, [...videoSubs].join(','), videoFormat);
    });
    const q = videoQualities[videoQualityIndex] || videoQualities[0];
    text($('#est'), `Estimated size  ·  ${q.sizeText || 'Not reported by source'}`);
    renderVideoSubtitleChips(info.subtitles || []);
    renderFormatChips();
    setInput($('#url'), info.url || '');
    goVideo('quality');
  }

  // Only these languages are offered. Anything else is never shown or downloaded.
  const SUB_LANGS = [
    { key: 'en', label: 'English', tint: '#8871FF' },
    { key: 'hi', label: 'Hindi', tint: '#FFB45F' },
    { key: 'mr', label: 'Marathi', tint: '#2DD4BF' }
  ];
  function findTrack(subtitles, key) {
    return subtitles.find(item => {
      const code = String(item.code || '').toLowerCase();
      return code === key || code.startsWith(key + '-') || code.startsWith(key + '_');
    });
  }
  function renderVideoSubtitleChips(subtitles) {
    const host = $('#vsubs');
    host.innerHTML = '';
    const tracks = SUB_LANGS.map(lang => ({ ...lang, track: findTrack(subtitles, lang.key) }));
    // Drop any saved choice that is no longer available, and tell the engine about the change
    const before = videoSubs.size;
    videoSubs = new Set([...videoSubs].filter(code => tracks.some(t => t.track && t.track.code === code)));
    if (videoSubs.size !== before) Native.setVideoSelection(videoQualityIndex, [...videoSubs].join(','), videoFormat);

    tracks.forEach(t => {
      const available = !!t.track;
      const selected = available && videoSubs.has(t.track.code);
      host.append(createChip(t.label, t.key, selected, t.tint, () => {
        if (!available) return;
        if (videoSubs.has(t.track.code)) videoSubs.delete(t.track.code); else videoSubs.add(t.track.code);
        Native.setVideoSelection(videoQualityIndex, [...videoSubs].join(','), videoFormat);
        renderVideoSubtitleChips(subtitles);
        renderFormatChips();
      }, !available));
    });
    host.append(createChip('None', 'none', videoSubs.size === 0, '#8E97A8', () => {
      videoSubs.clear();
      Native.setVideoSelection(videoQualityIndex, '', videoFormat);
      renderVideoSubtitleChips(subtitles);
      renderFormatChips();
    }));
    const note = document.createElement('span');
    note.className = 's';
    note.textContent = tracks.some(t => t.track)
      ? 'Grey languages are not available for this video.'
      : 'English, Hindi and Marathi are not available for this video.';
    host.append(note);
  }

  let lastFormatWasMkv = null;
  function renderFormatChips() {
    $$('#fmt .format-note').forEach(node => node.remove());
    $$('#fmt .chip').forEach((chip, i) => {
      chip.disabled = false;
      chip.classList.toggle('on', (i === 0) === (videoFormat === 'mp4'));
    });
    const pill = $('#fmtpill');
    const isMkv = videoFormat === 'mkv';
    if (pill) {
      const changed = lastFormatWasMkv !== null && lastFormatWasMkv !== isMkv;
      pill.classList.toggle('mkv', isMkv);
      if (changed) {
        pill.classList.remove('stretch', 'sweep');
        void pill.offsetWidth;
        pill.classList.add('stretch', 'sweep');
      }
    }
    lastFormatWasMkv = isMkv;
    if (videoSubs.size) {
      const note = document.createElement('div');
      note.className = 's format-note';
      note.style.width = '100%';
      note.textContent = videoFormat === 'mp4'
        ? 'Subtitles are saved as separate .srt files next to the video.'
        : 'Subtitles are embedded inside the MKV file.';
      $('#fmt').append(note);
    }
  }
  $$('#fmt .chip').forEach((chip, i) => chip.addEventListener('click', () => {
    videoFormat = i === 0 ? 'mp4' : 'mkv';
    Native.setVideoSelection(videoQualityIndex, [...videoSubs].join(','), videoFormat);
    renderFormatChips();
  }));

  $('#paste').addEventListener('click', () => {
    const url = $('#url').value.trim();
    if (url) Native.inspectVideo(url); else Native.pasteVideo();
  });
  $('#url').addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); $('#url').blur(); $('#paste').click(); } });
  $('#purl').addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); $('#purl').blur(); $('#ppaste').click(); } });
  $('#url').addEventListener('input', () => show($('#vx'), !!$('#url').value));
  $('#vx').addEventListener('click', () => {
    if (currentJob?.kind === 'video' && ['running', 'prompt'].includes(currentJob.phase)) return toast('Cancel the active video download before clearing it.');
    setInput($('#url'), ''); Native.clearVideo(); goVideo('idle');
  });
  $('#cont').addEventListener('click', () => { Native.showOptions(); goVideo('options'); });
  $('#back').addEventListener('click', () => { Native.backToQuality(); goVideo('quality'); });
  $('#dl').addEventListener('click', () => {
    if (!videoInfo) return toast('Inspect a video first.');
    goVideo('download');
    resetVideoProgress();
    Native.startVideo(videoQualityIndex, [...videoSubs].join(','), videoFormat);
  });
  $('#cancel').addEventListener('click', () => Native.cancelVideo());
  $('#open').addEventListener('click', () => Native.openFolder());
  $('#nv').addEventListener('click', () => {
    videoInfo = null; videoQualities = []; videoSubs.clear();
    setInput($('#url'), ''); Native.newVideo(); goVideo('idle');
  });

  let lastSpeed = '', lastEta = 0;
  function resetVideoProgress() {
    lastSpeed = ''; lastEta = 0;
    const pbw = $('#pbw');
    pbw.className = 'pbw';
    $('#fill').style.width = '0%';
    text($('#pc'), '0%');
    text($('#dt'), videoInfo?.title || 'Preparing your video');
    text($('#ds'), 'Starting download…');
    text($('#spd'), 'Connecting to source');
    show($('#cancel'), true); show($('#open'), false); show($('#nv'), false);
  }

  let donePulsed = false;
  function renderDownloadState(state) {
    if (!state || !state.jobId) { currentJob = null; return; }
    currentJob = state;
    if (state.kind === 'video') {
      if (state.phase !== 'idle') goVideo('download');
      const pct = Math.max(0, Math.min(100, Number(state.percent || 0)));
      const phase = state.phase;
      const finished = ['done', 'failed', 'cancelled'].includes(phase);
      $('#fill').style.width = (phase === 'done' ? 100 : pct) + '%';
      $('#pbw .pb').classList.toggle('ind', phase === 'running' && /subtitle/i.test(state.message || ''));
      text($('#pc'), phase === 'done' ? 'Completed' : phase === 'failed' ? 'FAILED' : phase === 'cancelled' ? 'STOPPED' : Math.round(pct) + '%');
      text($('#dt'), videoInfo?.title || state.items?.[0]?.title || 'Video download');
      text($('#ds'), phase === 'done' ? 'Your video is ready.' : phase === 'failed' ? (state.items?.[0]?.error || state.message || 'Download failed') : phase === 'cancelled' ? 'Download cancelled' : phase === 'prompt' ? state.prompt : 'Downloading video…');
      const item0 = state.items?.[0] || {};
      const sizeLine = item0.totalBytes > 0 ? `${fmtBytes(item0.doneBytes)} of ${fmtBytes(item0.totalBytes)}` : '';
      const speedLine = [sizeLine, state.speed, state.eta > 0 ? `ETA ${formatEta(state.eta)}` : ''].filter(Boolean).join('  ·  ');
      text($('#spd'), phase === 'done' ? `Saved to ${state.folder || settingsState.folder}` : speedLine || state.message || 'Calculating speed');
      if (state.speed) lastSpeed = state.speed;
      if (state.eta > 0) lastEta = state.eta;
      if (phase === 'running' && (sizeLine || lastSpeed)) {
        const ico = {
          dl: '<svg viewBox="0 0 24 24"><path d="M12 4v11M7 10l5 5 5-5M5 20h14"/></svg>',
          bolt: '<svg viewBox="0 0 24 24"><path d="M13 2L4 14h7l-1 8 9-12h-7z"/></svg>',
          clock: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>'
        };
        const eta = lastEta > 0 ? formatEta(lastEta) : '--:--';
        $('#spd').innerHTML = `<span class="st">${ico.dl}<span>${sizeLine || ''}</span></span><i class="sep"></i><span class="st spd">${ico.bolt}<b>${lastSpeed || '--'}</b></span><i class="sep"></i><span class="st">${ico.clock}<span>ETA ${eta}</span></span>`;
      }
      show($('#cancel'), !finished); show($('#open'), phase === 'done'); show($('#nv'), finished);
      if (phase === 'done' && !donePulsed) {
        donePulsed = true;
        setTimeout(() => { $('#pbw').classList.add('c1'); }, 100);
        setTimeout(() => { $('#pbw').classList.add('c2'); }, 350);
        setTimeout(() => { $('#pbw').classList.add('c3'); }, 650);
      } else if (phase !== 'done') {
        donePulsed = false;
      }
    } else if (state.kind === 'playlist') {
      renderPlaylistJob(state);
    }
    // Subtitle fallback prompts apply to both single-video and playlist jobs.
    if (state.phase === 'prompt') askSubtitleFallback(state.prompt || 'Subtitles could not be downloaded.');
  }

  function fmtBytes(bytes) {
    const b = Math.max(0, Number(bytes) || 0);
    if (b >= 1073741824) return (b / 1073741824).toFixed(2) + ' GB';
    return (b / 1048576).toFixed(b < 10485760 ? 1 : 0) + ' MB';
  }

  function formatEta(seconds) {
    const value = Math.max(0, Number(seconds) || 0);
    return `${String(Math.floor(value / 60)).padStart(2, '0')}:${String(Math.floor(value % 60)).padStart(2, '0')}`;
  }

  // ================== PLAYLIST ==================
  function goPlaylist(step) {
    show($('#pinsp'), step === 'inspect');
    show($('#pready'), step === 'ready' || step === 'run' || step === 'done');
    show($('#pcfg'), step === 'ready');
    show($('#prun'), step === 'run');
    show($('#pdone'), step === 'done');
  }
  function playlistFormatOptions() {
    return [
      { label: 'Best available', height: 0, sizeText: 'Per video' },
      { label: 'Up to 1080p', height: 1080, sizeText: 'Per video' },
      { label: 'Up to 720p', height: 720, sizeText: 'Per video' },
      { label: 'Up to 480p', height: 480, sizeText: 'Per video' },
      { label: 'Up to 360p', height: 360, sizeText: 'Per video' }
    ];
  }
  function renderPlaylistSubtitleChips() {
    const choices = [ ['en','English'], ['hi','Hindi'], ['mr','Marathi'], ['all','All languages'], ['none','None'] ];
    const host = $('#psubs'); host.innerHTML = '';
    choices.forEach(([code, label], i) => {
      const selected = code === 'none' ? playlistSubs.size === 0 : playlistSubs.has(code);
      host.append(createChip(label, code, selected, i % 2 ? 'var(--ind)' : 'var(--prog)', () => {
        if (code === 'none') playlistSubs.clear();
        else if (code === 'all') {
          if (playlistSubs.has('all')) playlistSubs.delete('all');
          else { playlistSubs.clear(); playlistSubs.add('all'); }
        } else {
          playlistSubs.delete('none');
          playlistSubs.delete('all');
          if (playlistSubs.has(code)) playlistSubs.delete(code); else playlistSubs.add(code);
        }
        Native.setPlaylistSelection(playlistQualityIndex, [...playlistSubs].filter(x => x !== 'none').join(','));
        renderPlaylistSubtitleChips();
      }));
    });
    const note = document.createElement('span'); note.className = 's'; note.style.width = '100%';
    note.textContent = 'Playlist tracks are requested per video; a language may not exist on every item.';
    host.append(note);
  }
  function renderPlaylistInfo(info) {
    playlistInfo = info;
    playlistSubs = new Set(Array.isArray(info.selectedSubs)
      ? info.selectedSubs
      : (settingsState.prefSub === 'none' ? [] : [settingsState.prefSub]));
    playlistQualities = playlistFormatOptions();
    playlistQualityIndex = Math.max(0, Math.min(playlistQualities.length - 1, Number(info.selectedQuality || 0)));
    text($('#ptitle'), `${info.title || 'Playlist'} · ${info.entries.length} videos`);
    buildDropdown($('#pdd'), playlistQualities, playlistQualityIndex, i => {
      playlistQualityIndex = i;
      Native.setPlaylistSelection(playlistQualityIndex, [...playlistSubs].filter(x => x !== 'none').join(','));
    });
    renderPlaylistSubtitleChips();
    renderPlaylistEntries(info.entries, false);
    goPlaylist('ready');
  }
  function ring(cls, pct, label) {
    const w = document.createElement('div');
    w.className = 'rw' + (cls ? ' ' + cls : '');
    w.innerHTML = '<svg viewBox="0 0 36 36"><circle class="bg" cx="18" cy="18" r="14"/><circle class="fg" cx="18" cy="18" r="14" style="stroke-dashoffset:' + (88 * (1 - Math.max(0, Math.min(100, pct)) / 100)) + '"/></svg><span></span>';
    w.querySelector('span').textContent = label;
    return w;
  }
  function renderPlaylistEntries(entries, live) {
    const host = $('#plist'); host.innerHTML = '';
    (entries || []).forEach((entry, index) => {
      const row = document.createElement('div'); row.className = 'li';
      const thumb = document.createElement('div'); thumb.className = 'thumb'; setThumb(thumb, entry.thumb);
      const meta = document.createElement('div'); meta.className = 'm';
      const titleEl = document.createElement('div'); titleEl.className = 't'; titleEl.textContent = entry.title || `Video ${index + 1}`;
      const subEl = document.createElement('div'); subEl.className = 's';
      const st = live ? (entry.status || 'queued') : 'queued';
      subEl.textContent = [entry.duration || 'Video', statusName(st)].filter(Boolean).join(' · ');
      meta.append(titleEl, subEl);
      row.append(thumb, meta);
      if (!live && playlistInfo) {
        const remove = document.createElement('button'); remove.className = 'cx'; remove.title = 'Remove video'; remove.textContent = '✕';
        remove.addEventListener('click', () => Native.removePlaylistEntry(index));
        row.append(remove);
      } else if (live && ['queued', 'run'].includes(st)) {
        const cancel = document.createElement('button'); cancel.className = 'cx'; cancel.title = 'Cancel video'; cancel.textContent = '✕';
        cancel.addEventListener('click', () => Native.cancelPlaylistItem(index)); row.append(cancel);
      }
      const pct = Number(entry.percent || 0);
      row.append(
        st === 'done' ? ring('ok', 100, '✓')
        : st === 'cancel' ? ring('no', 0, '✕')
        : st === 'fail' ? ring('no', 0, '!')
        : st === 'run' ? ring('', pct, Math.round(pct) + '%')
        : ring('', 0, '')
      );
      host.append(row);
    });
    if (!entries || !entries.length) {
      const empty = document.createElement('div'); empty.className = 's'; empty.textContent = 'No playlist entries'; host.append(empty);
    }
  }
  function statusName(status) {
    return ({ queued:'Queued', run:'Downloading', done:'Completed', fail:'Failed', cancel:'Cancelled' })[status] || 'Queued';
  }
  let playlistSig = '', playlistRenderedAt = 0;
  function renderPlaylistJob(state) {
    if (!playlistInfo && !state.items?.length) return;
    const entries = (state.items || []).map(item => ({ ...item }));
    // Rebuilding every row (and reloading thumbnails) on each progress tick is what made playlists stutter.
    const sig = entries.map(i => `${i.title}|${i.status}|${i.thumb}`).join('\n');
    const finished = ['done','failed','cancelled'].includes(state.phase);
    const now = Date.now();
    if (finished || sig !== playlistSig || now - playlistRenderedAt >= 1000) {
      renderPlaylistEntries(entries, true);
      playlistSig = sig; playlistRenderedAt = now;
    }
    const active = entries.filter(item => item.status !== 'cancel').length;
    const done = entries.filter(item => item.status === 'done').length;
    text($('#pcount'), `${done} of ${active} downloaded`);
    $('#pfill').style.width = `${Math.max(0, Math.min(100, Number(state.percent || 0)))}%`;
    if (['done','failed','cancelled'].includes(state.phase)) {
      const failed = entries.filter(item => item.status === 'fail').length;
      const cancelled = entries.filter(item => item.status === 'cancel').length;
      text($('#psum'), state.phase === 'cancelled' ? `Playlist cancelled · ${done} completed` : `Done · ${done} completed${failed ? ` · ${failed} failed` : ''}${cancelled ? ` · ${cancelled} cancelled` : ''}`);
      goPlaylist('done');
    } else {
      goPlaylist('run');
    }
  }

  $('#ppaste').addEventListener('click', () => {
    const url = $('#purl').value.trim();
    if (url) Native.inspectPlaylist(url); else Native.pastePlaylist();
  });
  $('#purl').addEventListener('input', () => show($('#px'), !!$('#purl').value));
  $('#px').addEventListener('click', () => {
    if (currentJob?.kind === 'playlist' && ['running', 'prompt'].includes(currentJob.phase)) return toast('Cancel the active playlist before clearing it.');
    setInput($('#purl'), ''); Native.clearPlaylist(); goPlaylist('idle');
  });
  $('#pgo').addEventListener('click', () => {
    if (!playlistInfo) return toast('Inspect a playlist first.');
    Native.startPlaylist(playlistQualityIndex, [...playlistSubs].filter(x => x !== 'none').join(','));
  });
  $('#pcancel').addEventListener('click', () => Native.cancelPlaylist());
  $('#popen').addEventListener('click', () => Native.openFolder());
  $('#pnew').addEventListener('click', () => {
    playlistInfo = null; playlistSubs.clear(); setInput($('#purl'), ''); Native.newPlaylist(); goPlaylist('idle'); $('#plist').innerHTML = '';
  });

  // ================== HISTORY ==================
  const historyRowCache = new Map();
  function renderHistory(items) {
    historyItems = Array.isArray(items) ? items : [];
    text($('#hc'), historyItems.length ? `${historyItems.length} ${historyItems.length === 1 ? 'item' : 'items'}` : '');
    show($('#hclr'), historyItems.length > 0);
    const host = $('#hist');
    if (!historyItems.length) {
      historyRowCache.clear();
      const empty = document.createElement('h3'); empty.textContent = 'No downloads yet'; host.replaceChildren(empty); return;
    }
    // Reuse row elements whose data is unchanged; only rebuild the rows that changed (e.g. the running download).
    const frag = document.createDocumentFragment();
    const liveIds = new Set();
    historyItems.forEach(record => {
      liveIds.add(record.id);
      const sig = JSON.stringify(record);
      const now = Date.now();
      let entry = historyRowCache.get(record.id);
      const changed = !entry || entry.sig !== sig;
      // Progress ticks for a running download refresh its row at most once a second; status changes apply at once.
      const dueNow = !entry || entry.status !== record.status || record.status !== 'run' || now - entry.at >= 1000;
      if (changed && dueNow) {
        entry = { sig, status: record.status, at: now, row: buildHistoryRow(record) };
        historyRowCache.set(record.id, entry);
      }
      frag.append(entry.row);
    });
    for (const id of [...historyRowCache.keys()]) if (!liveIds.has(id)) historyRowCache.delete(id);
    host.replaceChildren(frag);
  }
  function buildHistoryRow(record) {
      const row = document.createElement('div'); row.className = 'li';
      const thumb = document.createElement('div'); thumb.className = 'thumb'; setThumb(thumb, record.thumb);
      const meta = document.createElement('div'); meta.className = 'm';
      const titleEl = document.createElement('div'); titleEl.className = 't'; titleEl.textContent = record.title || 'Video';
      const sub = document.createElement('div'); sub.className = 's';
      sub.textContent = [record.quality, record.sizeText, record.format].filter(Boolean).join(' · ');
      const actions = document.createElement('div'); actions.className = 'act';
      const ICONS = {
        'Show in folder': '<svg viewBox="0 0 24 24"><path class="fl" d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/></svg>',
        'Copy URL': '<svg viewBox="0 0 24 24"><rect x="8" y="8" width="12" height="12" rx="3"/><path d="M16 8V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h2"/></svg>',
        'Retry / Resume': '<svg viewBox="0 0 24 24"><path d="M20 12a8 8 0 1 1-2.3-5.7"/><path d="M20 4v4h-4"/></svg>',
        'Show error': '<svg viewBox="0 0 24 24"><path class="fl" d="M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zm1 4v6h-2V7zm-1 10a1.2 1.2 0 1 1 0-2.4 1.2 1.2 0 0 1 0 2.4z"/></svg>',
        'Remove record': '<svg viewBox="0 0 24 24"><path d="M4 7h16"/><path d="M9 7V5a1.5 1.5 0 0 1 1.5-1.5h3A1.5 1.5 0 0 1 15 5v2"/><path d="M6 7l1 12a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2l1-12"/></svg>'
      };
      const addAction = (label, action) => {
        const b = document.createElement('button');
        b.className = 'ibtn' + (label === 'Remove record' ? ' danger' : label === 'Retry / Resume' ? ' primary' : '');
        b.innerHTML = ICONS[label] || '';
        if (!ICONS[label]) b.textContent = label;
        b.title = label; b.setAttribute('aria-label', label);
        b.addEventListener('click', action); actions.append(b);
      };
      if (record.status === 'ok') {
        addAction('Show in folder', () => Native.openRecord(record.id));
        addAction('Copy URL', () => Native.copyText(record.url || ''));
      } else if (record.status === 'fail' || record.status === 'cancelled') {
        addAction('Retry / Resume', () => Native.retryHistory(record.id));
        addAction('Show error', () => toast(record.error || 'No error details were saved.'));
      }
      addAction('Remove record', () => ask(record.status === 'ok' ? 'Delete this video from your phone?' : 'Remove this record from history?', [
        { label: 'Delete', action: () => Native.removeHistory(record.id) }, { label: 'Cancel', action: () => {} }
      ]));
      meta.append(titleEl, sub, actions);
      let mark;
      if (record.status === 'ok') mark = ring('ok', 100, '✓');
      else if (record.status === 'run') mark = ring('', Number(record.percent || 0), Math.round(record.percent || 0) + '%');
      else { mark = document.createElement('span'); mark.className = 'pill'; mark.textContent = record.status === 'cancelled' ? 'CANCELLED' : 'FAILED'; }
      row.append(thumb, meta, mark); return row;
  }
  $('#hclr').addEventListener('click', () => ask('Clear all history?', [
    { label: 'Clear history', action: () => Native.clearHistory() }, { label: 'Cancel', action: () => {} }
  ]));


  // ================== DIAGNOSTIC (press and hold) ==================
  // Hold a tab, the Active Bar or Engine panel, or the bottom bar for about 1 second.
  // A text file is saved to Download/Lumo on the phone and its path is shown.
  function attachHold(el, label) {
    if (!el) return;
    let timer = null;
    const cancel = () => clearTimeout(timer);
    el.addEventListener('touchstart', () => { timer = setTimeout(() => runDiagnostic(label), 1000); }, { passive: true });
    el.addEventListener('touchend', cancel);
    el.addEventListener('touchmove', cancel);
    el.addEventListener('touchcancel', cancel);
  }

  function runDiagnostic(label) {
    const rc = getComputedStyle(document.documentElement);
    const R = el => {
      if (!el) return 'missing';
      const r = el.getBoundingClientRect();
      return `left ${r.left.toFixed(1)} top ${r.top.toFixed(1)} w ${r.width.toFixed(1)} h ${r.height.toFixed(1)}`;
    };
    const W = el => el ? `${el.tagName}#${el.id || ''}.${String(el.className && el.className.baseVal !== undefined ? el.className.baseVal : el.className).trim().replace(/\s+/g, '.')}` : 'none';
    const PROPS = ['display', 'visibility', 'opacity', 'color', 'background-color', 'background-image', 'border-top', 'height', 'overflow', 'z-index', 'transform', 'backdrop-filter', 'padding-top', 'padding-bottom', 'box-sizing'];
    const S = el => {
      if (!el) return 'missing';
      const c = getComputedStyle(el);
      return PROPS.map(p => `${p}=${c.getPropertyValue(p)}`).join('; ');
    };
    const hits = (el) => {
      if (!el) return ['missing'];
      const r = el.getBoundingClientRect();
      const pts = [[r.left + r.width / 2, r.top + r.height / 2], [r.left + 4, r.top + 4], [r.right - 4, r.bottom - 4]];
      return pts.map(([x, y]) => `(${Math.round(x)},${Math.round(y)}) -> ` +
        document.elementsFromPoint(x, y).slice(0, 4).map(W).join(' < '));
    };
    const block = (title, el, withHits) => {
      const out = [`[${title}]`, `  element: ${W(el)}`, `  rect: ${R(el)}`, `  style: ${S(el)}`];
      if (withHits) hits(el).forEach(h => out.push(`  hit: ${h}`));
      return out;
    };

    const lines = [
      'LUMO DIAGNOSTIC REPORT',
      `held: ${label}`,
      `time: ${new Date().toString()}`,
      `user agent: ${navigator.userAgent}`,
      `viewport: ${innerWidth} x ${innerHeight} css px, devicePixelRatio ${devicePixelRatio}`,
      `insets css px: top ${rc.getPropertyValue('--sat').trim() || 'unset'}, bottom ${rc.getPropertyValue('--sab').trim() || 'unset'}, left ${rc.getPropertyValue('--sal').trim() || 'unset'}, right ${rc.getPropertyValue('--sar').trim() || 'unset'}`,
      `settings tab index: ${typeof settingsTab !== 'undefined' ? settingsTab : 'unknown'}`,
      `document scrollTop: ${document.scrollingElement ? document.scrollingElement.scrollTop : 'n/a'}`,
      ''
    ];
    const chips = $$('#tabs .chip');
    lines.push(...block('phone', $('#ph')));
    lines.push(...block('settings tab row', $('#tabs'), true));
    chips.forEach((c, i) => lines.push(...block(`tab chip ${i} (${c.textContent})`, c, true)));
    lines.push(...block('Customization panel #tc', $('#tc')));
    lines.push(...block('Customization card', $('#tc .card'), true));
    lines.push(...block('Active Bar swatches #s-ind', $('#s-ind')));
    lines.push(...block('Progress Bar swatches #s-prog', $('#s-prog')));
    lines.push(...block('Engine panel #t4', $('#t4')));
    lines.push(...block('Engine card', $('#t4 .card'), true));
    lines.push(...block('Engine update button #eup', $('#eup')));
    lines.push(...block('Engine status #estat', $('#estat')));
    lines.push(...block('bottom bar nav', $('nav'), true));
    lines.push(...block('bottom pill #npill', $('#npill'), true));
    lines.push(...block('page #pages or first page', document.querySelector('.pages') || document.querySelector('.page'), true));
    const navBtns = document.querySelectorAll('nav > *');
    navBtns.forEach((b, i) => lines.push(...block(`bottom bar item ${i}`, b)));

    const text = lines.join('\n');
    let where;
    try { where = Native.saveDiagnostic(text); } catch (e) { where = 'save failed: ' + e; }
    toast(`Diagnostic saved to ${where}`);
  }

  // ================== SETTINGS ==================
  // Settings layout: three tabs.
  // Downloads = folder, MP4, cookies, preferred subtitles (moved here from the old Subtitles tab).
  // Customization = Active Bar colour and Progress Bar colour (moved here from the two old colour tabs).
  // Engine = unchanged.
  const panelDownloads = $('#t1');
  const panelCustom = document.createElement('div');
  panelCustom.id = 'tc'; panelCustom.className = 'hide';
  const prefCard = $('#t2 .card');
  if (prefCard) { prefCard.style.marginTop = '14px'; panelDownloads.append(prefCard); }
  panelCustom.append($('#t0 .card'), $('#t3 .card'));
  $('#t0').remove(); $('#t2').remove(); $('#t3').remove();
  const panelEngine = $('#t4');
  panelEngine.before(panelCustom);
  panelDownloads.classList.remove('hide');
  const tabNames = ['Downloads', 'Customization', 'Engine'];
  tabNames.forEach((name, index) => {
    const chip = document.createElement('button'); chip.className = 'chip' + (index === 0 ? ' on' : ''); chip.textContent = name;
    chip.insertAdjacentHTML('beforeend', '<span class="ring"></span>');
    chip.addEventListener('click', () => {
      chip.classList.remove('pulse'); void chip.offsetWidth; chip.classList.add('pulse');
      setTimeout(() => chip.classList.remove('pulse'), 700);
      setSettingsTab(index);
    });
    $('#tabs').append(chip);
    attachHold(chip, 'Tab: ' + name);
  });
  requestAnimationFrame(() => { const row = $('#tabs'); void row.offsetWidth; $$('#tabs .chip').forEach(c => void c.offsetWidth); });
  attachHold(panelCustom.querySelector('.card'), 'Customization panel');
  attachHold($('#t4 .card'), 'Engine panel');
  attachHold($('nav'), 'Bottom bar');
  function setSettingsTab(index) {
    settingsTab = index;
    $$('#tabs .chip').forEach((chip, i) => chip.classList.toggle('on', i === index));
    // The glass tab row can stop painting its labels after a switch in some WebViews. Touching layout
    // here makes the browser repaint the row; nothing visible changes.
    const row = $('#tabs'); row.style.transform = 'translateZ(0)'; void row.offsetWidth; row.style.transform = '';
    [panelDownloads, panelCustom, panelEngine].forEach((panel, i) => show(panel, i === index));
  }

  const activePresets = [['Blue','#60A5FA'],['White','#F4F6FB'],['Violet','#8871FF'],['Turquoise','#2DD4BF'],['Amber','#FFB45F'],['Pink','#FF647F']];
  const progressPresets = [['Violet','#8871FF'],['Blue','#4C8DFF'],['Turquoise','#2DD4BF'],['Mint','#55D9A8'],['Amber','#FFB45F'],['Pink','#FF647F']];
  let lastRemove = 0;
  function removeSaved(hex) {
    if (Date.now() - lastRemove < 900) return;
    lastRemove = Date.now(); Native.removeSavedColor(hex);
  }
  function renderSwatches(kind, presets, current, saved) {
    const host = kind === 'ind' ? $('#s-ind') : $('#s-prog');
    const label = kind === 'ind' ? $('#l-ind') : $('#l-prog');
    host.innerHTML = '';
    const all = [...presets, ...(saved || []).map(hex => ['Custom', hex])];
    all.forEach(([name, hex], index) => {
      const b = document.createElement('button'); b.className = 'tile' + (String(hex).toUpperCase() === String(current).toUpperCase() ? ' on' : '');
      b.style.background = hex; b.style.setProperty('--c', hex); b.title = name;
      let pressTimer = 0, longPressed = false;
      b.addEventListener('click', () => { if (longPressed) { longPressed = false; return; } Native.setAccent(kind, hex); });
      if (index >= presets.length) {
        b.addEventListener('contextmenu', e => { e.preventDefault(); removeSaved(hex); });
        b.addEventListener('touchstart', () => { longPressed = false; pressTimer = setTimeout(() => { longPressed = true; removeSaved(hex); }, 600); }, { passive: true });
        ['touchend', 'touchmove', 'touchcancel'].forEach(ev => b.addEventListener(ev, () => clearTimeout(pressTimer), { passive: true }));
      }
      host.append(b);
    });
    const add = document.createElement('button'); add.className = 'plus'; add.textContent = '+';
    add.addEventListener('click', () => {
      if ((saved || []).length >= 5) return toast('Up to 5 saved colours. Long-press one to remove it.');
      openColorSheet(kind);
    });
    host.append(add);
    const selected = all.find(([n, hex]) => String(hex).toUpperCase() === String(current).toUpperCase());
    text(label, `Selected: ${selected?.[0] || 'Custom'}`);
  }

  function hexToHsl(hex) {
    const m = /^#?([0-9a-f]{6})$/i.exec(hex || ''); const n = parseInt(m ? m[1] : '8871FF', 16);
    const r = (n >> 16 & 255) / 255, g = (n >> 8 & 255) / 255, b = (n & 255) / 255;
    const max = Math.max(r, g, b), min = Math.min(r, g, b), l = (max + min) / 2; let h = 0, s = 0;
    if (max !== min) {
      const d = max - min; s = l > .5 ? d / (2 - max - min) : d / (max + min);
      h = max === r ? (g - b) / d + (g < b ? 6 : 0) : max === g ? (b - r) / d + 2 : (r - g) / d + 4; h *= 60;
    }
    return [Math.round(h), Math.round(s * 100), Math.round(l * 100)];
  }
  function hslToHex(h, s, l) {
    s /= 100; l /= 100; const k = n => (n + h / 30) % 12, a = s * Math.min(l, 1 - l);
    const f = n => Math.round(255 * (l - a * Math.max(-1, Math.min(k(n) - 3, Math.min(9 - k(n), 1)))));
    return '#' + [f(0), f(8), f(4)].map(v => v.toString(16).padStart(2, '0')).join('').toUpperCase();
  }
  function openColorSheet(kind) {
    const host = $('#shin'); host.innerHTML = '';
    const title = document.createElement('h3'); title.style.marginBottom = '8px'; title.textContent = 'Custom colour'; host.append(title);
    const hsl = hexToHsl(kind === 'ind' ? settingsState.indHex : settingsState.progHex);
    const prev = document.createElement('div'); prev.style.cssText = 'height:44px;border-radius:13px;margin:6px 0 12px;border:1px solid var(--bd)';
    const hexIn = document.createElement('input'); hexIn.className = 'url'; hexIn.maxLength = 7; hexIn.autocapitalize = 'characters'; hexIn.spellcheck = false; hexIn.style.marginBottom = '10px';
    const sliders = [];
    const paint = () => { const hex = hslToHex(hsl[0], hsl[1], hsl[2]); hexIn.value = hex; prev.style.background = hex; sliders.forEach(([r, i]) => { r.value = hsl[i]; }); };
    host.append(prev, hexIn);
    [['Hue', 0, 360], ['Saturation', 1, 100], ['Lightness', 2, 100]].forEach(([name, i, max]) => {
      const lab = document.createElement('div'); lab.className = 'lbl'; lab.style.margin = '6px 2px 4px'; lab.textContent = name.toUpperCase();
      const r = document.createElement('input'); r.type = 'range'; r.min = 0; r.max = max; r.style.cssText = 'width:100%;accent-color:var(--acc)';
      r.addEventListener('input', () => { hsl[i] = Number(r.value); paint(); });
      sliders.push([r, i]); host.append(lab, r);
    });
    hexIn.addEventListener('input', () => {
      if (/^#[0-9a-f]{6}$/i.test(hexIn.value)) { const v = hexToHsl(hexIn.value); hsl[0] = v[0]; hsl[1] = v[1]; hsl[2] = v[2]; prev.style.background = hexIn.value; sliders.forEach(([r, i]) => { r.value = hsl[i]; }); }
    });
    paint();
    const row = document.createElement('div'); row.className = 'row'; row.style.marginTop = '16px';
    const cancel = document.createElement('button'); cancel.className = 'gh'; cancel.textContent = 'Cancel';
    const save = document.createElement('button'); save.className = 'btn'; save.style.flex = '1'; save.textContent = 'Save colour';
    cancel.addEventListener('click', () => show($('#sheet'), false));
    save.addEventListener('click', () => {
      if (!/^#[0-9a-f]{6}$/i.test(hexIn.value)) return toast('Enter a colour like #3DDC97');
      show($('#sheet'), false); Native.saveAccent(kind, hexIn.value.toUpperCase());
    });
    row.append(cancel, save); host.append(row);
    show($('#sheet'), true);
  }
  function renderPrefs() {
    const phone = $('#ph');
    phone.style.setProperty('--ind', settingsState.indHex || '#FFB45F');
    phone.style.setProperty('--prog', settingsState.progHex || '#8871FF');
    text($('#fpath'), 'Internal storage/' + settingsState.folder);
    $('#mp4').classList.toggle('on', !!settingsState.preferMp4);
    $('#eauto').classList.toggle('on', !!settingsState.autoUpdate);
    text($('#estat'), engineStatusText || (engineReady ? 'Download engine ready' : 'Starting download engine…'));
    text($('#cstat'), settingsState.hasCookies ? 'cookies.txt imported' : 'No file imported');
    $('#cstat').classList.toggle('f', !!settingsState.hasCookies);
    const importBtn = $('#cimp');
    importBtn.title = settingsState.hasCookies ? 'Replace cookies file' : 'Import cookies';
    importBtn.setAttribute('aria-label', importBtn.title);
    show($('#crem'), !!settingsState.hasCookies);
    $('#pref').innerHTML = '';
    [['en','English'],['hi','Hindi'],['mr','Marathi'],['none','None']].forEach(([code,label]) => {
      $('#pref').append(createChip(label, code, settingsState.prefSub === code, code === 'hi' ? 'var(--ind)' : 'var(--prog)', () => Native.setPrefSub(code)));
    });
    renderSwatches('ind', activePresets, settingsState.indHex, settingsState.savedColors);
    renderSwatches('prog', progressPresets, settingsState.progHex, settingsState.savedColors);
  }
  $('#browse').addEventListener('click', () => ask('Choose download folder', [
    { label:'Internal storage/Download/Lumo', action:() => Native.setFolder('Download/Lumo') },
    { label:'Internal storage/Movies/Lumo', action:() => Native.setFolder('Movies/Lumo') },
    { label:'Internal storage/DCIM/Lumo', action:() => Native.setFolder('DCIM/Lumo') },
    { label:'Cancel', action:() => {} }
  ]));
  $('#mp4').addEventListener('click', () => Native.setPreferMp4(!settingsState.preferMp4));
  $('#eauto').addEventListener('click', () => Native.setAutoUpdate(!settingsState.autoUpdate));
  $('#cimp').addEventListener('click', () => Native.pickCookies());
  $('#crem').addEventListener('click', () => Native.removeCookies());
  $('#eup').addEventListener('click', () => { text($('#estat'), 'Updating download engine…'); Native.updateEngine(); });

  // ================== SHEETS & PROMPTS ==================
  function ask(title, options) {
    const host = $('#shin'); host.innerHTML = '';
    const h = document.createElement('h3'); h.style.marginBottom = '8px'; h.textContent = title; host.append(h);
    options.forEach(option => {
      const b = document.createElement('button'); b.className = 'o';
      const span = document.createElement('span'); span.textContent = option.label; b.append(span);
      b.addEventListener('click', () => { show($('#sheet'), false); option.action(); });
      host.append(b);
    });
    show($('#sheet'), true);
  }
  $('#sheet').addEventListener('click', e => {
    if (e.target.id === 'sheet') {
      show($('#sheet'), false);
      if (currentJob?.phase === 'prompt') Native.decideSubtitles('cancel');
    }
  });
  function askSubtitleFallback(message) {
    if ($('#sheet').classList.contains('hide')) {
      ask(message, [
        { label:'Download without subtitles', action:() => Native.decideSubtitles('without') },
        { label:'Cancel download', action:() => Native.decideSubtitles('cancel') }
      ]);
    }
  }

  // Returns true when the page used the Back press; false lets Android leave the app.
  function handleBack() {
    if (!$('#sheet').classList.contains('hide')) {
      show($('#sheet'), false);
      if (currentJob?.phase === 'prompt') Native.decideSubtitles('cancel');
      return true;
    }
    if (activeNav !== 0) { navTo(0); return true; }
    if (!$('#vo').classList.contains('hide')) { Native.backToQuality(); goVideo('quality'); return true; }
    if (!$('#vq').classList.contains('hide')) { videoInfo = null; Native.clearVideo(); goVideo('idle'); return true; }
    if (!$('#pmode').classList.contains('hide') && playlistInfo) {
      if (currentJob?.kind === 'playlist' && ['running', 'prompt'].includes(currentJob.phase)) {
        toast('The playlist is still downloading. Cancel it before leaving this view.');
        return true;
      }
      playlistInfo = null; Native.clearPlaylist(); goPlaylist('idle'); return true;
    }
    return false;
  }

  window.LumoApp = {
    boot(raw) {
      const data = parse(raw);
      settingsState = { ...settingsState, ...(data.settings || {}) };
      engineReady = !!data.engineReady;
      mode(!!data.playlistMode);
      engineStatusText = data.engineStatus || '';
      renderPrefs();
      renderHistory(data.history || []);
      if (data.download) renderDownloadState(data.download);
    },
    onEngine(raw) {
      const data = parse(raw); engineReady = !!data.ready;
      engineStatusText = data.status || (engineReady ? 'Download engine ready' : 'Engine unavailable');
      text($('#estat'), engineStatusText);
    },
    onVideoInspecting(raw) {
      const data = parse(raw); navTo(0); mode(false); setInput($('#url'), data.url || $('#url').value);
      goVideo('inspect');
    },
    onVideoInfo(raw) { renderVideoInfo(parse(raw)); },
    onVideoStep(raw) {
      const step = parse(raw).step;
      goVideo(step === 'options' ? 'options' : step === 'download' ? 'download' : 'quality');
    },
    onVideoError(raw) {
      const data = parse(raw); goVideo('idle');
      toast(data.message || 'Could not inspect this video.');
    },
    onPlaylistInspecting(raw) {
      const data = parse(raw); navTo(0); mode(true); setInput($('#purl'), data.url || $('#purl').value);
      goPlaylist('inspect');
    },
    onPlaylistInfo(raw) { renderPlaylistInfo(parse(raw)); },
    onPlaylistEntryRemoved(raw) {
      const data = parse(raw);
      if (playlistInfo?.entries) {
        playlistInfo.entries.splice(Number(data.index), 1);
        text($('#ptitle'), `${playlistInfo.title || 'Playlist'} · ${playlistInfo.entries.length} videos`);
        renderPlaylistEntries(playlistInfo.entries, false);
      }
    },
    onPlaylistCleared() { playlistInfo = null; goPlaylist('idle'); $('#plist').innerHTML = ''; },
    onPlaylistError(raw) { const data = parse(raw); goPlaylist('idle'); toast(data.message || 'Could not read this playlist.'); },
    onDownloadState(raw) { renderDownloadState(parse(raw)); },
    onHistory(raw) { renderHistory(parse(raw).items || []); },
    onSettings(raw) { settingsState = { ...settingsState, ...parse(raw) }; renderPrefs(); },
    onToast(raw) { const data = parse(raw); toast(data.message || ''); },
    onSystemBack() { return handleBack(); }
  };

  // Initialize the HTML controls without waiting for native state.
  $('#hist').innerHTML = '<h3>No downloads yet</h3>';
  setSettingsTab(0);
  mode(false);
  goVideo('idle');
  goPlaylist('idle');
  renderPrefs();
  if (!Native) toast('Native download bridge is not available.');
})();
