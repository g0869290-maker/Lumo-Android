# Lumo 2.0 for Android

Native Jetpack Compose app. Extract this zip so that settings.gradle.kts, app/ and .github/ sit at the repository root, then push to GitHub. The "Build Lumo Android" workflow builds the debug APK into the run's Artifacts.
