# Lumo 2.1 for Android

Native Jetpack Compose app. Same layout and behaviour as the HTML preview, with real downloads.

## Build on GitHub

1. Put `Lumo_Android_Native_Project.zip` in the root of your repository.
2. Put `build-android.yml` in `.github/workflows/` in the same repository.
3. Push to `main` or `master`, or run "Build Lumo Android" from the Actions tab.
4. Download `Lumo-Android-debug-APK` from the run's Artifacts.

## Screens

- **Download:** Video or Playlist. Paste a link, choose quality (sizes from yt-dlp), pick subtitles and MP4 or MKV, then watch real progress with speed and ETA.
- **History:** every download, with Show in folder, Copy URL, Retry / Resume, Show error and Remove record.
- **Settings:** Active Bar colour, download folder, MP4 preference, preferred subtitles, progress bar colour, and engine update.

## Behaviour notes

- Playlists download one video at a time, so each video has its own real progress, and you can cancel a single video.
- If YouTube refuses subtitles during a download, Lumo asks whether to continue without them.
- Sizes use exact sizes when yt-dlp reports them, otherwise bitrate × duration.
- Finished files are saved to the folder you choose in Settings, using MediaStore on Android 10 and newer.
