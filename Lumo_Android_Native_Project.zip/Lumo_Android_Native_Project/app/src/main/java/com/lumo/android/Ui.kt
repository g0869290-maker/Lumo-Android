package com.lumo.android

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

@Composable
fun Label(text: String) {
    Text(
        text,
        color = C.Muted,
        fontSize = 10.5.sp,
        letterSpacing = 1.sp,
        modifier = Modifier.padding(start = 2.dp, top = 12.dp, bottom = 2.dp)
    )
}

@Composable
fun LCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(C.Card)
            .border(1.dp, C.Line, RoundedCornerShape(18.dp))
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        content = content
    )
}

@Composable
fun LChip(label: String, on: Boolean, tint: Color, enabled: Boolean = true, onClick: () -> Unit) {
    val bg = if (on) lerp(C.Alt, tint, 0.2f) else C.Alt
    val bd = if (on) lerp(C.Line, tint, 0.55f) else C.Line
    Column(
        Modifier
            .clip(RoundedCornerShape(13.dp))
            .background(bg)
            .border(1.dp, bd, RoundedCornerShape(13.dp))
            .alpha(if (enabled) 1f else 0.35f)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            (if (on) "✓  " else "") + label,
            color = if (on) C.Ink else C.Muted,
            fontSize = 12.5.sp
        )
        if (on) {
            Box(
                Modifier
                    .padding(top = 5.dp)
                    .fillMaxWidth(0.8f)
                    .height(3.dp)
                    .clip(RoundedCornerShape(3.dp))
                    .background(Palette.ind)
            )
        }
    }
}

@Composable
fun PrimaryButton(text: String, modifier: Modifier = Modifier, enabled: Boolean = true, onClick: () -> Unit) {
    Box(
        modifier
            .height(50.dp)
            .clip(RoundedCornerShape(15.dp))
            .background(Brush.linearGradient(listOf(C.Acc, lerp(C.Acc, Color.Black, 0.35f))))
            .alpha(if (enabled) 1f else 0.4f)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 18.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1)
    }
}

@Composable
fun GhostButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier
            .height(44.dp)
            .clip(RoundedCornerShape(13.dp))
            .background(C.Alt)
            .border(1.dp, C.Line, RoundedCornerShape(13.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = C.Ink, fontSize = 13.sp, maxLines = 1)
    }
}

@Composable
fun SmallAction(text: String, onClick: () -> Unit) {
    Box(
        Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(C.Alt)
            .clickable(onClick = onClick)
            .padding(horizontal = 9.dp, vertical = 6.dp)
    ) {
        Text(text, color = C.Muted, fontSize = 10.5.sp, maxLines = 1)
    }
}

/** Glowing bar with an animated sweep. Pass indeterminate = true while waiting. */
@Composable
fun GlowBar(progress: Float, modifier: Modifier = Modifier, indeterminate: Boolean = false, height: Dp = 12.dp) {
    val shape = RoundedCornerShape(99.dp)
    val fill = Brush.horizontalGradient(listOf(Palette.prog, lerp(Palette.prog, Color.White, 0.38f)))
    Box(
        modifier
            .fillMaxWidth()
            .height(height)
            .clip(shape)
            .background(C.Alt)
            .border(1.dp, C.Line, shape)
    ) {
        if (indeterminate) {
            val t by rememberInfiniteTransition(label = "sweep").animateFloat(
                initialValue = 0f,
                targetValue = 1f,
                animationSpec = infiniteRepeatable(tween(1300), RepeatMode.Reverse),
                label = "sweep-x"
            )
            val lead: Float = (t * 0.66f).coerceIn(0.0001f, 0.66f)
            val rest: Float = (0.66f - lead).coerceAtLeast(0.0001f)
            androidx.compose.foundation.layout.Row(Modifier.fillMaxSize()) {
                Spacer(Modifier.weight(lead))
                Box(Modifier.weight(0.34f).fillMaxHeight().clip(shape).background(fill))
                Spacer(Modifier.weight(rest))
            }
        } else {
            Box(
                Modifier
                    .fillMaxWidth(progress.coerceIn(0f, 1f))
                    .fillMaxHeight()
                    .clip(shape)
                    .background(fill)
            )
        }
    }
}

/** Circular percentage ring, or a tick / cross when finished. tone: run, ok or no. */
@Composable
fun Ring(progress: Float, tone: String, label: String) {
    val track = Color(0xFF262935)
    val arc = when (tone) {
        "ok" -> C.Ok
        "no" -> C.Dim
        else -> Palette.prog
    }
    val labelColor = when (tone) {
        "ok" -> C.Ok
        "no" -> C.Muted
        else -> C.Ink
    }
    Box(Modifier.size(36.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(36.dp)) {
            val stroke = 3.6.dp.toPx()
            val r = (size.minDimension - stroke) / 2f
            val topLeft = Offset(stroke / 2f, stroke / 2f)
            val box = Size(r * 2f, r * 2f)
            drawArc(track, startAngle = 0f, sweepAngle = 360f, useCenter = false, topLeft = topLeft, size = box, style = Stroke(stroke))
            val sweep = if (tone == "run") 360f * progress.coerceIn(0f, 1f) else 360f
            if (sweep > 0.5f) {
                drawArc(arc, startAngle = -90f, sweepAngle = sweep, useCenter = false, topLeft = topLeft, size = box, style = Stroke(stroke, cap = StrokeCap.Round))
            }
        }
        if (label.isNotEmpty()) {
            Text(label, color = labelColor, fontWeight = FontWeight.Bold, fontSize = if (tone == "run") 9.5.sp else 14.sp)
        }
    }
}

@Composable
fun StatusMark(status: String, percent: Float) {
    when (status) {
        "done", "ok" -> Ring(1f, "ok", "✓")
        "fail", "failed" -> Pill("FAILED", C.Bad)
        "cancel", "cancelled" -> Ring(1f, "no", "✕")
        "run" -> Ring(percent / 100f, "run", "${percent.roundToInt()}%")
        else -> Ring(0f, "run", "")
    }
}

@Composable
fun Pill(text: String, color: Color) {
    Box(
        Modifier
            .clip(RoundedCornerShape(99.dp))
            .background(C.Alt)
            .border(1.dp, color.copy(alpha = 0.45f), RoundedCornerShape(99.dp))
            .padding(horizontal = 8.dp, vertical = 5.dp)
    ) {
        Text(text, color = color, fontSize = 9.5.sp, letterSpacing = 0.6.sp, maxLines = 1)
    }
}

/** Icon drawn with paths, so no icon font or asset is needed. Kinds: film, list, down, clock, gear. */
@Composable
fun Glyph(kind: String, color: Color, size: Dp = 22.dp) {
    Canvas(Modifier.size(size)) {
        val s = this.size.width / 24f
        val stroke = Stroke(width = 1.9f * s, cap = StrokeCap.Round, join = StrokeJoin.Round)
        fun p(x: Float, y: Float) = Offset(x * s, y * s)
        when (kind) {
            "film" -> {
                drawRoundRect(color, topLeft = p(3f, 5f), size = Size(18f * s, 14f * s), cornerRadius = androidx.compose.ui.geometry.CornerRadius(3f * s), style = stroke)
                val tri = Path().apply {
                    moveTo(10f * s, 9.5f * s)
                    lineTo(10f * s, 14.5f * s)
                    lineTo(14.5f * s, 12f * s)
                    close()
                }
                drawPath(tri, color, style = stroke)
            }
            "list" -> {
                drawLine(color, p(3f, 7f), p(16f, 7f), strokeWidth = 1.9f * s, cap = StrokeCap.Round)
                drawLine(color, p(3f, 12f), p(16f, 12f), strokeWidth = 1.9f * s, cap = StrokeCap.Round)
                drawLine(color, p(3f, 17f), p(10f, 17f), strokeWidth = 1.9f * s, cap = StrokeCap.Round)
                val tri = Path().apply {
                    moveTo(17f * s, 14f * s)
                    lineTo(21f * s, 11.5f * s)
                    lineTo(17f * s, 9f * s)
                    close()
                }
                drawPath(tri, color, style = stroke)
            }
            "down" -> {
                drawLine(color, p(12f, 4f), p(12f, 15f), strokeWidth = 1.9f * s, cap = StrokeCap.Round)
                drawLine(color, p(12f, 15f), p(8f, 11f), strokeWidth = 1.9f * s, cap = StrokeCap.Round)
                drawLine(color, p(12f, 15f), p(16f, 11f), strokeWidth = 1.9f * s, cap = StrokeCap.Round)
                drawLine(color, p(5f, 20f), p(19f, 20f), strokeWidth = 1.9f * s, cap = StrokeCap.Round)
            }
            "clock" -> {
                drawCircle(color, radius = 8f * s, center = p(12f, 12f), style = stroke)
                drawLine(color, p(12f, 8f), p(12f, 12f), strokeWidth = 1.9f * s, cap = StrokeCap.Round)
                drawLine(color, p(12f, 12f), p(15f, 14f), strokeWidth = 1.9f * s, cap = StrokeCap.Round)
            }
            "gear" -> {
                drawCircle(color, radius = 3f * s, center = p(12f, 12f), style = stroke)
                for (k in 0 until 8) {
                    val a = k * Math.PI / 4.0
                    val x1 = 12f + 6.5f * cos(a).toFloat()
                    val y1 = 12f + 6.5f * sin(a).toFloat()
                    val x2 = 12f + 9.5f * cos(a).toFloat()
                    val y2 = 12f + 9.5f * sin(a).toFloat()
                    drawLine(color, p(x1, y1), p(x2, y2), strokeWidth = 1.9f * s, cap = StrokeCap.Round)
                }
            }
        }
    }
}

@Composable
fun SegButton(label: String, glyph: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier
            .clip(RoundedCornerShape(16.dp))
            .background(if (selected) lerp(C.Card, C.Acc, 0.14f) else C.Card)
            .border(1.dp, if (selected) lerp(C.Line, C.Acc, 0.45f) else C.Line, RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Glyph(glyph, if (selected) C.Ink else C.Muted, 19.dp)
            Spacer(Modifier.width(8.dp))
            Text(label, color = if (selected) C.Ink else C.Muted, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        }
        Box(
            Modifier
                .padding(top = 8.dp)
                .fillMaxWidth(0.6f)
                .height(4.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(if (selected) Palette.ind else Color.Transparent)
        )
    }
}

/** Dropdown that opens inline. options are (label, sub-label) pairs. */
@Composable
fun Dropdown(options: List<Pair<String, String>>, selected: Int, onSelect: (Int) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxWidth()) {
        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(C.Alt)
                .border(1.dp, C.Line, RoundedCornerShape(14.dp))
                .clickable { open = !open }
                .padding(horizontal = 14.dp, vertical = 13.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(options.getOrNull(selected)?.first.orEmpty(), color = C.Ink, fontSize = 13.5.sp, modifier = Modifier.weight(1f))
            Text("▾", color = C.Muted, fontSize = 13.sp)
        }
        if (open) {
            Column(
                Modifier
                    .padding(top = 6.dp)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0xFF14151C))
                    .border(1.dp, C.Line, RoundedCornerShape(14.dp))
                    .padding(6.dp)
            ) {
                options.forEachIndexed { i, o ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (i == selected) lerp(C.Card, C.Acc, 0.18f) else Color.Transparent)
                            .clickable {
                                onSelect(i)
                                open = false
                            }
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(o.first, color = C.Ink, fontSize = 13.sp, modifier = Modifier.weight(1f))
                        Text(o.second, color = C.Muted, fontSize = 11.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun LSwitch(on: Boolean, onToggle: () -> Unit) {
    val x by animateDpAsState(targetValue = if (on) 19.dp else 3.dp, label = "switch")
    Box(
        Modifier
            .width(44.dp)
            .height(25.dp)
            .clip(RoundedCornerShape(99.dp))
            .background(if (on) C.Acc else Color(0xFF2A2E3B))
            .clickable(onClick = onToggle)
    ) {
        Box(
            Modifier
                .offset(x = x, y = 3.dp)
                .size(19.dp)
                .clip(CircleShape)
                .background(Color.White)
        )
    }
}

/** Remote image with a gradient placeholder while loading or when the URL is blank. */
@Composable
fun Thumb(url: String, modifier: Modifier = Modifier, corner: Dp = 12.dp) {
    val bitmap by produceState<ImageBitmap?>(initialValue = null, key1 = url) {
        value = if (url.isBlank()) null else withContext(Dispatchers.IO) { ImageCache.load(url)?.asImageBitmap() }
    }
    Box(
        modifier
            .clip(RoundedCornerShape(corner))
            .background(Brush.linearGradient(listOf(Color(0xFF1D1A3A), C.Violet, C.Acc))),
        contentAlignment = Alignment.Center
    ) {
        val b = bitmap
        if (b != null) {
            Image(
                bitmap = b,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        }
    }
}

/** Text field look used by the URL bar. */
@Composable
fun UrlBar(text: String, filled: Boolean, showClear: Boolean, onClear: () -> Unit, onPaste: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Box(
            Modifier
                .weight(1f)
                .clip(RoundedCornerShape(14.dp))
                .background(Color(0xFF08090C))
                .border(1.dp, C.Line, RoundedCornerShape(14.dp))
                .padding(
                    start = 12.dp,
                    end = if (showClear) 40.dp else 12.dp,
                    top = 13.dp,
                    bottom = 13.dp
                )
        ) {
            Text(
                text,
                color = if (filled) C.Ink else C.Muted,
                fontSize = 13.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            if (showClear) {
                Box(
                    Modifier
                        .align(Alignment.CenterEnd)
                        .size(28.dp)
                        .clip(CircleShape)
                        .clickable(onClick = onClear),
                    contentAlignment = Alignment.Center
                ) {
                    Text("✕", color = C.Muted, fontSize = 13.sp)
                }
            }
        }
        PrimaryButton("Paste", onClick = onPaste)
    }
}

private data class SwatchTile(val hex: String, val custom: Boolean, val plus: Boolean)

/** Colour swatches. Presets come first, then saved custom colours, then a "+" tile. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Swatches(
    presets: List<Pair<String, String>>,
    current: String,
    saved: List<String>,
    onPick: (String) -> Unit,
    onAdd: () -> Unit,
    onRemove: (String) -> Unit
) {
    val tiles = presets.map { SwatchTile(it.second, false, false) } +
        saved.map { SwatchTile(it, true, false) } +
        SwatchTile("", false, true)

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        tiles.chunked(6).forEach { chunk ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                chunk.forEach { t: SwatchTile ->
                    val selected = !t.plus && t.hex.equals(current, ignoreCase = true)
                    Box(
                        Modifier
                            .size(44.dp)
                            .clip(RoundedCornerShape(13.dp))
                            .background(if (t.plus) C.Alt else Color(android.graphics.Color.parseColor(t.hex)))
                            .border(
                                if (selected) 2.dp else 1.dp,
                                if (selected) Color.White else C.Line,
                                RoundedCornerShape(13.dp)
                            )
                            .combinedClickable(
                                onClick = { if (t.plus) onAdd() else onPick(t.hex) },
                                onLongClick = if (t.custom) ({ onRemove(t.hex) }) else null
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        when {
                            t.plus -> Text("+", color = C.Ink, fontSize = 24.sp, fontWeight = FontWeight.Light)
                            selected -> Text("✓", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

/** A wrapping row of text on the surface, used for small captions. */
@Composable
fun Caption(text: String) {
    Text(text, color = C.Muted, fontSize = 11.5.sp)
}
