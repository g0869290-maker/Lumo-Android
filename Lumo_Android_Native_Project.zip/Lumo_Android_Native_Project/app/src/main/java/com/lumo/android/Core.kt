package com.lumo.android

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.roundToInt

object C {
    val Bg = Color(0xFF000000)
    val Card = Color(0xFF0E0F14)
    val Alt = Color(0xFF171920)
    val Line = Color(0xFF242732)
    val Ink = Color(0xFFF4F6FB)
    val Muted = Color(0xFF8E97A8)
    val Acc = Color(0xFFFF647F)
    val Violet = Color(0xFF8871FF)
    val Amber = Color(0xFFFFB45F)
    val Teal = Color(0xFF2DD4BF)
    val Ok = Color(0xFF55D9A8)
    val Bad = Color(0xFFFF647F)
    val Dim = Color(0xFF3A3E4B)
}

/** Live accent colours. Compose reads these, so changing them repaints the app. */
object Palette {
    var prog by mutableStateOf(C.Violet)
    var ind by mutableStateOf(C.Amber)
}

fun hexColor(hex: String, fallback: Color): Color = try {
    Color(android.graphics.Color.parseColor(hex))
} catch (_: Exception) {
    fallback
}

fun isHttpUrl(s: String): Boolean =
    (s.startsWith("http://") || s.startsWith("https://")) && s.length > 10 && !s.contains(' ')

fun formatDuration(seconds: Long): String {
    val h = seconds / 3600
    val m = (seconds % 3600) / 60
    val s = seconds % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
}

data class QualityOpt(val label: String, val height: Int, val sizeText: String)

data class VideoInfo(
    val url: String,
    val title: String,
    val extractor: String,
    val duration: String,
    val thumb: String,
    val sizesMb: Map<Int, Double>,
    val mp4Heights: Set<Int>,
    val subCodes: Set<String>
)

data class PlaylistEntry(val url: String, val title: String, val duration: String, val thumb: String)

data class PlaylistInfo(
    val url: String,
    val title: String,
    val entries: List<PlaylistEntry>
)

data class HistoryRecord(
    val id: String,
    val title: String,
    val url: String,
    val thumb: String,
    val quality: String,
    val sizeText: String,
    val format: String,
    val status: String,        // ok, run, fail, cancelled
    val percent: Float,
    val error: String,
    val uri: String,
    val path: String,
    val folder: String,
    val time: Long,
    val formatSel: String,
    val container: String,
    val subs: String
)

object Quality {
    fun options(sizes: Map<Int, Double>, playlist: Boolean): List<QualityOpt> {
        if (playlist) {
            return listOf(
                QualityOpt("Best available", 0, "Size varies"),
                QualityOpt("1080p", 1080, "Size varies"),
                QualityOpt("720p", 720, "Size varies"),
                QualityOpt("480p", 480, "Size varies"),
                QualityOpt("360p", 360, "Size varies")
            )
        }
        val heights = sizes.keys.filter { it in 1..2160 }.sortedDescending()
        val fallback = if (heights.isEmpty()) listOf(1080, 720, 480, 360) else heights
        val best = sizes.values.filter { it > 0.0 }.maxOrNull()
        val out = mutableListOf(
            QualityOpt("Best available", 0, if (best != null) "~${best.roundToInt()} MB" else "Auto")
        )
        for (h in fallback) {
            val mb = sizes[h] ?: 0.0
            out.add(QualityOpt("${h}p", h, if (mb > 0.0) "~${mb.roundToInt()} MB" else "Available"))
        }
        return out
    }

    fun selector(height: Int, container: String, mp4Heights: Set<Int>): String = when {
        height <= 0 && container == "mp4" ->
            "bestvideo[ext=mp4]+bestaudio[ext=m4a]/bestvideo+bestaudio/best[ext=mp4]/best"
        height <= 0 -> "bestvideo+bestaudio/best"
        container == "mp4" && height in mp4Heights ->
            "bestvideo[height=$height][ext=mp4]+bestaudio[ext=m4a]/bestvideo[height<=$height][ext=mp4]+bestaudio[ext=m4a]/bestvideo[height<=$height]+bestaudio/best[height<=$height]/best"
        else ->
            "bestvideo[height=$height]+bestaudio/bestvideo[height<=$height]+bestaudio/best[height<=$height]/best"
    }
}

object HistoryStore {
    private lateinit var sp: SharedPreferences
    private val _items = MutableStateFlow<List<HistoryRecord>>(emptyList())
    val items: StateFlow<List<HistoryRecord>> = _items.asStateFlow()

    fun init(context: Context) {
        sp = context.applicationContext.getSharedPreferences("lumo_history", Context.MODE_PRIVATE)
        // A download that was running when the app died cannot resume in place, so mark it failed.
        val list = read().map {
            if (it.status == "run") it.copy(status = "fail", error = "Lumo closed before this download finished.") else it
        }
        _items.value = list
        persist(list)
    }

    fun get(id: String): HistoryRecord? = _items.value.firstOrNull { it.id == id }

    /** Adds or replaces a record and saves it. */
    fun save(rec: HistoryRecord) {
        val list = (listOf(rec) + _items.value.filter { it.id != rec.id }).take(100)
        _items.value = list
        persist(list)
    }

    /** Updates progress in memory only, so the list repaints without writing storage every tick. */
    fun live(id: String, percent: Float) {
        _items.value = _items.value.map { if (it.id == id) it.copy(percent = percent) else it }
    }

    fun remove(id: String) {
        val list = _items.value.filter { it.id != id }
        _items.value = list
        persist(list)
    }

    fun clear() {
        _items.value = emptyList()
        persist(emptyList())
    }

    private fun read(): List<HistoryRecord> {
        val arr = try { JSONArray(sp.getString("items", "[]")) } catch (_: Exception) { JSONArray() }
        val out = mutableListOf<HistoryRecord>()
        for (i in 0 until arr.length()) {
            arr.optJSONObject(i)?.let { out.add(fromJson(it)) }
        }
        return out
    }

    private fun persist(list: List<HistoryRecord>) {
        val arr = JSONArray()
        list.forEach { arr.put(toJson(it)) }
        sp.edit().putString("items", arr.toString()).apply()
    }

    private fun toJson(r: HistoryRecord): JSONObject = JSONObject()
        .put("id", r.id)
        .put("title", r.title)
        .put("url", r.url)
        .put("thumb", r.thumb)
        .put("quality", r.quality)
        .put("size", r.sizeText)
        .put("format", r.format)
        .put("status", r.status)
        .put("percent", r.percent.toDouble())
        .put("error", r.error)
        .put("uri", r.uri)
        .put("path", r.path)
        .put("folder", r.folder)
        .put("time", r.time)
        .put("formatSel", r.formatSel)
        .put("container", r.container)
        .put("subs", r.subs)

    private fun fromJson(o: JSONObject): HistoryRecord = HistoryRecord(
        id = o.optString("id"),
        title = o.optString("title"),
        url = o.optString("url"),
        thumb = o.optString("thumb"),
        quality = o.optString("quality"),
        sizeText = o.optString("size"),
        format = o.optString("format"),
        status = o.optString("status", "fail"),
        percent = o.optDouble("percent", 0.0).toFloat(),
        error = o.optString("error"),
        uri = o.optString("uri"),
        path = o.optString("path"),
        folder = o.optString("folder"),
        time = o.optLong("time", 0L),
        formatSel = o.optString("formatSel"),
        container = o.optString("container", "mp4"),
        subs = o.optString("subs")
    )
}

object Prefs {
    private lateinit var sp: SharedPreferences

    fun init(context: Context) {
        sp = context.applicationContext.getSharedPreferences("lumo_settings", Context.MODE_PRIVATE)
        Palette.prog = hexColor(progHex(), C.Violet)
        Palette.ind = hexColor(indHex(), C.Amber)
    }

    var autoUpdate: Boolean
        get() = sp.getBoolean("auto_update", false)
        set(v) { sp.edit().putBoolean("auto_update", v).apply() }

    var preferMp4: Boolean
        get() = sp.getBoolean("prefer_mp4", true)
        set(v) { sp.edit().putBoolean("prefer_mp4", v).apply() }

    /** Folder relative to the shared storage root, e.g. "Download/Lumo". */
    var folder: String
        get() = sp.getString("folder", "Download/Lumo") ?: "Download/Lumo"
        set(v) { sp.edit().putString("folder", v).apply() }

    var prefSub: String
        get() = sp.getString("pref_sub", "en") ?: "en"
        set(v) { sp.edit().putString("pref_sub", v).apply() }

    fun indHex(): String = sp.getString("ind", "#FFB45F") ?: "#FFB45F"
    fun progHex(): String = sp.getString("prog", "#8871FF") ?: "#8871FF"

    fun setInd(hex: String) {
        sp.edit().putString("ind", hex).apply()
        Palette.ind = hexColor(hex, C.Amber)
    }

    fun setProg(hex: String) {
        sp.edit().putString("prog", hex).apply()
        Palette.prog = hexColor(hex, C.Violet)
    }

    fun savedColors(): List<String> =
        (sp.getString("saved", "") ?: "").split(",").filter { it.isNotBlank() }

    fun saveColors(list: List<String>) {
        sp.edit().putString("saved", list.joinToString(",")).apply()
    }
}

object ImageCache {
    private val cache = object : android.util.LruCache<String, Bitmap>(40) {}

    fun load(url: String): Bitmap? {
        cache.get(url)?.let { return it }
        return try {
            val conn = URL(url).openConnection() as HttpURLConnection
            conn.connectTimeout = 8000
            conn.readTimeout = 8000
            conn.instanceFollowRedirects = true
            conn.setRequestProperty(
                "User-Agent",
                "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/124.0 Mobile Safari/537.36"
            )
            val bmp = conn.inputStream.use { BitmapFactory.decodeStream(it) }
            if (bmp != null) cache.put(url, bmp)
            bmp
        } catch (_: Exception) {
            null
        }
    }
}
