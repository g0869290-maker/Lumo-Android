package com.lumo.android

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.IBinder
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import androidx.core.app.NotificationCompat
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.Executors
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

data class ItemState(
    val title: String = "",
    val thumb: String = "",
    val duration: String = "",
    val status: String = "queued",   // queued, run, done, fail, cancel
    val percent: Float = 0f,
    val error: String = ""
)

data class JobState(
    val jobId: String = "",
    val kind: String = "video",
    val items: List<ItemState> = emptyList(),
    val phase: String = "idle",      // idle, running, prompt, done, cancelled, failed
    val percent: Float = 0f,
    val speed: String = "",
    val eta: Int = 0,
    val message: String = "",
    val folder: String = "",
    val prompt: String = "",
    val lastUri: String = "",
    val lastPath: String = ""
)

/** Shared download state. The service writes it, the UI reads it. */
object DownloadBus {
    val state = MutableStateFlow(JobState())

    fun update(block: (JobState) -> JobState) {
        state.value = block(state.value)
    }

    fun setItem(index: Int, block: (ItemState) -> ItemState) {
        update { s -> s.copy(items = s.items.mapIndexed { i, it -> if (i == index) block(it) else it }) }
    }
}

class DownloadService : Service() {
    private val executor = Executors.newSingleThreadExecutor()
    private val busy = AtomicBoolean(false)
    private val decisions = LinkedBlockingQueue<String>()
    private val notifId = 701

    @Volatile private var cancelAll = false
    @Volatile private var cancelIndex = -1
    @Volatile private var currentPid = ""
    @Volatile private var currentRecordId = ""
    @Volatile private var jobId = ""
    @Volatile private var lastNotify = 0L

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                val payload = intent.getStringExtra(EXTRA_PAYLOAD).orEmpty()
                startForeground(notifId, notification("Starting download…", 0, true))
                if (busy.compareAndSet(false, true)) {
                    executor.execute { runJob(payload) }
                }
            }
            ACTION_CANCEL -> handleCancel(intent.getIntExtra(EXTRA_INDEX, -1))
            ACTION_DECIDE -> decisions.offer(intent.getStringExtra(EXTRA_CHOICE).orEmpty())
        }
        return START_NOT_STICKY
    }

    private fun handleCancel(index: Int) {
        if (index < 0) {
            cancelAll = true
            decisions.offer("cancel")
            killCurrent()
            return
        }
        when (DownloadBus.state.value.items.getOrNull(index)?.status) {
            "run" -> {
                cancelIndex = index
                decisions.offer("cancel")
                killCurrent()
            }
            "queued" -> DownloadBus.setItem(index) { it.copy(status = "cancel") }
            else -> Unit
        }
    }

    private fun killCurrent() {
        val pid = currentPid
        if (pid.isBlank()) return
        try {
            YoutubeDL.getInstance().destroyProcessById(pid)
        } catch (_: Exception) {
            // Process already finished.
        }
    }

    private fun runJob(p: JSONObject) {
        jobId = p.optString("jobId", "job")
        cancelAll = false
        cancelIndex = -1
        currentPid = ""

        val kind = p.optString("kind", "video")
        val format = p.optString("format", "bestvideo+bestaudio/best")
        val want = p.optString("container", "mp4")
        val subs = p.optString("subs", "")
        val folder = p.optString("folder", "Download/Lumo")
        val quality = p.optString("quality", "")
        val arr = p.optJSONArray("items") ?: JSONArray()
        val reqs = (0 until arr.length()).mapNotNull { arr.optJSONObject(it) }
        val work = workFolder()

        DownloadBus.state.value = JobState(
            jobId = jobId,
            kind = kind,
            items = reqs.map {
                ItemState(title = it.optString("title"), thumb = it.optString("thumb"), duration = it.optString("duration"))
            },
            phase = "running",
            folder = folder,
            message = "Starting…"
        )

        var ok = 0
        var failed = 0
        try {
            if (!YtEngine.ready) throw IllegalStateException("Download engine is not ready")
            for ((i, req) in reqs.withIndex()) {
                if (cancelAll || DownloadBus.state.value.items[i].status == "cancel") {
                    DownloadBus.setItem(i) { it.copy(status = "cancel") }
                    continue
                }
                val id = req.optString("recordId").ifBlank { "$jobId-$i" }
                val container = if (subs.isNotBlank()) "mkv" else want
                val base = HistoryRecord(
                    id = id,
                    title = req.optString("title"),
                    url = req.optString("url"),
                    thumb = req.optString("thumb"),
                    quality = quality,
                    sizeText = req.optString("size"),
                    format = if (container == "mkv") "MKV" else "MP4",
                    status = "run",
                    percent = 0f,
                    error = "",
                    uri = "",
                    path = "",
                    folder = folder,
                    time = System.currentTimeMillis(),
                    formatSel = format,
                    container = want,
                    subs = subs
                )
                HistoryStore.save(base)
                currentRecordId = id
                DownloadBus.setItem(i) { it.copy(status = "run", percent = 0f) }
                DownloadBus.update { it.copy(message = "Downloading ${req.optString("title")}…") }

                when (val out = downloadOne(i, req.optString("url"), format, want, subs, work, folder)) {
                    is Outcome.Done -> {
                        ok++
                        HistoryStore.save(base.copy(status = "ok", percent = 100f, uri = out.uri, path = out.path))
                        DownloadBus.setItem(i) { it.copy(status = "done", percent = 100f) }
                        DownloadBus.update { it.copy(lastUri = out.uri, lastPath = out.path) }
                    }
                    is Outcome.Failed -> {
                        failed++
                        HistoryStore.save(base.copy(status = "fail", error = out.message))
                        DownloadBus.setItem(i) { it.copy(status = "fail", error = out.message) }
                    }
                    is Outcome.Cancelled -> {
                        HistoryStore.save(base.copy(status = "cancelled"))
                        DownloadBus.setItem(i) { it.copy(status = "cancel") }
                        if (cancelIndex == i) cancelIndex = -1
                    }
                }
            }
        } catch (e: Exception) {
            failed++
            DownloadBus.update { it.copy(message = "Failed: ${e.message ?: "unknown error"}") }
        } finally {
            val phase = when {
                cancelAll -> "cancelled"
                failed > 0 && ok == 0 -> "failed"
                else -> "done"
            }
            val summary = when (phase) {
                "cancelled" -> "Download cancelled"
                "failed" -> DownloadBus.state.value.message.ifBlank { "Download failed" }
                else -> if (ok == 1 && kind == "video") "Download completed · saved to $folder"
                else "$ok downloads completed · saved to $folder"
            }
            DownloadBus.update {
                it.copy(phase = phase, percent = if (phase == "done") 100f else it.percent, speed = "", eta = 0, prompt = "", message = summary)
            }
            currentPid = ""
            currentRecordId = ""
            busy.set(false)
            getSystemService(NotificationManager::class.java).notify(notifId, notification(summary, 100, false))
            stopForeground(STOP_FOREGROUND_DETACH)
            stopSelf()
        }
    }

    private sealed class Outcome {
        object Cancelled : Outcome()
        class Failed(val message: String) : Outcome()
        class Done(val uri: String, val path: String) : Outcome()
    }

    private fun downloadOne(
        i: Int,
        url: String,
        format: String,
        want: String,
        subsIn: String,
        work: File,
        folder: String
    ): Outcome {
        var subs = subsIn
        val before = work.listFiles()?.map { it.name }?.toSet().orEmpty()
        while (true) {
            val container = if (subs.isNotBlank()) "mkv" else want
            try {
                runYtDlp(i, url, format, container, subs, work)
                break
            } catch (e: Exception) {
                if (cancelAll || cancelIndex == i) return Outcome.Cancelled
                val msg = e.message.orEmpty()
                if (subs.isNotBlank() && isSubtitleFailure(msg)) {
                    decisions.clear()
                    DownloadBus.update { it.copy(phase = "prompt", prompt = "Subtitles failed. Download without them?") }
                    val choice = decisions.poll(10, TimeUnit.MINUTES)
                    DownloadBus.update { it.copy(phase = "running", prompt = "") }
                    if (choice == "without") {
                        subs = ""
                        continue
                    }
                    return Outcome.Cancelled
                }
                return Outcome.Failed(YtEngine.friendly(msg))
            }
        }

        val produced = work.listFiles()
            ?.filter { it.isFile && it.name !in before && isMedia(it) }
            ?.sortedBy { it.lastModified() }
            .orEmpty()
        if (produced.isEmpty()) return Outcome.Failed("No finished media file was found.")

        return try {
            var uri = ""
            var path = ""
            for (f in produced) {
                val published = publish(f, folder)
                if (published != null) {
                    uri = published.toString()
                    f.delete()
                } else {
                    path = f.absolutePath
                }
            }
            Outcome.Done(uri, path)
        } catch (e: Exception) {
            Outcome.Failed("Could not save the file: ${e.message ?: "unknown error"}")
        }
    }

    private fun runYtDlp(i: Int, url: String, format: String, container: String, subs: String, work: File) {
        val req = YoutubeDLRequest(url)
        req.addOption("--no-mtime")
        req.addOption("--newline")
        req.addOption("--no-overwrites")
        req.addOption("--no-playlist")
        req.addOption("--retries", "5")
        req.addOption("--fragment-retries", "5")
        req.addOption("--socket-timeout", "30")
        req.addOption("-f", format.ifBlank { "bestvideo+bestaudio/best" })
        req.addOption("--merge-output-format", container)
        req.addOption("-o", File(work, "%(title).120B [%(id)s].%(ext)s").absolutePath)
        if (subs.isNotBlank()) {
            req.addOption("--write-subs")
            req.addOption("--write-auto-subs")
            req.addOption("--sub-langs", subs)
            req.addOption("--embed-subs")
            req.addOption("--convert-subs", "srt")
            req.addOption("--sleep-subtitles", "5")
            req.addOption("--sleep-requests", "1")
        }
        val pid = "lumo-$jobId-$i"
        currentPid = pid
        try {
            YoutubeDL.getInstance().execute(req, pid) { progress, eta, line ->
                onProgress(i, progress, eta, line)
            }
        } finally {
            currentPid = ""
        }
    }

    private fun onProgress(i: Int, progress: Float, eta: Long, line: String) {
        val pct = progress.coerceIn(0f, 100f)
        val speed = SPEED.find(line)?.groupValues?.get(1)?.replace("iB", "B")
        DownloadBus.setItem(i) { it.copy(percent = pct) }
        DownloadBus.update { s ->
            s.copy(percent = overall(s), speed = speed ?: s.speed, eta = eta.toInt().coerceAtLeast(0))
        }
        HistoryStore.live(currentRecordId, pct)
        val now = System.currentTimeMillis()
        if (now - lastNotify > 700) {
            lastNotify = now
            getSystemService(NotificationManager::class.java).notify(
                notifId,
                notification(DownloadBus.state.value.message, pct.toInt(), true)
            )
        }
    }

    private fun overall(s: JobState): Float {
        if (s.items.isEmpty()) return 0f
        val sum = s.items.sumOf {
            when (it.status) {
                "done" -> 100.0
                "run" -> it.percent.toDouble()
                else -> 0.0
            }
        }
        return (sum / s.items.size).toFloat()
    }

    private fun isSubtitleFailure(msg: String): Boolean =
        msg.contains("subtitle", ignoreCase = true) || msg.contains("429")

    private fun isMedia(file: File): Boolean =
        file.extension.lowercase() in setOf("mp4", "mkv", "webm", "mov", "m4v", "mp3", "m4a", "opus", "ogg", "wav", "flac")

    private fun workFolder(): File {
        val base = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: filesDir
        return File(base, "LumoWork").apply { mkdirs() }
    }

    /** Copies a finished file into the user's chosen shared folder. Returns its URI, or null for a plain file path. */
    private fun publish(file: File, folder: String): Uri? {
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(file.extension.lowercase())
            ?: "application/octet-stream"

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            val type = when {
                folder.startsWith("Movies") -> Environment.DIRECTORY_MOVIES
                folder.startsWith("DCIM") -> Environment.DIRECTORY_DCIM
                else -> Environment.DIRECTORY_DOWNLOADS
            }
            @Suppress("DEPRECATION")
            val dir = File(Environment.getExternalStoragePublicDirectory(type), "Lumo")
            if (!dir.exists() && !dir.mkdirs()) throw IllegalStateException("Cannot create ${dir.path}")
            val dest = File(dir, file.name)
            file.inputStream().use { input -> dest.outputStream().use { output -> input.copyTo(output) } }
            return Uri.fromFile(dest)
        }

        val collection = when {
            folder.startsWith("Download") -> MediaStore.Downloads.EXTERNAL_CONTENT_URI
            mime.startsWith("video/") -> MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            else -> MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        }
        val resolver = contentResolver
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, file.name)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, folder)
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val uri = resolver.insert(collection, values) ?: throw IllegalStateException("Cannot create the file in $folder")
        try {
            val out = resolver.openOutputStream(uri, "w") ?: throw IllegalStateException("Cannot open the output stream")
            out.use { o -> file.inputStream().use { it.copyTo(o) } }
            resolver.update(uri, ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }, null, null)
            return uri
        } catch (e: Exception) {
            resolver.delete(uri, null, null)
            throw e
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Lumo downloads", NotificationManager.IMPORTANCE_LOW)
                .apply { description = "Download progress and cancellation" }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun notification(message: String, progress: Int, ongoing: Boolean): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("Lumo")
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setContentIntent(open)
            .setOnlyAlertOnce(true)
            .setOngoing(ongoing)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setProgress(100, progress.coerceIn(0, 100), false)
        if (ongoing) {
            val cancel = PendingIntent.getService(
                this, 2,
                Intent(this, DownloadService::class.java).setAction(ACTION_CANCEL).putExtra(EXTRA_INDEX, -1),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            builder.addAction(android.R.drawable.ic_menu_close_clear_cancel, "Cancel", cancel)
        }
        return builder.build()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        executor.shutdown()
        super.onDestroy()
    }

    companion object {
        const val ACTION_START = "com.lumo.android.action.START"
        const val ACTION_CANCEL = "com.lumo.android.action.CANCEL"
        const val ACTION_DECIDE = "com.lumo.android.action.DECIDE"
        const val EXTRA_PAYLOAD = "payload"
        const val EXTRA_INDEX = "index"
        const val EXTRA_CHOICE = "choice"
        private const val CHANNEL_ID = "lumo_downloads"
        private val SPEED = Regex("""at\s+([\d.]+\s*\S+/s)""")
    }
}
