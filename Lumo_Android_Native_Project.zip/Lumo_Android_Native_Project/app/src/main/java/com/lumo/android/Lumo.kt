package com.lumo.android

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.Executors

enum class VStep { Idle, Inspecting, Quality, Options, Running }
enum class PStep { Idle, Inspecting, Ready, Running }

class SheetOption(val label: String, val onClick: () -> Unit)
class SheetSpec(val title: String, val options: List<SheetOption>)

val FOLDER_CHOICES = listOf("Download/Lumo", "Movies/Lumo", "DCIM/Lumo")
val SUBTITLE_CHOICES = listOf(
    Triple("en", "English", C.Violet),
    Triple("hi", "Hindi", C.Amber),
    Triple("mr", "Marathi", C.Teal)
)

/** App state and actions. Compose reads these fields directly; all writes happen on the main thread. */
object Lumo {
    private lateinit var app: Context
    private var initialized = false
    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newFixedThreadPool(2)
    private var pendingShare: String? = null

    var tab by mutableIntStateOf(0)
    var playlistMode by mutableStateOf(false)
    var engineReady by mutableStateOf(false)
    var engineStatus by mutableStateOf("Starting download engine…")

    var toastText by mutableStateOf<String?>(null)
    var toastSeq by mutableIntStateOf(0)
    var sheet by mutableStateOf<SheetSpec?>(null)
    var colorTarget by mutableStateOf<String?>(null)

    // Settings mirrored into state so the UI repaints when they change.
    var autoUpdateOn by mutableStateOf(false)
    var preferMp4On by mutableStateOf(true)
    var folderName by mutableStateOf("Download/Lumo")
    var prefSubCode by mutableStateOf("en")
    var indHex by mutableStateOf("#FFB45F")
    var progHex by mutableStateOf("#8871FF")
    var savedColors by mutableStateOf<List<String>>(emptyList())

    // Video mode
    var vUrl by mutableStateOf("")
    var vStep by mutableStateOf(VStep.Idle)
    var vInfo by mutableStateOf<VideoInfo?>(null)
    var vError by mutableStateOf("")
    var vQuality by mutableIntStateOf(0)
    var vSubs by mutableStateOf(setOf<String>())
    var vContainer by mutableStateOf("mp4")
    var vJobId by mutableStateOf("")

    // Playlist mode
    var pUrl by mutableStateOf("")
    var pStep by mutableStateOf(PStep.Idle)
    var pInfo by mutableStateOf<PlaylistInfo?>(null)
    var pError by mutableStateOf("")
    var pQuality by mutableIntStateOf(0)
    var pSubs by mutableStateOf(setOf<String>())
    var pJobId by mutableStateOf("")

    fun init(context: Context) {
        if (initialized) return
        initialized = true
        app = context.applicationContext
        Prefs.init(app)
        HistoryStore.init(app)
        autoUpdateOn = Prefs.autoUpdate
        preferMp4On = Prefs.preferMp4
        folderName = Prefs.folder
        prefSubCode = Prefs.prefSub
        indHex = Prefs.indHex()
        progHex = Prefs.progHex()
        savedColors = Prefs.savedColors()
        vContainer = if (preferMp4On) "mp4" else "mkv"

        worker.execute {
            val msg = YtEngine.init(app)
            post {
                engineReady = YtEngine.ready
                engineStatus = msg
                pendingShare?.let { url ->
                    pendingShare = null
                    inspectVideo(url)
                }
            }
            if (YtEngine.ready && Prefs.autoUpdate) {
                val m = YtEngine.update(app)
                post { engineStatus = m }
            }
        }
    }

    private fun post(block: () -> Unit) {
        main.post { block() }
    }

    fun toast(message: String) {
        toastText = message
        toastSeq++
    }

    fun onBack() {
        when {
            sheet != null -> sheet = null
            colorTarget != null -> colorTarget = null
            tab != 0 -> tab = 0
            vStep == VStep.Options -> vStep = VStep.Quality
            vStep == VStep.Quality -> {
                vStep = VStep.Idle
                vInfo = null
            }
        }
    }

    fun clipboardText(): String {
        val cm = app.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        return cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(app)?.toString().orEmpty()
    }

    fun copyText(text: String) {
        val cm = app.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("Lumo", text))
    }

    /** Called when another app shares a link to Lumo. */
    fun handleShare(text: String) {
        val url = Regex("https?://\\S+").find(text)?.value ?: text.trim()
        if (!isHttpUrl(url)) return
        tab = 0
        playlistMode = false
        if (engineReady) inspectVideo(url) else pendingShare = url
    }

    fun setMode(playlist: Boolean) {
        playlistMode = playlist
    }

    private fun isJobActive(jobId: String): Boolean {
        val s = DownloadBus.state.value
        return jobId.isNotEmpty() && s.jobId == jobId && (s.phase == "running" || s.phase == "prompt")
    }

    private fun anyJobActive(): Boolean {
        val s = DownloadBus.state.value
        return s.phase == "running" || s.phase == "prompt"
    }

    // ---------- Video ----------

    fun pasteVideo() {
        val text = clipboardText().trim()
        if (!isHttpUrl(text)) {
            toast("Copy a video link first")
            return
        }
        inspectVideo(text)
    }

    fun inspectVideo(url: String) {
        if (!YtEngine.ready) {
            vError = "The download engine is still starting."
            return
        }
        vUrl = url
        vError = ""
        vInfo = null
        vStep = VStep.Inspecting
        worker.execute {
            try {
                val info = YtEngine.inspectVideo(url)
                post {
                    vInfo = info
                    vQuality = 0
                    vSubs = defaultSubs(info.subCodes)
                    vContainer = if (preferMp4On) "mp4" else "mkv"
                    vStep = VStep.Quality
                }
            } catch (e: Exception) {
                val msg = YtEngine.friendly(e.message)
                post {
                    vStep = VStep.Idle
                    vError = msg
                }
            }
        }
    }

    private fun defaultSubs(codes: Set<String>): Set<String> =
        if (prefSubCode != "none" && prefSubCode in codes) setOf(prefSubCode) else emptySet()

    fun clearVideo() {
        if (isJobActive(vJobId)) {
            toast("Cancel the download first.")
            return
        }
        vUrl = ""
        vError = ""
        vInfo = null
        vSubs = emptySet()
        vStep = VStep.Idle
    }

    fun toggleSub(code: String) {
        vSubs = if (code in vSubs) vSubs - code else vSubs + code
    }

    fun chooseMp4() {
        vSubs = emptySet()
        vContainer = "mp4"
    }

    fun chooseMkv() {
        vContainer = "mkv"
    }

    fun startVideo() {
        val info = vInfo ?: return
        if (anyJobActive()) {
            toast("Another download is running.")
            return
        }
        val opts = Quality.options(info.sizesMb, false)
        val q = opts.getOrNull(vQuality) ?: opts.first()
        val subs = vSubs.sorted().joinToString(",")
        val container = if (subs.isNotBlank()) "mkv" else vContainer
        val id = "v" + System.currentTimeMillis()
        vJobId = id
        vStep = VStep.Running
        val item = JSONObject()
            .put("url", info.url)
            .put("title", info.title)
            .put("thumb", info.thumb)
            .put("duration", info.duration)
            .put("size", q.sizeText)
        launch(id, "video", Quality.selector(q.height, container, info.mp4Heights), container, subs, q.label, listOf(item))
    }

    fun cancelVideo() = sendCancel(-1)

    fun newVideo() {
        vUrl = ""
        vInfo = null
        vError = ""
        vSubs = emptySet()
        vJobId = ""
        vStep = VStep.Idle
        vContainer = if (preferMp4On) "mp4" else "mkv"
    }

    fun backToQuality() {
        vStep = VStep.Quality
    }

    // ---------- Playlist ----------

    fun pastePlaylist() {
        val text = clipboardText().trim()
        if (!isHttpUrl(text)) {
            toast("Copy a playlist link first")
            return
        }
        inspectPlaylist(text)
    }

    fun inspectPlaylist(url: String) {
        if (!YtEngine.ready) {
            pError = "The download engine is still starting."
            return
        }
        if (isJobActive(pJobId)) {
            toast("A playlist is downloading. Cancel it first.")
            return
        }
        pUrl = url
        pError = ""
        pInfo = null
        pStep = PStep.Inspecting
        worker.execute {
            try {
                val info = YtEngine.inspectPlaylist(url)
                post {
                    pInfo = info
                    pQuality = 0
                    pSubs = if (prefSubCode != "none") setOf(prefSubCode) else emptySet()
                    pStep = PStep.Ready
                }
            } catch (e: Exception) {
                val msg = YtEngine.friendly(e.message)
                post {
                    pStep = PStep.Idle
                    pError = msg
                }
            }
        }
    }

    fun togglePlaylistSub(code: String) {
        pSubs = if (code in pSubs) pSubs - code else pSubs + code
    }

    fun removeEntry(index: Int) {
        val info = pInfo ?: return
        val entries = info.entries.filterIndexed { i, _ -> i != index }
        if (entries.isEmpty()) {
            clearPlaylist()
            return
        }
        pInfo = info.copy(entries = entries)
    }

    fun startPlaylist() {
        val info = pInfo ?: return
        if (anyJobActive()) {
            toast("Another download is running.")
            return
        }
        val opts = Quality.options(emptyMap(), true)
        val q = opts.getOrNull(pQuality) ?: opts.first()
        val subs = pSubs.sorted().joinToString(",")
        val container = if (subs.isNotBlank()) "mkv" else if (preferMp4On) "mp4" else "mkv"
        val id = "p" + System.currentTimeMillis()
        pJobId = id
        pStep = PStep.Running
        val items = info.entries.map { e ->
            JSONObject()
                .put("url", e.url)
                .put("title", e.title)
                .put("thumb", e.thumb)
                .put("duration", e.duration)
                .put("size", "")
        }
        launch(id, "playlist", Quality.selector(q.height, container, emptySet()), container, subs, q.label, items)
    }

    fun cancelPlaylist() = sendCancel(-1)

    fun cancelItem(index: Int) = sendCancel(index)

    fun clearPlaylist() {
        if (isJobActive(pJobId)) {
            toast("Cancel the playlist first.")
            return
        }
        pUrl = ""
        pError = ""
        pInfo = null
        pStep = PStep.Idle
    }

    fun newPlaylist() {
        pUrl = ""
        pInfo = null
        pError = ""
        pJobId = ""
        pStep = PStep.Idle
    }

    // ---------- Shared job plumbing ----------

    private fun launch(
        jobId: String,
        kind: String,
        format: String,
        container: String,
        subs: String,
        quality: String,
        items: List<JSONObject>
    ) {
        val arr = JSONArray()
        items.forEach { arr.put(it) }
        val payload = JSONObject()
            .put("jobId", jobId)
            .put("kind", kind)
            .put("format", format)
            .put("container", container)
            .put("subs", subs)
            .put("quality", quality)
            .put("folder", folderName)
            .put("items", arr)

        DownloadBus.state.value = JobState(
            jobId = jobId,
            kind = kind,
            items = items.map {
                ItemState(title = it.optString("title"), thumb = it.optString("thumb"), duration = it.optString("duration"))
            },
            phase = "running",
            folder = folderName,
            message = "Starting…"
        )
        val intent = Intent(app, DownloadService::class.java)
            .setAction(DownloadService.ACTION_START)
            .putExtra(DownloadService.EXTRA_PAYLOAD, payload.toString())
        ContextCompat.startForegroundService(app, intent)
    }

    private fun sendCancel(index: Int) {
        app.startService(
            Intent(app, DownloadService::class.java)
                .setAction(DownloadService.ACTION_CANCEL)
                .putExtra(DownloadService.EXTRA_INDEX, index)
        )
    }

    fun decideSubtitles(choice: String) {
        app.startService(
            Intent(app, DownloadService::class.java)
                .setAction(DownloadService.ACTION_DECIDE)
                .putExtra(DownloadService.EXTRA_CHOICE, choice)
        )
    }

    // ---------- History ----------

    fun retry(rec: HistoryRecord) {
        if (!YtEngine.ready) {
            toast("The download engine is still starting.")
            return
        }
        if (anyJobActive()) {
            toast("Another download is running.")
            return
        }
        val item = JSONObject()
            .put("url", rec.url)
            .put("title", rec.title)
            .put("thumb", rec.thumb)
            .put("duration", "")
            .put("size", rec.sizeText)
            .put("recordId", rec.id)
        val container = if (rec.subs.isNotBlank()) "mkv" else rec.container
        toast("Retrying. Partial files are resumed when possible.")
        launch("r" + System.currentTimeMillis(), "video", rec.formatSel, container, rec.subs, rec.quality, listOf(item))
    }

    fun removeRecord(rec: HistoryRecord) {
        if (rec.status == "run") {
            toast("Cancel this download before removing its record.")
            return
        }
        HistoryStore.remove(rec.id)
        toast("Record removed. The file was not deleted.")
    }

    fun askClearHistory() {
        sheet = SheetSpec(
            "Clear all history?",
            listOf(
                SheetOption("Clear history") {
                    HistoryStore.clear()
                    toast("History cleared")
                },
                SheetOption("Cancel") {}
            )
        )
    }

    fun openRecord(rec: HistoryRecord) {
        openUriOrFolder(rec.uri, rec.path)
    }

    private fun openUriOrFolder(uriText: String, path: String) {
        try {
            val uri = if (uriText.isNotBlank()) {
                Uri.parse(uriText)
            } else if (path.isNotBlank() && File(path).exists()) {
                FileProvider.getUriForFile(app, "${app.packageName}.fileprovider", File(path))
            } else {
                null
            }
            if (uri == null) {
                openFolder()
                return
            }
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "video/*")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            app.startActivity(intent)
        } catch (_: Exception) {
            openFolder()
        }
    }

    fun openFolder() {
        val intent = Intent(Intent.ACTION_VIEW)
            .setDataAndType(
                Uri.parse("content://com.android.externalstorage.documents/document/primary%3A" + Uri.encode(folderName)),
                "vnd.android.document/directory"
            )
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            app.startActivity(intent)
        } catch (_: Exception) {
            toast("Open Files → $folderName")
        }
    }

    // ---------- Settings ----------

    fun setAutoUpdate(on: Boolean) {
        Prefs.autoUpdate = on
        autoUpdateOn = on
    }

    fun setPreferMp4(on: Boolean) {
        Prefs.preferMp4 = on
        preferMp4On = on
        toast(if (on) "MP4 preferred" else "Keeping the original container (MKV)")
    }

    fun updateEngine() {
        engineStatus = "Updating…"
        worker.execute {
            val m = YtEngine.update(app)
            post { engineStatus = m }
        }
    }

    fun askFolder() {
        sheet = SheetSpec(
            "Choose download folder",
            FOLDER_CHOICES.map { f ->
                SheetOption("Internal storage/$f") {
                    Prefs.folder = f
                    folderName = f
                    toast("Download folder updated")
                }
            }
        )
    }

    fun setPrefSub(code: String, label: String) {
        Prefs.prefSub = code
        prefSubCode = code
        toast("Preferred subtitles: $label")
    }

    fun pickColor(target: String, hex: String) {
        if (target == "ind") {
            Prefs.setInd(hex)
            indHex = hex
        } else {
            Prefs.setProg(hex)
            progHex = hex
        }
    }

    fun applyCustomColor(target: String, rawHex: String) {
        val hex = rawHex.trim().uppercase()
        if (!Regex("#[0-9A-F]{6}").matches(hex)) {
            toast("Enter a colour like #3DDC97")
            return
        }
        val list = savedColors.toMutableList()
        if (hex !in list) {
            if (list.size >= 5) {
                toast("Up to 5 saved colours. Long-press one to remove it.")
                return
            }
            list.add(hex)
            savedColors = list
            Prefs.saveColors(list)
        }
        pickColor(target, hex)
        colorTarget = null
    }

    fun removeSavedColor(hex: String) {
        val list = savedColors.filter { it != hex }
        savedColors = list
        Prefs.saveColors(list)
        toast("Saved colour removed")
    }
}
