package com.lumo.android

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object HistoryStore {
    private const val PREFS = "lumo_history"
    private const val KEY_ITEMS = "items"

    @Synchronized
    fun add(
        context: Context,
        title: String,
        url: String,
        status: String,
        location: String,
        uri: String = "",
        path: String = ""
    ) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val old = try { JSONArray(prefs.getString(KEY_ITEMS, "[]")) } catch (_: Exception) { JSONArray() }
        val next = JSONArray()
        next.put(JSONObject()
            .put("title", title)
            .put("url", url)
            .put("status", status)
            .put("location", location)
            .put("uri", uri)
            .put("path", path)
            .put("time", System.currentTimeMillis()))
        for (i in 0 until old.length()) {
            val item = old.optJSONObject(i) ?: continue
            next.put(item)
        }
        while (next.length() > 100) next.remove(next.length() - 1)
        prefs.edit().putString(KEY_ITEMS, next.toString()).apply()
    }

    fun items(context: Context): JSONArray {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_ITEMS, "[]") ?: "[]"
        return try { JSONArray(raw) } catch (_: Exception) { JSONArray() }
    }

    fun clear(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(KEY_ITEMS).apply()
    }
}
