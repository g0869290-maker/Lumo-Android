package com.lumo.android

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

// ============================== DOWNLOAD ==============================

@Composable
fun DownloadScreen() {
    val job by DownloadBus.state.collectAsState()
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 18.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(30.dp)
                    .clip(RoundedCornerShape(9.dp))
                    .background(Brush.linearGradient(listOf(C.Acc, C.Violet))),
                contentAlignment = Alignment.Center
            ) {
                Text("L", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp)
            }
            Spacer(Modifier.width(10.dp))
            Text("Download", color = C.Ink, fontWeight = FontWeight.Bold, fontSize = 24.sp)
        }
        SegmentRow(Lumo.playlistMode) { Lumo.setMode(it) }
        if (Lumo.playlistMode) PlaylistPage(job) else VideoPage(job)
        Spacer(Modifier.height(10.dp))
    }
}

@Composable
private fun SegmentRow(playlist: Boolean, onPick: (Boolean) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        SegButton("Video", "film", !playlist, Modifier.weight(1f)) { onPick(false) }
        SegButton("Playlist", "list", playlist, Modifier.weight(1f)) { onPick(true) }
    }
}

@Composable
private fun VideoPage(job: JobState) {
    val mine = Lumo.vJobId.isNotEmpty() && job.jobId == Lumo.vJobId
    val running = mine && (job.phase == "running" || job.phase == "prompt")
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        UrlBar(
            text = if (Lumo.vUrl.isBlank()) "Paste a video link…" else Lumo.vUrl,
            filled = Lumo.vUrl.isNotBlank(),
            showClear = Lumo.vUrl.isNotBlank() && !running,
            onClear = { Lumo.clearVideo() },
            onPaste = { Lumo.pasteVideo() }
        )
        if (Lumo.vError.isNotBlank()) {
            Text(Lumo.vError, color = C.Acc, fontSize = 12.5.sp)
        }
        when (Lumo.vStep) {
            VStep.Inspecting -> FinderCard("Finding your video…")
            VStep.Quality -> Lumo.vInfo?.let { QualitySection(it) }
            VStep.Options -> Lumo.vInfo?.let { OptionsSection(it) }
            VStep.Running -> Lumo.vInfo?.let { DownloadCard(it.title, it.thumb, job, mine) }
            VStep.Idle -> Unit
        }
    }
}

@Composable
private fun FinderCard(title: String) {
    LCard {
        Text(title, color = C.Ink, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        GlowBar(0f, indeterminate = true, height = 6.dp)
    }
}

@Composable
private fun QualitySection(info: VideoInfo) {
    val opts = Quality.options(info.sizesMb, false)
    val sel = opts.getOrNull(Lumo.vQuality) ?: opts.first()
    Text("Choose quality", color = C.Ink, fontWeight = FontWeight.Bold, fontSize = 18.sp)
    LCard {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Thumb(info.thumb, Modifier.size(width = 84.dp, height = 52.dp), 12.dp)
            Column(Modifier.weight(1f)) {
                Text(
                    info.title,
                    color = C.Ink,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.5.sp,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    listOf(info.extractor, info.duration).filter { it.isNotBlank() }.joinToString(" · "),
                    color = C.Muted,
                    fontSize = 11.5.sp
                )
            }
        }
    }
    Label("VIDEO QUALITY")
    Dropdown(opts.map { it.label to it.sizeText }, Lumo.vQuality) { Lumo.vQuality = it }
    Caption("Estimated size  ·  ${sel.sizeText}")
    PrimaryButton("Continue  →", Modifier.fillMaxWidth()) { Lumo.vStep = VStep.Options }
}

@Composable
private fun OptionsSection(info: VideoInfo) {
    val container = if (Lumo.vSubs.isNotEmpty()) "mkv" else Lumo.vContainer
    Text("Make it yours", color = C.Ink, fontWeight = FontWeight.Bold, fontSize = 18.sp)
    Label("SUBTITLES")
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        SUBTITLE_CHOICES.forEach { (code, label, tint) ->
            LChip(label, on = code in Lumo.vSubs, tint = tint, enabled = code in info.subCodes) {
                Lumo.toggleSub(code)
            }
        }
    }
    if (info.subCodes.isEmpty()) {
        Caption("This video has no subtitle tracks Lumo can read.")
    }
    Label("FILE FORMAT")
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        LChip("MP4  ·  Compatible", on = container == "mp4", tint = C.Violet, enabled = Lumo.vSubs.isEmpty()) {
            Lumo.chooseMp4()
        }
        LChip("MKV  ·  Flexible", on = container == "mkv", tint = C.Acc) { Lumo.chooseMkv() }
    }
    if (Lumo.vSubs.isNotEmpty()) {
        Caption("Subtitles are embedded, so the file is saved as MKV.")
    }
    Row(
        Modifier.padding(top = 10.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        GhostButton("← Quality") { Lumo.vStep = VStep.Quality }
        PrimaryButton("Download video  ↓", Modifier.weight(1f)) { Lumo.startVideo() }
    }
}

@Composable
private fun DownloadCard(title: String, thumb: String, job: JobState, mine: Boolean) {
    val phase = if (mine) job.phase else "running"
    val done = phase == "done"
    val stopped = phase == "cancelled" || phase == "failed"
    val finished = done || stopped
    val pct = if (done) 100f else if (mine) job.percent else 0f
    LCard {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Thumb(thumb, Modifier.size(width = 64.dp, height = 42.dp), 10.dp)
            Column(Modifier.weight(1f)) {
                Text(
                    if (title.isBlank()) "Preparing your video" else title,
                    color = C.Ink,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(statusLine(phase, job), color = if (phase == "failed") C.Bad else C.Muted, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                GlowBar(pct / 100f)
                if (done) Badge()
            }
            Spacer(Modifier.width(10.dp))
            Text(
                when {
                    done -> "Completed"
                    stopped -> "Stopped"
                    else -> "${pct.roundToInt()}%"
                },
                color = if (done) C.Ok else C.Ink,
                fontWeight = FontWeight.Bold,
                fontSize = if (done) 12.sp else 15.sp
            )
        }
        if (phase == "prompt") {
            Caption("Waiting for your choice…")
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
            if (!finished) {
                GhostButton("Cancel download") { Lumo.cancelVideo() }
            } else {
                if (done) GhostButton("Open download folder") { Lumo.openFolder() }
                if (stopped) GhostButton("Back to quality") { Lumo.backToQuality() }
                PrimaryButton("New video") { Lumo.newVideo() }
            }
        }
    }
}

private fun statusLine(phase: String, job: JobState): String = when (phase) {
    "done" -> "Your file is ready · saved to ${job.folder}"
    "cancelled" -> "Download cancelled"
    "failed" -> job.message.ifBlank { "Download failed" }
    "prompt" -> job.prompt
    else -> {
        val speed = job.speed.ifBlank { "Calculating speed" }
        if (job.eta > 0) "$speed   ·   ETA %02d:%02d".format(job.eta / 60, job.eta % 60) else speed
    }
}

@Composable
private fun Badge() {
    Box(
        Modifier
            .size(34.dp)
            .clip(androidx.compose.foundation.shape.CircleShape)
            .background(C.Ok),
        contentAlignment = Alignment.Center
    ) {
        Text("✓", color = Color(0xFF07140D), fontWeight = FontWeight.Bold, fontSize = 17.sp)
    }
}

@Composable
private fun PlaylistPage(job: JobState) {
    val mine = Lumo.pJobId.isNotEmpty() && job.jobId == Lumo.pJobId
    val running = mine && (job.phase == "running" || job.phase == "prompt")
    val finished = mine && (job.phase == "done" || job.phase == "cancelled" || job.phase == "failed")

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        UrlBar(
            text = if (Lumo.pUrl.isBlank()) "Paste a playlist link…" else Lumo.pUrl,
            filled = Lumo.pUrl.isNotBlank(),
            showClear = Lumo.pUrl.isNotBlank() && !running,
            onClear = { Lumo.clearPlaylist() },
            onPaste = { Lumo.pastePlaylist() }
        )
        if (Lumo.pError.isNotBlank()) {
            Text(Lumo.pError, color = C.Acc, fontSize = 12.5.sp)
        }
        when (Lumo.pStep) {
            PStep.Inspecting -> FinderCard("Loading playlist…")
            PStep.Ready -> Lumo.pInfo?.let { PlaylistConfig(it) }
            else -> Unit
        }
        if (mine && (running || finished)) {
            if (finished) PlaylistDone(job) else PlaylistRun(job)
        }
        PlaylistList(job, mine)
    }
}

@Composable
private fun PlaylistConfig(info: PlaylistInfo) {
    val opts = Quality.options(emptyMap(), true)
    LCard {
        Text("${info.title} · ${info.entries.size} videos", color = C.Ink, fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Label("VIDEO QUALITY")
        Dropdown(opts.map { it.label to it.sizeText }, Lumo.pQuality) { Lumo.pQuality = it }
        Label("SUBTITLES")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SUBTITLE_CHOICES.forEach { (code, label, tint) ->
                LChip(label, on = code in Lumo.pSubs, tint = tint) { Lumo.togglePlaylistSub(code) }
            }
        }
        PrimaryButton("Download Playlist", Modifier.fillMaxWidth().padding(top = 6.dp)) { Lumo.startPlaylist() }
    }
}

@Composable
private fun PlaylistRun(job: JobState) {
    val active = job.items.filter { it.status != "cancel" }
    val doneCount = job.items.count { it.status == "done" }
    LCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("$doneCount of ${active.size} downloaded", color = C.Ink, fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.weight(1f))
            GhostButton("Cancel playlist") { Lumo.cancelPlaylist() }
        }
        GlowBar(job.percent / 100f, height = 10.dp)
    }
}

@Composable
private fun PlaylistDone(job: JobState) {
    val d = job.items.count { it.status == "done" }
    val c = job.items.count { it.status == "cancel" }
    val summary = if (job.phase == "cancelled") "Playlist cancelled" else "Done · $d completed" + (if (c > 0) ", $c cancelled" else "")
    LCard {
        Text(summary, color = C.Ink, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            GhostButton("Open download folder") { Lumo.openFolder() }
            PrimaryButton("New playlist") { Lumo.newPlaylist() }
        }
    }
}

@Composable
private fun PlaylistList(job: JobState, mine: Boolean) {
    val info = Lumo.pInfo
    if (Lumo.pStep == PStep.Ready && info != null) {
        LCard {
            info.entries.forEachIndexed { i, e ->
                if (i > 0) RowDivider()
                VideoRow(e.thumb, e.title, e.duration.ifBlank { "Video" } + " · Queued", "queued", 0f, removable = true) {
                    Lumo.removeEntry(i)
                }
            }
        }
    } else if (mine && job.items.isNotEmpty()) {
        LCard {
            job.items.forEachIndexed { i, item ->
                if (i > 0) RowDivider()
                val sub = (if (item.duration.isNotBlank()) item.duration + " · " else "") + statusName(item.status)
                VideoRow(
                    item.thumb,
                    item.title,
                    sub,
                    item.status,
                    item.percent,
                    removable = item.status == "queued" || item.status == "run"
                ) { Lumo.cancelItem(i) }
            }
        }
    }
}

private fun statusName(status: String): String = when (status) {
    "run" -> "Downloading"
    "done" -> "Completed"
    "fail" -> "Failed"
    "cancel" -> "Cancelled"
    else -> "Queued"
}

@Composable
private fun RowDivider() {
    Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0xFF1A1C24)))
}

@Composable
private fun VideoRow(
    thumb: String,
    title: String,
    sub: String,
    status: String,
    percent: Float,
    removable: Boolean,
    onAction: () -> Unit
) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Thumb(thumb, Modifier.size(width = 58.dp, height = 38.dp), 9.dp)
        Column(Modifier.weight(1f)) {
            Text(title, color = C.Ink, fontSize = 12.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(sub, color = C.Muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (removable) {
            Box(
                Modifier
                    .size(26.dp)
                    .clip(androidx.compose.foundation.shape.CircleShape)
                    .background(C.Alt)
                    .clickable(onClick = onAction),
                contentAlignment = Alignment.Center
            ) {
                Text("✕", color = C.Muted, fontSize = 11.sp)
            }
        }
        StatusMark(status, percent)
    }
}

// ============================== HISTORY ==============================

@Composable
fun HistoryScreen() {
    val items by HistoryStore.items.collectAsState()
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 18.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("History", color = C.Ink, fontWeight = FontWeight.Bold, fontSize = 24.sp, modifier = Modifier.weight(1f))
            if (items.isNotEmpty()) {
                Text("${items.size} ${if (items.size == 1) "item" else "items"}", color = C.Muted, fontSize = 12.sp)
                Spacer(Modifier.width(10.dp))
                GhostButton("Clear") { Lumo.askClearHistory() }
            }
        }
        if (items.isEmpty()) {
            LCard { Text("No downloads yet", color = C.Ink, fontWeight = FontWeight.Bold, fontSize = 14.sp) }
        } else {
            LCard {
                items.forEachIndexed { i, rec ->
                    if (i > 0) RowDivider()
                    HistoryRow(rec)
                }
            }
        }
        Spacer(Modifier.height(10.dp))
    }
}

@Composable
private fun HistoryRow(rec: HistoryRecord) {
    val when_ = SimpleDateFormat("d MMM, h:mm a", Locale.US).format(Date(rec.time))
    val meta = listOf(rec.quality, rec.sizeText, rec.format, when_).filter { it.isNotBlank() }.joinToString(" · ")
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Thumb(rec.thumb, Modifier.size(width = 58.dp, height = 38.dp), 9.dp)
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(rec.title, color = C.Ink, fontWeight = FontWeight.Bold, fontSize = 12.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(meta, color = C.Muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                when (rec.status) {
                    "ok" -> {
                        SmallAction("Show in folder") { Lumo.openRecord(rec) }
                        SmallAction("Copy URL") {
                            Lumo.copyText(rec.url)
                            Lumo.toast("URL copied to clipboard")
                        }
                    }
                    "fail", "cancelled" -> {
                        SmallAction("Retry / Resume") { Lumo.retry(rec) }
                        SmallAction("Show error") { Lumo.toast(rec.error.ifBlank { "No details were saved." }) }
                    }
                    else -> Unit
                }
                SmallAction("Remove record") { Lumo.removeRecord(rec) }
            }
        }
        when (rec.status) {
            "ok" -> StatusMark("done", 100f)
            "run" -> StatusMark("run", rec.percent)
            "cancelled" -> StatusMark("cancel", 0f)
            else -> StatusMark("fail", 0f)
        }
    }
}

// ============================== SETTINGS ==============================

private val ACTIVE_BAR_PRESETS = listOf(
    "Blue" to "#60A5FA", "White" to "#F4F6FB", "Violet" to "#8871FF",
    "Turquoise" to "#2DD4BF", "Amber" to "#FFB45F", "Pink" to "#FF647F"
)
private val PROGRESS_PRESETS = listOf(
    "Violet" to "#8871FF", "Blue" to "#4C8DFF", "Turquoise" to "#2DD4BF",
    "Mint" to "#55D9A8", "Amber" to "#FFB45F", "Pink" to "#FF647F"
)
private val TAB_NAMES = listOf("Active Bar", "Downloads", "Subtitles", "Progress Bar", "Engine")

@Composable
fun SettingsScreen() {
    var tab by remember { mutableIntStateOf(0) }
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 18.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Settings", color = C.Ink, fontWeight = FontWeight.Bold, fontSize = 24.sp)
        Row(
            Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            TAB_NAMES.forEachIndexed { i, name ->
                LChip(name, on = tab == i, tint = C.Violet) { tab = i }
            }
        }
        when (tab) {
            0 -> LCard {
                Text("Active Bar", color = C.Ink, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Swatches(
                    presets = ACTIVE_BAR_PRESETS,
                    current = Lumo.indHex,
                    saved = Lumo.savedColors,
                    onPick = { Lumo.pickColor("ind", it) },
                    onAdd = { Lumo.colorTarget = "ind" },
                    onRemove = { Lumo.removeSavedColor(it) }
                )
                Caption("Selected: ${nameFor(ACTIVE_BAR_PRESETS, Lumo.indHex)}")
            }
            1 -> {
                Label("DOWNLOAD FOLDER")
                LCard {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            "Internal storage/${Lumo.folderName}",
                            color = C.Ink,
                            fontSize = 13.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )
                        GhostButton("Browse") { Lumo.askFolder() }
                    }
                }
                LCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Prefer MP4 when merging is possible", color = C.Ink, fontSize = 13.sp, modifier = Modifier.weight(1f))
                        LSwitch(Lumo.preferMp4On) { Lumo.setPreferMp4(!Lumo.preferMp4On) }
                    }
                }
            }
            2 -> LCard {
                Text("Preferred subtitles", color = C.Ink, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(
                        Triple("en", "English", C.Violet),
                        Triple("hi", "Hindi", C.Amber),
                        Triple("mr", "Marathi", C.Teal),
                        Triple("none", "None", C.Muted)
                    ).forEach { (code, label, tint) ->
                        LChip(label, on = Lumo.prefSubCode == code, tint = tint) { Lumo.setPrefSub(code, label) }
                    }
                }
            }
            3 -> LCard {
                Text("Progress bar colour", color = C.Ink, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Swatches(
                    presets = PROGRESS_PRESETS,
                    current = Lumo.progHex,
                    saved = Lumo.savedColors,
                    onPick = { Lumo.pickColor("prog", it) },
                    onAdd = { Lumo.colorTarget = "prog" },
                    onRemove = { Lumo.removeSavedColor(it) }
                )
                Caption("Selected: ${nameFor(PROGRESS_PRESETS, Lumo.progHex)}")
            }
            else -> {
                LCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Update engine on start", color = C.Ink, fontSize = 13.sp, modifier = Modifier.weight(1f))
                        LSwitch(Lumo.autoUpdateOn) { Lumo.setAutoUpdate(!Lumo.autoUpdateOn) }
                    }
                }
                PrimaryButton("Update engine now", Modifier.fillMaxWidth()) { Lumo.updateEngine() }
                Caption(Lumo.engineStatus)
            }
        }
        Spacer(Modifier.height(10.dp))
    }
}

private fun nameFor(presets: List<Pair<String, String>>, hex: String): String =
    presets.firstOrNull { it.second.equals(hex, ignoreCase = true) }?.first ?: "Custom"

// ============================== OVERLAYS ==============================

@Composable
fun ToastLayer() {
    val text = Lumo.toastText
    val seq = Lumo.toastSeq
    LaunchedEffect(seq) {
        if (Lumo.toastText != null) {
            delay(2000)
            Lumo.toastText = null
        }
    }
    Box(
        Modifier.fillMaxSize().padding(start = 16.dp, end = 16.dp, bottom = 96.dp).navigationBarsPadding(),
        contentAlignment = Alignment.BottomCenter
    ) {
        AnimatedVisibility(visible = text != null, enter = fadeIn(), exit = fadeOut()) {
            Box(
                Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF1D2029))
                    .border(1.dp, C.Line, RoundedCornerShape(12.dp))
                    .padding(horizontal = 12.dp, vertical = 10.dp)
            ) {
                Text(text.orEmpty(), color = C.Ink, fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun SheetLayer() {
    val spec = Lumo.sheet ?: return
    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0x99000000))
            .clickable { Lumo.sheet = null },
        contentAlignment = Alignment.BottomCenter
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp))
                .background(Color(0xFF111218))
                .border(1.dp, C.Line, RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp))
                .navigationBarsPadding()
                .padding(16.dp)
                .pointerInput(Unit) { detectTapGestures(onTap = {}) },
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(spec.title, color = C.Ink, fontWeight = FontWeight.Bold, fontSize = 15.sp, modifier = Modifier.padding(bottom = 6.dp))
            spec.options.forEach { opt ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .clickable {
                            Lumo.sheet = null
                            opt.onClick()
                        }
                        .padding(horizontal = 10.dp, vertical = 13.dp)
                ) {
                    Text(opt.label, color = C.Ink, fontSize = 13.5.sp)
                }
            }
        }
    }
}

@Composable
fun PromptLayer(job: JobState) {
    if (job.phase != "prompt") return
    Box(
        Modifier.fillMaxSize().background(Color(0x99000000)),
        contentAlignment = Alignment.BottomCenter
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp))
                .background(Color(0xFF111218))
                .navigationBarsPadding()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(job.prompt, color = C.Ink, fontWeight = FontWeight.Bold, fontSize = 15.sp, modifier = Modifier.padding(bottom = 6.dp))
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { Lumo.decideSubtitles("without") }.padding(horizontal = 10.dp, vertical = 13.dp)
            ) {
                Text("Download without subtitles", color = C.Ink, fontSize = 13.5.sp)
            }
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { Lumo.decideSubtitles("cancel") }.padding(horizontal = 10.dp, vertical = 13.dp)
            ) {
                Text("Cancel", color = C.Muted, fontSize = 13.5.sp)
            }
        }
    }
}

@Composable
fun ColorLayer() {
    val target = Lumo.colorTarget ?: return
    var text by remember(target) { mutableStateOf("#") }
    Box(
        Modifier.fillMaxSize().background(Color(0x99000000)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            Modifier
                .padding(24.dp)
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(Color(0xFF111218))
                .border(1.dp, C.Line, RoundedCornerShape(20.dp))
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Custom colour", color = C.Ink, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text("Type a hex colour such as #3DDC97", color = C.Muted, fontSize = 12.sp)
            Box(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF08090C))
                    .border(1.dp, C.Line, RoundedCornerShape(12.dp))
                    .padding(12.dp)
            ) {
                BasicTextField(
                    value = text,
                    onValueChange = { text = it.take(7) },
                    textStyle = TextStyle(color = C.Ink, fontSize = 15.sp),
                    cursorBrush = SolidColor(C.Acc),
                    modifier = Modifier.fillMaxWidth()
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                GhostButton("Cancel") { Lumo.colorTarget = null }
                PrimaryButton("Save", Modifier.weight(1f)) { Lumo.applyCustomColor(target, text) }
            }
        }
    }
}

// ============================== NAV ==============================

@Composable
fun BottomNav(tab: Int, onTab: (Int) -> Unit) {
    Box(Modifier.fillMaxWidth().background(Color.Black).navigationBarsPadding()) {
        androidx.compose.foundation.layout.BoxWithConstraints(Modifier.fillMaxWidth().height(68.dp)) {
            val itemWidth = maxWidth / 3
            val x by animateDpAsStateNav(itemWidth * tab.toFloat())
            Box(
                Modifier
                    .offset(x = x)
                    .width(itemWidth)
                    .fillMaxHeight()
                    .padding(8.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(lerp(C.Card, C.Acc, 0.25f))
                    .border(1.dp, lerp(C.Card, C.Acc, 0.5f), RoundedCornerShape(18.dp))
            )
            Row(Modifier.fillMaxSize()) {
                NavItem("Download", "down", tab == 0, Modifier.weight(1f)) { onTab(0) }
                NavItem("History", "clock", tab == 1, Modifier.weight(1f)) { onTab(1) }
                NavItem("Settings", "gear", tab == 2, Modifier.weight(1f)) { onTab(2) }
            }
        }
    }
}

@Composable
private fun animateDpAsStateNav(target: androidx.compose.ui.unit.Dp) =
    androidx.compose.animation.core.animateDpAsState(targetValue = target, label = "nav")

@Composable
private fun NavItem(label: String, glyph: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier.clickable(onClick = onClick),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Glyph(glyph, if (selected) C.Ink else C.Muted, 22.dp)
        Spacer(Modifier.height(3.dp))
        Text(label, color = if (selected) C.Ink else C.Muted, fontSize = 10.5.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal)
    }
}
