package com.lumo.android

import android.content.Context
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/** Wraps yt-dlp. All calls here block, so run them off the main thread. */
object YtEngine {
    @Volatile
    var ready = false

    fun init(context: Context): String = try {
        YoutubeDL.getInstance().init(context.applicationContext)
        FFmpeg.getInstance().init(context.applicationContext)
        ready = true
        "Download engine ready"
    } catch (e: Exception) {
        ready = false
        "Engine failed to start: ${e.message ?: "unknown error"}"
    }

    fun update(context: Context): String = try {
        "Engine update: " + YoutubeDL.getInstance().updateYoutubeDL(context.applicationContext)
    } catch (e: Exception) {
        "Engine update failed: ${e.message ?: "unknown error"}"
    }

    fun inspectVideo(url: String): VideoInfo {
        val json = dumpJson(url, playlist = false)
        val formats = json.optJSONArray("formats") ?: JSONArray()
        val duration = json.optDouble("duration", 0.0).let { if (it.isNaN()) 0.0 else it }

        var bestAudioBytes = 0.0
        val videoOnly = linkedMapOf<Int, Double>()
        val combined = linkedMapOf<Int, Double>()
        val mp4 = mutableSetOf<Int>()

        for (i in 0 until formats.length()) {
            val f = formats.optJSONObject(i) ?: continue
            val vcodec = f.optString("vcodec", "")
            val acodec = f.optString("acodec", "")
            val height = f.optInt("height", 0)
            val ext = f.optString("ext", "").lowercase(Locale.US)
            val bytes = formatBytes(f, duration)
            val hasAudio = acodec.isNotEmpty() && acodec != "none"
            val hasVideo = (vcodec.isNotEmpty() && vcodec != "none") || (vcodec.isEmpty() && height > 0)

            if (!hasVideo) {
                if (hasAudio && bytes > bestAudioBytes) bestAudioBytes = bytes
                continue
            }
            if (height <= 0) continue
            if (ext == "mp4") mp4.add(height)
            if (hasAudio) {
                combined[height] = maxOf(combined[height] ?: 0.0, bytes)
            } else {
                videoOnly[height] = maxOf(videoOnly[height] ?: 0.0, bytes)
            }
        }

        // Size of each height as yt-dlp will download it: video stream plus best audio stream when separate.
        val sizes = linkedMapOf<Int, Double>()
        for (h in (videoOnly.keys + combined.keys).toSortedSet()) {
            val v = videoOnly[h] ?: 0.0
            val total = if (v > 0.0) v + bestAudioBytes else (combined[h] ?: 0.0)
            sizes[h] = total / 1048576.0
        }

        val title = json.optString("title", "").ifBlank { "Video" }
        val extractor = json.optString("extractor_key", "").ifBlank { json.optString("extractor", "Source") }
        return VideoInfo(
            url = url,
            title = title,
            extractor = extractor,
            duration = if (duration > 0.0) formatDuration(duration.toLong()) else "",
            thumb = pickThumb(json),
            sizesMb = sizes,
            mp4Heights = mp4,
            subCodes = subtitleCodes(json)
        )
    }

    fun inspectPlaylist(url: String): PlaylistInfo {
        val json = dumpJson(url, playlist = true)
        val arr = json.optJSONArray("entries") ?: JSONArray()
        val entries = mutableListOf<PlaylistEntry>()
        for (i in 0 until arr.length()) {
            val e = arr.optJSONObject(i) ?: continue
            val eu = entryUrl(e)
            if (eu.isBlank()) continue
            val dur = e.optDouble("duration", 0.0)
            entries.add(
                PlaylistEntry(
                    url = eu,
                    title = e.optString("title", "").ifBlank { "Video ${entries.size + 1}" },
                    duration = if (!dur.isNaN() && dur > 0.0) formatDuration(dur.toLong()) else "",
                    thumb = pickThumb(e)
                )
            )
        }
        if (entries.isEmpty()) throw IllegalStateException("This playlist has no videos Lumo can read.")
        return PlaylistInfo(
            url = url,
            title = json.optString("title", "").ifBlank { "Playlist" },
            entries = entries
        )
    }

    fun friendly(raw: String?): String {
        val msg = raw.orEmpty()
        return when {
            msg.contains("429") -> "YouTube is rate-limiting this app. Wait a few minutes and try again."
            msg.contains("Sign in", true) || msg.contains("confirm you", true) ->
                "YouTube asked for sign-in to confirm you're not a bot."
            msg.contains("Video unavailable", true) || msg.contains("Private video", true) ->
                "This video is unavailable or private."
            msg.contains("Unsupported URL", true) -> "This link isn't supported."
            msg.contains("older", true) && msg.contains("yt-dlp", true) ->
                "The download engine is out of date. Update it in Settings."
            msg.isBlank() -> "Could not read this link."
            else -> "Could not read this link: ${msg.lineSequence().firstOrNull()?.take(140).orEmpty()}"
        }
    }

    private fun dumpJson(url: String, playlist: Boolean): JSONObject {
        val req = YoutubeDLRequest(url)
        req.addOption("--dump-single-json")
        req.addOption("--skip-download")
        req.addOption("--no-warnings")
        if (playlist) {
            req.addOption("--flat-playlist")
            req.addOption("--yes-playlist")
        } else {
            req.addOption("--no-playlist")
        }
        val raw = YoutubeDL.getInstance().execute(req).out.orEmpty()
        val start = raw.indexOf('{')
        val end = raw.lastIndexOf('}')
        if (start < 0 || end <= start) throw IllegalStateException("No video information returned")
        return JSONObject(raw.substring(start, end + 1))
    }

    /** Exact size when reported, otherwise bitrate × duration. Returns bytes. */
    private fun formatBytes(f: JSONObject, duration: Double): Double {
        val exact = f.optDouble("filesize", 0.0).takeIf { !it.isNaN() && it > 0.0 }
            ?: f.optDouble("filesize_approx", 0.0).takeIf { !it.isNaN() && it > 0.0 }
        if (exact != null) return exact
        val tbr = f.optDouble("tbr", 0.0).let { if (it.isNaN()) 0.0 else it }
        return if (tbr > 0.0 && duration > 0.0) tbr * 1000.0 / 8.0 * duration else 0.0
    }

    private fun subtitleCodes(json: JSONObject): Set<String> {
        val codes = mutableSetOf<String>()
        for (key in listOf("subtitles", "automatic_captions")) {
            val obj = json.optJSONObject(key) ?: continue
            val keys = obj.keys()
            while (keys.hasNext()) {
                val k = keys.next().lowercase(Locale.US).trim()
                if (k.isNotBlank()) {
                    codes.add(k)
                    codes.add(k.substringBefore("-"))
                }
            }
        }
        return codes
    }

    private fun pickThumb(json: JSONObject): String {
        val direct = json.optString("thumbnail", "")
        if (direct.startsWith("http")) return direct
        val arr = json.optJSONArray("thumbnails") ?: return ""
        for (i in arr.length() - 1 downTo 0) {
            val u = arr.optJSONObject(i)?.optString("url", "").orEmpty()
            if (u.startsWith("http")) return u
        }
        return ""
    }

    private fun entryUrl(e: JSONObject): String {
        val web = e.optString("webpage_url", "")
        if (web.startsWith("http")) return web
        val u = e.optString("url", "")
        if (u.startsWith("http")) return u
        val id = e.optString("id", "")
        return if (id.isNotBlank()) "https://www.youtube.com/watch?v=$id" else ""
    }
}
