package com.lumo.android

import android.Manifest
import android.content.BroadcastReceiver
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale
import java.util.concurrent.Executors

private val Bg = Color(0xFF050506)
private val Card = Color(0xFF0E0F14)
private val CardAlt = Color(0xFF171920)
private val Line = Color(0xFF242732)
private val Ink = Color(0xFFF4F6FB)
private val Muted = Color(0xFF8E97A8)
private val Accent = Color(0xFFFF647F)
private val Indigo = Color(0xFFFFB45F)
private val Purple = Color(0xFF8871FF)
private val Ok = Color(0xFF55D9A8)

private val BaseSubtitleOptions = listOf(
    "English" to "en",
    "Hindi" to "hi",
    "Marathi" to "mr"
)

class MainActivity : ComponentActivity() {
    private val worker = Executors.newSingleThreadExecutor()
    private val progress = mutableStateOf(ProgressState())
    private val engineReady = mutableStateOf(false)
    private val engineStatus = mutableStateOf("Starting download engine…")
    private val infoCache = java.util.concurrent.ConcurrentHashMap<String, VideoSummary>()

    // Hoisted wizard state so switching tabs (History / Settings) or receiving updates
    // never resets selections, inspected forecast, or active download progress.
    private val activeTab = mutableIntStateOf(0)
    private val playlistMode = mutableStateOf(false)
    private val urlInput = mutableStateOf("")
    private val inspectedInfo = mutableStateOf<VideoSummary?>(null)
    private val inspectError = mutableStateOf<String?>(null)
    private val wizardStage = mutableStateOf(Stage.Idle)
    private val selectedHeight = mutableIntStateOf(0)
    private val selectedSubs = mutableStateOf(setOf<String>())
    private val selectedContainer = mutableStateOf("mp4")
    private val downloadStarted = mutableStateOf(false)

    private val progressReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent == null) return
            val ongoing = intent.getBooleanExtra(DownloadService.EXTRA_PROGRESS_ONGOING, false)
            val success = intent.getBooleanExtra(DownloadService.EXTRA_PROGRESS_SUCCESS, false)
            val pct = intent.getIntExtra(DownloadService.EXTRA_PROGRESS_VALUE, 0)
            progress.value = ProgressState(
                message = intent.getStringExtra(DownloadService.EXTRA_PROGRESS_MESSAGE).orEmpty(),
                percent = pct,
                ongoing = ongoing,
                success = success || (!ongoing && pct >= 100),
                visible = true
            )
            if (downloadStarted.value && !ongoing) {
                wizardStage.value = Stage.Done
            }
        }
    }

    private val notificationPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)

        val filter = IntentFilter(DownloadService.ACTION_PROGRESS)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(progressReceiver, filter, RECEIVER_NOT_EXPORTED)
        else @Suppress("DEPRECATION") registerReceiver(progressReceiver, filter)

        restorePersistedDownloadState()
        handleIncomingShareIntent(intent)
        initEngine(autoUpdate = Settings.autoUpdate(this))

        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Accent, background = Bg, surface = Card)) {
                LumoApp()
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIncomingShareIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        restorePersistedDownloadState()
    }

    private fun restorePersistedDownloadState() {
        val prefs = getSharedPreferences("lumo_download_state", MODE_PRIVATE)
        val visible = prefs.getBoolean("visible", false)
        if (!visible) return
        val ongoing = prefs.getBoolean("ongoing", false)
        val success = prefs.getBoolean("success", false)
        val pct = prefs.getInt("progress", 0)
        val msg = prefs.getString("message", "").orEmpty()
        progress.value = ProgressState(
            message = msg,
            percent = pct,
            ongoing = ongoing,
            success = success || (!ongoing && pct >= 100),
            visible = true
        )
        if (ongoing) {
            downloadStarted.value = true
            wizardStage.value = Stage.Downloading
        } else if (downloadStarted.value && wizardStage.value == Stage.Downloading) {
            wizardStage.value = Stage.Done
        }
    }

    private fun handleIncomingShareIntent(incoming: Intent?) {
        if (incoming?.action != Intent.ACTION_SEND) return
        val sharedText = incoming.getStringExtra(Intent.EXTRA_TEXT).orEmpty().trim()
        val extracted = Regex("https?://\\S+").find(sharedText)?.value ?: sharedText
        if (extracted.isNotBlank() && validUrl(extracted)) {
            activeTab.intValue = 0
            urlInput.value = extracted
            resetWizardState(keepUrl = true)
            if (engineReady.value) inspectNow(extracted)
        }
    }

    private fun resetWizardState(keepUrl: Boolean = false) {
        if (!keepUrl) urlInput.value = ""
        inspectedInfo.value = null
        inspectError.value = null
        wizardStage.value = Stage.Idle
        selectedHeight.intValue = 0
        selectedSubs.value = emptySet()
        selectedContainer.value = "mp4"
        downloadStarted.value = false
        progress.value = ProgressState()
        getSharedPreferences("lumo_download_state", MODE_PRIVATE).edit().clear().apply()
    }

    private fun inspectNow(link: String) {
        val clean = link.trim()
        if (!validUrl(clean)) {
            inspectError.value = "Enter a valid http or https link"
            return
        }
        inspectError.value = null
        inspectedInfo.value = null
        wizardStage.value = Stage.Inspecting
        inspect(clean) { summary, err ->
            if (summary != null) {
                inspectedInfo.value = summary
                selectedHeight.intValue = 0
                // Pre-select English only if available, otherwise none (user can pick any)
                selectedSubs.value = if ("en" in summary.availableSubtitleCodes) setOf("en") else emptySet()
                wizardStage.value = Stage.Quality
            } else {
                inspectError.value = err
                wizardStage.value = Stage.Idle
            }
        }
    }

    private fun initEngine(autoUpdate: Boolean) {
        worker.execute {
            try {
                YoutubeDL.getInstance().init(applicationContext)
                FFmpeg.getInstance().init(applicationContext)
                engineReady.value = true
                engineStatus.value = "Download engine ready"
                val pendingUrl = urlInput.value.trim()
                if (pendingUrl.isNotBlank() && validUrl(pendingUrl) && wizardStage.value == Stage.Idle && inspectedInfo.value == null) {
                    runOnUiThread { inspectNow(pendingUrl) }
                }
                if (autoUpdate) runCatching { YoutubeDL.getInstance().updateYoutubeDL(applicationContext) }
            } catch (e: Exception) {
                engineReady.value = false
                engineStatus.value = "Engine failed to start: ${e.message ?: "unknown error"}"
            }
        }
    }

    fun updateEngineNow(onDone: (String) -> Unit) {
        worker.execute {
            val result = try {
                val status = YoutubeDL.getInstance().updateYoutubeDL(applicationContext)
                "Engine update: $status"
            } catch (e: Exception) {
                "Engine update failed: ${e.message ?: "unknown error"}"
            }
            runOnUiThread { onDone(result) }
        }
    }

    fun inspect(url: String, onResult: (VideoSummary?, String?) -> Unit) {
        worker.execute {
            try {
                infoCache[url]?.let { cached ->
                    runOnUiThread { onResult(cached, null) }
                    return@execute
                }
                if (!engineReady.value) throw IllegalStateException("Download engine is still starting")
                val info = YoutubeDL.getInstance().getInfo(url)
                val parsed = parseFormatsAndSizes(info)
                val availableSubs = extractSubtitleCodes(info)
                val summary = VideoSummary(
                    title = info.title?.takeIf { it.isNotBlank() } ?: "Video",
                    extractor = info.extractor ?: "Source",
                    duration = if (info.duration > 0) formatDuration(info.duration.toLong()) else "",
                    thumbnail = thumbnailOf(info),
                    sizesMb = parsed.sizesMb,
                    mp4Heights = parsed.mp4Heights,
                    availableSubtitleCodes = availableSubs
                )
                if (infoCache.size >= 20) infoCache.clear()
                infoCache[url] = summary
                runOnUiThread { onResult(summary, null) }
            } catch (e: Exception) {
                runOnUiThread { onResult(null, friendlyError(e.message)) }
            }
        }
    }

    fun startDownload(
        url: String,
        title: String,
        height: Int,
        requestedContainer: String,
        subs: String,
        playlist: Boolean,
        summary: VideoSummary?
    ) {
        // Subtitles embed cleanly into MKV; force MKV whenever subtitles are selected.
        val container = if (subs.isNotBlank()) "mkv" else requestedContainer

        // Build exact format selector:
        // - If user chose MP4 and the selected height actually has an MP4 stream (or Best), prefer MP4 video + m4a audio,
        //   with graceful fallback to best video at that exact height so 1440p/2160p WebM streams aren't silently downgraded!
        val format = when {
            height <= 0 && container == "mp4" ->
                "bestvideo[ext=mp4]+bestaudio[ext=m4a]/bestvideo+bestaudio/best[ext=mp4]/best"
            height <= 0 ->
                "bestvideo+bestaudio/best"
            container == "mp4" && (summary == null || height in summary.mp4Heights) ->
                "bestvideo[height=$height][ext=mp4]+bestaudio[ext=m4a]/bestvideo[height<=$height][ext=mp4]+bestaudio[ext=m4a]/bestvideo[height<=$height]+bestaudio/best[height<=$height]/best"
            else ->
                "bestvideo[height=$height]+bestaudio/bestvideo[height<=$height]+bestaudio/best[height<=$height]/best"
        }

        val intent = Intent(this, DownloadService::class.java).apply {
            action = DownloadService.ACTION_START
            putExtra(DownloadService.EXTRA_URL, url)
            putExtra(DownloadService.EXTRA_TITLE, title)
            putExtra(DownloadService.EXTRA_FORMAT, format)
            putExtra(DownloadService.EXTRA_CONTAINER, container)
            putExtra(DownloadService.EXTRA_SUBTITLE_LANGS, subs)
            putExtra(DownloadService.EXTRA_PLAYLIST, playlist)
        }
        ContextCompat.startForegroundService(this, intent)
        progress.value = ProgressState("Starting download…", 0, ongoing = true, success = false, visible = true)
    }

    fun cancelDownload() {
        startService(Intent(this, DownloadService::class.java).setAction(DownloadService.ACTION_CANCEL))
    }

    fun clipboardText(): String {
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        return cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(this)?.toString().orEmpty()
    }

    fun validUrl(s: String): Boolean = runCatching {
        val u = Uri.parse(s)
        (u.scheme == "http" || u.scheme == "https") && !u.host.isNullOrBlank()
    }.getOrDefault(false)

    private fun friendlyError(raw: String?): String {
        val msg = raw.orEmpty()
        return when {
            msg.contains("429") -> "YouTube is rate-limiting this app. Wait a few minutes and try again."
            msg.contains("Sign in", true) || msg.contains("confirm your age", true) ->
                "This video needs a signed-in account, which Lumo can't use yet."
            msg.contains("Video unavailable", true) || msg.contains("Private video", true) ->
                "This video is unavailable or private."
            msg.contains("Unsupported URL", true) -> "This link isn't supported."
            msg.contains("yt-dlp", true) && msg.contains("older", true) ->
                "The download engine is out of date. Update it in Settings."
            msg.isBlank() -> "Could not read this link."
            else -> "Could not read this link: ${msg.lineSequence().firstOrNull()?.take(140).orEmpty()}"
        }
    }

    private data class ParsedFormats(
        val sizesMb: Map<Int, Double>,
        val mp4Heights: Set<Int>
    )

    private fun parseFormatsAndSizes(info: Any): ParsedFormats {
        val videoMaxByHeight = linkedMapOf<Int, Double>()
        val mp4Heights = mutableSetOf<Int>()
        var bestAudioBytes = 0.0
        val durationSec = try {
            (info.javaClass.getMethod("getDuration").invoke(info) as? Number)?.toDouble() ?: 0.0
        } catch (_: Exception) { 0.0 }

        try {
            val formats = info.javaClass.getMethod("getFormats").invoke(info) as? List<*> ?: return ParsedFormats(emptyMap(), emptySet())
            formats.forEach { f ->
                if (f == null) return@forEach
                try {
                    val h = (f.javaClass.getMethod("getHeight").invoke(f) as? Number)?.toInt() ?: 0
                    val ext = (try { f.javaClass.getMethod("getExt").invoke(f) as? String } catch (_: Exception) { null }).orEmpty().lowercase()
                    val vcodec = (try { f.javaClass.getMethod("getVcodec").invoke(f) as? String } catch (_: Exception) { null }).orEmpty()
                    val acodec = (try { f.javaClass.getMethod("getAcodec").invoke(f) as? String } catch (_: Exception) { null }).orEmpty()

                    var bytes = listOf("getFileSize", "getFileSizeApprox", "getFilesize", "getFilesizeApprox")
                        .firstNotNullOfOrNull { name ->
                            try { (f.javaClass.getMethod(name).invoke(f) as? Number)?.toDouble() } catch (_: Exception) { null }
                        } ?: 0.0

                    // Estimate size from bitrate * duration when exact file size is missing
                    if (bytes <= 0.0 && durationSec > 0.0) {
                        val tbr = listOf("getTbr", "getVbr", "getAbr").firstNotNullOfOrNull { name ->
                            try { (f.javaClass.getMethod(name).invoke(f) as? Number)?.toDouble() } catch (_: Exception) { null }
                        } ?: 0.0
                        if (tbr > 0.0) {
                            bytes = (tbr * 1000.0 / 8.0) * durationSec
                        }
                    }

                    val isAudioOnly = h <= 0 && (vcodec == "none" || acodec != "none")
                    if (isAudioOnly) {
                        if (bytes > bestAudioBytes) bestAudioBytes = bytes
                    } else if (h > 0) {
                        if (ext == "mp4") mp4Heights.add(h)
                        // Ensure key exists even if size is 0 so resolution still shows up
                        val prev = videoMaxByHeight[h] ?: 0.0
                        if (bytes > prev || h !in videoMaxByHeight) {
                            videoMaxByHeight[h] = maxOf(prev, bytes)
                        }
                    }
                } catch (_: Exception) { }
            }
        } catch (_: Exception) { }

        val out = linkedMapOf<Int, Double>()
        for ((h, vBytes) in videoMaxByHeight) {
            out[h] = if (vBytes > 0.0) (vBytes + bestAudioBytes) / 1048576.0 else 0.0
        }
        return ParsedFormats(out, mp4Heights)
    }

    private fun extractSubtitleCodes(info: Any): Set<String> {
        val codes = mutableSetOf<String>()
        listOf("getSubtitles", "getAutomaticCaptions", "getAutomatic_captions").forEach { methodName ->
            try {
                val map = info.javaClass.getMethod(methodName).invoke(info) as? Map<*, *>
                map?.keys?.forEach { key ->
                    val k = key?.toString()?.lowercase()?.trim().orEmpty()
                    if (k.isNotBlank()) {
                        codes.add(k)
                        codes.add(k.substringBefore("-"))
                    }
                }
            } catch (_: Exception) { }
        }
        return codes
    }

    private fun thumbnailOf(info: Any): String = try {
        listOf("getThumbnail", "getThumbnailUrl").firstNotNullOfOrNull { name ->
            try { (info.javaClass.getMethod(name).invoke(info) as? String)?.takeIf { it.startsWith("http") } } catch (_: Exception) { null }
        }.orEmpty()
    } catch (_: Exception) { "" }

    private fun formatDuration(s: Long): String {
        val hrs = s / 3600
        val mins = (s % 3600) / 60
        val secs = s % 60
        return if (hrs > 0) "%d:%02d:%02d".format(hrs, mins, secs) else "%d:%02d".format(mins, secs)
    }

    override fun onDestroy() {
        runCatching { unregisterReceiver(progressReceiver) }
        worker.shutdown()
        super.onDestroy()
    }

    // ---------- UI ----------

    @Composable
    private fun LumoApp() {
        var tab by activeTab
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF0A0B0F)) {
                    listOf("Download", "History", "Settings").forEachIndexed { i, label ->
                        NavigationBarItem(
                            selected = tab == i,
                            onClick = { tab = i },
                            icon = { Text(listOf("⬇", "🕘", "⚙")[i], fontSize = 18.sp) },
                            label = { Text(label, fontSize = 12.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Accent,
                                selectedTextColor = Accent,
                                indicatorColor = Color(0xFF2A1A20),
                                unselectedIconColor = Muted,
                                unselectedTextColor = Muted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            Box(Modifier.padding(padding).fillMaxSize().background(Bg)) {
                when (tab) {
                    0 -> DownloadScreen()
                    1 -> HistoryScreen()
                    else -> SettingsScreen()
                }
            }
        }
    }

    @Composable
    private fun DownloadScreen() {
        val ready by engineReady
        val prog by progress
        var isPlaylist by playlistMode
        var url by urlInput
        val info by inspectedInfo
        val error by inspectError
        var stage by wizardStage
        var height by selectedHeight
        var subs by selectedSubs
        var container by selectedContainer
        var started by downloadStarted

        // When the service reports it is no longer busy, show the finished state.
        LaunchedEffect(prog.ongoing, prog.visible) {
            if (started && prog.visible && !prog.ongoing) stage = Stage.Done
        }

        // System back button moves one page back instead of leaving the app.
        BackHandler(enabled = stage == Stage.Quality || stage == Stage.Options || stage == Stage.Inspecting) {
            when (stage) {
                Stage.Options -> stage = Stage.Quality
                else -> resetWizardState(keepUrl = true)
            }
        }

        val page = when (stage) {
            Stage.Idle, Stage.Inspecting -> 0
            Stage.Quality -> 1
            Stage.Options -> 2
            Stage.Downloading, Stage.Done -> 3
        }

        AnimatedContent(
            targetState = page,
            transitionSpec = {
                if (targetState > initialState)
                    (slideInHorizontally { it / 4 } + fadeIn()) togetherWith (slideOutHorizontally { -it / 4 } + fadeOut())
                else
                    (slideInHorizontally { -it / 4 } + fadeIn()) togetherWith (slideOutHorizontally { it / 4 } + fadeOut())
            },
            label = "download-pages"
        ) { current ->
            when (current) {
                // ---------------- Page 1: paste link ----------------
                0 -> Column(
                    Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 18.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier.size(44.dp).clip(RoundedCornerShape(14.dp))
                                .background(Brush.linearGradient(listOf(Accent, Purple))),
                            contentAlignment = Alignment.Center
                        ) { Text("L", color = Ink, fontWeight = FontWeight.Bold, fontSize = 20.sp) }
                        Spacer(Modifier.width(12.dp))
                        Text("Download", color = Ink, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                    }

                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(CardAlt).padding(4.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Segment("Video", !isPlaylist, Modifier.weight(1f)) {
                            if (isPlaylist) {
                                isPlaylist = false
                                resetWizardState(keepUrl = true)
                            }
                        }
                        Segment("Playlist", isPlaylist, Modifier.weight(1f)) {
                            if (!isPlaylist) {
                                isPlaylist = true
                                resetWizardState(keepUrl = true)
                            }
                        }
                    }

                    Text(
                        if (isPlaylist) "Paste a playlist link" else "Paste a video link",
                        color = Ink, fontWeight = FontWeight.Bold, fontSize = 18.sp
                    )
                    Text("Lumo will find the video and show your quality options.", color = Muted, fontSize = 13.sp)

                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = url,
                            onValueChange = {
                                url = it.trim()
                                if (stage != Stage.Idle || error != null || info != null) {
                                    resetWizardState(keepUrl = true)
                                }
                            },
                            modifier = Modifier.weight(1f),
                            enabled = stage != Stage.Inspecting,
                            placeholder = {
                                Text(if (isPlaylist) "Paste a playlist link…" else "Paste a video link…", color = Muted)
                            },
                            singleLine = true,
                            trailingIcon = {
                                if (url.isNotEmpty() && stage != Stage.Inspecting)
                                    TextButton(onClick = { resetWizardState(keepUrl = false) }) { Text("✕", color = Muted) }
                            },
                            shape = RoundedCornerShape(16.dp)
                        )
                        Button(
                            onClick = {
                                val pasted = clipboardText().trim()
                                if (pasted.isBlank()) {
                                    inspectError.value = "Clipboard is empty"
                                } else {
                                    url = pasted
                                    resetWizardState(keepUrl = true)
                                    if (ready) inspectNow(pasted)
                                }
                            },
                            enabled = stage != Stage.Inspecting,
                            colors = ButtonDefaults.buttonColors(containerColor = Accent),
                            shape = RoundedCornerShape(16.dp),
                            contentPadding = PaddingValues(horizontal = 18.dp, vertical = 16.dp)
                        ) { Text("Paste", fontWeight = FontWeight.Bold) }
                    }

                    error?.let { Text(it, color = Accent, fontSize = 13.sp) }

                    if (stage == Stage.Inspecting) {
                        LumoCard {
                            Text(if (isPlaylist) "Loading playlist…" else "Finding your video…", color = Ink, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                            Text("Connecting to the video source", color = Muted, fontSize = 13.sp)
                            Spacer(Modifier.height(8.dp))
                            LinearProgressIndicator(
                                modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                                color = Purple, trackColor = Line
                            )
                        }
                    } else {
                        Button(
                            onClick = { inspectNow(url) },
                            enabled = url.isNotBlank() && ready,
                            modifier = Modifier.fillMaxWidth().height(52.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Accent, disabledContainerColor = CardAlt),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Text(
                                if (!ready) "Starting download engine…" else if (isPlaylist) "Check playlist" else "Check link",
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                // ---------------- Page 2: quality and size ----------------
                1 -> info?.let { v ->
                    PageFrame(
                        step = 2, title = "Choose quality",
                        subtitle = "The size is an estimate and can vary slightly.",
                        onBack = { resetWizardState(keepUrl = true) },
                        bottom = {
                            Button(
                                onClick = { stage = Stage.Options },
                                modifier = Modifier.fillMaxWidth().height(54.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Accent),
                                shape = RoundedCornerShape(16.dp)
                            ) { Text("Continue  →", fontWeight = FontWeight.Bold, fontSize = 16.sp) }
                        }
                    ) {
                        LumoCard {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                                RemoteThumb(v.thumbnail, Modifier.size(width = 120.dp, height = 68.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(v.title, color = Ink, fontWeight = FontWeight.Bold, fontSize = 16.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                    Text(listOf(v.extractor, v.duration).filter { it.isNotBlank() }.joinToString(" · "), color = Muted, fontSize = 13.sp)
                                }
                            }
                        }
                        Label("VIDEO QUALITY")
                        qualityOptions(v, isPlaylist).forEach { (label, h, sizeText) ->
                            QualityRow(label, sizeText, selected = height == h) { height = h }
                        }
                    }
                }

                // ---------------- Page 3: subtitles and mp4 / mkv ----------------
                2 -> info?.let { v ->
                    val effectiveContainer = if (subs.isNotEmpty()) "mkv" else container
                    val needsMkvForQuality = height > 0 && height !in v.mp4Heights && v.mp4Heights.isNotEmpty()
                    PageFrame(
                        step = 3, title = "Make it yours",
                        subtitle = "Choose subtitles and the file format.",
                        onBack = { stage = Stage.Quality },
                        bottom = {
                            Button(
                                onClick = {
                                    started = true
                                    stage = Stage.Downloading
                                    startDownload(
                                        url = url,
                                        title = v.title,
                                        height = height,
                                        requestedContainer = container,
                                        subs = subs.joinToString(","),
                                        playlist = isPlaylist,
                                        summary = v
                                    )
                                },
                                enabled = ready,
                                modifier = Modifier.fillMaxWidth().height(56.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Accent),
                                shape = RoundedCornerShape(18.dp)
                            ) { Text(if (isPlaylist) "Download playlist ↓" else "Download video ↓", fontWeight = FontWeight.Bold, fontSize = 17.sp) }
                        }
                    ) {
                        LumoCard {
                            val chosenQuality = if (height == 0) "Best available" else "${height}p"
                            val chosenSubs = if (subs.isEmpty()) "No subtitles" else subs.joinToString(", ") { it.uppercase(Locale.US) }
                            Text(v.title, color = Ink, fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(
                                "$chosenQuality · ${effectiveContainer.uppercase(Locale.US)} · $chosenSubs",
                                color = Muted, fontSize = 12.sp
                            )
                        }
                        Label("SUBTITLES")
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            BaseSubtitleOptions.forEach { (label, code) ->
                                LumoChip(label, code in subs) {
                                    subs = if (code in subs) subs - code else subs + code
                                }
                            }
                        }
                        if (v.availableSubtitleCodes.isNotEmpty()) {
                            val matched = BaseSubtitleOptions.filter { it.second in v.availableSubtitleCodes }.map { it.first }
                            Text(
                                if (matched.isNotEmpty()) "Detected tracks: ${matched.joinToString(", ")}"
                                else "Other subtitle tracks detected; selected tracks will fall back to auto-captions if available.",
                                color = Muted, fontSize = 12.sp
                            )
                        }
                        Spacer(Modifier.height(6.dp))
                        Label("FILE FORMAT")
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            LumoChip("MP4 · Compatible", effectiveContainer == "mp4") {
                                subs = emptySet()
                                container = "mp4"
                            }
                            LumoChip("MKV · Flexible", effectiveContainer == "mkv") {
                                container = "mkv"
                            }
                        }
                        if (subs.isNotEmpty()) {
                            Text("Subtitles are embedded, so the file will be saved as MKV. Tap MP4 to clear subtitles.", color = Muted, fontSize = 12.sp)
                        } else if (needsMkvForQuality && effectiveContainer == "mp4") {
                            Text("${height}p is only offered as WebM/MKV by this source; Lumo will keep ${height}p quality.", color = Muted, fontSize = 12.sp)
                        }
                    }
                }

                // ---------------- Page 4: thumbnail + progress bar ----------------
                else -> {
                    val v = info
                    val finished = stage == Stage.Done
                    val success = finished && (prog.success || prog.percent >= 100)
                    val statusColor = when {
                        success -> Ok
                        finished -> Accent
                        else -> Indigo
                    }
                    Column(
                        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 18.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Text("Step 4 of 4", color = Muted, fontSize = 12.sp, letterSpacing = 1.sp)
                        Text(
                            when { success -> "Download complete"; finished -> "Download stopped"; else -> "Downloading" },
                            color = Ink, fontSize = 28.sp, fontWeight = FontWeight.Bold
                        )
                        RemoteThumb(
                            v?.thumbnail.orEmpty(),
                            Modifier.fillMaxWidth().aspectRatio(16f / 9f),
                            corner = 18.dp
                        )
                        Text(v?.title ?: "Download", color = Ink, fontWeight = FontWeight.Bold, fontSize = 18.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        LumoCard {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    when { success -> "Completed"; finished -> "Not finished"; else -> "Downloading" },
                                    color = Muted, fontSize = 13.sp, modifier = Modifier.weight(1f)
                                )
                                Text(
                                    if (success) "100%" else if (finished) "—" else "${prog.percent}%",
                                    color = statusColor, fontWeight = FontWeight.Bold, fontSize = 20.sp
                                )
                            }
                            Spacer(Modifier.height(4.dp))
                            LinearProgressIndicator(
                                progress = { if (success) 1f else prog.percent / 100f },
                                modifier = Modifier.fillMaxWidth().height(12.dp).clip(RoundedCornerShape(6.dp)),
                                color = if (success) Ok else Purple,
                                trackColor = Line
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(prog.message, color = Muted, fontSize = 12.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
                        }
                        if (!finished) {
                            OutlinedButton(
                                onClick = { cancelDownload() },
                                modifier = Modifier.fillMaxWidth().height(52.dp),
                                shape = RoundedCornerShape(16.dp)
                            ) { Text("Cancel download", color = Ink) }
                        } else {
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                if (success) {
                                    OutlinedButton(
                                        onClick = { openDownloadFolder(this@MainActivity) },
                                        modifier = Modifier.weight(1f).height(52.dp),
                                        shape = RoundedCornerShape(16.dp)
                                    ) { Text("Open folder", color = Ink) }
                                }
                                Button(
                                    onClick = { resetWizardState(keepUrl = false) },
                                    modifier = Modifier.weight(1f).height(52.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = Accent),
                                    shape = RoundedCornerShape(16.dp)
                                ) { Text(if (isPlaylist) "New playlist" else "New video", fontWeight = FontWeight.Bold) }
                            }
                        }
                    }
                }
            }
        }
    }

    /** A full-screen wizard page: step label, back arrow, title, scrolling content and a pinned bottom action. */
    @Composable
    private fun PageFrame(
        step: Int,
        title: String,
        subtitle: String,
        onBack: () -> Unit,
        bottom: @Composable () -> Unit,
        content: @Composable ColumnScope.() -> Unit
    ) {
        Column(Modifier.fillMaxSize().padding(horizontal = 20.dp).padding(top = 14.dp, bottom = 14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).background(CardAlt).clickable(onClick = onBack),
                    contentAlignment = Alignment.Center
                ) { Text("←", color = Ink, fontSize = 18.sp) }
                Spacer(Modifier.width(12.dp))
                Text("Step $step of 4", color = Muted, fontSize = 12.sp, letterSpacing = 1.sp)
            }
            Spacer(Modifier.height(14.dp))
            Text(title, color = Ink, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Text(subtitle, color = Muted, fontSize = 13.sp)
            Spacer(Modifier.height(14.dp))
            Column(
                Modifier.weight(1f).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                content = content
            )
            Spacer(Modifier.height(10.dp))
            bottom()
        }
    }

    private fun openDownloadFolder(context: Context) {
        val intent = Intent(Intent.ACTION_VIEW).setDataAndType(
            Uri.parse("content://com.android.externalstorage.documents/document/primary%3ADownload%2FLumo"),
            "vnd.android.document/directory"
        )
        try { context.startActivity(intent) } catch (_: Exception) {
            try {
                context.startActivity(Intent(android.app.DownloadManager.ACTION_VIEW_DOWNLOADS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (_: Exception) {
                Toast.makeText(context, "Open Files app → Downloads → Lumo", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun openHistoryMedia(context: Context, item: HistoryItem) {
        val uri = when {
            item.uri.isNotBlank() -> runCatching { Uri.parse(item.uri) }.getOrNull()
            item.path.isNotBlank() -> runCatching {
                val f = File(item.path)
                if (f.exists()) FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", f) else null
            }.getOrNull()
            else -> null
        }
        if (uri == null) {
            openDownloadFolder(context)
            return
        }
        val mime = if (item.location.endsWith(".mkv", true)) "video/x-matroska" else "video/*"
        val viewIntent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, mime)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            context.startActivity(viewIntent)
        } catch (_: Exception) {
            openDownloadFolder(context)
        }
    }

    private fun qualityOptions(v: VideoSummary, playlist: Boolean = false): List<Triple<String, Int, String>> {
        if (playlist) return listOf(
            Triple("Best available", 0, "Size varies"),
            Triple("1080p", 1080, "Size varies"),
            Triple("720p", 720, "Size varies"),
            Triple("480p", 480, "Size varies"),
            Triple("360p", 360, "Size varies")
        )
        val heights = v.sizesMb.keys.filter { it <= 2160 }.sortedDescending()
        val fallback = if (heights.isEmpty()) listOf(1080, 720, 480, 360) else heights
        val bestSize = v.sizesMb.values.filter { it > 0.0 }.maxOrNull()
        val out = mutableListOf(
            Triple("Best available", 0, bestSize?.let { "~${"%.0f".format(Locale.US, it)} MB" } ?: "Auto")
        )
        fallback.forEach { h ->
            val mb = v.sizesMb[h] ?: 0.0
            out.add(Triple("${h}p", h, if (mb > 0.0) "~${"%.0f".format(Locale.US, mb)} MB" else "Available"))
        }
        return out
    }

    @Composable
    private fun HistoryScreen() {
        val context = LocalContext.current
        var history by remember { mutableStateOf(historyList(context)) }
        Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("History", color = Ink, fontSize = 30.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                TextButton(onClick = { HistoryStore.clear(context); history = emptyList() }) { Text("Clear", color = Muted) }
            }
            if (history.isEmpty()) Text("No downloads yet.", color = Muted)
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(history) { item ->
                    val isDone = item.status.startsWith("Completed")
                    Column(
                        Modifier.fillMaxWidth()
                            .clip(RoundedCornerShape(18.dp))
                            .background(Card)
                            .border(1.dp, Line, RoundedCornerShape(18.dp))
                            .clickable(enabled = isDone) { openHistoryMedia(context, item) }
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(item.title, color = Ink, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text(item.status, color = if (isDone) Ok else Muted, fontSize = 13.sp)
                        Text(
                            if (isDone) "${item.location} · Tap to open" else item.location,
                            color = Muted, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }
    }

    @Composable
    private fun SettingsScreen() {
        val context = LocalContext.current
        val status by engineStatus
        var auto by remember { mutableStateOf(Settings.autoUpdate(context)) }
        var message by remember { mutableStateOf("") }
        Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text("Settings", color = Ink, fontSize = 30.sp, fontWeight = FontWeight.Bold)
            LumoCard {
                Text(status, color = Muted, fontSize = 13.sp)
            }
            LumoCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Update download engine on start", color = Ink, fontWeight = FontWeight.Bold)
                        Text("Keeps yt-dlp current, which YouTube changes often.", color = Muted, fontSize = 13.sp)
                    }
                    Switch(checked = auto, onCheckedChange = { auto = it; Settings.setAutoUpdate(context, it) })
                }
            }
            Button(
                onClick = {
                    message = "Updating…"
                    updateEngineNow { message = it }
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Accent),
                shape = RoundedCornerShape(16.dp)
            ) { Text("Update download engine now", fontWeight = FontWeight.Bold) }
            if (message.isNotBlank()) Text(message, color = Muted, fontSize = 13.sp)
            Text("Lumo 2.1.0 · Finished files are saved to Downloads/Lumo.", color = Muted, fontSize = 12.sp)
        }
    }

    // ---------- small pieces ----------

    @Composable
    private fun LumoCard(content: @Composable ColumnScope.() -> Unit) {
        Column(
            Modifier.fillMaxWidth()
                .clip(RoundedCornerShape(18.dp))
                .background(Card)
                .border(1.dp, Line, RoundedCornerShape(18.dp))
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
            content = content
        )
    }

    @Composable
    private fun Segment(label: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
        Box(
            modifier
                .clip(RoundedCornerShape(14.dp))
                .background(if (selected) Color(0xFF2A1A20) else Color.Transparent)
                .clickable(onClick = onClick)
                .padding(vertical = 14.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(label, color = if (selected) Ink else Muted, fontWeight = FontWeight.Bold)
        }
    }

    @Composable
    private fun QualityRow(label: String, sizeText: String, selected: Boolean, onClick: () -> Unit) {
        Row(
            Modifier.fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(if (selected) Color(0xFF2B2650) else CardAlt)
                .border(1.dp, if (selected) Purple else Line, RoundedCornerShape(14.dp))
                .clickable(onClick = onClick)
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            RadioButton(selected = selected, onClick = null, colors = RadioButtonDefaults.colors(selectedColor = Accent))
            Spacer(Modifier.width(8.dp))
            Text(label, color = Ink, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Text(sizeText, color = Muted, fontSize = 13.sp)
        }
    }

    @Composable
    private fun LumoChip(label: String, selected: Boolean, onClick: () -> Unit) {
        Box(
            Modifier
                .clip(RoundedCornerShape(16.dp))
                .background(if (selected) Color(0xFF2B2650) else CardAlt)
                .border(1.dp, if (selected) Purple else Line, RoundedCornerShape(16.dp))
                .clickable(onClick = onClick)
                .padding(horizontal = 14.dp, vertical = 12.dp)
        ) {
            Text((if (selected) "✓ " else "") + label, color = if (selected) Ink else Muted, fontSize = 14.sp)
        }
    }

    @Composable
    private fun Label(text: String) {
        Text(text, color = Muted, fontSize = 12.sp, letterSpacing = 1.sp)
    }

    @Composable
    private fun RemoteThumb(url: String, modifier: Modifier, corner: androidx.compose.ui.unit.Dp = 12.dp) {
        val bitmap by produceState<android.graphics.Bitmap?>(initialValue = null, key1 = url) {
            value = if (url.isBlank()) null else withContext(Dispatchers.IO) { fetchBitmap(url) }
        }
        Box(modifier.clip(RoundedCornerShape(corner)).background(CardAlt), contentAlignment = Alignment.Center) {
            bitmap?.let {
                Image(
                    bitmap = it.asImageBitmap(),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
    }

    private val thumbCache = object : android.util.LruCache<String, android.graphics.Bitmap>(40) {}

    private fun fetchBitmap(url: String): android.graphics.Bitmap? {
        thumbCache.get(url)?.let { return it }
        return try {
            val conn = java.net.URL(url).openConnection() as java.net.HttpURLConnection
            conn.connectTimeout = 8000
            conn.readTimeout = 8000
            val bmp = conn.inputStream.use { android.graphics.BitmapFactory.decodeStream(it) }
            if (bmp != null) thumbCache.put(url, bmp)
            bmp
        } catch (_: Exception) { null }
    }

    private fun historyList(context: Context): List<HistoryItem> {
        val arr: JSONArray = HistoryStore.items(context)
        return (0 until arr.length()).mapNotNull { i ->
            val o: JSONObject = arr.optJSONObject(i) ?: return@mapNotNull null
            HistoryItem(
                title = o.optString("title"),
                status = o.optString("status"),
                location = o.optString("location"),
                uri = o.optString("uri"),
                path = o.optString("path")
            )
        }
    }
}

enum class Stage { Idle, Inspecting, Quality, Options, Downloading, Done }

data class ProgressState(
    val message: String = "",
    val percent: Int = 0,
    val ongoing: Boolean = false,
    val success: Boolean = false,
    val visible: Boolean = false
)

data class VideoSummary(
    val title: String,
    val extractor: String,
    val duration: String,
    val thumbnail: String,
    val sizesMb: Map<Int, Double>,
    val mp4Heights: Set<Int> = emptySet(),
    val availableSubtitleCodes: Set<String> = emptySet()
)

data class HistoryItem(val title: String, val status: String, val location: String, val uri: String, val path: String)

object Settings {
    private const val PREFS = "lumo_settings"
    fun autoUpdate(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean("auto_update", false)
    fun setAutoUpdate(context: Context, value: Boolean) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean("auto_update", value).apply()
}
