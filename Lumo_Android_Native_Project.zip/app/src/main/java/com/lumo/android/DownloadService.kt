package com.lumo.android

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.IBinder
import android.provider.MediaStore
import androidx.core.app.NotificationCompat
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import com.yausername.ffmpeg.FFmpeg
import java.io.File
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import android.webkit.MimeTypeMap

class DownloadService : Service() {
    private val executor = Executors.newSingleThreadExecutor()
    private val isRunning = AtomicBoolean(false)
    private val cancelRequested = AtomicBoolean(false)
    private val processId = "lumo-main-download"
    private val notificationId = 701

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_CANCEL -> {
                cancelRequested.set(true)
                try { YoutubeDL.getInstance().destroyProcessById(processId) } catch (_: Exception) { }
                if (isRunning.get()) {
                    updateNotification("Cancelling download…", 0, true)
                } else {
                    stopSelf(startId)
                }
                return START_NOT_STICKY
            }
            ACTION_START -> {
                if (!isRunning.compareAndSet(false, true)) {
                    return START_NOT_STICKY
                }
                val url = intent.getStringExtra(EXTRA_URL).orEmpty()
                val title = intent.getStringExtra(EXTRA_TITLE).orEmpty().ifBlank { "Lumo download" }
                val format = intent.getStringExtra(EXTRA_FORMAT).orEmpty().ifBlank { "best" }
                val container = intent.getStringExtra(EXTRA_CONTAINER).orEmpty().ifBlank { "mp4" }
                val subtitleLangs = intent.getStringExtra(EXTRA_SUBTITLE_LANGS).orEmpty()
                val playlist = intent.getBooleanExtra(EXTRA_PLAYLIST, false)
                cancelRequested.set(false)
                startForeground(notificationId, buildNotification("Starting download…", 0, true))
                executor.execute { runDownload(url, title, format, container, subtitleLangs, playlist) }
            }
        }
        return START_NOT_STICKY
    }

    private fun runDownload(
        url: String,
        title: String,
        format: String,
        container: String,
        subtitleLangs: String,
        playlist: Boolean
    ) {
        var workFolder: File? = null
        var subtitlesSkipped = false
        val existingNames = mutableSetOf<String>()
        try {
            YoutubeDL.getInstance().init(applicationContext)
            FFmpeg.getInstance().init(applicationContext)

            val base = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: filesDir
            val folder = File(base, "LumoWork")
            if (!folder.exists() && !folder.mkdirs()) throw IllegalStateException("Cannot create Lumo working folder")
            workFolder = folder
            folder.listFiles()?.forEach { existingNames.add(it.name) }

            val onProgress: (Float, Long, String) -> Unit = { progressValue, eta, line ->
                val percent = progressValue.toInt().coerceIn(0, 100)
                val etaText = if (eta > 0) " · ${eta}s left" else ""
                val lineText = friendlyLine(line).ifBlank { "Downloading $title" }
                updateNotification("$lineText$etaText", percent, true)
            }

            updateNotification(if (playlist) "Preparing playlist…" else "Preparing $title…", 0, true)
            var subsToUse = subtitleLangs
            var attempts = 0
            while (true) {
                try {
                    runYtDlp(url, format, container, subsToUse, playlist, folder, onProgress)
                    break
                } catch (e: Exception) {
                    if (cancelRequested.get() || subsToUse.isBlank()) throw e
                    attempts++
                    if (attempts < 3) {
                        updateNotification("YouTube limited subtitles. Retrying in 30 seconds…", 0, true)
                        Thread.sleep(30_000)
                        if (cancelRequested.get()) throw e
                    } else {
                        updateNotification("Subtitles skipped (YouTube limited them). Downloading video…", 0, true)
                        subtitlesSkipped = true
                        subsToUse = ""
                    }
                }
            }

            if (cancelRequested.get()) {
                HistoryStore.add(this, title, url, "Cancelled", folder.absolutePath)
                updateNotification("Download cancelled", 0, false)
                return
            }

            val mediaFiles = folder.listFiles()?.filter { file ->
                file.isFile && file.name !in existingNames && isMediaFile(file)
            }?.sortedBy { it.lastModified() }.orEmpty()

            if (mediaFiles.isEmpty()) {
                HistoryStore.add(this, title, url, "Failed: no finished media file was found", folder.absolutePath)
                updateNotification("yt-dlp finished but no completed media file was found", 0, false)
                return
            }

            var savedCount = 0
            for (file in mediaFiles) {
                if (cancelRequested.get()) break
                val published = publishToDownloads(file)
                val savedUri = published?.toString().orEmpty()
                val savedPath = if (published == null) file.absolutePath else ""
                val displayedLocation = if (published != null) "Downloads/Lumo/${file.name}" else file.absolutePath
                HistoryStore.add(
                    this,
                    file.nameWithoutExtension,
                    url,
                    "Completed",
                    displayedLocation,
                    savedUri,
                    savedPath
                )
                if (published != null) file.delete()
                savedCount++
            }

            if (cancelRequested.get()) {
                updateNotification("Download cancelled · $savedCount file(s) saved", 0, false)
            } else {
                updateNotification(
                    if (savedCount == 1) "Download completed" + (if (subtitlesSkipped) " · subtitles skipped" else "") + " · saved to Downloads/Lumo" else "$savedCount downloads completed · saved to Downloads/Lumo",
                    100,
                    false
                )
            }
        } catch (e: Exception) {
            val cancelled = cancelRequested.get()
            val message = if (cancelled) "Download cancelled" else "Failed: ${e.message ?: "Unknown download error"}"
            HistoryStore.add(this, title, url, if (cancelled) "Cancelled" else message, workFolder?.absolutePath.orEmpty())
            updateNotification(if (cancelled) "Download cancelled" else "Download failed: ${e.message ?: "Unknown error"}", 0, false)
        } finally {
            isRunning.set(false)
            stopForeground(STOP_FOREGROUND_DETACH)
            stopSelf()
        }
    }

    private fun runYtDlp(
        url: String,
        format: String,
        container: String,
        subtitleLangs: String,
        playlist: Boolean,
        folder: File,
        onProgress: (Float, Long, String) -> Unit
    ) {
        val request = YoutubeDLRequest(url)
        request.addOption("--no-mtime")
        request.addOption("--newline")
        request.addOption("--no-overwrites")
        request.addOption("-f", format)
        request.addOption("--merge-output-format", container)
        request.addOption("-o", File(folder, "%(title).120B [%(id)s].%(ext)s").absolutePath)
        if (playlist) {
            request.addOption("--yes-playlist")
            request.addOption("--ignore-errors")
        } else {
            request.addOption("--no-playlist")
        }
        if (subtitleLangs.isNotBlank()) {
            request.addOption("--write-subs")
            request.addOption("--write-auto-subs")
            request.addOption("--sub-langs", subtitleLangs)
            request.addOption("--embed-subs")
            request.addOption("--convert-subs", "srt")
            request.addOption("--sleep-subtitles", "5")
            request.addOption("--sleep-requests", "1")
        }
        YoutubeDL.getInstance().execute(request, processId) { progress, eta, line ->
            onProgress(progress, eta, line)
        }
    }

    private fun friendlyLine(line: String): String {
        val clean = line.trim()
        return when {
            clean.contains("429") -> "YouTube is rate-limiting requests. Waiting…"
            clean.startsWith("WARNING", true) -> ""
            else -> clean.take(105)
        }
    }

    private fun isMediaFile(file: File): Boolean {
        val extension = file.extension.lowercase()
        return extension in setOf("mp4", "mkv", "webm", "mov", "avi", "m4v", "mp3", "m4a", "opus", "ogg", "wav", "flac")
    }

    /** Copy from app-private working storage into the user's Downloads/Lumo collection. */
    private fun publishToDownloads(file: File): Uri? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return null
        val resolver = contentResolver
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(file.extension.lowercase()) ?: "application/octet-stream"
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, file.name)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, "${Environment.DIRECTORY_DOWNLOADS}/Lumo")
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return null
        try {
            val output = resolver.openOutputStream(uri, "w") ?: throw IllegalStateException("Cannot open Downloads output stream")
            file.inputStream().use { input -> output.use { input.copyTo(it) } }
            val published = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
            resolver.update(uri, published, null, null)
            return uri
        } catch (e: Exception) {
            resolver.delete(uri, null, null)
            throw e
        }
    }

    private fun updateNotification(message: String, progress: Int, ongoing: Boolean) {
        getSharedPreferences("lumo_download_state", MODE_PRIVATE).edit()
            .putString("message", message)
            .putInt("progress", progress.coerceIn(0, 100))
            .putBoolean("ongoing", ongoing)
            .apply()
        val update = Intent(ACTION_PROGRESS).setPackage(packageName).apply {
            putExtra(EXTRA_PROGRESS_MESSAGE, message)
            putExtra(EXTRA_PROGRESS_VALUE, progress.coerceIn(0, 100))
            putExtra(EXTRA_PROGRESS_ONGOING, ongoing)
        }
        sendBroadcast(update)
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(notificationId, buildNotification(message, progress, ongoing))
    }

    private fun buildNotification(message: String, progress: Int, ongoing: Boolean): Notification {
        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("Lumo")
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setContentIntent(openIntent)
            .setOnlyAlertOnce(true)
            .setOngoing(ongoing)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setAutoCancel(!ongoing)
        if (ongoing) builder.setProgress(100, progress, false) else builder.setProgress(0, 0, false)
        if (ongoing) {
            val cancelIntent = PendingIntent.getService(
                this, 2, Intent(this, DownloadService::class.java).setAction(ACTION_CANCEL),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            builder.addAction(android.R.drawable.ic_menu_close_clear_cancel, "Cancel", cancelIntent)
        }
        return builder.build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "Lumo downloads", NotificationManager.IMPORTANCE_LOW
            ).apply { description = "Download progress and cancellation controls" }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        executor.shutdown()
        super.onDestroy()
    }

    companion object {
        const val ACTION_START = "com.lumo.android.action.START"
        const val ACTION_CANCEL = "com.lumo.android.action.CANCEL"
        const val EXTRA_URL = "url"
        const val EXTRA_TITLE = "title"
        const val EXTRA_FORMAT = "format"
        const val EXTRA_CONTAINER = "container"
        const val EXTRA_SUBTITLE_LANGS = "subtitle_langs"
        const val EXTRA_PLAYLIST = "playlist"
        const val ACTION_PROGRESS = "com.lumo.android.action.PROGRESS"
        const val EXTRA_PROGRESS_MESSAGE = "progress_message"
        const val EXTRA_PROGRESS_VALUE = "progress_value"
        const val EXTRA_PROGRESS_ONGOING = "progress_ongoing"
        private const val CHANNEL_ID = "lumo_downloads"
    }
}
