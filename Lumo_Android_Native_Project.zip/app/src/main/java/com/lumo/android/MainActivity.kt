package com.lumo.android

import android.Manifest
import android.content.BroadcastReceiver
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.clickable
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.foundation.Image
import androidx.compose.runtime.produceState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import com.yausername.ffmpeg.FFmpeg
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.Executors

private val Bg = Color(0xFF050506)
private val Card = Color(0xFF0E0F14)
private val CardAlt = Color(0xFF171920)
private val Line = Color(0xFF242732)
private val Ink = Color(0xFFF4F6FB)
private val Muted = Color(0xFF8E97A8)
private val Accent = Color(0xFFFF647F)
private val Indigo = Color(0xFFFFB45F)
private val Purple = Color(0xFF8871FF)
private val Ok = Color(0xFF55D9A8)

private val SubtitleOptions = listOf("English" to "en", "Hindi" to "hi", "Marathi" to "mr")

class MainActivity : ComponentActivity() {
    private val worker = Executors.newSingleThreadExecutor()
    private val progress = mutableStateOf(ProgressState())
    private val engineReady = mutableStateOf(false)
    private val engineStatus = mutableStateOf("Starting download engine…")

    private val progressReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent == null) return
            progress.value = ProgressState(
                message = intent.getStringExtra(DownloadService.EXTRA_PROGRESS_MESSAGE).orEmpty(),
                percent = intent.getIntExtra(DownloadService.EXTRA_PROGRESS_VALUE, 0),
                ongoing = intent.getBooleanExtra(DownloadService.EXTRA_PROGRESS_ONGOING, false),
                visible = true
            )
        }
    }

    private val notificationPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)

        val filter = IntentFilter(DownloadService.ACTION_PROGRESS)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(progressReceiver, filter, RECEIVER_NOT_EXPORTED)
        else @Suppress("DEPRECATION") registerReceiver(progressReceiver, filter)

        initEngine(autoUpdate = Settings.autoUpdate(this))

        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Accent, background = Bg, surface = Card)) {
                LumoApp()
            }
        }
    }

    private fun initEngine(autoUpdate: Boolean) {
        worker.execute {
            try {
                YoutubeDL.getInstance().init(applicationContext)
                FFmpeg.getInstance().init(applicationContext)
                if (autoUpdate) runCatching { YoutubeDL.getInstance().updateYoutubeDL(applicationContext) }
                engineReady.value = true
                engineStatus.value = "Download engine ready"
            } catch (e: Exception) {
                engineReady.value = false
                engineStatus.value = "Engine failed to start: ${e.message ?: "unknown error"}"
            }
        }
    }

    fun updateEngineNow(onDone: (String) -> Unit) {
        worker.execute {
            val result = try {
                val status = YoutubeDL.getInstance().updateYoutubeDL(applicationContext)
                "Engine update: $status"
            } catch (e: Exception) {
                "Engine update failed: ${e.message ?: "unknown error"}"
            }
            runOnUiThread { onDone(result) }
        }
    }

    fun inspect(url: String, onResult: (VideoSummary?, String?) -> Unit) {
        worker.execute {
            try {
                if (!engineReady.value) throw IllegalStateException("Download engine is still starting")
                val info = YoutubeDL.getInstance().getInfo(url)
                val summary = VideoSummary(
                    title = info.title?.takeIf { it.isNotBlank() } ?: "Video",
                    extractor = info.extractor ?: "Source",
                    duration = if (info.duration > 0) formatDuration(info.duration.toLong()) else "",
                    thumbnail = thumbnailOf(info),
                    sizesMb = sizeMap(info)
                )
                runOnUiThread { onResult(summary, null) }
            } catch (e: Exception) {
                runOnUiThread { onResult(null, friendlyError(e.message)) }
            }
        }
    }

    fun startDownload(url: String, title: String, quality: String, container: String, subs: String, playlist: Boolean) {
        val cap = when (quality) {
            "1080p" -> 1080; "720p" -> 720; "480p" -> 480; "360p" -> 360; else -> 0
        }
        val ext = if (container == "mp4") "[ext=mp4]" else ""
        val format = if (cap == 0) "bestvideo$ext+bestaudio/best$ext/best"
        else "bestvideo$ext[height<=$cap]+bestaudio/best$ext[height<=$cap]/best[height<=$cap]"
        val intent = Intent(this, DownloadService::class.java).apply {
            action = DownloadService.ACTION_START
            putExtra(DownloadService.EXTRA_URL, url)
            putExtra(DownloadService.EXTRA_TITLE, title)
            putExtra(DownloadService.EXTRA_FORMAT, format)
            putExtra(DownloadService.EXTRA_CONTAINER, container)
            putExtra(DownloadService.EXTRA_SUBTITLE_LANGS, subs)
            putExtra(DownloadService.EXTRA_PLAYLIST, playlist)
        }
        ContextCompat.startForegroundService(this, intent)
        progress.value = ProgressState("Starting download…", 0, true, true)
    }

    fun cancelDownload() {
        startService(Intent(this, DownloadService::class.java).setAction(DownloadService.ACTION_CANCEL))
    }

    fun clipboardText(): String {
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        return cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(this)?.toString().orEmpty()
    }

    fun validUrl(s: String): Boolean = runCatching {
        val u = Uri.parse(s)
        (u.scheme == "http" || u.scheme == "https") && !u.host.isNullOrBlank()
    }.getOrDefault(false)

    private fun friendlyError(raw: String?): String {
        val msg = raw.orEmpty()
        return when {
            msg.contains("429") -> "YouTube is rate-limiting this app. Wait a few minutes and try again."
            msg.contains("Sign in", true) || msg.contains("confirm your age", true) ->
                "This video needs a signed-in account, which Lumo can't use yet."
            msg.contains("Video unavailable", true) || msg.contains("Private video", true) ->
                "This video is unavailable or private."
            msg.contains("Unsupported URL", true) -> "This link isn't supported."
            msg.contains("yt-dlp", true) && msg.contains("older", true) ->
                "The download engine is out of date. Update it in Settings."
            msg.isBlank() -> "Could not read this link."
            else -> "Could not read this link: ${msg.lineSequence().firstOrNull()?.take(140).orEmpty()}"
        }
    }

    private fun sizeMap(info: Any): Map<Int, Double> {
        val out = linkedMapOf<Int, Double>()
        try {
            val formats = info.javaClass.getMethod("getFormats").invoke(info) as? List<*> ?: return out
            formats.forEach { f ->
                if (f == null) return@forEach
                try {
                    val h = (f.javaClass.getMethod("getHeight").invoke(f) as? Number)?.toInt() ?: 0
                    val bytes = listOf("getFileSize", "getFileSizeApprox", "getFilesize", "getFilesizeApprox")
                        .firstNotNullOfOrNull { name ->
                            try { (f.javaClass.getMethod(name).invoke(f) as? Number)?.toDouble() } catch (_: Exception) { null }
                        } ?: 0.0
                    if (h > 0 && bytes > 0 && bytes > (out[h] ?: 0.0)) out[h] = bytes / 1048576.0
                } catch (_: Exception) { }
            }
        } catch (_: Exception) { }
        return out
    }

    private fun thumbnailOf(info: Any): String = try {
        listOf("getThumbnail", "getThumbnailUrl").firstNotNullOfOrNull { name ->
            try { (info.javaClass.getMethod(name).invoke(info) as? String)?.takeIf { it.startsWith("http") } } catch (_: Exception) { null }
        }.orEmpty()
    } catch (_: Exception) { "" }

    private fun formatDuration(s: Long) = "%d:%02d".format(s / 60, s % 60)

    override fun onDestroy() {
        runCatching { unregisterReceiver(progressReceiver) }
        worker.shutdown()
        super.onDestroy()
    }

    // ---------- UI ----------

    @Composable
    private fun LumoApp() {
        var tab by remember { mutableStateOf(0) }
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF0A0B0F)) {
                    listOf("Download", "History", "Settings").forEachIndexed { i, label ->
                        NavigationBarItem(
                            selected = tab == i,
                            onClick = { tab = i },
                            icon = { Text(listOf("⬇", "🕘", "⚙")[i], fontSize = 18.sp) },
                            label = { Text(label, fontSize = 12.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Accent,
                                selectedTextColor = Accent,
                                indicatorColor = Color(0xFF2A1A20),
                                unselectedIconColor = Muted,
                                unselectedTextColor = Muted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            Box(Modifier.padding(padding).fillMaxSize().background(Bg)) {
                when (tab) {
                    0 -> DownloadScreen()
                    1 -> HistoryScreen()
                    else -> SettingsScreen()
                }
            }
        }
    }

    @Composable
    private fun DownloadScreen() {
        val ready by engineReady
        val prog by progress
        var playlistMode by remember { mutableStateOf(false) }
        var url by remember { mutableStateOf("") }
        var info by remember { mutableStateOf<VideoSummary?>(null) }
        var error by remember { mutableStateOf<String?>(null) }
        var inspecting by remember { mutableStateOf(false) }
        var stage by remember { mutableStateOf(Stage.Idle) }
        var height by remember { mutableStateOf(0) }
        var subs by remember { mutableStateOf(setOf("en")) }
        var container by remember { mutableStateOf("mp4") }
        var started by remember { mutableStateOf(false) }

        fun reset() {
            info = null; error = null; stage = Stage.Idle; height = 0; started = false
            progress.value = ProgressState()
        }

        fun inspectNow() {
            if (!validUrl(url)) { error = "Enter a valid http or https link"; return }
            inspecting = true; error = null; info = null; stage = Stage.Inspecting
            inspect(url) { s, e ->
                inspecting = false
                if (s != null) { info = s; stage = Stage.Quality; height = 0 } else { error = e; stage = Stage.Idle }
            }
        }

        // Once the service reports the download has finished, leave the card in its done state.
        LaunchedEffect(prog.ongoing, prog.visible) {
            if (started && prog.visible && !prog.ongoing) stage = Stage.Done
        }

        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(44.dp).clip(RoundedCornerShape(14.dp))
                        .background(Brush.linearGradient(listOf(Accent, Purple))),
                    contentAlignment = Alignment.Center
                ) { Text("L", color = Ink, fontWeight = FontWeight.Bold, fontSize = 20.sp) }
                Spacer(Modifier.width(12.dp))
                Text("Download", color = Ink, fontSize = 30.sp, fontWeight = FontWeight.Bold)
            }

            // Video / Playlist segmented control
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(CardAlt).padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Segment("Video", !playlistMode, Modifier.weight(1f)) { playlistMode = false; reset() }
                Segment("Playlist", playlistMode, Modifier.weight(1f)) { playlistMode = true; reset() }
            }

            // Link box + Paste, like the HTML
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = url,
                    onValueChange = { url = it.trim(); reset() },
                    modifier = Modifier.weight(1f),
                    placeholder = {
                        Text(if (playlistMode) "Paste a playlist link…" else "Paste a video link…", color = Muted)
                    },
                    singleLine = true,
                    trailingIcon = {
                        if (url.isNotEmpty()) TextButton(onClick = { url = ""; reset() }) { Text("✕", color = Muted) }
                    },
                    shape = RoundedCornerShape(16.dp)
                )
                Button(
                    onClick = {
                        val pasted = clipboardText().trim()
                        if (pasted.isBlank()) error = "Clipboard is empty" else { url = pasted; reset() }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Accent),
                    shape = RoundedCornerShape(16.dp),
                    contentPadding = PaddingValues(horizontal = 18.dp, vertical = 16.dp)
                ) { Text("Paste", fontWeight = FontWeight.Bold) }
            }

            error?.let { Text(it, color = Accent, fontSize = 13.sp) }

            // Step 1: finding the video (only while inspecting, or when nothing is chosen yet)
            if (stage == Stage.Idle && !playlistMode) {
                Button(
                    onClick = { inspectNow() },
                    enabled = url.isNotBlank() && ready,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = CardAlt),
                    shape = RoundedCornerShape(16.dp)
                ) { Text(if (ready) "Check link" else "Starting download engine…", color = Ink) }
            }

            if (stage == Stage.Inspecting) {
                LumoCard {
                    Text("Finding your video…", color = Ink, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Text("Connecting to the video source", color = Muted, fontSize = 13.sp)
                    Spacer(Modifier.height(8.dp))
                    LinearProgressIndicator(
                        modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                        color = Purple, trackColor = Line
                    )
                }
            }

            // Step 2: quality with size estimates
            if (stage == Stage.Quality && info != null) {
                val v = info!!
                LumoCard {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        RemoteThumb(v.thumbnail, Modifier.size(width = 120.dp, height = 68.dp))
                        Column(Modifier.weight(1f)) {
                            Text(v.title, color = Ink, fontWeight = FontWeight.Bold, fontSize = 16.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            Text(listOf(v.extractor, v.duration).filter { it.isNotBlank() }.joinToString(" · "), color = Muted, fontSize = 13.sp)
                        }
                    }
                }
                if (!playlistMode) {
                    Label("VIDEO QUALITY")
                    Text("The size is an estimate and can vary slightly.", color = Muted, fontSize = 12.sp)
                    qualityOptions(v).forEach { (label, h, sizeText) ->
                        QualityRow(label, sizeText, selected = height == h) { height = h }
                    }
                    Button(
                        onClick = { stage = Stage.Options },
                        modifier = Modifier.fillMaxWidth().height(52.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = CardAlt),
                        shape = RoundedCornerShape(16.dp)
                    ) { Text("Continue  →", color = Ink, fontWeight = FontWeight.Bold) }
                } else {
                    Button(
                        onClick = { stage = Stage.Options },
                        modifier = Modifier.fillMaxWidth().height(52.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = CardAlt),
                        shape = RoundedCornerShape(16.dp)
                    ) { Text("Continue  →", color = Ink, fontWeight = FontWeight.Bold) }
                }
            }

            // Playlist: check the playlist first
            if (playlistMode && stage == Stage.Idle) {
                Button(
                    onClick = { inspectNow() },
                    enabled = url.isNotBlank() && ready && !inspecting,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = CardAlt),
                    shape = RoundedCornerShape(16.dp)
                ) { Text("Check playlist", color = Ink) }
            }

            // Step 3: subtitles and format
            if (stage == Stage.Options && info != null) {
                val v = info!!
                Text("Make it yours", color = Ink, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text("Choose subtitles and the file format.", color = Muted, fontSize = 13.sp)
                Label("SUBTITLES")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SubtitleOptions.forEach { (label, code) ->
                        LumoChip(label, code in subs) { subs = if (code in subs) subs - code else subs + code }
                    }
                }
                Label("FILE FORMAT")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    LumoChip("MP4 · Compatible", container == "mp4") { container = "mp4" }
                    LumoChip("MKV · Flexible", container == "mkv") { container = "mkv" }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedButton(onClick = { stage = if (playlistMode) Stage.Idle else Stage.Quality }, shape = RoundedCornerShape(16.dp)) {
                        Text("← Quality", color = Ink)
                    }
                    Button(
                        onClick = {
                            started = true
                            stage = Stage.Downloading
                            val label = qualityOptions(v).firstOrNull { it.second == height }?.first ?: "Best available"
                            startDownload(url, v.title, label, container, subs.joinToString(","), playlistMode)
                        },
                        enabled = ready,
                        modifier = Modifier.weight(1f).height(56.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Accent),
                        shape = RoundedCornerShape(18.dp)
                    ) { Text("Download video ↓", fontWeight = FontWeight.Bold, fontSize = 17.sp) }
                }
            }

            // Step 4: download card with thumbnail, title and progress
            if (stage == Stage.Downloading || stage == Stage.Done) {
                val v = info
                LumoCard {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        RemoteThumb(v?.thumbnail.orEmpty(), Modifier.size(width = 120.dp, height = 68.dp))
                        Column(Modifier.weight(1f)) {
                            Text(v?.title ?: "Download", color = Ink, fontWeight = FontWeight.Bold, fontSize = 16.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            Text(
                                if (stage == Stage.Done) "Completed" else "${prog.percent}%",
                                color = if (stage == Stage.Done) Ok else Indigo,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    LinearProgressIndicator(
                        progress = { if (stage == Stage.Done) 1f else prog.percent / 100f },
                        modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                        color = if (stage == Stage.Done) Ok else Purple,
                        trackColor = Line
                    )
                    Text(prog.message, color = Muted, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Spacer(Modifier.height(8.dp))
                    if (stage == Stage.Downloading) {
                        OutlinedButton(onClick = { cancelDownload() }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                            Text("Cancel download", color = Ink)
                        }
                    } else {
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedButton(onClick = { openDownloadFolder(this@MainActivity) }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(16.dp)) {
                                Text("Open folder", color = Ink)
                            }
                            Button(
                                onClick = { url = ""; reset() },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = Accent),
                                shape = RoundedCornerShape(16.dp)
                            ) { Text("New video", fontWeight = FontWeight.Bold) }
                        }
                    }
                }
            }
        }
    }

    private fun openDownloadFolder(context: Context) {
        val intent = Intent(Intent.ACTION_VIEW).setDataAndType(
            Uri.parse("content://com.android.externalstorage.documents/document/primary%3ADownload%2FLumo"),
            "vnd.android.document/directory"
        )
        try { context.startActivity(intent) } catch (_: Exception) {
            android.widget.Toast.makeText(context, "Open Files app → Downloads → Lumo", android.widget.Toast.LENGTH_LONG).show()
        }
    }

    private fun qualityOptions(v: VideoSummary): List<Triple<String, Int, String>> {
        val heights = v.sizesMb.keys.filter { it <= 2160 }.sortedDescending()
        val fallback = if (heights.isEmpty()) listOf(1080, 720, 480, 360) else heights
        val bestSize = v.sizesMb.values.maxOrNull()
        val out = mutableListOf(Triple("Best available", 0, bestSize?.let { "~${"%.0f".format(java.util.Locale.US, it)} MB" } ?: "Size unknown"))
        fallback.forEach { h ->
            val mb = v.sizesMb[h]
            out.add(Triple("${h}p", h, mb?.let { "~${"%.0f".format(java.util.Locale.US, it)} MB" } ?: "Size unknown"))
        }
        return out
    }

    @Composable
    private fun HistoryScreen() {
        val context = LocalContext.current
        var history by remember { mutableStateOf(historyList(context)) }
        Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("History", color = Ink, fontSize = 30.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                TextButton(onClick = { HistoryStore.clear(context); history = emptyList() }) { Text("Clear", color = Muted) }
            }
            if (history.isEmpty()) Text("No downloads yet.", color = Muted)
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(history) { item ->
                    LumoCard {
                        Text(item.title, color = Ink, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text(item.status, color = if (item.status == "Completed") Ok else Muted, fontSize = 13.sp)
                        Text(item.location, color = Muted, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        }
    }

    @Composable
    private fun SettingsScreen() {
        val context = LocalContext.current
        val status by engineStatus
        var auto by remember { mutableStateOf(Settings.autoUpdate(context)) }
        var message by remember { mutableStateOf("") }
        Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text("Settings", color = Ink, fontSize = 30.sp, fontWeight = FontWeight.Bold)
            LumoCard {
                Text(status, color = Muted, fontSize = 13.sp)
            }
            LumoCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Update download engine on start", color = Ink, fontWeight = FontWeight.Bold)
                        Text("Keeps yt-dlp current, which YouTube changes often.", color = Muted, fontSize = 13.sp)
                    }
                    Switch(checked = auto, onCheckedChange = { auto = it; Settings.setAutoUpdate(context, it) })
                }
            }
            Button(
                onClick = {
                    message = "Updating…"
                    updateEngineNow { message = it }
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Accent),
                shape = RoundedCornerShape(16.dp)
            ) { Text("Update download engine now", fontWeight = FontWeight.Bold) }
            if (message.isNotBlank()) Text(message, color = Muted, fontSize = 13.sp)
            Text("Lumo 2.0.1 · Finished files are saved to Downloads/Lumo.", color = Muted, fontSize = 12.sp)
        }
    }

    // ---------- small pieces ----------

    @Composable
    private fun LumoCard(content: @Composable ColumnScope.() -> Unit) {
        Column(
            Modifier.fillMaxWidth()
                .clip(RoundedCornerShape(18.dp))
                .background(Card)
                .border(1.dp, Line, RoundedCornerShape(18.dp))
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
            content = content
        )
    }

    @Composable
    private fun Segment(label: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
        Box(
            modifier
                .clip(RoundedCornerShape(14.dp))
                .background(if (selected) Color(0xFF2A1A20) else Color.Transparent)
                .clickable(onClick = onClick)
                .padding(vertical = 14.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(label, color = if (selected) Ink else Muted, fontWeight = FontWeight.Bold)
        }
    }

    @Composable
    private fun QualityRow(label: String, sizeText: String, selected: Boolean, onClick: () -> Unit) {
        Row(
            Modifier.fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(if (selected) Color(0xFF2B2650) else CardAlt)
                .border(1.dp, if (selected) Purple else Line, RoundedCornerShape(14.dp))
                .clickable(onClick = onClick)
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            RadioButton(selected = selected, onClick = null, colors = RadioButtonDefaults.colors(selectedColor = Accent))
            Spacer(Modifier.width(8.dp))
            Text(label, color = Ink, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Text(sizeText, color = Muted, fontSize = 13.sp)
        }
    }

    @Composable
    private fun LumoChip(label: String, selected: Boolean, onClick: () -> Unit) {
        Box(
            Modifier
                .clip(RoundedCornerShape(16.dp))
                .background(if (selected) Color(0xFF2B2650) else CardAlt)
                .border(1.dp, if (selected) Purple else Line, RoundedCornerShape(16.dp))
                .clickable(onClick = onClick)
                .padding(horizontal = 14.dp, vertical = 12.dp)
        ) {
            Text((if (selected) "✓ " else "") + label, color = if (selected) Ink else Muted, fontSize = 14.sp)
        }
    }

    @Composable
    private fun Label(text: String) {
        Text(text, color = Muted, fontSize = 12.sp, letterSpacing = 1.sp)
    }

    @Composable
    private fun RemoteThumb(url: String, modifier: Modifier) {
        val bitmap by produceState<android.graphics.Bitmap?>(initialValue = null, key1 = url) {
            value = if (url.isBlank()) null else withContext(Dispatchers.IO) { fetchBitmap(url) }
        }
        Box(modifier.clip(RoundedCornerShape(12.dp)).background(CardAlt), contentAlignment = Alignment.Center) {
            bitmap?.let {
                Image(
                    bitmap = it.asImageBitmap(),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
    }

    private fun fetchBitmap(url: String): android.graphics.Bitmap? = try {
        val conn = java.net.URL(url).openConnection() as java.net.HttpURLConnection
        conn.connectTimeout = 8000
        conn.readTimeout = 8000
        conn.inputStream.use { android.graphics.BitmapFactory.decodeStream(it) }
    } catch (_: Exception) { null }

    private fun historyList(context: Context): List<HistoryItem> {
        val arr: JSONArray = HistoryStore.items(context)
        return (0 until arr.length()).mapNotNull { i ->
            val o: JSONObject = arr.optJSONObject(i) ?: return@mapNotNull null
            HistoryItem(
                title = o.optString("title"),
                status = o.optString("status"),
                location = o.optString("location"),
                uri = o.optString("uri"),
                path = o.optString("path")
            )
        }
    }
}

enum class Stage { Idle, Inspecting, Quality, Options, Downloading, Done }

data class ProgressState(
    val message: String = "",
    val percent: Int = 0,
    val ongoing: Boolean = false,
    val visible: Boolean = false
)

data class VideoSummary(
    val title: String,
    val extractor: String,
    val duration: String,
    val thumbnail: String,
    val sizesMb: Map<Int, Double>
)

data class HistoryItem(val title: String, val status: String, val location: String, val uri: String, val path: String)

object Settings {
    private const val PREFS = "lumo_settings"
    fun autoUpdate(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean("auto_update", true)
    fun setAutoUpdate(context: Context, value: Boolean) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean("auto_update", value).apply()
}
