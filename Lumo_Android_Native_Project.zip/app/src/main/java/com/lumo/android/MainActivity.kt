package com.lumo.android

import android.Manifest
import android.content.BroadcastReceiver
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.clickable
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import com.yausername.ffmpeg.FFmpeg
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.Executors

private val Bg = Color(0xFF050506)
private val Card = Color(0xFF0E0F14)
private val CardAlt = Color(0xFF171920)
private val Line = Color(0xFF242732)
private val Ink = Color(0xFFF4F6FB)
private val Muted = Color(0xFF8E97A8)
private val Accent = Color(0xFFFF647F)
private val Indigo = Color(0xFFFFB45F)
private val Purple = Color(0xFF8871FF)
private val Ok = Color(0xFF55D9A8)

private val SubtitleOptions = listOf("English" to "en", "Hindi" to "hi", "Marathi" to "mr")
private val QualityOptions = listOf("Best available", "1080p", "720p", "480p", "360p")

class MainActivity : ComponentActivity() {
    private val worker = Executors.newSingleThreadExecutor()
    private val progress = mutableStateOf(ProgressState())
    private val engineReady = mutableStateOf(false)
    private val engineStatus = mutableStateOf("Starting download engine…")

    private val progressReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent == null) return
            progress.value = ProgressState(
                message = intent.getStringExtra(DownloadService.EXTRA_PROGRESS_MESSAGE).orEmpty(),
                percent = intent.getIntExtra(DownloadService.EXTRA_PROGRESS_VALUE, 0),
                ongoing = intent.getBooleanExtra(DownloadService.EXTRA_PROGRESS_ONGOING, false),
                visible = true
            )
        }
    }

    private val notificationPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)

        val filter = IntentFilter(DownloadService.ACTION_PROGRESS)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(progressReceiver, filter, RECEIVER_NOT_EXPORTED)
        else @Suppress("DEPRECATION") registerReceiver(progressReceiver, filter)

        initEngine(autoUpdate = Settings.autoUpdate(this))

        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Accent, background = Bg, surface = Card)) {
                LumoApp()
            }
        }
    }

    private fun initEngine(autoUpdate: Boolean) {
        worker.execute {
            try {
                YoutubeDL.getInstance().init(applicationContext)
                FFmpeg.getInstance().init(applicationContext)
                if (autoUpdate) runCatching { YoutubeDL.getInstance().updateYoutubeDL(applicationContext) }
                engineReady.value = true
                engineStatus.value = "Download engine ready"
            } catch (e: Exception) {
                engineReady.value = false
                engineStatus.value = "Engine failed to start: ${e.message ?: "unknown error"}"
            }
        }
    }

    fun updateEngineNow(onDone: (String) -> Unit) {
        worker.execute {
            val result = try {
                val status = YoutubeDL.getInstance().updateYoutubeDL(applicationContext)
                "Engine update: $status"
            } catch (e: Exception) {
                "Engine update failed: ${e.message ?: "unknown error"}"
            }
            runOnUiThread { onDone(result) }
        }
    }

    fun inspect(url: String, onResult: (VideoSummary?, String?) -> Unit) {
        worker.execute {
            try {
                if (!engineReady.value) throw IllegalStateException("Download engine is still starting")
                val info = YoutubeDL.getInstance().getInfo(url)
                val summary = VideoSummary(
                    title = info.title?.takeIf { it.isNotBlank() } ?: "Video",
                    extractor = info.extractor ?: "Source",
                    duration = if (info.duration > 0) formatDuration(info.duration.toLong()) else "",
                    sizes = sizeSummary(info)
                )
                runOnUiThread { onResult(summary, null) }
            } catch (e: Exception) {
                runOnUiThread { onResult(null, friendlyError(e.message)) }
            }
        }
    }

    fun startDownload(url: String, title: String, quality: String, container: String, subs: String, playlist: Boolean) {
        val cap = when (quality) {
            "1080p" -> 1080; "720p" -> 720; "480p" -> 480; "360p" -> 360; else -> 0
        }
        val ext = if (container == "mp4") "[ext=mp4]" else ""
        val format = if (cap == 0) "bestvideo$ext+bestaudio/best$ext/best"
        else "bestvideo$ext[height<=$cap]+bestaudio/best$ext[height<=$cap]/best[height<=$cap]"
        val intent = Intent(this, DownloadService::class.java).apply {
            action = DownloadService.ACTION_START
            putExtra(DownloadService.EXTRA_URL, url)
            putExtra(DownloadService.EXTRA_TITLE, title)
            putExtra(DownloadService.EXTRA_FORMAT, format)
            putExtra(DownloadService.EXTRA_CONTAINER, container)
            putExtra(DownloadService.EXTRA_SUBTITLE_LANGS, subs)
            putExtra(DownloadService.EXTRA_PLAYLIST, playlist)
        }
        ContextCompat.startForegroundService(this, intent)
        progress.value = ProgressState("Starting download…", 0, true, true)
    }

    fun cancelDownload() {
        startService(Intent(this, DownloadService::class.java).setAction(DownloadService.ACTION_CANCEL))
    }

    fun clipboardText(): String {
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        return cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(this)?.toString().orEmpty()
    }

    fun validUrl(s: String): Boolean = runCatching {
        val u = Uri.parse(s)
        (u.scheme == "http" || u.scheme == "https") && !u.host.isNullOrBlank()
    }.getOrDefault(false)

    private fun friendlyError(raw: String?): String {
        val msg = raw.orEmpty()
        return when {
            msg.contains("429") -> "YouTube is rate-limiting this app. Wait a few minutes and try again."
            msg.contains("Sign in", true) || msg.contains("confirm your age", true) ->
                "This video needs a signed-in account, which Lumo can't use yet."
            msg.contains("Video unavailable", true) || msg.contains("Private video", true) ->
                "This video is unavailable or private."
            msg.contains("Unsupported URL", true) -> "This link isn't supported."
            msg.contains("yt-dlp", true) && msg.contains("older", true) ->
                "The download engine is out of date. Update it in Settings."
            msg.isBlank() -> "Could not read this link."
            else -> "Could not read this link: ${msg.lineSequence().firstOrNull()?.take(140).orEmpty()}"
        }
    }

    private fun sizeSummary(info: Any): String {
        return try {
            val formats = info.javaClass.getMethod("getFormats").invoke(info) as? List<*> ?: return "Size unavailable"
            val best = linkedMapOf<Int, Double>()
            formats.forEach { f ->
                if (f == null) return@forEach
                val h = (f.javaClass.getMethod("getHeight").invoke(f) as? Number)?.toInt() ?: 0
                val bytes = ((f.javaClass.getMethod("getFileSize").invoke(f) as? Number)?.toDouble()
                    ?: (f.javaClass.getMethod("getFileSizeApprox").invoke(f) as? Number)?.toDouble()) ?: 0.0
                if (h > 0 && bytes > 0 && bytes > (best[h] ?: 0.0)) best[h] = bytes
            }
            if (best.isEmpty()) "Size unavailable for this source"
            else best.entries.sortedByDescending { it.key }.joinToString(" · ") {
                "${it.key}p ~ ${"%.1f".format(java.util.Locale.US, it.value / 1048576.0)} MB"
            }
        } catch (_: Exception) {
            "Size unavailable for this source"
        }
    }

    private fun formatDuration(s: Long) = "%d:%02d".format(s / 60, s % 60)

    override fun onDestroy() {
        runCatching { unregisterReceiver(progressReceiver) }
        worker.shutdown()
        super.onDestroy()
    }

    // ---------- UI ----------

    @Composable
    private fun LumoApp() {
        var tab by remember { mutableStateOf(0) }
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                NavigationBar(containerColor = Bg) {
                    listOf("Download", "History", "Settings").forEachIndexed { i, label ->
                        NavigationBarItem(
                            selected = tab == i,
                            onClick = { tab = i },
                            icon = { Text(listOf("⬇", "🕘", "⚙")[i], fontSize = 18.sp) },
                            label = { Text(label) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Accent,
                                selectedTextColor = Accent,
                                indicatorColor = Color(0xFF2A1A20),
                                unselectedIconColor = Muted,
                                unselectedTextColor = Muted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            Box(Modifier.padding(padding).fillMaxSize().background(Bg)) {
                when (tab) {
                    0 -> DownloadScreen()
                    1 -> HistoryScreen()
                    else -> SettingsScreen()
                }
            }
        }
    }

    @Composable
    private fun DownloadScreen() {
        val context = LocalContext.current
        var playlistMode by remember { mutableStateOf(false) }
        var url by remember { mutableStateOf("") }
        var summary by remember { mutableStateOf<VideoSummary?>(null) }
        var error by remember { mutableStateOf<String?>(null) }
        var inspecting by remember { mutableStateOf(false) }
        var subs by remember { mutableStateOf(setOf("en")) }
        var container by remember { mutableStateOf("mp4") }
        var quality by remember { mutableStateOf("Best available") }
        var step by remember { mutableStateOf(0) }
        val ready by engineReady
        val status by engineStatus
        val prog by progress

        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(44.dp).clip(RoundedCornerShape(14.dp))
                        .background(Brush.linearGradient(listOf(Accent, Purple))),
                    contentAlignment = Alignment.Center
                ) { Text("L", color = Ink, fontWeight = FontWeight.Bold, fontSize = 20.sp) }
                Spacer(Modifier.width(12.dp))
                Text("Download", color = Ink, fontSize = 30.sp, fontWeight = FontWeight.Bold)
            }

            Text(status, color = if (ready) Ok else Muted, fontSize = 12.sp)

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                ModeTab("Video", !playlistMode, Modifier.weight(1f)) { playlistMode = false; step = 0 }
                ModeTab("Playlist", playlistMode, Modifier.weight(1f)) { playlistMode = true; step = 0 }
            }

            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = url,
                    onValueChange = { url = it.trim(); summary = null; error = null; step = 0 },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("Paste a video or playlist link", color = Muted) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Uri),
                    shape = RoundedCornerShape(16.dp)
                )
                Button(
                    onClick = {
                        val pasted = clipboardText()
                        if (pasted.isBlank()) error = "Clipboard is empty" else { url = pasted.trim(); summary = null; error = null; step = 0 }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Accent),
                    shape = RoundedCornerShape(16.dp)
                ) { Text("Paste", fontWeight = FontWeight.Bold) }
            }

            if (!playlistMode && step == 0) {
                Button(
                    onClick = {
                        if (!validUrl(url)) { error = "Enter a valid http or https link"; return@Button }
                        inspecting = true; error = null
                        inspect(url) { s, e ->
                            inspecting = false
                            if (s != null) { summary = s; step = 1 } else error = e
                        }
                    },
                    enabled = url.isNotBlank() && !inspecting && ready,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = CardAlt),
                    shape = RoundedCornerShape(16.dp)
                ) { Text(if (inspecting) "Reading link…" else "Check link", color = Ink) }
            }

            error?.let { Text(it, color = Accent, fontSize = 13.sp) }

            if (playlistMode) {
                LumoCard {
                    Text("Playlist download", color = Ink, fontWeight = FontWeight.Bold)
                    Text("Downloads every video in the playlist to Downloads/Lumo, with the options below.", color = Muted, fontSize = 13.sp)
                }
            }

            if (!playlistMode && step == 1 && summary != null) {
                val s = summary!!
                LumoCard {
                    Text(s.title, color = Ink, fontWeight = FontWeight.Bold, fontSize = 17.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Text(listOf(s.extractor, s.duration).filter { it.isNotBlank() }.joinToString(" · "), color = Muted, fontSize = 13.sp)
                    Spacer(Modifier.height(6.dp))
                    Text(s.sizes, color = Muted, fontSize = 12.sp)
                }
            }

            if (step == 1 || playlistMode) {
                Text("Make it yours", color = Ink, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text("Choose subtitles and the file format.", color = Muted, fontSize = 13.sp)
                Label("SUBTITLES")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SubtitleOptions.forEach { (label, code) ->
                        Chip(label, code in subs) {
                            subs = if (code in subs) subs - code else subs + code
                        }
                    }
                }
                Label("FILE FORMAT")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Chip("MP4 · Compatible", container == "mp4") { container = "mp4" }
                    Chip("MKV · Flexible", container == "mkv") { container = "mkv" }
                }
                Label("QUALITY")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    QualityOptions.forEach { q -> Chip(q, quality == q) { quality = q } }
                }
                Button(
                    onClick = {
                        val subsArg = subs.joinToString(",")
                        startDownload(url, summary?.title ?: "Lumo download", quality, container, subsArg, playlistMode)
                    },
                    enabled = validUrl(url) && ready,
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Accent),
                    shape = RoundedCornerShape(18.dp)
                ) { Text(if (playlistMode) "Download playlist ↓" else "Download video ↓", fontWeight = FontWeight.Bold, fontSize = 17.sp) }
            }

            if (prog.visible) {
                LumoCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            if (prog.ongoing) "${prog.percent}%" else "Finished",
                            color = if (prog.ongoing) Indigo else Ok,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(Modifier.height(8.dp))
                    LinearProgressIndicator(
                        progress = { prog.percent / 100f },
                        modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                        color = Purple,
                        trackColor = Line
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(prog.message, color = Muted, fontSize = 13.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
                    Spacer(Modifier.height(12.dp))
                    if (prog.ongoing) {
                        OutlinedButton(onClick = { cancelDownload() }, modifier = Modifier.fillMaxWidth()) {
                            Text("Cancel", color = Ink)
                        }
                    } else {
                        Button(
                            onClick = { url = ""; summary = null; step = 0; progress.value = ProgressState() },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = Accent)
                        ) { Text("New video", fontWeight = FontWeight.Bold) }
                    }
                }
            }
        }
    }

    @Composable
    private fun HistoryScreen() {
        val context = LocalContext.current
        var items by remember { mutableStateOf(historyList(context)) }
        Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("History", color = Ink, fontSize = 30.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                TextButton(onClick = { HistoryStore.clear(context); items = emptyList() }) { Text("Clear", color = Muted) }
            }
            if (items.isEmpty()) {
                Text("No downloads yet.", color = Muted)
            }
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(items) { item ->
                    LumoCard {
                        Text(item.title, color = Ink, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text(item.status, color = if (item.status == "Completed") Ok else Muted, fontSize = 13.sp)
                        Text(item.location, color = Muted, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        if (item.status == "Completed" && item.path.isNotBlank()) {
                            Spacer(Modifier.height(6.dp))
                            OutlinedButton(onClick = { openFile(context, item.path, item.uri) }) { Text("Open", color = Ink) }
                        }
                    }
                }
            }
        }
    }

    @Composable
    private fun SettingsScreen() {
        val context = LocalContext.current
        var auto by remember { mutableStateOf(Settings.autoUpdate(context)) }
        var message by remember { mutableStateOf("") }
        Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text("Settings", color = Ink, fontSize = 30.sp, fontWeight = FontWeight.Bold)
            LumoCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Update download engine on start", color = Ink, fontWeight = FontWeight.Bold)
                        Text("Keeps yt-dlp current, which YouTube changes often.", color = Muted, fontSize = 13.sp)
                    }
                    Switch(checked = auto, onCheckedChange = { auto = it; Settings.setAutoUpdate(context, it) })
                }
            }
            Button(
                onClick = {
                    message = "Updating…"
                    (context as MainActivity).updateEngineNow { message = it }
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Accent),
                shape = RoundedCornerShape(16.dp)
            ) { Text("Update download engine now", fontWeight = FontWeight.Bold) }
            if (message.isNotBlank()) Text(message, color = Muted, fontSize = 13.sp)
            Text("Lumo 2.0.0 · Finished files are saved to Downloads/Lumo.", color = Muted, fontSize = 12.sp)
        }
    }

    // ---------- small pieces ----------

    @Composable
    private fun LumoCard(content: @Composable ColumnScope.() -> Unit) {
        Column(
            Modifier.fillMaxWidth()
                .clip(RoundedCornerShape(18.dp))
                .background(Card)
                .border(1.dp, Line, RoundedCornerShape(18.dp))
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
            content = content
        )
    }

    @Composable
    private fun ModeTab(label: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
        Box(
            modifier
                .clip(RoundedCornerShape(18.dp))
                .background(if (selected) Color(0xFF2A1A20) else CardAlt)
                .border(1.dp, if (selected) Accent else Line, RoundedCornerShape(18.dp))
                .clickable(onClick = onClick)
                .padding(vertical = 16.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(label, color = if (selected) Ink else Muted, fontWeight = FontWeight.Bold)
        }
    }

    @Composable
    private fun Chip(label: String, selected: Boolean, onClick: () -> Unit) {
        Box(
            Modifier
                .clip(RoundedCornerShape(16.dp))
                .background(if (selected) Color(0xFF2B2650) else CardAlt)
                .border(1.dp, if (selected) Purple else Line, RoundedCornerShape(16.dp))
                .clickable(onClick = onClick)
                .padding(horizontal = 14.dp, vertical = 12.dp)
        ) {
            Text((if (selected) "✓ " else "") + label, color = if (selected) Ink else Muted, fontSize = 14.sp)
        }
    }

    @Composable
    private fun Label(text: String) {
        Text(text, color = Muted, fontSize = 12.sp, letterSpacing = 1.sp)
    }

    private fun historyList(context: Context): List<HistoryItem> {
        val arr: JSONArray = HistoryStore.items(context)
        return (0 until arr.length()).mapNotNull { i ->
            val o: JSONObject = arr.optJSONObject(i) ?: return@mapNotNull null
            HistoryItem(
                title = o.optString("title"),
                status = o.optString("status"),
                location = o.optString("location"),
                uri = o.optString("uri"),
                path = o.optString("path")
            )
        }
    }

    private fun openFile(context: Context, path: String, uri: String) {
        val target = if (uri.isNotBlank()) Uri.parse(uri) else null
        if (target != null) {
            context.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(target, "video/*").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
        }
    }
}

data class ProgressState(
    val message: String = "",
    val percent: Int = 0,
    val ongoing: Boolean = false,
    val visible: Boolean = false
)

data class VideoSummary(val title: String, val extractor: String, val duration: String, val sizes: String)

data class HistoryItem(val title: String, val status: String, val location: String, val uri: String, val path: String)

object Settings {
    private const val PREFS = "lumo_settings"
    fun autoUpdate(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean("auto_update", true)
    fun setAutoUpdate(context: Context, value: Boolean) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean("auto_update", value).apply()
}
