# -*- mode: python ; coding: utf-8 -*-
from pathlib import Path
from PyInstaller.utils.hooks import collect_submodules, collect_all

ROOT = Path(SPECPATH).resolve()
ICON = ROOT / "Lumo_icon.ico"
ORIGINAL_UI = ROOT / "main_original.pyc"

if not ICON.is_file():
    raise FileNotFoundError(f"Approved Lumo icon not found: {ICON}")
if not ORIGINAL_UI.is_file():
    raise FileNotFoundError(f"Recovered UI bytecode not found: {ORIGINAL_UI}")

# main.py patches the recovered UI in memory at startup, so bundle the untouched original.
datas = [(str(ORIGINAL_UI), "."), (str(ICON), ".")]
binaries = []
hiddenimports = [
    "lumo_windows", "lumo_windows.downloader", "lumo_windows.history",
    "lumo_windows.settings", "lumo_windows.diagnostics",
    "lumo_windows.playlist_ui", "lumo_windows.playlist_motion", "lumo_windows.ui_patch",
    "tkinter.colorchooser", "tkinter.filedialog",
]
hiddenimports += collect_submodules("tkinter")
for package in ("yt_dlp", "yt_dlp_ejs", "PIL"):
    package_datas, package_binaries, package_hiddenimports = collect_all(package)
    datas += package_datas
    binaries += package_binaries
    hiddenimports += package_hiddenimports

a = Analysis(
    [str(ROOT / "main.py")], pathex=[str(ROOT)], binaries=binaries,
    datas=datas, hiddenimports=hiddenimports, hookspath=[], hooksconfig={},
    runtime_hooks=[], excludes=[], noarchive=False, optimize=0,
)
pyz = PYZ(a.pure)
exe = EXE(
    pyz, a.scripts, [], exclude_binaries=True, name="Lumo", debug=False,
    bootloader_ignore_signals=False, strip=False, upx=True, console=False,
    disable_windowed_traceback=False, argv_emulation=False, target_arch=None,
    codesign_identity=None, entitlements_file=None, icon=[str(ICON)],
    contents_directory="_internal",
)
coll = COLLECT(
    exe, a.binaries, a.datas, strip=False, upx=True, upx_exclude=[], name="Lumo",
)
