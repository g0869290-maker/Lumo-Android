#!/usr/bin/env python3
r"""lumo_debug.py - run Lumo and print every error with its exact cause, in this window.

Run from the project folder in PowerShell:
    .\.venv312\Scripts\python.exe lumo_debug.py

Every problem is printed as it happens:
  [CRASH]    an uncaught exception that stops the app
  [UI]       an error raised by a button, page or widget (Tkinter callback)
  [THREAD]   an error inside a background thread (download, inspection, thumbnail)
  [INSPECT]  each video inspection: how long it took and the result or error
  [YTDLP]    yt-dlp / ffmpeg warnings and errors, with the reason
  [THUMB]    thumbnail and subtitle trace lines that report a failure
  [FREEZE]   the window stopped responding (with the code that was running)
  [SILENT]   code that hides errors (an except block that does nothing)

At the end, a summary lists every distinct problem with its count and cause.
Everything is saved to ONE file: lumo_full_report.txt in the project folder.
Nothing in Lumo is changed. Close the Lumo window to finish.
"""
from __future__ import annotations

import ast
import os
import re
import subprocess
import sys
import threading
import time
import traceback
from collections import Counter, OrderedDict
from pathlib import Path

ROOT = Path(__file__).resolve().parent
FREEZE_MS = 150
HEARTBEAT_MS = 20
SKIP_DIRS = {".venv", ".venv312", "venv", "build", "dist", "__pycache__", "release",
             "installer_output", "old_files", "tests", ".git"}

# ------------------------------------------------------------------ causes
# Each known message is explained in plain words. The first match wins.
KNOWN_CAUSES = [
    ("CERTIFICATE_VERIFY_FAILED", "HTTPS certificate not trusted on this PC (antivirus or web filter "
     "inspecting HTTPS). Thumbnails use the certifi bundle; see the antivirus HTTPS setting."),
    ("Signature solving failed", "No working JavaScript runtime (deno) or outdated yt-dlp-ejs. "
     "Check vendor\\deno.exe --version (needs 2.3+) and update yt-dlp-ejs."),
    ("n challenge solving failed", "No working JavaScript runtime (deno) or outdated yt-dlp-ejs. "
     "Check vendor\\deno.exe --version (needs 2.3+) and update yt-dlp-ejs."),
    ("Only images are available", "YouTube gave only storyboard images: JavaScript runtime missing "
     "or yt-dlp is out of date. Update yt-dlp and check deno."),
    ("Requested format is not available", "The chosen quality is not offered for this video: "
     "JavaScript runtime missing, or the quality is really absent."),
    ("Video unavailable", "Private, removed, age-restricted or region-blocked video, or YouTube changed "
     "its page (update yt-dlp)."),
    ("Sign in to confirm", "YouTube wants a login: the cookie file is missing, wrong or expired."),
    ("HTTP Error 429", "YouTube is rate-limiting this connection. Wait a few minutes."),
    ("504", "A server or proxy timed out (504 Gateway Timeout). Retry later or change network."),
    ("Read timed out", "Network too slow or blocked for youtube.com. Retry or change network."),
    ("handshake operation timed out", "Network timeout while connecting to YouTube (TLS handshake)."),
    ("TimeoutError", "A network operation timed out."),
    ("ffmpeg", "ffmpeg is missing or failed: check vendor\\ffmpeg.exe."),
    ("No module named", "A Python package is missing from .venv312: run check_and_install.bat."),
    ("Permission denied", "A file is in use or the folder is not writable. Close other programs using it."),
    ("UnicodeEncodeError", "Text encoding problem in the console or a file name."),
    ("Errno 28", "The disk is full."),
]


def explain(text: str) -> str:
    for pattern, cause in KNOWN_CAUSES:
        if pattern in text:
            return cause
    return "Not a known cause. The traceback or message above shows where it happened."


# ------------------------------------------------------------------ output
REPORT: list[str] = []


def say(text: str = "") -> None:
    """Print to the PowerShell window and keep the same line for the single report file."""
    print(text, flush=True)
    REPORT.append(str(text))


LOG: list[tuple[str, str, str]] = []   # (category, message, cause)
LOCK = threading.Lock()


def emit(category: str, message: str, cause: str = "", detail: str = "") -> None:
    stamp = time.strftime("%H:%M:%S")
    with LOCK:
        LOG.append((category, message.strip().splitlines()[0] if message.strip() else "", cause))
        lines = [f"{stamp} [{category}] {message.strip()}"]
        if cause:
            lines.append(f"            cause: {cause}")
        if detail:
            lines.append(detail.rstrip())
        say("\n".join(lines))


def tail(text: str, count: int = 12) -> str:
    rows = [r for r in (text or "").splitlines() if r.strip()]
    return "\n".join("            | " + r for r in rows[-count:])


# ------------------------------------------------------------------ silent except scan
def silent_except_scan() -> list[str]:
    """Find except blocks whose only statement is 'pass': errors vanish there."""
    found: list[str] = []
    for path in sorted(ROOT.rglob("*.py")):
        if any(part in SKIP_DIRS for part in path.relative_to(ROOT).parts[:-1]):
            continue
        if path.name in {"lumo_debug.py", "lumo_diagnose.py", "recovered_main.py"}:
            continue
        try:
            tree = ast.parse(path.read_text(encoding="utf-8", errors="replace"))
        except SyntaxError:
            continue
        for node in ast.walk(tree):
            if isinstance(node, ast.ExceptHandler) and len(node.body) == 1 \
                    and isinstance(node.body[0], ast.Pass):
                kind = ast.unparse(node.type) if node.type is not None else "bare except"
                found.append(f"{path.relative_to(ROOT).as_posix()}:{node.lineno}  except {kind}: pass")
    return found


# ------------------------------------------------------------------ hooks
def install_crash_hooks() -> None:
    def crash(exc_type, exc, tb):
        text = "".join(traceback.format_exception(exc_type, exc, tb))
        emit("CRASH", f"{exc_type.__name__}: {exc}", explain(str(exc) + text), text)
    sys.excepthook = crash

    def thread_crash(args):
        text = "".join(traceback.format_exception(args.exc_type, args.exc_value, args.exc_traceback))
        emit("THREAD", f"in thread '{args.thread.name if args.thread else '?'}': "
             f"{args.exc_type.__name__}: {args.exc_value}",
             explain(str(args.exc_value) + text), text)
    threading.excepthook = thread_crash


def install_tk_hooks(tk) -> None:
    def ui_error(self, exc, val, tb):
        text = "".join(traceback.format_exception(exc, val, tb))
        emit("UI", f"{exc.__name__}: {val}", explain(str(val) + text), text)
    tk.Tk.report_callback_exception = ui_error


def wrap_downloader(module) -> None:
    """Time and report every inspection; report failures from its results."""
    for name in ("inspect_url", "extract_playlist_urls"):
        original = getattr(module, name, None)
        if not callable(original):
            continue

        def make(original=original, name=name):
            def wrapped(url, *args, **kwargs):
                started = time.perf_counter()
                try:
                    result = original(url, *args, **kwargs)
                except Exception as exc:
                    emit("INSPECT", f"{name} raised {type(exc).__name__}: {exc}",
                         explain(str(exc)), traceback.format_exc())
                    raise
                took = time.perf_counter() - started
                info, error = (result if isinstance(result, tuple) and len(result) == 2 else (result, None))
                if error:
                    emit("INSPECT", f"{name} failed after {took:.1f} s for {str(url)[:70]}",
                         explain(str(error)), f"            | {str(error)[:400]}")
                else:
                    title = info.get("title") if isinstance(info, dict) else type(info).__name__
                    emit("INSPECT", f"{name} ok in {took:.1f} s: {str(title)[:70]}")
                return result
            return wrapped
        setattr(module, name, make())


def wrap_subprocess() -> None:
    real_run = subprocess.run

    def run(args, *a, **k):
        result = real_run(args, *a, **k)
        command = " ".join(map(str, args)) if isinstance(args, (list, tuple)) else str(args)
        if "yt_dlp" in command or "ffmpeg" in command or "ffprobe" in command:
            stderr = result.stderr if isinstance(result.stderr, str) else ""
            stdout = result.stdout if isinstance(result.stdout, str) else ""
            for line in (stderr + "\n" + stdout).splitlines():
                clean = line.strip()
                if clean.startswith(("WARNING:", "ERROR:")):
                    emit("YTDLP", clean[:220], explain(clean))
            if result.returncode not in (0, None):
                emit("YTDLP", f"process exited with code {result.returncode}",
                     explain(stderr + stdout), tail(stderr or stdout))
        return result
    subprocess.run = run


def watch_freezes(tk) -> None:
    """Report any UI freeze longer than FREEZE_MS with the project code that was running."""
    state = {"root": None, "beat": None, "main": threading.get_ident(), "reported": None}
    original_init = tk.Tk.__init__

    def beat():
        state["beat"] = time.perf_counter()
        if state["root"] is not None:
            state["root"].after(HEARTBEAT_MS, beat)

    def patched_init(self, *a, **k):
        original_init(self, *a, **k)
        if state["root"] is None:
            state["root"] = self
            state["main"] = threading.get_ident()
            self.after(HEARTBEAT_MS, beat)
    tk.Tk.__init__ = patched_init

    def watchdog():
        while True:
            time.sleep(0.01)
            last = state["beat"]
            if last is None or state["reported"] == last:
                continue
            late = time.perf_counter() - last
            if late * 1000 > FREEZE_MS:
                state["reported"] = last
                frame = sys._current_frames().get(state["main"])
                where = []
                if frame is not None:
                    for f in traceback.extract_stack(frame):
                        if str(ROOT).casefold() in f.filename.casefold() and "lumo_debug" not in f.filename:
                            where.append(f"{Path(f.filename).name}:{f.lineno} {f.name}")
                emit("FREEZE", f"window stopped responding for more than {FREEZE_MS} ms",
                     "Heavy work on the window thread. The code below was running.",
                     "            | " + (" -> ".join(where[-4:]) or "(no project code: Tk drawing)"))
    threading.Thread(target=watchdog, daemon=True, name="lumo-debug-watchdog").start()


# ------------------------------------------------------------------ summary
def summary(silent: list[str]) -> None:
    counts = Counter(cat for cat, _, _ in LOG)
    causes: "OrderedDict[str, list]" = OrderedDict()
    for cat, msg, cause in LOG:
        if cat in ("INSPECT", "CRASH", "UI", "THREAD", "YTDLP", "FREEZE") and cause:
            entry = causes.setdefault(cause, [0, cat, msg])
            entry[0] += 1
    out = ["", "=" * 78, "SUMMARY", "=" * 78]
    out.append("Events: " + ", ".join(f"{k}={v}" for k, v in sorted(counts.items())) if counts else "No events.")
    out.append(f"Silent except blocks in the project (errors hidden there): {len(silent)}")
    if causes:
        out.append("\nDistinct problems, most frequent first:")
        for cause, (count, cat, msg) in sorted(causes.items(), key=lambda kv: -kv[1][0]):
            out.append(f"  x{count}  [{cat}] {msg[:120]}")
            out.append(f"        cause: {cause}")
    if silent:
        out.append("Full list of silent except blocks: section 5 of lumo_full_report.txt")
    for line in out:
        say(line)


def trace_files_summary() -> None:
    temp = Path(os.environ.get("TEMP", "/tmp"))
    for name in ("lumo_subs_trace.log", "lumo_thumb_trace.log", "lumo_tick_trace.log"):
        path = temp / name
        if not path.exists():
            continue
        rows = path.read_text(encoding="utf-8", errors="replace").splitlines()
        bad = [r for r in rows if re.search(r"fail|skipped|error|no usable|gave up|timed out|exit [1-9]", r, re.I)]
        if bad:
            emit("THUMB" if "thumb" in name else "YTDLP",
                 f"{name}: {len(bad)} failure line(s); last: {bad[-1][:180]}",
                 explain(bad[-1]))


# ------------------------------------------------------------------ single report
def _cmd(args: list[str], timeout: int = 20) -> str:
    try:
        out = subprocess.run(args, capture_output=True, text=True, timeout=timeout,
                             creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        return ((out.stdout or "") + (out.stderr or "")).strip()
    except Exception as exc:
        return f"(could not run: {exc})"


def _sha256(path: Path) -> str:
    import hashlib
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def write_full_report() -> None:
    import platform
    lines = ["LUMO FULL REPORT", "Generated: " + time.strftime("%Y-%m-%d %H:%M:%S"), ""]
    lines += ["=" * 78, "1. ENVIRONMENT", "=" * 78]
    lines += [f"Python      : {sys.version.splitlines()[0]}",
              f"Executable  : {sys.executable}",
              f"Platform    : {platform.platform()}",
              f"Project     : {ROOT}"]
    py = sys.executable
    lines += ["", "=" * 78, "2. TOOLS AND PACKAGES", "=" * 78]
    lines.append("yt-dlp      : " + _cmd([py, "-m", "yt_dlp", "--version"]).splitlines()[0:1][0]
                 if _cmd([py, "-m", "yt_dlp", "--version"]) else "yt-dlp      : (not importable)")
    for pkg in ("yt-dlp-ejs", "pyinstaller", "pillow", "certifi"):
        info = _cmd([py, "-m", "pip", "show", pkg])
        version = next((ln.split(":", 1)[1].strip() for ln in info.splitlines() if ln.startswith("Version:")), "not installed")
        lines.append(f"{pkg:<12}: {version}")
    deno = ROOT / "vendor" / "deno.exe"
    lines.append("deno        : " + (_cmd([str(deno), "--version"]).splitlines() or ["(no output)"])[0]
                 if deno.exists() else "deno        : vendor\\deno.exe MISSING")
    ffmpeg = ROOT / "vendor" / "ffmpeg.exe"
    lines.append("ffmpeg      : " + (_cmd([str(ffmpeg), "-version"]).splitlines() or ["(no output)"])[0]
                 if ffmpeg.exists() else "ffmpeg      : vendor\\ffmpeg.exe MISSING")

    lines += ["", "=" * 78, "3. PROJECT FILES (size and SHA-256 of every file)", "=" * 78]
    for path in sorted(ROOT.rglob("*")):
        rel = path.relative_to(ROOT)
        if not path.is_file() or any(part in SKIP_DIRS for part in rel.parts[:-1]):
            continue
        try:
            lines.append(f"{rel.as_posix():<52} {path.stat().st_size:>12,} bytes  {_sha256(path)[:16]}")
        except OSError as exc:
            lines.append(f"{rel.as_posix():<52} ERROR {exc}")

    lines += ["", "=" * 78, "4. TRACE LOGS (last 200 lines of each, from %TEMP%)", "=" * 78]
    temp = Path(os.environ.get("TEMP", "/tmp"))
    for name in ("lumo_subs_trace.log", "lumo_thumb_trace.log", "lumo_tick_trace.log", "lumo_perf.log"):
        path = temp / name
        lines.append(f"--- {name}")
        if path.exists():
            rows = path.read_text(encoding="utf-8", errors="replace").splitlines()
            lines += rows[-200:] or ["(empty)"]
        else:
            lines.append("(not created yet)")

    lines += ["", "=" * 78, "5. SILENT EXCEPT BLOCKS (errors hidden without a message)", "=" * 78]
    lines += silent_except_scan() or ["(none)"]

    lines += ["", "=" * 78, "6. SESSION (everything printed while Lumo ran)", "=" * 78]
    lines += REPORT
    try:
        (ROOT / "lumo_full_report.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
        print("Single report saved: " + str(ROOT / "lumo_full_report.txt"))
    except OSError as exc:
        print(f"Could not save the report: {exc}")


# ------------------------------------------------------------------ main
def main() -> int:
    os.chdir(ROOT)
    sys.path.insert(0, str(ROOT))
    say("Lumo debug monitor. Errors appear below as they happen. Close Lumo to finish.")
    say(f"Project: {ROOT}\n")

    silent = silent_except_scan()
    say(f"[SILENT] {len(silent)} except block(s) hide errors. Full list is in the report.")
    for line in silent[:8]:
        say("         " + line)

    install_crash_hooks()
    wrap_subprocess()
    import tkinter as tk
    install_tk_hooks(tk)
    watch_freezes(tk)
    try:
        import lumo_windows.downloader as downloader
        wrap_downloader(downloader)
    except Exception as exc:
        emit("CRASH", f"could not load the downloader module: {exc}", explain(str(exc)),
             traceback.format_exc())

    import runpy
    try:
        runpy.run_path(str(ROOT / "main.py"), run_name="__main__")
    except SystemExit:
        pass
    except BaseException as exc:
        emit("CRASH", f"main.py stopped: {type(exc).__name__}: {exc}", explain(str(exc)),
             traceback.format_exc())
    trace_files_summary()
    summary(silent)
    write_full_report()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
