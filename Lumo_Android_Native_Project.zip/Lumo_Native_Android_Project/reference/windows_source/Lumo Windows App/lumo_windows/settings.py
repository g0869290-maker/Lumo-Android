"""Settings storage for Lumo.

Keeps the app's existing settings path and normalises persistent preferences.
The launcher adds the independent progress bar colour to the recovered UI.
Appearance is locked to Dark; accent, indicator, and progress colours are
validated six-digit hex values.
"""
from __future__ import annotations

import json
import os
import re
from pathlib import Path
from typing import Any

def _resolve_base_dir() -> Path:
    """Use the classic D:\\YTD folder when it exists, otherwise a per-user folder.

    Keeps existing settings and history on machines that have a D: drive, and
    stops the app failing on machines that do not.
    """
    override = os.environ.get("LUMO_HOME") or os.environ.get("VIDZY_HOME")
    if override:
        return Path(override)
    if os.name == "nt" and Path("D:\\").exists():
        return Path("D:\\YTD")
    base = Path(os.environ.get("LOCALAPPDATA") or str(Path.home()))
    current, previous = base / "Lumo", base / "Vidzy"
    if not current.exists() and previous.exists():
        return previous  # keep settings from the earlier per-user folder
    return current


BASE_DIR = _resolve_base_dir()
DATA_DIR = BASE_DIR / "Data"
SETTINGS_FILE = DATA_DIR / "settings.json"

DEFAULTS: dict[str, Any] = {
    "download_dir": str(BASE_DIR / "Downloads"),
    "use_cookies": True,
    "cookie_file": str(BASE_DIR / "Backup" / "www.youtube.com_cookies.txt"),
    "cookie_prompt_seen": False,
    "subtitle_languages": ["en", "hi", "mr"],
    "prefer_creator_subtitles": True,
    "merge_to_mp4": True,
    "save_thumbnail": False,
    "save_metadata": False,
    "preferred_subtitle": "en",
    # The current user's recovered settings contain these values. They are safe
    # fallbacks; valid values already in settings.json always take precedence.
    "appearance": "Dark",
    "accent": "#FF647F",
    "indicator": "#FFB45F",
    "progress_color": "#8871FF",
    "progress_glow_enabled": True,
    "progress_glow_intensity": 45,
    "progress_animation_enabled": True,
    "progress_animation_speed": "normal",
    "progress_thickness": 14,
    # Optional interface controls; hiding a button never deletes the underlying feature.
    "show_history_action_icons": False,
    "animate_history_action_icons": False,
    "show_open_location_action": True,
    "show_share_action": True,
    "show_delete_action": True,
    "show_playlist_thumbnails": True,
    "compact_playlist_rows": False,
    "confirm_file_delete": True,
}

_HEX_COLOUR = re.compile(r"^#[0-9A-Fa-f]{6}$")


def _fresh_defaults() -> dict[str, Any]:
    """Return defaults without sharing the mutable subtitle list."""
    return {
        key: (list(value) if isinstance(value, list) else value)
        for key, value in DEFAULTS.items()
    }


def _normalise(settings: dict[str, Any]) -> dict[str, Any]:
    """Validate known settings and enforce the requested dark-only mode."""
    clean = _fresh_defaults()
    for key, default in DEFAULTS.items():
        value = settings.get(key, default)
        if type(value) is type(default):
            clean[key] = list(value) if isinstance(value, list) else value

    # Dark mode is intentional and must not flip back to Light on startup.
    clean["appearance"] = "Dark"
    for key in ("accent", "indicator", "progress_color"):
        value = clean.get(key)
        if not isinstance(value, str) or not _HEX_COLOUR.fullmatch(value):
            clean[key] = DEFAULTS[key]
        else:
            clean[key] = value.upper()

    clean["progress_glow_intensity"] = max(0, min(100, clean.get("progress_glow_intensity", 45)))
    clean["progress_thickness"] = max(9, min(16, clean.get("progress_thickness", 14)))
    if clean.get("progress_animation_speed") not in {"slow", "normal", "fast"}:
        clean["progress_animation_speed"] = "normal"

    # History uses plain-text actions by design. Ignore True left in settings.json
    # by earlier builds so those icons cannot return after an upgrade.
    clean["show_history_action_icons"] = False
    clean["animate_history_action_icons"] = False
    for key in (
        "show_open_location_action", "show_share_action", "show_delete_action",
        "show_playlist_thumbnails", "compact_playlist_rows", "confirm_file_delete",
    ):
        clean[key] = bool(clean.get(key, DEFAULTS[key]))

    languages = clean.get("subtitle_languages")
    if not isinstance(languages, list) or any(not isinstance(item, str) for item in languages):
        clean["subtitle_languages"] = list(DEFAULTS["subtitle_languages"])
    return clean


def ensure_data_dir() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)


def load_settings() -> dict[str, Any]:
    """Read all known preferences, including accent/indicator/theme keys."""
    ensure_data_dir()
    if not SETTINGS_FILE.exists():
        return _fresh_defaults()

    try:
        with SETTINGS_FILE.open("r", encoding="utf-8") as handle:
            stored = json.load(handle)
    except (OSError, json.JSONDecodeError, UnicodeDecodeError):
        # Preserve a damaged file for inspection rather than deleting it.
        damaged = DATA_DIR / "settings.damaged.json"
        try:
            if damaged.exists():
                damaged = DATA_DIR / "settings.damaged.previous.json"
            os.replace(SETTINGS_FILE, damaged)
        except OSError:
            # Do not make app startup fail because recovery/rename failed.
            pass
        return _fresh_defaults()

    if not isinstance(stored, dict):
        return _fresh_defaults()
    return _normalise(stored)


def save_settings(settings: dict[str, Any]) -> None:
    """Atomically save the app's known settings without losing colour keys."""
    ensure_data_dir()
    clean = _normalise(settings if isinstance(settings, dict) else {})
    temp_file = DATA_DIR / "settings.tmp"
    try:
        with temp_file.open("w", encoding="utf-8", newline="\n") as handle:
            json.dump(clean, handle, indent=2, ensure_ascii=False)
            handle.write("\n")
        os.replace(temp_file, SETTINGS_FILE)
    finally:
        # If write/replace failed, remove only the temporary file created here.
        try:
            temp_file.unlink(missing_ok=True)
        except OSError:
            pass


def check_download_dir(path_text: str) -> tuple[bool, str]:
    path = Path(path_text)
    try:
        path.mkdir(parents=True, exist_ok=True)
        probe = path / ".lumo_write_test"
        probe.write_text("ok", encoding="utf-8")
        probe.unlink()
    except OSError as error:
        return False, f"Cannot use this folder: {error}"
    return True, "Folder is ready."
