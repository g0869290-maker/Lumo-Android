"""Downloader backend for Lumo.

This module intentionally performs one metadata extraction during inspection,
keeps a private temporary cookie copy alive until download starts, and uses an
explicit height cap for the selected quality.

Requires: pip install -U yt-dlp
For merging separate video/audio streams, FFmpeg must be installed and available
on PATH.
"""
from __future__ import annotations

import atexit
import copy
import functools
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import time
from collections import OrderedDict
from pathlib import Path
from typing import Any, Callable


_OWNED_COOKIE_FILES: set[str] = set()
_COOKIE_LOCK = threading.Lock()
# Seconds between progress callbacks. Hooks can fire hundreds of times a second with
# fragmented streams; throttling keeps the UI thread responsive.
_PROGRESS_INTERVAL = 0.15


def _yt_dlp():
    try:
        import yt_dlp
    except ImportError as exc:
        raise RuntimeError(
            "yt-dlp is not installed. Open a terminal and run: python -m pip install -U yt-dlp"
        ) from exc
    return yt_dlp


_RUNTIME_CACHE: tuple[dict[str, Any], str | None] | None = None
_RUNTIME_LOCK = threading.Lock()

# Inspection results are kept briefly so that re-inspecting the same link is instant,
# and starting a download does not repeat the slow extraction (JavaScript challenge
# solving). Stream URLs stay valid for hours, so a 20-minute lifetime is safe.
_DETAILS_CACHE: OrderedDict[tuple[str, str], tuple[float, dict[str, Any], list]] = OrderedDict()
_DETAILS_LOCK = threading.Lock()
_DETAILS_TTL_SECONDS = 20 * 60
_DETAILS_MAX_ENTRIES = 8


def _cookie_cache_token(cookie_path: str | os.PathLike[str] | bool | None) -> str:
    """Distinguish inspection caches by the selected cookie file, not just on/off."""
    # prepare_cookies() writes a new temporary copy on every call, so the path
    # differs between inspection and download. Key on whether cookies are used,
    # not on the temporary file's path, so a download reuses the inspection.
    if isinstance(cookie_path, bool):  # compatibility with older private callers
        return "enabled" if cookie_path else "disabled"
    return "enabled" if str(cookie_path or "").strip() else "disabled"


def _details_store(url: str, cookie_path: str | os.PathLike[str] | bool | None,
                   details: dict[str, Any], messages: list) -> None:
    key = (str(url).strip(), _cookie_cache_token(cookie_path))
    with _DETAILS_LOCK:
        _DETAILS_CACHE[key] = (time.monotonic(), details, messages)
        _DETAILS_CACHE.move_to_end(key)
        while len(_DETAILS_CACHE) > _DETAILS_MAX_ENTRIES:
            _DETAILS_CACHE.popitem(last=False)


def _details_take(url: str, cookie_path: str | os.PathLike[str] | bool | None):
    """Return private copies of fresh (details, messages), or None if nothing fresh is cached."""
    key = (str(url).strip(), _cookie_cache_token(cookie_path))
    with _DETAILS_LOCK:
        entry = _DETAILS_CACHE.get(key)
        if entry is None:
            return None
        stored_at, details, messages = entry
        if time.monotonic() - stored_at > _DETAILS_TTL_SECONDS:
            _DETAILS_CACHE.pop(key, None)
            return None
        _DETAILS_CACHE.move_to_end(key)
    # yt-dlp may add fields to the top-level info dict and to each format while
    # downloading. Copy those two levels only: a full deep copy of a large
    # metadata dict on every reuse was a needless cost on each inspection/start.
    try:
        top = dict(details)
        if isinstance(top.get("formats"), list):
            top["formats"] = [dict(f) if isinstance(f, dict) else f for f in top["formats"]]
        return top, list(messages)
    except Exception:
        return None


def _version_tuple(executable: str, runtime: str) -> tuple[int, ...] | None:
    """Return a numeric runtime version, or None if it cannot be read quickly."""
    try:
        result = subprocess.run(
            [executable, "--version"], capture_output=True, text=True,
            timeout=20, check=False, stdin=subprocess.DEVNULL, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        output = (result.stdout or result.stderr or "").strip()
        if result.returncode != 0 or not output:
            return None
        if runtime == "deno":
            match = re.search(r"\b(\d+)\.(\d+)\.(\d+)\b", output)
        else:
            match = re.search(r"v?(\d+)\.(\d+)\.(\d+)", output)
        return tuple(map(int, match.groups())) if match else None
    except (OSError, subprocess.SubprocessError, ValueError):
        return None


def _ffmpeg_dir() -> str:
    """Find the FFmpeg folder without masking a working system-PATH installation.

    Prefer the app's portable copy. If it is missing, use the folder containing
    FFmpeg on PATH. Only return the expected vendor folder as a last-resort hint;
    callers can then choose the no-FFmpeg fallback instead of assuming it exists.
    """
    app_dir = (Path(sys.executable).resolve().parent if getattr(sys, "frozen", False)
               else Path(__file__).resolve().parents[1])
    exe_name = "ffmpeg.exe" if os.name == "nt" else "ffmpeg"
    for folder in (app_dir, app_dir / "vendor"):
        try:
            if (folder / exe_name).is_file():
                return str(folder)
        except OSError:
            pass
    on_path = shutil.which("ffmpeg") or shutil.which("ffmpeg.exe")
    if on_path:
        return str(Path(on_path).resolve().parent)
    return str(app_dir / "vendor")


def _ffmpeg_available() -> bool:
    """Return whether FFmpeg is present in the app bundle or on PATH."""
    name = "ffmpeg.exe" if os.name == "nt" else "ffmpeg"
    try:
        if (Path(_ffmpeg_dir()) / name).is_file():
            return True
    except OSError:
        pass
    return bool(shutil.which("ffmpeg") or shutil.which("ffmpeg.exe"))


def _runtime_candidates(runtime: str) -> list[Path]:
    """Look for runtimes on PATH and in common portable/Windows install locations."""
    exe_name = runtime + (".exe" if os.name == "nt" else "")
    found: list[Path] = []
    on_path = shutil.which(runtime) or shutil.which(exe_name)
    if on_path:
        found.append(Path(on_path))

    app_dir = Path(__file__).resolve().parent.parent
    candidates = [app_dir / exe_name, app_dir / "bin" / exe_name,
                  app_dir / "vendor" / exe_name,
                  Path(sys.executable).resolve().parent / exe_name]
    if os.name == "nt":
        local = os.environ.get("LOCALAPPDATA")
        profile = os.environ.get("USERPROFILE")
        program_files = os.environ.get("PROGRAMFILES")
        if runtime == "deno":
            if profile:
                candidates.append(Path(profile) / ".deno" / "bin" / exe_name)
            if local:
                candidates.append(Path(local) / "Programs" / "deno" / exe_name)
            if program_files:
                candidates.append(Path(program_files) / "Deno" / exe_name)
        elif runtime == "node" and program_files:
            candidates.append(Path(program_files) / "nodejs" / exe_name)
    for path in candidates:
        try:
            if path.is_file():
                found.append(path)
        except OSError:
            continue
    unique: list[Path] = []
    seen: set[str] = set()
    for path in found:
        try:
            resolved = str(path.resolve())
        except (OSError, RuntimeError):
            resolved = str(path)
        if resolved.casefold() not in seen:
            seen.add(resolved.casefold())
            unique.append(Path(resolved))
    return unique


def _js_runtime_options() -> tuple[dict[str, Any], str | None]:
    """Use a supported local JS runtime even if it isn't on this process's PATH.

    Current yt-dlp needs a supported runtime for complete YouTube format extraction.
    Deno 2.3+ is preferred; Node 22+ is a fallback. No software is installed by this
    function, and a missing runtime is reported separately instead of guessed at.
    """
    global _RUNTIME_CACHE
    with _RUNTIME_LOCK:
        if _RUNTIME_CACHE is not None:
            return dict(_RUNTIME_CACHE[0]), _RUNTIME_CACHE[1]
        for runtime, minimum, display in (("deno", (2, 3, 0), "Deno"),
                                          ("node", (22, 0, 0), "Node.js")):
            for path in _runtime_candidates(runtime):
                version = _version_tuple(str(path), runtime)
                if version is None or version < minimum:
                    continue
                options = {"js_runtimes": {runtime: {"path": str(path)}}}
                label = f"{display} {'.'.join(map(str, version))} ({path})"
                _RUNTIME_CACHE = (options, label)
                return dict(options), label
        # Do not cache a failure: a slow first run (antivirus scan) must be retried.
        return {}, None


def warm_up() -> None:
    """Import yt-dlp and locate a JavaScript runtime in the background.

    Calling this at startup moves the one-time costs (module import and the
    runtime version checks) out of the user's first inspection.
    """
    try:
        _yt_dlp()
    except RuntimeError:
        return
    _js_runtime_options()


class _InspectionLogger:
    """Collect yt-dlp messages during metadata inspection so the UI can explain failures.

    With LUMO_PERF=1, each YouTube step yt-dlp reports is printed with the time it
    happened, so slow stages show up in the PowerShell window.
    """
    def __init__(self, cancel_event: "threading.Event | None" = None):
        self.messages: list[tuple[str, str]] = []
        self._started = time.perf_counter()
        # When set, the next message yt-dlp reports aborts that extraction. Used to stop
        # the losing route of the inspection race instead of letting it keep running.
        self._cancel_event = cancel_event

    def _step(self, message) -> None:
        if self._cancel_event is not None and self._cancel_event.is_set():
            from yt_dlp.utils import DownloadCancelled
            raise DownloadCancelled("route no longer needed")
        if os.environ.get("LUMO_PERF") != "1":
            return
        text = str(message or "").strip()
        if "[youtube" in text or "player" in text.lower():
            elapsed = time.perf_counter() - self._started
            print(f"[step +{elapsed:6.2f}s] {text[:150]}", flush=True)

    def debug(self, message):
        self._step(message)

    def info(self, message):
        self._step(message)

    def warning(self, message):
        message = str(message or "").strip()
        if message:
            self.messages.append(("warning", message))
            self._step(message)

    def error(self, message):
        message = str(message or "").strip()
        if message:
            self.messages.append(("error", message))
            self._step(message)


def prepare_cookies(use_cookies: bool, cookie_file: str | os.PathLike[str] | None):
    """Copy a Netscape-format cookie file to a private temporary file.

    Returning a copy (rather than the user's original file) is important:
    callers clean up the copy after use, never the original cookie file.
    """
    if not use_cookies:
        return None, "Cookies are off."
    if not str(cookie_file or "").strip():
        raise ValueError("Cookies are enabled, but no cookie file is selected in Settings.")

    source = Path(cookie_file).expanduser()
    if not source.is_file():
        raise FileNotFoundError(f"The cookie file does not exist: {source}")

    try:
        raw = source.read_bytes()
        text = raw.decode("utf-8-sig")
    except UnicodeDecodeError as exc:
        raise ValueError("The cookie file is not readable UTF-8 text. Export a Netscape-format cookies.txt file.") from exc
    except OSError as exc:
        raise OSError(f"The cookie file could not be read: {exc}") from exc

    # yt-dlp expects the Netscape cookie-file format, not a browser database.
    first_lines = "\n".join(text.replace("\r\n", "\n").split("\n")[:8]).lower()
    if "netscape http cookie file" not in first_lines and "http cookie file" not in first_lines:
        raise ValueError(
            "This does not look like a Netscape-format cookies.txt file. "
            "Export cookies as cookies.txt, then select that file in Settings."
        )

    newline = "\r\n" if os.name == "nt" else "\n"
    normalized = text.replace("\r\n", "\n").replace("\r", "\n").replace("\n", newline)
    fd, temp_name = tempfile.mkstemp(prefix="lumo_cookie_", suffix=".txt")
    target = Path(temp_name)
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as handle:
            handle.write(normalized)
        resolved = str(target.resolve())
        with _COOKIE_LOCK:
            _OWNED_COOKIE_FILES.add(resolved)
        return resolved, "Private cookie copy prepared."
    except Exception:
        try:
            os.close(fd)
        except OSError:
            pass
        target.unlink(missing_ok=True)
        raise


def cleanup_cookies(cookie_path: str | os.PathLike[str] | None) -> None:
    """Delete only temporary copies made by prepare_cookies()."""
    if not cookie_path:
        return
    try:
        resolved = str(Path(cookie_path).resolve())
    except (OSError, RuntimeError, TypeError, ValueError):
        return
    with _COOKIE_LOCK:
        owned = resolved in _OWNED_COOKIE_FILES
        if owned:
            _OWNED_COOKIE_FILES.discard(resolved)
    if owned:
        try:
            Path(resolved).unlink(missing_ok=True)
        except OSError:
            pass


def cleanup_all_cookies() -> None:
    """Best-effort removal of every temporary cookie copy owned by this process."""
    with _COOKIE_LOCK:
        paths = list(_OWNED_COOKIE_FILES)
        _OWNED_COOKIE_FILES.clear()
    for path in paths:
        try:
            Path(path).unlink(missing_ok=True)
        except OSError:
            pass


atexit.register(cleanup_all_cookies)


_PROBE_LAST = [0.0]


class _SpeedTracker:
    """Smoothed speed and ETA for one download, from the combined bytes of all streams.

    The speed is the average over a short window, blended with the previous value so it
    does not jump. A stalled download decays toward 0 instead of freezing at its last
    speed. Bytes never go backwards, so a reset in one stream cannot show a fake speed.
    """

    WINDOW_SECONDS = 2.0
    MIN_SPAN_SECONDS = 0.5
    BLEND = 0.4  # weight of the newest measurement
    MIN_ETA_SPEED = 1024.0  # below 1 KB/s an ETA is meaningless, so none is shown

    def __init__(self) -> None:
        self._samples: list[tuple[float, float]] = []
        self._speed: float | None = None
        self._done = 0.0

    def update(self, now: float, done: float, total: float | None) -> tuple[float | None, float | None]:
        done = max(float(done or 0.0), self._done)
        self._done = done
        self._samples.append((now, done))
        cutoff = now - self.WINDOW_SECONDS
        while len(self._samples) > 2 and self._samples[1][0] <= cutoff:
            self._samples.pop(0)
        start_time, start_done = self._samples[0]
        span = now - start_time
        if span >= self.MIN_SPAN_SECONDS:
            instant = max(0.0, (done - start_done) / span)
            if instant == 0.0:
                # Nothing arrived in the window: show a stall at once, not a slow decay.
                self._speed = 0.0
            elif self._speed is None:
                self._speed = instant
            else:
                self._speed = (1.0 - self.BLEND) * self._speed + self.BLEND * instant
        speed = self._speed
        eta = None
        if speed is not None and speed >= self.MIN_ETA_SPEED and total and total > done:
            eta = (total - done) / speed
        return speed, eta


def _progress_probe(downloaded: float, total: float, pct: float, streams: int, expected: int) -> None:
    """With LUMO_PERF=1, print the numbers behind the progress bar about every 3 seconds."""
    if os.environ.get("LUMO_PERF") != "1":
        return
    now = time.monotonic()
    if now - _PROBE_LAST[0] < 3.0:
        return
    _PROBE_LAST[0] = now
    print(f"[progress] {time.strftime('%H:%M:%S')}  {downloaded / 1048576:8.1f} MB of "
          f"{total / 1048576:8.1f} MB  = {pct:5.1f}%  streams {streams}/{expected}", flush=True)


def _subs_trace(message: str) -> None:
    """Report one subtitle step: printed to the console (CMD) and appended to %TEMP%\\lumo_subs_trace.log."""
    line = f"{time.strftime('%H:%M:%S')} [subs] {message}"
    print(line, flush=True)
    try:
        with (Path(tempfile.gettempdir()) / "lumo_subs_trace.log").open("a", encoding="utf-8") as handle:
            handle.write(line + "\n")
    except OSError:
        pass


def _cookie_option(cookie_path):
    if not cookie_path:
        return {}
    path = Path(cookie_path).expanduser()
    if not path.is_file():
        raise FileNotFoundError("The prepared cookie file is no longer available. Recheck the cookie file in Settings.")
    return {"cookiefile": str(path)}


def _size_of(fmt: dict[str, Any]) -> float | None:
    value = fmt.get("filesize") or fmt.get("filesize_approx")
    try:
        number = float(value)
        return number if number > 0 else None
    except (TypeError, ValueError):
        return None


def _has_video(fmt: dict[str, Any]) -> bool:
    raw_codec = fmt.get("vcodec")
    codec = str(raw_codec or "").strip().lower()
    if codec not in {"", "unknown"}:
        return codec != "none"
    # Some clients return sparse format metadata. A usable height is strong evidence
    # of a video stream even if yt-dlp omitted vcodec in that entry.
    return _height(fmt) is not None or bool(fmt.get("width"))


def _has_audio(fmt: dict[str, Any]) -> bool:
    codec = str(fmt.get("acodec") or "none").lower()
    return codec not in {"none", "", "unknown"}


def _height(fmt: dict[str, Any]) -> int | None:
    value = fmt.get("height")
    try:
        number = int(value)
        if number > 0:
            return number
    except (TypeError, ValueError):
        pass
    # Compatibility with extractor responses that only expose a resolution/note.
    for key in ("resolution", "format_note", "format", "format_id"):
        text = str(fmt.get(key) or "")
        dimensions = re.search(r"\b\d{2,5}\s*[x×]\s*(\d{3,4})\b", text, re.IGNORECASE)
        if dimensions:
            try:
                return int(dimensions.group(1))
            except (TypeError, ValueError):
                pass
        label = re.search(r"(?<!\d)(\d{3,4})\s*p(?:\d+)?\b", text, re.IGNORECASE)
        if label:
            try:
                return int(label.group(1))
            except (TypeError, ValueError):
                pass
    return None


def _selector_estimates(formats: list[dict[str, Any]], heights: list[int]) -> dict[int, float]:
    """Size of what yt-dlp will really download at each height.

    The download uses a format selector that picks ONE video stream (by yt-dlp's own
    codec/bitrate ranking, usually VP9 or AV1) and ONE audio stream. The old estimate took the
    largest stream at that height (usually the bigger H.264 file), so it could be 2-3x too
    high. Running the same selector here makes the estimate match the download. Any failure
    returns an empty dict and the caller falls back to the older calculation.
    """
    result: dict[int, float] = {}
    try:
        import yt_dlp
        usable = [f for f in formats if isinstance(f, dict)]
        if not usable:
            return result
        with yt_dlp.YoutubeDL({"quiet": True, "no_warnings": True, "skip_download": True}) as ydl:
            context = {
                "formats": usable,
                "incomplete_formats": False,
                "has_merged_format": any(f.get("acodec") not in (None, "none")
                                         and f.get("vcodec") not in (None, "none") for f in usable),
            }
            for height in heights:
                if _ffmpeg_available():
                    spec = f"bestvideo[height<={height}]+bestaudio/best[height<={height}]"
                else:
                    spec = f"best[height<={height}]"
                try:
                    chosen = list(ydl.build_format_selector(spec)(context))
                except Exception:
                    continue
                if not chosen:
                    continue
                parts = chosen[0].get("requested_formats") or [chosen[0]]
                sizes = [_size_of(part) for part in parts if isinstance(part, dict)]
                if sizes and all(size is not None for size in sizes):
                    result[height] = float(sum(sizes))
    except Exception:
        return {}
    return result


def _estimates(formats: list[dict[str, Any]], heights: list[int]) -> dict[Any, float]:
    estimates: dict[Any, float] = {}
    planned = _selector_estimates(formats, heights)
    audio_sizes = [size for fmt in formats if not _has_video(fmt) and _has_audio(fmt)
                   if (size := _size_of(fmt)) is not None]
    best_audio = max(audio_sizes, default=None)

    for height in heights:
        at_height = [fmt for fmt in formats if _height(fmt) == height and _has_video(fmt)]
        video_sizes = [_size_of(fmt) for fmt in at_height if not _has_audio(fmt)]
        video_sizes = [value for value in video_sizes if value is not None]
        muxed_sizes = [_size_of(fmt) for fmt in at_height if _has_audio(fmt)]
        muxed_sizes = [value for value in muxed_sizes if value is not None]
        possibilities = list(muxed_sizes)
        best_video = max(video_sizes, default=None)
        if best_video is not None and best_audio is not None:
            possibilities.append(best_video + best_audio)
        if planned.get(height):
            possibilities = [planned[height]]
        if possibilities:
            value = max(possibilities)
            estimates[height] = value
            estimates[str(height)] = value
            estimates[f"{height}p"] = value

    if heights:
        best_height = max(heights)
        best = estimates.get(best_height)
        if best:
            estimates["best"] = best
            estimates["Best available"] = best
            estimates["best_available"] = best
    return estimates


def _cookie_guidance(message: str) -> str:
    """Add safe, actionable guidance only for errors commonly caused by sign-in restrictions."""
    text = str(message or "").strip()
    lowered = text.casefold()
    terms = (
        "sign in to confirm", "not a bot", "login_required", "login required",
        "private video", "video is private", "members-only", "members only",
        "age-restricted", "age restricted", "age verification",
        "cookies are enabled, but no cookie file", "cookie file does not exist",
        "verify you are human", "confirm your age", "requires authentication",
    )
    if text and any(term in lowered for term in terms):
        return ("YouTube may require sign-in for this video. If you can watch it in your browser, "
                "import or refresh your own exported cookies.txt in Settings, then retry. "
                "Cookies cannot grant access your account does not have. Details: " + text[:1400])
    return text

_NETWORK_TERMS = (
    "getaddrinfo failed", "name or service not known", "temporary failure in name resolution",
    "failed to resolve", "network is unreachable", "no route to host", "connection refused",
    "connection reset", "connection aborted", "remote end closed", "timed out", "timeout",
    "urlopen error", "unable to download webpage", "connectionerror", "readtimeout",
    "ssl:", "certificate verify failed", "temporarily unavailable",
)


def _looks_like_network_error(text: str) -> bool:
    lowered = str(text or "").casefold()
    return any(term in lowered for term in _NETWORK_TERMS)


def _write_error_log(stage: str, technical: str) -> str:
    """Keep full technical detail in a log file, never in the user-facing message."""
    try:
        folder = Path(tempfile.gettempdir()) / "Lumo"
        folder.mkdir(parents=True, exist_ok=True)
        log_path = folder / "last_error.log"
        stamp = time.strftime("%Y-%m-%d %H:%M:%S")
        log_path.write_text(f"{stamp} [{stage}]\n{technical}\n", encoding="utf-8")
        return str(log_path)
    except OSError:
        return ""


def plain_error(message: str, stage: str = "download") -> str:
    """Turn a technical yt-dlp/OS error into one sentence a normal user can act on."""
    technical = re.sub(r"^(ERROR:\s*)+", "", str(message or "").strip(), flags=re.IGNORECASE)
    lowered = technical.casefold()
    if any(term in lowered for term in ("no space left", "disk full", "errno 28", "not enough space")):
        friendly = "There is not enough free disk space in the download folder. Free some space and try again."
    elif any(term in lowered for term in ("permission denied", "errno 13", "winerror 5", "access is denied")):
        friendly = "Lumo cannot write to the download folder. Choose another folder in Settings and try again."
    elif _looks_like_network_error(lowered):
        friendly = "There is an internet problem. Check your connection and try again."
    elif any(term in lowered for term in ("http error 429", "too many requests", "rate limit")):
        friendly = "YouTube is limiting requests right now. Wait a few minutes and try again."
    elif any(term in lowered for term in ("http error 403", "http error 401")):
        friendly = ("YouTube refused this request. The downloader may be out of date. "
                    "Update Lumo (or yt-dlp) and try again.")
    elif any(term in lowered for term in ("unable to extract", "unsupported url", "signature extraction",
                                          "nsig", "requested format is not available",
                                          "no video formats", "javascript runtime", "js runtime")):
        friendly = ("This video could not be read by the current downloader. It may need an update. "
                    "Update Lumo (or yt-dlp) and try again.")
    elif any(term in lowered for term in ("ffmpeg", "ffprobe")) and any(
            term in lowered for term in ("not found", "no such file", "is not installed", "unavailable")):
        friendly = "A required part (FFmpeg) is missing. Reinstall Lumo and try again."
    elif any(term in lowered for term in ("video unavailable", "has been removed", "is unavailable",
                                          "not available in your country", "no longer available")):
        friendly = "This video is unavailable. It may have been removed or hidden in your region."
    elif any(term in lowered for term in ("sign in", "not a bot", "login_required", "login required",
                                          "private video", "members-only", "members only",
                                          "age-restricted", "age restricted", "confirm your age",
                                          "cookie")):
        friendly = ("This video needs you to be signed in, or it is private. If you can watch it in your "
                    "browser, refresh your cookies.txt in Settings and try again.")
    elif stage == "inspect":
        friendly = "We could not read this link. Check that it is a full video link and try again."
    else:
        friendly = "The download did not finish. Try again. If it keeps failing, check your internet connection."
    log_path = _write_error_log(stage, technical or friendly)
    if log_path:
        friendly += f" (Details: {log_path})"
    return friendly


def _extract_with_retry(yt_dlp, options: dict[str, Any], url: str) -> Any:
    """Run one metadata extraction, retrying once after a short pause on network trouble."""
    last_error: BaseException | None = None
    for attempt in range(2):
        try:
            with yt_dlp.YoutubeDL(options) as ydl:
                return ydl.extract_info(url, download=False)
        except Exception as exc:
            last_error = exc
            if attempt == 0 and _looks_like_network_error(str(exc)):
                time.sleep(1.5)
                continue
            raise
    raise last_error if last_error else RuntimeError("Inspection failed.")



def is_youtube_playlist_url(url: str) -> bool:
    """Return True only for a YouTube URL carrying a non-empty playlist ID.

    Accepts canonical playlist URLs and YouTube watch URLs that include ``list=``
    (the common Share URL for the current video inside a playlist). Ordinary video
    links and non-YouTube links are deliberately rejected by the dedicated Playlist
    page, so it cannot silently become a multi-URL download queue.
    """
    from urllib.parse import parse_qs, urlparse
    raw = str(url or "").strip()
    if not raw or any(ch.isspace() for ch in raw):
        return False
    try:
        parsed = urlparse(raw)
        if parsed.scheme.casefold() not in {"http", "https"}:
            return False
        host = (parsed.hostname or "").casefold().rstrip(".")
        supported_hosts = {
            "youtube.com", "www.youtube.com", "m.youtube.com",
            "music.youtube.com", "youtu.be", "www.youtu.be",
        }
        if host not in supported_hosts:
            return False
        playlist_ids = parse_qs(parsed.query).get("list", [])
        if not any(str(value).strip() for value in playlist_ids):
            return False
        path = parsed.path.rstrip("/").casefold()
        # The long YouTube domains use /playlist for a playlist and /watch for
        # a current-video link carrying playlist context. The short youtu.be form
        # is accepted only when it explicitly carries list= as well.
        if host in {"youtu.be", "www.youtu.be"}:
            return bool(path and path != "/")
        return path in {"/playlist", "/watch"}
    except (TypeError, ValueError):
        return False


def is_playlist_url(url: str) -> bool:
    """Compatibility alias for the strict YouTube playlist URL check."""
    return is_youtube_playlist_url(url)


def extract_playlist_urls(url: str, cookie_path: str | None = None) -> tuple[list[str], str | None]:
    """Expand one YouTube playlist URL to unique video URLs without downloading media."""
    if not is_youtube_playlist_url(url):
        return [], "Paste a YouTube playlist link that includes a playlist ID (list=...)."
    logger = _InspectionLogger()
    try:
        yt_dlp = _yt_dlp()
        runtime_options, _runtime_label = _js_runtime_options()
        options = {
            "quiet": True, "no_warnings": False, "logger": logger,
            "noplaylist": False, "extract_flat": "in_playlist", "skip_download": True,
            "ignoreerrors": True, "socket_timeout": 30, "retries": 3,
            "extractor_retries": 2, **runtime_options, **_cookie_option(cookie_path),
        }
        with yt_dlp.YoutubeDL(options) as ydl:
            info = ydl.extract_info(str(url).strip(), download=False)
        if not isinstance(info, dict):
            return [], "YouTube did not return playlist details. Check the playlist link."
        entries = info.get("entries")
        if entries is None:
            return [], (
                "YouTube returned a single video instead of playlist entries. "
                "Check that the playlist ID is valid and the playlist is accessible."
            )
        result, seen = [], set()
        for entry in entries:
            if not isinstance(entry, dict):
                continue
            video_url = str(entry.get("webpage_url") or entry.get("url") or "").strip()
            video_id = str(entry.get("id") or "").strip()
            extractor = str(entry.get("ie_key") or entry.get("extractor_key") or
                            info.get("extractor_key") or "").casefold()
            # This function accepts only a validated YouTube playlist URL. Prefer
            # stable video IDs and canonical watch links, avoiding duplicate rows
            # caused by differing list/index query strings for the same video.
            if video_id and ("youtube" in extractor or "youtube.com" in str(url).casefold()):
                video_url = f"https://www.youtube.com/watch?v={video_id}"
            elif not video_url.startswith(("http://", "https://")):
                continue
            key = video_url.casefold()
            if key not in seen:
                seen.add(key)
                result.append(video_url)
        if not result:
            return [], "No downloadable video entries were found in this playlist."
        return result, None
    except Exception as exc:
        message = str(exc).strip() or exc.__class__.__name__
        return [], _cookie_guidance(message)

def _perf_note(label: str, started: float) -> None:
    """Show one timing line in the console and append it to the perf log when LUMO_PERF=1."""
    if os.environ.get("LUMO_PERF") != "1":
        return
    elapsed = (time.perf_counter() - started) * 1000.0
    print(f"[perf] {time.strftime('%H:%M:%S')}  {label:<22} {elapsed / 1000.0:7.2f} s", flush=True)
    try:
        import tempfile
        with (Path(tempfile.gettempdir()) / "lumo_perf.log").open("a", encoding="utf-8") as handle:
            handle.write(f"{time.strftime('%H:%M:%S')}  {label:<28} {elapsed:8.1f} ms\n")
    except Exception:
        pass


def inspect_url(url: str, cookie_path: str | None = None):
    started = time.perf_counter()
    try:
        return _inspect_url_impl(url, cookie_path)
    finally:
        _perf_note("inspect link", started)


_ANDROID_VR_FALLBACK = {
    "name": "ANDROID_VR",
    "name_id": "28",
    "version": "1.65.10",
    "user_agent": "com.google.android.apps.youtube.vr.oculus/1.65.10 (Linux; U; Android 12L; eureka-user Build/SQ3A.220605.009.A1) gzip",
    "context": {"client": {"clientName": "ANDROID_VR", "clientVersion": "1.65.10",
                           "deviceMake": "Oculus", "deviceModel": "Quest 3",
                           "androidSdkVersion": 32, "osName": "Android", "osVersion": "12L",
                           "hl": "en", "gl": "US"}},
}


def _youtube_video_id(url: str) -> str | None:
    match = re.search(r"(?:v=|youtu\.be/|/shorts/|/live/|/embed/)([A-Za-z0-9_-]{11})", url)
    return match.group(1) if match else None


def _android_vr_client(key: str = "android_vr") -> dict[str, Any] | None:
    """Innertube client settings ("android_vr" or "android"), from the installed yt-dlp.

    Returns None for a client with no fallback when yt-dlp does not provide its settings.
    """
    try:
        from yt_dlp.extractor.youtube._base import INNERTUBE_CLIENTS  # type: ignore
        cfg = INNERTUBE_CLIENTS[key]
        context = copy.deepcopy(cfg.get("INNERTUBE_CONTEXT") or _ANDROID_VR_FALLBACK["context"])
        return {
            "context": context,
            "name_id": str(cfg.get("INNERTUBE_CONTEXT_CLIENT_NAME") or _ANDROID_VR_FALLBACK["name_id"]),
            "version": str(cfg.get("INNERTUBE_CLIENT_VERSION") or _ANDROID_VR_FALLBACK["version"]),
            "user_agent": str(cfg.get("USER_AGENT") or _ANDROID_VR_FALLBACK["user_agent"]),
        }
    except Exception:
        if key != "android_vr":
            return None
        return {
            "context": copy.deepcopy(_ANDROID_VR_FALLBACK["context"]),
            "name_id": _ANDROID_VR_FALLBACK["name_id"],
            "version": _ANDROID_VR_FALLBACK["version"],
            "user_agent": _ANDROID_VR_FALLBACK["user_agent"],
        }


def _direct_format(item: dict[str, Any], user_agent: str) -> dict[str, Any] | None:
    url = item.get("url")
    if not url or item.get("signatureCipher") or item.get("cipher"):
        return None
    mime = str(item.get("mimeType") or "")
    codecs_match = re.search(r'codecs="([^"]+)"', mime)
    codecs = [c.strip() for c in (codecs_match.group(1).split(",") if codecs_match else [])]
    is_video = mime.startswith("video/")
    is_audio = mime.startswith("audio/")
    if not (is_video or is_audio):
        return None
    ext = "mp4" if "mp4" in mime else ("webm" if "webm" in mime else "unknown")
    vcodec = next((c for c in codecs if c.startswith(("avc", "vp", "av01", "hev", "hvc"))), None)
    acodec = next((c for c in codecs if c.startswith(("mp4a", "opus", "vorbis", "ec-3", "ac-3"))), None)
    fmt: dict[str, Any] = {
        "format_id": str(item.get("itag")),
        "url": url,
        "ext": ext,
        "protocol": "https",
        "http_headers": {"User-Agent": user_agent},
        "vcodec": vcodec or ("none" if not is_video else "unknown"),
        "acodec": acodec or ("none" if not is_audio else "unknown"),
        "tbr": (item.get("bitrate") or 0) / 1000.0 or None,
        "filesize": int(item["contentLength"]) if str(item.get("contentLength", "")).isdigit() else None,
        "format_note": item.get("qualityLabel"),
    }
    if is_video:
        fmt["width"] = item.get("width")
        fmt["height"] = item.get("height")
        fmt["fps"] = item.get("fps")
    return fmt


def _youtube_cookie_header(cookie_path: str | None) -> str:
    """Build a Cookie header from a Netscape cookie file, for YouTube and Google domains."""
    if not cookie_path:
        return ""
    pairs = []
    try:
        for line in Path(cookie_path).read_text(encoding="utf-8", errors="replace").splitlines():
            if not line or line.startswith("#"):
                continue
            parts = line.split("\t")
            if len(parts) < 7:
                continue
            domain, name, value = parts[0], parts[5], parts[6]
            if "youtube.com" in domain or "google.com" in domain:
                pairs.append(f"{name}={value}")
    except OSError:
        return ""
    return "; ".join(pairs)


def _ssl_context():
    """TLS context that also works in the packaged exe (bundled certifi, then Windows store)."""
    import ssl
    context = None
    try:
        import certifi
        context = ssl.create_default_context(cafile=certifi.where())
    except Exception:
        context = ssl.create_default_context()
    return context


def _fast_direct_details(url: str, cookie_path: str | None = None,
                         client_key: str = "android_vr") -> dict[str, Any] | None:
    """One direct request to YouTube's player API, with no JavaScript challenge solving.

    This is the fastest route to the quality list: a single HTTP call instead of the
    full extraction. Returns None whenever the answer is not complete and usable, so the
    caller falls back to the complete lookup.
    """
    import urllib.request
    video_id = _youtube_video_id(url)
    if not video_id:
        return None
    client = _android_vr_client(client_key)
    if client is None:
        return None
    body = json.dumps({
        "context": client["context"],
        "videoId": video_id,
        "contentCheckOk": True,
        "racyCheckOk": True,
    }).encode("utf-8")
    request = urllib.request.Request(
        "https://www.youtube.com/youtubei/v1/player?prettyPrint=false",
        data=body,
        headers={
            "Content-Type": "application/json",
            "User-Agent": client["user_agent"],
            "X-YouTube-Client-Name": client["name_id"],
            "X-YouTube-Client-Version": client["version"],
            "Origin": "https://www.youtube.com",
            # No Cookie header on purpose: this mobile-app client is rejected with
            # LOGIN_REQUIRED when it is sent a web session. Cookies are still used by the
            # full lookup and by the download itself.
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=8, context=_ssl_context()) as response:
            data = json.loads(response.read().decode("utf-8", "replace"))
    except Exception as exc:
        _subs_trace(f"fast lookup skipped: {exc!r}")
        return None
    if not isinstance(data, dict):
        return None
    playability = data.get("playabilityStatus") or {}
    if playability.get("status") != "OK":
        _subs_trace(f"direct lookup rejected: status={playability.get('status')} "
                    f"reason={str(playability.get('reason'))[:120]!r}")
        return None
    streaming = data.get("streamingData") or {}
    raw_items = list(streaming.get("formats") or []) + list(streaming.get("adaptiveFormats") or [])
    formats = []
    ciphered = 0
    for item in raw_items:
        if isinstance(item, dict):
            if item.get("signatureCipher") or item.get("cipher"):
                ciphered += 1
            fmt = _direct_format(item, client["user_agent"])
            if fmt:
                formats.append(fmt)
    if not any(_has_video(f) and _height(f) is not None for f in formats):
        _subs_trace(f"direct lookup rejected: {len(raw_items)} format(s), {ciphered} need signature "
                    f"decoding, {len(formats)} usable, no usable video")
        return None

    details_video = data.get("videoDetails") or {}
    subtitles: dict[str, list[dict[str, str]]] = {}
    automatic: dict[str, list[dict[str, str]]] = {}
    renderer = (data.get("captions") or {}).get("playerCaptionsTracklistRenderer") or {}
    tracks = renderer.get("captionTracks") or []
    translation_codes = [
        str(item.get("languageCode") or "").strip()
        for item in (renderer.get("translationLanguages") or [])
        if isinstance(item, dict)
    ]
    for track in tracks:
        if not isinstance(track, dict):
            continue
        code = str(track.get("languageCode") or "").strip()
        base = str(track.get("baseUrl") or "")
        if not code or not base:
            continue
        entry = [{"url": base, "ext": "vtt"}]
        if track.get("kind") == "asr":
            # The video's own auto-generated caption, then its auto-translations
            # (Option B: translated captions count as available languages).
            if "tlang=" not in base:
                automatic[f"{code}-orig"] = entry
                for target in translation_codes:
                    if target and target != code and target not in automatic:
                        automatic[target] = [{"url": f"{base}&tlang={target}", "ext": "vtt"}]
        else:
            subtitles[code] = entry

    return {
        "id": video_id,
        "title": details_video.get("title"),
        "uploader": details_video.get("author"),
        "duration": int(details_video.get("lengthSeconds") or 0) or None,
        "webpage_url": f"https://www.youtube.com/watch?v={video_id}",
        "extractor": "youtube",
        "formats": formats,
        "subtitles": subtitles,
        "automatic_captions": automatic,
        "language": None,
        "_lumo_direct": True,
    }


def _plan_sizes(ydl, spec: Any, info: dict[str, Any]) -> dict[str, float | None] | None:
    """Ask yt-dlp which formats the selector will download, and their sizes.

    Done before the download starts, so the progress bar knows the full planned total
    from the first moment (instead of learning about the second stream halfway through).
    """
    try:
        formats = [f for f in (info.get("formats") or []) if isinstance(f, dict)]
        if not formats or not spec:
            return None
        selector = ydl.build_format_selector(spec)
        ctx = {
            "formats": formats,
            "incomplete_formats": False,
            "has_merged_format": any(f.get("acodec") not in (None, "none") and f.get("vcodec") not in (None, "none")
                                     for f in formats),
        }
        planned: dict[str, float | None] = {}
        for item in list(selector(ctx)):
            parts = item.get("requested_formats") or [item]
            for part in parts:
                if isinstance(part, dict) and part.get("format_id") is not None:
                    planned[str(part["format_id"])] = _size_of(part)
        return planned or None
    except Exception:
        return None


def _usable_video_details(candidate: Any) -> bool:
    if not isinstance(candidate, dict):
        return False
    fmts = [f for f in (candidate.get("formats") or []) if isinstance(f, dict)]
    has_video = any(_has_video(f) and _height(f) is not None for f in fmts)
    # A quality list without any audio stream could never be downloaded as a video.
    has_audio = any(_has_audio(f) for f in fmts)
    return has_video and has_audio


def _has_good_quality(candidate: Any, min_height: int = 720) -> bool:
    """True when the candidate offers a video stream at or above min_height.

    The direct player request can return only the 360p muxed streams for videos that
    have 1080p; accepting such a result caps the quality list for the whole session.
    """
    fmts = [f for f in (candidate.get("formats") or []) if isinstance(f, dict)]
    heights = [h for f in fmts if _has_video(f) and (h := _height(f)) is not None]
    return bool(heights) and max(heights) >= min_height


def _race_fast_routes(yt_dlp, options: dict[str, Any], url: str, cookie_path: str | None):
    """Run the direct player request and ONE yt-dlp client together.

    Returns (details, winner_name, messages). details is None when neither route gives
    usable qualities, and the caller then runs the complete lookup.

    Earlier versions also ran web_embedded at the same time. Both clients need the
    JavaScript challenge solver, so two Deno processes fought for the CPU (about 27 s
    each) and the loser kept running after the winner returned. Now only tv_samsung
    runs; web_embedded stays available through the complete lookup.
    """
    from concurrent.futures import ThreadPoolExecutor, as_completed

    cancel = threading.Event()

    def direct(client_key: str):
        def run_direct() -> tuple[Any, list[tuple[str, str]]]:
            return _fast_direct_details(url, cookie_path, client_key), []
        return run_direct

    def client_only(client_name: str):
        def run_client() -> tuple[Any, list[tuple[str, str]]]:
            client_logger = _InspectionLogger(cancel)
            client_options = dict(options)
            client_options["logger"] = client_logger
            client_options["extractor_args"] = {"youtube": {"player_client": [client_name]}}
            return _extract_with_retry(yt_dlp, client_options, url), list(client_logger.messages)
        return run_client

    pool = ThreadPoolExecutor(max_workers=3, thread_name_prefix="lumo-race")
    futures = {
        pool.submit(direct("android_vr")): "direct android_vr",
        pool.submit(direct("android")): "direct android",
        pool.submit(client_only("tv_samsung")): "tv_samsung youtube",
    }
    weak: tuple[Any, str, list[tuple[str, str]]] | None = None
    try:
        for future in as_completed(futures, timeout=60):
            try:
                candidate, messages = future.result()
            except Exception as exc:
                _subs_trace(f"{futures[future]} lookup failed: {exc!r}")
                continue
            if _usable_video_details(candidate):
                if _has_good_quality(candidate):
                    return candidate, futures[future], messages
                # Usable but capped (e.g. 360p only): keep waiting for the other route,
                # and use this result only if nothing better arrives.
                _subs_trace(f"{futures[future]} lookup capped below 720p; waiting for the other route")
                if weak is None:
                    weak = (candidate, futures[future], messages)
                continue
            _subs_trace(f"{futures[future]} lookup gave no usable video qualities")
    except Exception:
        pass
    finally:
        cancel.set()  # stop whichever route is still running
        pool.shutdown(wait=False, cancel_futures=True)
    if weak is not None:
        return weak
    return None, None, []


def _inspect_url_impl(url: str, cookie_path: str | None = None):
    """Inspect a URL once and return metadata plus the real format diagnostics.

    A fresh extraction result is checked before runtime discovery. Runtime discovery
    can spawn several short-lived subprocesses on a first run; doing that before a
    cache hit made repeat inspection unnecessarily slow despite cached metadata.
    The recovered App calls this backend from its inspection worker thread.
    """
    logger = _InspectionLogger()
    try:
        cached = _details_take(url, cookie_path)
        from_cache = cached is not None
        if cached is not None:
            details, cached_messages = cached
            logger.messages.extend(cached_messages)
            with _RUNTIME_LOCK:
                runtime_options, runtime_label = (dict(_RUNTIME_CACHE[0]), _RUNTIME_CACHE[1]) if _RUNTIME_CACHE else ({}, None)
        else:
            discovery_started = time.perf_counter()
            runtime_options, runtime_label = _js_runtime_options()
            _perf_note("runtime discovery", discovery_started)
        yt_dlp = _yt_dlp()
        options = {
            "quiet": os.environ.get("LUMO_VERBOSE") != "1",
            "verbose": os.environ.get("LUMO_VERBOSE") == "1",
            # Do not suppress the warnings needed to diagnose missing format metadata.
            "no_warnings": False,
            "logger": logger,
            "noplaylist": True,
            "skip_download": True,
            "extract_flat": False,
            "socket_timeout": 20,
            "retries": 2,
            "extractor_retries": 2,
            # Allows the official EJS challenge-solver component to be fetched when
            # it is not already installed with yt-dlp[default].
            "remote_components": ["ejs:github"],
            **runtime_options,
            **_cookie_option(cookie_path),
        }
        if not from_cache:
            # Fast path: the iOS player client needs no JavaScript challenge solving and
            # skips the extra webpage/config requests, which is where the time went.
            # If it returns no usable video formats, the full lookup below runs as before.
            extract_started = time.perf_counter()
            # Routes 1 and 2 run at the same time; the first one with usable qualities wins.
            details, winner, fast_messages = _race_fast_routes(yt_dlp, options, url, cookie_path)
            if details is not None:
                logger.messages.extend(fast_messages)
                _perf_note(f"{winner} lookup", extract_started)
            # Route 3: the complete lookup, used whenever the routes above are not usable.
            if details is None:
                details = _extract_with_retry(yt_dlp, options, url)
                _perf_note("youtube lookup", extract_started)
        if not isinstance(details, dict):
            return None, "The site did not return video details. Check the link and try again."

        formats = [fmt for fmt in (details.get("formats") or []) if isinstance(fmt, dict)]
        # Cache only a complete (720p+) result. A capped 360p-only result cached here
        # would be served again on every later inspection of the same link.
        if not from_cache and _has_good_quality(details):
            _details_store(url, cookie_path, details, list(logger.messages))
        available_heights = sorted({
            h for fmt in formats if _has_video(fmt) if (h := _height(fmt)) is not None
        }, reverse=True)
        if not available_heights:
            h = _height(details)
            if h:
                available_heights = [h]

        subtitles = details.get("subtitles") or {}
        automatic = details.get("automatic_captions") or {}
        # Offer manual tracks and automatic captions, including auto-translated ones
        # (Option B). A language neither list contains is shown greyed out in the app.
        real_manual, real_original = _real_subtitle_keys(details)
        manual_codes = sorted(real_manual)
        automatic_codes = sorted(real_original)
        codes = sorted(real_manual | real_original)
        subtitle_tracks = [{"code": c, "kind": "manual"} for c in manual_codes] + [
            {"code": c, "kind": "auto"} for c in automatic_codes
        ]
        tracks_known = "subtitles" in details or "automatic_captions" in details
        warnings = [message for level, message in logger.messages if level == "warning"]
        errors = [message for level, message in logger.messages if level == "error"]
        quality_diagnostic = None
        if not available_heights:
            combined = "\n".join(warnings + errors).lower()
            if "javascript runtime" in combined or "js runtime" in combined:
                quality_diagnostic = (
                    "yt-dlp did not return usable resolution data and reported a JavaScript-runtime issue. "
                    "The app will still offer maximum-resolution caps, but the actual available quality "
                    "may be lower. Install Deno 2.3+ (recommended) or Node.js 22+, then update yt-dlp "
                    "with: python -m pip install -U \"yt-dlp[default]\"."
                )
            elif any(term in combined for term in ("sign in", "not a bot", "login_required", "private video", "members-only")):
                relevant = next((m for m in warnings + errors if any(t in m.lower() for t in
                    ("sign in", "not a bot", "login_required", "private video", "members-only"))), "")
                quality_diagnostic = "YouTube restricted metadata access: " + relevant[:400]
            elif warnings or errors:
                relevant = (errors + warnings)[-1]
                quality_diagnostic = (
                    "YouTube returned no usable resolution list. Quality choices below are maximum-height caps. "
                    "yt-dlp message: " + relevant[:400]
                )
            elif not runtime_label:
                quality_diagnostic = (
                    "No supported JavaScript runtime was found by Lumo. YouTube can omit video formats "
                    "without one. Quality choices below are maximum-height caps; install Deno 2.3+ or Node.js 22+."
                )
            else:
                quality_diagnostic = (
                    "The site returned metadata but no usable resolution list. Quality choices below set a "
                    "maximum height; yt-dlp will choose the best available stream at or below that limit."
                )

        info = {
            "title": details.get("title") or "Untitled video",
            "duration": details.get("duration"),
            "uploader": details.get("uploader") or details.get("channel"),
            "thumbnail_url": details.get("thumbnail"),
            "thumbnails": details.get("thumbnails") or [],
            "heights": available_heights,
            "estimates": _estimates(formats, available_heights),
            "subtitles_available": codes,
            "subtitle_languages": codes,
            "subtitle_tracks": subtitle_tracks,
            "_subtitle_tracks_known": tracks_known,
            "_format_count": len(formats),
            "_video_format_count": sum(1 for fmt in formats if _has_video(fmt)),
            "_yt_dlp_warnings": (warnings + errors)[-8:],
            "_js_runtime": runtime_label,
            "_quality_diagnostic": quality_diagnostic,
        }
        return info, None
    except Exception as exc:
        message = str(exc).strip() or exc.__class__.__name__
        message = re.sub(r"^(ERROR:\s*)+", "", message, flags=re.IGNORECASE)
        related = [m for _level, m in logger.messages if m]
        if related:
            message += " | yt-dlp diagnostic: " + " | ".join(related[-3:])[:1000]
        return None, plain_error(message, "inspect")


class _LumoLogger:
    """Surface actionable yt-dlp warnings in the GUI and keep them for the final message."""
    def __init__(self, on_status=None):
        self.on_status = on_status
        self.messages: list[str] = []

    def debug(self, message):
        # yt-dlp sends routine progress/debug noise here; progress hooks handle bytes.
        # With LUMO_SUBS_DEBUG=1 it is written to a file so subtitle failures can be traced.
        if os.environ.get("LUMO_SUBS_DEBUG") == "1":
            try:
                with (Path(tempfile.gettempdir()) / "lumo_subs_debug.log").open("a", encoding="utf-8") as handle:
                    handle.write(str(message)[:2000] + "\n")
            except OSError:
                pass
        return

    def warning(self, message):
        message = str(message or "").strip()
        if message:
            self.messages.append("warning: " + message[:500])
            if self.on_status:
                self.on_status("yt-dlp warning: " + message[:500])

    def error(self, message):
        message = str(message or "").strip()
        if message:
            self.messages.append("error: " + message[:500])
            if self.on_status:
                self.on_status("yt-dlp: " + message[:500])


def _downloaded_height(info: dict[str, Any]) -> int | None:
    """Height of the video that was actually written, which can be below the requested cap."""
    heights: list[int] = []
    requested = info.get("requested_formats")
    if isinstance(requested, list):
        for item in requested:
            if isinstance(item, dict) and _has_video(item):
                height = _height(item)
                if height:
                    heights.append(height)
    if not heights:
        height = _height(info)
        if height:
            heights.append(height)
    return max(heights) if heights else None


def _real_subtitle_keys(info: Any) -> tuple[set[str], set[str]]:
    """(manual track codes, automatic caption codes) the video offers.

    Rule (Option B): a language is available when the video has a manual subtitle for
    it, or an automatic caption for it. That includes the video's own auto-generated
    captions and auto-translated/dubbed captions that YouTube lists. A language the
    video lists in neither place is not available, so it is greyed out in the app.
    """
    if not isinstance(info, dict):
        return set(), set()
    manual = {str(k).strip() for k in (info.get("subtitles") or {}) if str(k).strip()}
    automatic = {str(k).strip() for k in (info.get("automatic_captions") or {}) if str(k).strip()}
    automatic -= manual
    return manual, automatic


def _resolve_subtitle_languages(selected: Any, info: Any = None) -> list[str]:
    """Map each selected language to a real track the video actually has.

    An exact code always wins. Otherwise the same language is matched by its base
    code (for example ``hi`` for ``hi-IN``). Manual and automatic tracks are both
    considered per language; yt-dlp prefers the manual track for a language when
    one exists. A selection that matches nothing is dropped rather than replaced
    by some other language.
    """
    requested: list[str] = []
    for raw in selected or []:
        code = str(raw).strip()
        if code and re.fullmatch(r"[A-Za-z0-9_-]+", code) and code not in requested:
            requested.append(code)

    if not requested or not isinstance(info, dict):
        return requested
    if info.get("_lumo_direct"):
        # Direct links carry no subtitle metadata; keep the selection as asked.
        return requested

    manual, automatic = _real_subtitle_keys(info)
    known = manual | automatic
    if not known:
        # Metadata that says "no subtitles" means the selection is unavailable and is
        # dropped. Missing metadata (no such keys at all) cannot prove anything, so the
        # selection is kept as asked.
        has_metadata = "subtitles" in info or "automatic_captions" in info
        return [] if has_metadata else requested

    def rank(track: str, asked: str) -> tuple[int, int, str]:
        # 0 = a real manual subtitle, 1 = the video's own auto captions (-orig),
        # 2 = an auto-translated caption. The exact code breaks ties within a rank.
        if track in manual:
            tier = 0
        elif track.casefold().endswith("-orig"):
            tier = 1
        else:
            tier = 2
        return (tier, 0 if track == asked else 1, track)

    resolved: list[str] = []
    for code in requested:
        base = re.split(r"[-_]", code, maxsplit=1)[0].casefold()
        candidates = [
            track for track in known
            if track == code or re.split(r"[-_]", track, maxsplit=1)[0].casefold() == base
        ]
        if not candidates:
            continue
        best = min(candidates, key=lambda track: rank(track, code))
        if best not in resolved:
            resolved.append(best)
    return resolved


def _ffprobe_executable() -> str | None:
    """Find FFprobe beside FFmpeg, in the app vendor directory, or on PATH."""
    found = shutil.which("ffprobe") or shutil.which("ffprobe.exe")
    if found:
        return found
    name = "ffprobe.exe" if os.name == "nt" else "ffprobe"
    candidate = Path(_ffmpeg_dir()) / name
    return str(candidate) if candidate.is_file() else None


_ISO_SUBTITLE_LANGUAGE = {
    "en": "eng", "hi": "hin", "mr": "mar", "bn": "ben", "ur": "urd", "ta": "tam",
    "te": "tel", "gu": "guj", "kn": "kan", "ml": "mal", "pa": "pan", "fr": "fra",
    "de": "deu", "es": "spa", "pt": "por", "ru": "rus", "ja": "jpn", "ko": "kor",
    "zh": "zho", "ar": "ara", "it": "ita", "tr": "tur", "id": "ind", "vi": "vie",
}


def _ffmpeg_path() -> Path:
    return Path(_ffmpeg_dir()) / ("ffmpeg.exe" if os.name == "nt" else "ffmpeg")


def _subtitle_files_in(folder: Path) -> list[tuple[str, Path]]:
    """Caption files yt-dlp wrote into a folder, as (language_code, path) pairs."""
    found: list[tuple[str, Path]] = []
    for path in sorted(folder.glob("sub.*.vtt")):
        parts = path.name.split(".")  # sub.<language>.vtt
        if len(parts) >= 3 and path.stat().st_size > 0:
            found.append((parts[1], path))
    return found


def _fetch_subtitles_in_process(yt_dlp, url: str, languages: list[str], folder: Path,
                                cookie_path=None) -> list[tuple[str, Path]]:
    """Fallback used only in a packaged build, where no Python interpreter is available."""
    class _TraceLogger:
        def debug(self, message):
            text = str(message)
            if any(t in text.lower() for t in ("subtitle", "caption", "deno", "js ", "challenge", "ejs", "timedtext")):
                _subs_trace("in-process yt-dlp: " + text[:300])

        def info(self, message):
            self.debug(message)

        def warning(self, message):
            _subs_trace("in-process yt-dlp WARNING: " + str(message)[:400])

        def error(self, message):
            _subs_trace("in-process yt-dlp ERROR: " + str(message)[:400])

    _js_options, _js_label = _js_runtime_options()
    _subs_trace(f"in-process fetch: js runtime = {_js_label or 'NONE FOUND'}")
    options = {
        "quiet": True,
        "logger": _TraceLogger(),
        "verbose": True,
        "no_warnings": False,
        "noplaylist": True,
        "skip_download": True,
        "writesubtitles": True,
        "writeautomaticsubtitles": True,
        "subtitleslangs": list(languages),
        "subtitlesformat": "vtt/best",
        "outtmpl": str(folder / "sub.%(ext)s"),
        "socket_timeout": 30,
        "retries": 3,
        "remote_components": ["ejs:github"],
        **_js_options,
        **({"ffmpeg_location": _ffmpeg_dir()} if _ffmpeg_available() else {}),
        **_cookie_option(cookie_path),
    }
    with yt_dlp.YoutubeDL(options) as ydl:
        ydl.download([url])
    return _subtitle_files_in(folder)


def _fetch_subtitle_files_separately(yt_dlp, url: str, languages: list[str],
                                     folder: Path, cookie_path=None) -> list[tuple[str, Path]]:
    """Fetch only the subtitle files, using the same yt-dlp command that was verified to work.

    The command runs as its own process, so no in-process option can change what it does.
    Its exit code and output are written to the subtitle trace.
    """
    label = "with cookies" if cookie_path else "without cookies"
    if getattr(sys, "frozen", False):
        found = _fetch_subtitles_in_process(yt_dlp, url, languages, folder, cookie_path)
        _subs_trace(f"separate fetch {label} (in-process): {len(found)} file(s)")
        return found
    command = [
        sys.executable, "-m", "yt_dlp",
        "--skip-download", "--write-subs", "--write-auto-subs",
        "--sub-langs", ",".join(languages),
        "--remote-components", "ejs:github",
        "--no-playlist",
        "--ffmpeg-location", str(_ffmpeg_dir()),
        "-o", str(folder / "sub.%(ext)s"),
    ]
    # Without a JavaScript runtime yt-dlp sees only storyboard images for YouTube.
    # Pass the bundled Deno explicitly, as the other download paths already do.
    js_options, _js_label = _js_runtime_options()
    for runtime_name, runtime_cfg in (js_options.get("js_runtimes") or {}).items():
        command += ["--js-runtimes", f"{runtime_name}:{runtime_cfg['path']}"]
    if cookie_path:
        command += ["--cookies", str(Path(cookie_path).expanduser())]
    command.append(url)
    try:
        result = subprocess.run(
            command, capture_output=True, text=True, timeout=300, check=False,
            stdin=subprocess.DEVNULL,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
    except (OSError, subprocess.SubprocessError) as exc:
        _subs_trace(f"separate fetch {label} could not run: {exc!r}")
        raise
    found = _subtitle_files_in(folder)
    output_tail = ((result.stdout or "") + (result.stderr or ""))[-700:]
    _subs_trace(f"separate fetch {label}: exit {result.returncode}, {len(found)} file(s) "
                f"{[p.name for _, p in found]}; yt-dlp said: {output_tail!r}")
    return found

def _mux_subtitles_into_video(video: Path, subtitles: list[tuple[str, Path]],
                              ffmpeg: Path) -> bool:
    """Add each subtitle file to the finished video as a selectable track, without re-encoding."""
    if not subtitles or not video.is_file() or not ffmpeg.is_file():
        return False
    temporary = video.with_name(video.stem + ".subtitles-added" + video.suffix)
    command = [str(ffmpeg), "-y", "-loglevel", "error", "-i", str(video)]
    for _language, path in subtitles:
        command += ["-i", str(path)]
    command += ["-map", "0"]
    for index in range(len(subtitles)):
        command += ["-map", str(index + 1)]
    subtitle_codec = "mov_text" if video.suffix.lower() == ".mp4" else "srt"
    command += ["-c", "copy", "-c:s", subtitle_codec]
    for index, (language, _path) in enumerate(subtitles):
        base = re.split(r"[-_]", language, maxsplit=1)[0].casefold()
        command += [f"-metadata:s:s:{index}", f"language={_ISO_SUBTITLE_LANGUAGE.get(base, 'und')}"]
    command.append(str(temporary))
    try:
        result = subprocess.run(
            command, capture_output=True, text=True, check=False,
            stdin=subprocess.DEVNULL,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        if result.returncode != 0 or not temporary.is_file() or temporary.stat().st_size == 0:
            _subs_trace(f"ffmpeg mux failed (code {result.returncode}): {(result.stderr or '')[-400:]}")
            temporary.unlink(missing_ok=True)
            return False
        os.replace(temporary, video)
        return True
    except OSError as exc:
        _subs_trace(f"ffmpeg mux could not run: {exc!r}")
        temporary.unlink(missing_ok=True)
        return False


def _subtitle_stream_count(path: str) -> int | None:
    """Return embedded subtitle stream count, or None when FFprobe is unavailable."""
    executable = _ffprobe_executable()
    if not executable:
        return None
    try:
        result = subprocess.run(
            [executable, "-v", "error", "-select_streams", "s",
             "-show_entries", "stream=index", "-of", "json", path],
            capture_output=True, text=True, timeout=15, check=False,
            stdin=subprocess.DEVNULL,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        if result.returncode != 0:
            return None
        import json
        payload = json.loads(result.stdout or "{}")
        streams = payload.get("streams", [])
        return len(streams) if isinstance(streams, list) else None
    except (OSError, subprocess.SubprocessError, ValueError, TypeError):
        return None


def _is_subtitle_processing_error(exc: BaseException) -> bool:
    """Return True only when the reported failure specifically concerns subtitles."""
    message = f"{exc.__class__.__name__}: {exc}".casefold()
    markers = (
        "subtitle", "subtitles", "ffmpegembedsubtitle", "embed subtitle",
        "embed-subtitle", "subtitle postprocessor", "subtitle converter",
        "subtitle conversion", "unable to download subtitles",
    )
    return any(marker in message for marker in markers)


_PARTIAL_DIR_NAME = "_partial_downloads"


def _quality_key(max_height) -> str:
    return str(int(max_height)) if max_height else "best"


def partial_folder_for(out_dir: Path, url: str) -> Path:
    digest = hashlib.sha1(str(url).strip().encode("utf-8")).hexdigest()[:20]
    return Path(out_dir) / _PARTIAL_DIR_NAME / digest


def prepare_partial_folder(out_dir: Path, url: str, max_height) -> tuple[Path, bool]:
    """Return (folder, resumed).

    Partial data is reused only when the quality choice matches the earlier attempt
    for this link. Subtitles and container are not part of the key, so they never
    block a resume. A different quality discards the old partial data first.
    """
    folder = partial_folder_for(out_dir, url)
    manifest = folder / "partial.json"
    wanted = _quality_key(max_height)
    previous = None
    if manifest.is_file():
        try:
            previous = json.loads(manifest.read_text(encoding="utf-8")).get("quality")
        except (OSError, ValueError):
            previous = None
    resumed = previous == wanted and any(folder.glob("*.part"))
    if folder.exists() and previous != wanted:
        shutil.rmtree(folder, ignore_errors=True)
    folder.mkdir(parents=True, exist_ok=True)
    manifest.write_text(json.dumps({"url": str(url).strip(), "quality": wanted}), encoding="utf-8")
    return folder, bool(resumed)


def discard_partial_folder(out_dir: Path, url: str) -> None:
    shutil.rmtree(partial_folder_for(out_dir, url), ignore_errors=True)


def _expected_total_bytes(requested_formats: Any) -> float | None:
    """Sum the per-stream sizes yt-dlp reports (video + audio), or None if any is unknown.

    Using the real sizes keeps every percent equal in weight: 1% of the bar is 1% of the
    bytes actually transferred, instead of the first stream being squeezed into 0-49%.
    """
    if not isinstance(requested_formats, list) or not requested_formats:
        return None
    total = 0.0
    for item in requested_formats:
        if not isinstance(item, dict):
            return None
        size = item.get("filesize") or item.get("filesize_approx")
        try:
            size_num = float(size)
        except (TypeError, ValueError):
            return None
        if size_num <= 0:
            return None
        total += size_num
    return total if total > 0 else None


_RUNNING_JOBS: list[Any] = []
_RUNNING_LOCK = threading.Lock()


def current_job() -> Any:
    """The download currently running, or None. The UI uses this to reach the live job."""
    with _RUNNING_LOCK:
        return _RUNNING_JOBS[-1] if _RUNNING_JOBS else None


class DownloadJob:
    """A cancellable yt-dlp download job, compatible with the GUI event hooks."""

    def __init__(self, url, out_dir, max_height=None, cookie_path=None,
                 subtitle_langs=None, merge_mp4=True, estimate_bytes=None):
        self.url = str(url)
        self.out_dir = Path(out_dir).expanduser()
        self.max_height = int(max_height) if max_height not in (None, "") else None
        if self.max_height is not None and self.max_height <= 0:
            self.max_height = None
        self.cookie_path = str(cookie_path) if cookie_path else None
        self.subtitle_langs = list(subtitle_langs or [])
        self.merge_mp4 = bool(merge_mp4)
        try:
            self.estimate_bytes = float(estimate_bytes) if estimate_bytes else None
        except (TypeError, ValueError):
            self.estimate_bytes = None
        self.estimate_bytes = self.estimate_bytes if self.estimate_bytes and self.estimate_bytes > 0 else None
        self._cancel_event = threading.Event()
        self._resume_event = threading.Event()
        self._resume_event.set()
        self._progress_by_stream: dict[str, dict[str, float]] = {}
        self._expected_progress_streams = 1
        self._progress_lock = threading.Lock()
        # The percentage shown to the user only moves forward. While streams download
        # it stays below 99; merging and subtitle embedding move it from 99 to 100.
        self._last_overall = 0.0
        self._last_view: dict[str, Any] = {"downloaded": None, "total": None, "total_estimated": True}
        # The total size is chosen once, from the first reliable size, and never changes
        # during the download. Switching totals mid-download made the bar jump.
        self._locked_total: float | None = None
        # Per-format accounting used by the progress bar (see the progress hook).
        self._format_state: dict[str, dict[str, Any]] = {}
        self._stream_format_map: dict[str, str] = {}
        self._planned_sizes: dict[str, float | None] | None = None
        self._locked_total_estimated = True
        taken = _details_take(self.url, self.cookie_path)
        # Reuse inspection data for the download when it is still fresh (see _download_with).
        self._prefetched = taken[0] if taken else None

    def cancel(self):
        self._cancel_event.set()
        # A paused job must always wake so cancellation cannot deadlock.
        self._resume_event.set()

    def pause(self):
        """Pause at the next yt-dlp progress checkpoint. Partial data is kept."""
        self._resume_event.clear()

    def resume(self):
        """Resume a job paused at a progress checkpoint."""
        self._resume_event.set()

    def is_paused(self) -> bool:
        return not self._resume_event.is_set()

    def _format_selector(self) -> str:
        # Without FFmpeg, yt-dlp cannot merge separate video/audio streams. Prefer
        # a single-file format so the video can still download instead of failing
        # at the merge step. The selected maximum height remains enforced.
        if not _ffmpeg_available():
            return f"best[height<={self.max_height}]" if self.max_height is not None else "best"
        if self.max_height is not None:
            cap = self.max_height
            return f"bestvideo[height<={cap}]+bestaudio/best[height<={cap}]"
        return "bestvideo*+bestaudio/best"

    @staticmethod
    def _pretty_bytes(value) -> str:
        try:
            number = float(value)
        except (TypeError, ValueError):
            return "—"
        units = ("B/s", "KB/s", "MB/s", "GB/s")
        idx = 0
        while number >= 1024 and idx < len(units) - 1:
            number /= 1024
            idx += 1
        return f"{number:.1f} {units[idx]}"

    @staticmethod
    def _pretty_eta(value) -> str:
        try:
            seconds = max(0, int(value))
        except (TypeError, ValueError):
            return "unknown"
        minutes, secs = divmod(seconds, 60)
        hours, minutes = divmod(minutes, 60)
        return f"{hours}:{minutes:02d}:{secs:02d}" if hours else f"{minutes}:{secs:02d}"

    def _make_progress_hook(self, callback: Callable[[dict[str, Any]], None] | None):
        yt_dlp = _yt_dlp()
        last_emit = 0.0
        speed_tracker = _SpeedTracker()

        def hook(data):
            nonlocal last_emit
            while not self._resume_event.wait(0.1):
                if self._cancel_event.is_set():
                    raise yt_dlp.utils.DownloadCancelled("Download cancelled by user.")
            if self._cancel_event.is_set():
                raise yt_dlp.utils.DownloadCancelled("Download cancelled by user.")
            status = data.get("status")
            if status not in {"downloading", "finished"}:
                return

            info_dict = data.get("info_dict") or {}
            # filename can be identical for the video-only and audio-only streams.
            # Include format_id so those streams are counted separately rather than
            # overwriting each other's byte totals in the aggregate.
            format_id = str(info_dict.get("format_id") or data.get("format_id") or "").strip()
            filename = str(data.get("filename") or data.get("tmpfilename") or "").strip()
            requested_formats = info_dict.get("requested_formats")
            try:
                has_video = _has_video(info_dict)
                has_audio = _has_audio(info_dict)
            except Exception:
                has_video = has_audio = False
            stream_role = "video" if has_video and not has_audio else (
                "audio" if has_audio and not has_video else "muxed"
            )
            if format_id and filename:
                stream_key = f"{format_id}|{filename}"
            elif format_id:
                stream_key = f"format:{format_id}"
            elif filename:
                # Even without a format_id, a video-only and audio-only download
                # may report the same final filename. Keep their counters separate.
                stream_key = f"{stream_role}|{filename}"
            else:
                stream_key = str(info_dict.get("id") or stream_role or "stream")

            # Some yt-dlp hooks omit format_id even though requested_formats lists
            # the selected streams. Match each distinct hook stream to an unused
            # planned format so byte totals do not collapse to zero or 0/2.
            if not format_id and isinstance(requested_formats, list) and requested_formats:
                with self._progress_lock:
                    mapped_id = self._stream_format_map.get(stream_key)
                    if not mapped_id:
                        candidates = [item for item in requested_formats
                                      if isinstance(item, dict) and item.get("format_id") is not None]
                        used = set(self._stream_format_map.values())
                        role_candidates = []
                        for item in candidates:
                            candidate_id = str(item.get("format_id"))
                            if candidate_id in used:
                                continue
                            item_video, item_audio = _has_video(item), _has_audio(item)
                            item_role = "video" if item_video and not item_audio else (
                                "audio" if item_audio and not item_video else "muxed")
                            if item_role == stream_role:
                                role_candidates.append(candidate_id)
                        if not role_candidates:
                            role_candidates = [str(item.get("format_id")) for item in candidates
                                               if str(item.get("format_id")) not in used]
                        if role_candidates:
                            mapped_id = role_candidates[0]
                            self._stream_format_map[stream_key] = mapped_id
                    if mapped_id:
                        format_id = mapped_id
                        stream_key = f"{format_id}|{filename}" if filename else f"format:{format_id}"

            # Know whether yt-dlp selected separate video/audio streams. Do not
            # show 100% after the video-only stream finishes while audio is pending.
            if isinstance(requested_formats, list):
                expected_now = max(1, sum(1 for item in requested_formats if isinstance(item, dict)))
            else:
                try:
                    expected_now = 2 if _has_video(info_dict) and not _has_audio(info_dict) else 1
                except Exception:
                    expected_now = 1

            downloaded = data.get("downloaded_bytes")
            total = data.get("total_bytes") or data.get("total_bytes_estimate")
            try:
                downloaded_num = float(downloaded or 0)
            except (TypeError, ValueError):
                downloaded_num = 0.0
            if downloaded_num < 0:
                # A bad reading must not move the size or the bar; keep the last good view.
                return
            try:
                total_num = float(total) if total else 0.0
            except (TypeError, ValueError):
                total_num = 0.0
            if status == "finished" and total_num:
                downloaded_num = max(downloaded_num, total_num)

            with self._progress_lock:
                self._expected_progress_streams = max(self._expected_progress_streams, expected_now)
                self._progress_by_stream[stream_key] = {
                    "downloaded": downloaded_num,
                    "total": total_num,
                }
                stream_count = len(self._progress_by_stream)
                expected_streams = self._expected_progress_streams
                aggregate_downloaded = sum(x["downloaded"] for x in self._progress_by_stream.values())
                aggregate_total = sum(x["total"] for x in self._progress_by_stream.values())
                all_stream_totals_known = all(x["total"] > 0 for x in self._progress_by_stream.values())

            # Progress is measured against the selected formats, not each transient
            # yt-dlp callback in isolation. The last stream must not make the bar jump
            # to 99% while another selected stream has not started yet.
            if isinstance(requested_formats, list) and requested_formats and self._planned_sizes is None:
                planned_map: dict[str, float | None] = {}
                for item in requested_formats:
                    if isinstance(item, dict) and item.get("format_id") is not None:
                        planned_map[str(item["format_id"])] = _size_of(item)
                with self._progress_lock:
                    if self._planned_sizes is None:
                        self._planned_sizes = planned_map or None

            fid = format_id or stream_key
            with self._progress_lock:
                state = self._format_state.setdefault(fid, {"downloaded": 0.0, "total": None, "done": False})
                state["downloaded"] = downloaded_num
                if status == "finished":
                    state["done"] = True
                    state["total"] = max(downloaded_num, total_num or 0.0)
                elif total_num > 0:
                    state["total"] = total_num

                planned_map = self._planned_sizes or {}
                planned_ids = list(planned_map.keys())
                ids = planned_ids if planned_ids else list(self._format_state.keys())
                total_sum = 0.0
                done_sum = 0.0
                all_known = bool(ids)
                all_done = True
                for key in ids:
                    st = self._format_state.get(key) or {}
                    size = st.get("total") or planned_map.get(key)
                    if not size or float(size) <= 0:
                        all_known = False
                        all_done = all_done and bool(st.get("done"))
                        continue
                    size = float(size)
                    total_sum += size
                    done_sum += min(float(st.get("downloaded") or 0.0), size)
                    all_done = all_done and bool(st.get("done"))

                expected_streams = max(self._expected_progress_streams, len(planned_ids))
                stream_count = min(len(self._format_state), expected_streams)
                represented_streams = len(self._format_state)
                missing_streams = max(0, expected_streams - represented_streams)

            downloaded_for_ui = done_sum if planned_ids else aggregate_downloaded
            total_for_ui = None
            total_estimated = True
            if planned_ids and all_known and total_sum > 0:
                total_for_ui = total_sum
                # Use a true percentage; reserve the final 1% for postprocessing.
                pct = min(99.0, done_sum / total_sum * 100.0)
                total_estimated = not all_done or represented_streams < expected_streams
            elif self.estimate_bytes and self.estimate_bytes > 0:
                total_for_ui = max(float(self.estimate_bytes), total_sum, aggregate_total)
                pct = min(99.0, downloaded_for_ui / total_for_ui * 100.0)
                total_estimated = missing_streams > 0 or not all_stream_totals_known
            elif missing_streams > 0:
                # Unknown audio/video size: hold below halfway until the remaining
                # selected stream appears, rather than falsely showing completion.
                total_for_ui = None
                pct = min(49.0, max(self._last_overall, 49.0 if status == "finished" else 0.0))
                total_estimated = True
            elif all_known and total_sum > 0:
                total_for_ui = total_sum
                pct = min(99.0, done_sum / total_sum * 100.0)
                total_estimated = not all_done
            else:
                total_for_ui = None
                pct = self._last_overall if self._last_overall > 0 else None
                total_estimated = True

            if pct is not None:
                pct = min(pct, 99.0)
                with self._progress_lock:
                    pct = max(pct, self._last_overall)
                    self._last_overall = pct
                    self._last_view = {"downloaded": downloaded_for_ui, "total": total_for_ui,
                                       "total_estimated": total_estimated}
            _progress_probe(downloaded_for_ui, total_for_ui or 0.0, pct or 0.0, stream_count, expected_streams)
            now = time.monotonic()
            if callback and (status == "finished" or now - last_emit >= _PROGRESS_INTERVAL):
                last_emit = now
                # One speed and one ETA for the whole job, measured from the bytes of every
                # stream together. yt-dlp reports each stream's own speed and ETA, so with
                # separate video and audio the stats line used to alternate between them.
                speed_value, eta_seconds = speed_tracker.update(now, downloaded_for_ui, total_for_ui)
                callback({
                    "overall": pct,
                    "downloaded": downloaded_for_ui,
                    "total": total_for_ui,
                    "total_estimated": total_estimated,
                    "speed": self._pretty_bytes(speed_value) if speed_value is not None else None,
                    "eta": self._pretty_eta(eta_seconds) if eta_seconds is not None else None,
                    "status": status,
                })

        return hook

    def _make_postprocessor_hook(self, callback: Callable[[dict[str, Any]], None] | None):
        """Move the bar through the final steps: merging, embedding subtitles, metadata.

        yt-dlp reports these as postprocessor events. Without this the bar stopped
        near the end of the download and only moved when the file was complete.
        """
        def hook(data: dict[str, Any]) -> None:
            status = str(data.get("status") or "")
            if status == "started" or status == "processing":
                target = 99.0
            elif status == "finished":
                target = 100.0
            else:
                return
            with self._progress_lock:
                pct = max(target, self._last_overall)
                self._last_overall = pct
            if callback:
                with self._progress_lock:
                    view = dict(self._last_view)
                callback({
                    "overall": pct,
                    "downloaded": view.get("downloaded"),
                    "total": view.get("total"),
                    "total_estimated": view.get("total_estimated", True),
                    "speed": None,
                    "eta": None,
                    "status": "postprocessing",
                })

        return hook

    def _find_output(self, info, before_files: set[Path], started_at: float, ydl=None):
        candidates: list[Path] = []
        for key in ("filepath", "_filename"):
            value = info.get(key) if isinstance(info, dict) else None
            if value:
                candidates.append(Path(value))
        requested = info.get("requested_downloads") if isinstance(info, dict) else None
        if isinstance(requested, list):
            for item in requested:
                if isinstance(item, dict):
                    for key in ("filepath", "_filename"):
                        if item.get(key):
                            candidates.append(Path(item[key]))
        if ydl is not None and isinstance(info, dict):
            try:
                candidates.append(Path(ydl.prepare_filename(info)))
            except Exception:
                pass

        for candidate in candidates:
            try:
                if candidate.is_file() and candidate.suffix.lower() not in {".part", ".ytdl", ".json"}:
                    return str(candidate.resolve())
                for ext in (".mp4", ".mkv", ".webm", ".mov", ".m4v"):
                    alternate = candidate.with_suffix(ext)
                    if alternate.is_file():
                        return str(alternate.resolve())
            except OSError:
                continue

        ignored = {".part", ".ytdl", ".json", ".srt", ".vtt", ".ass", ".lrc", ".jpg", ".webp", ".png"}
        try:
            changed = [p for p in self.out_dir.iterdir()
                       if p.is_file() and p not in before_files and p.suffix.lower() not in ignored
                       and p.stat().st_mtime >= started_at - 2]
            if changed:
                return str(max(changed, key=lambda p: p.stat().st_mtime).resolve())
        except OSError:
            pass
        return None

    def _start_caption_prefetch(self, yt_dlp, languages: list[str]) -> None:
        """Fetch the caption files in the background while the video downloads.

        The caption lookup takes roughly 35 seconds on its own. Starting it together
        with the video means it usually finishes while the video is still downloading,
        so subtitles no longer add that time after the download.
        """
        self._caption_prefetch = None
        if not languages or self._cancel_event.is_set():
            return
        holder: dict[str, Any] = {"done": threading.Event(), "files": [], "folder": None}
        self._caption_prefetch = holder

        def worker() -> None:
            try:
                folder = Path(tempfile.mkdtemp(prefix="lumo_subs_pre_"))
                holder["folder"] = folder
                holder["files"] = _fetch_subtitle_files_separately(
                    yt_dlp, self.url, languages, folder, self.cookie_path or None)
            except Exception as exc:
                _subs_trace(f"caption prefetch error: {exc!r}")
            finally:
                holder["done"].set()

        threading.Thread(target=worker, daemon=True).start()

    def _add_subtitles_separately(self, yt_dlp, languages: list[str], file_path: str) -> bool:
        """Fetch the selected subtitles and add them to the saved video.

        Tries without cookies first, then with the account cookies, because YouTube
        sometimes returns captions only to one kind of request. Every step is written
        to the subtitle trace file so a failure can be read instead of guessed.
        """
        _subs_trace(f"fallback start: languages={languages} file={file_path}")
        holder = getattr(self, "_caption_prefetch", None)
        if holder is not None:
            holder["done"].wait(timeout=90)
            prefetched = list(holder.get("files") or [])
            folder = holder.get("folder")
            self._caption_prefetch = None
            try:
                if prefetched and _mux_subtitles_into_video(Path(file_path), prefetched, _ffmpeg_path()):
                    _subs_trace("prefetched captions added to the video")
                    return True
                _subs_trace("prefetched captions not usable; trying the normal fetch")
            finally:
                if folder is not None:
                    shutil.rmtree(folder, ignore_errors=True)
        # Always use the account cookies when they are set: age-restricted and
        # members-only videos need them. A cookie-less attempt is only used when no
        # cookie file is configured at all.
        attempts = [self.cookie_path] if self.cookie_path else [None]
        for number, cookie in enumerate(attempts, start=1):
            if self._cancel_event.is_set():
                return False
            _subs_trace(f"fallback attempt {number} of {len(attempts)} "
                        f"({'with cookies' if cookie else 'no cookie file configured'})")
            try:
                with tempfile.TemporaryDirectory(prefix="lumo_subs_") as temporary:
                    subtitles = _fetch_subtitle_files_separately(
                        yt_dlp, self.url, languages, Path(temporary), cookie)
                    if not subtitles:
                        _subs_trace(f"fallback attempt {number}: no caption files found")
                        continue
                    if _mux_subtitles_into_video(Path(file_path), subtitles, _ffmpeg_path()):
                        _subs_trace("fallback success: subtitles added to the video")
                        return True
                    _subs_trace("fallback: ffmpeg could not add the subtitle files")
            except Exception as exc:
                print("Subtitle fallback failed:", repr(exc), flush=True)
                _subs_trace(f"fallback error: {exc!r}")
        _subs_trace("fallback finished without subtitles")
        return False

    def _download_with(self, ydl, yt_dlp, on_status):
        """Reuse inspection metadata; refresh only when the stream metadata is stale.

        A postprocessor/FFmpeg failure must not trigger a second complete download.
        """
        prefetched, self._prefetched = self._prefetched, None
        if prefetched is not None:
            for key in ("requested_formats", "requested_downloads", "requested_subtitles",
                        "_filename", "filepath"):
                prefetched.pop(key, None)
            if prefetched.get("_lumo_direct"):
                prefetched["subtitles"] = {}
                prefetched["automatic_captions"] = {}
            planned = _plan_sizes(ydl, (ydl.params or {}).get("format"), prefetched)
            if planned:
                with self._progress_lock:
                    self._planned_sizes = planned
            try:
                info = ydl.process_ie_result(prefetched, download=True)
                if isinstance(info, dict):
                    return info
            except Exception as exc:
                if self._cancel_event.is_set() or isinstance(exc, yt_dlp.utils.DownloadCancelled):
                    raise
                message = str(exc).casefold()
                # Do not repeat a large download because FFmpeg/remux/subtitle
                # postprocessing failed after the media bytes were already fetched.
                if any(term in message for term in (
                    "ffmpeg", "ffprobe", "postprocessor", "merger", "remux",
                    "subtitle", "subtitles", "permission denied",
                )):
                    raise
                retryable = _looks_like_network_error(message) or any(term in message for term in (
                    "http error 403", "http error 410", "url has expired", "signature",
                    "requested format is not available", "no video formats", "nsig",
                    "unable to download webpage", "unable to download api page",
                ))
                if not retryable:
                    raise
                if on_status:
                    on_status("Refreshing stream links and trying again…")
        return ydl.extract_info(self.url, download=True)

    def run(self, on_progress=None, on_status=None):
        result = {"status": "Failed", "file_path": None, "error": "The download did not start."}
        started_at = time.time()
        perf_started = time.perf_counter()
        before_files: set[Path] = set()
        info: dict[str, Any] | None = None
        file_path: str | None = None
        languages: list[str] = []
        try:
            yt_dlp = _yt_dlp()
            self.out_dir.mkdir(parents=True, exist_ok=True)
            before_files = {p.resolve() for p in self.out_dir.iterdir() if p.is_file()}
            languages = _resolve_subtitle_languages(self.subtitle_langs, self._prefetched)
            # Keep the inspection metadata for the automatic-caption decision below.
            metadata_hint = self._prefetched
            # Subtitles no longer force a second full lookup here: captions are fetched in
            # the background (see _start_caption_prefetch) and added after the download, so
            # the inspection data can be reused and the download skips the extra ~30 s.
            partial_dir, resumed = prepare_partial_folder(self.out_dir, self.url, self.max_height)

            if on_status:
                on_status("Starting download…" if self._prefetched is not None
                          else "Checking the video…")
            dl_logger = _LumoLogger(on_status)
            options = {
                "quiet": True,
                "verbose": os.environ.get("LUMO_SUBS_DEBUG") == "1",
                "no_warnings": False,
                "logger": dl_logger,
                "noplaylist": True,
                # Bound a stalled network request so Pause/Cancel can be observed
                # at the next yt-dlp callback rather than appearing dead for minutes.
                "socket_timeout": 10,
                "format": self._format_selector(),
                **({"ffmpeg_location": _ffmpeg_dir()} if _ffmpeg_available() else {}),
                "outtmpl": "%(title).180B [%(id)s].%(ext)s",
                # Final files go to the chosen folder; in-progress .part files live in a
                # per-link folder so an interrupted download can resume later.
                "paths": {"home": str(self.out_dir), "temp": str(partial_dir)},
                "merge_output_format": "mp4" if self.merge_mp4 else "mkv",
                # Remux when a single-file source uses a different container;
                # this changes the container without re-encoding the video.
                "postprocessors": ([{
                    "key": "FFmpegVideoRemuxer",
                    "preferedformat": "mp4" if self.merge_mp4 else "mkv",
                }] if _ffmpeg_available() else []),
                "concurrent_fragment_downloads": 4,
                # YouTube throttles a single connection; larger chunks keep the speed up.
                "http_chunk_size": 10 * 1024 * 1024,
                "retries": 3,
                "fragment_retries": 4,
                "extractor_retries": 2,
                "continuedl": True,
                "windowsfilenames": os.name == "nt",
                "progress_hooks": [self._make_progress_hook(on_progress)],
                "postprocessor_hooks": [self._make_postprocessor_hook(on_progress)],
                "remote_components": ["ejs:github"],
                **_js_runtime_options()[0],
                **_cookie_option(self.cookie_path),
            }
            if languages:
                # yt-dlp uses the manual track for a language when one exists and only
                # falls back to the automatic caption for languages without one.
                if metadata_hint:
                    _manual, _original = _real_subtitle_keys(metadata_hint)
                    use_automatic_tracks = any(code in _original for code in languages)
                else:
                    use_automatic_tracks = True
                options.update({
                    "writesubtitles": True,
                    "writeautomaticsubtitles": use_automatic_tracks,
                    "subtitleslangs": languages,
                    "subtitlesformat": "vtt/best",  # Keep VTT sidecars when FFmpeg is missing.
                })
                if _ffmpeg_available():
                    # Keep subtitles as selectable tracks; do not burn them into the picture.
                    options["embedsubtitles"] = True
                    options["postprocessors"] = list(options["postprocessors"]) + [
                        {"key": "FFmpegSubtitlesConvertor", "format": "srt"},
                        {"key": "FFmpegEmbedSubtitle"},
                    ]
                else:
                    # Avoid an impossible embed step; the selected subtitle files can
                    # still be saved beside the video as sidecar tracks.
                    options["embedsubtitles"] = False
            else:
                options["writesubtitles"] = False
                options["writeautomaticsubtitles"] = False

            if self._cancel_event.is_set():
                return {"status": "Cancelled", "file_path": None, "error": "Download cancelled by user."}
            self._start_caption_prefetch(yt_dlp, languages)
            _perf_note("download start", perf_started)
            with yt_dlp.YoutubeDL(options) as ydl:
                info = self._download_with(ydl, yt_dlp, on_status)
                _perf_note("download finished", perf_started)
                if self._cancel_event.is_set():
                    return {"status": "Cancelled", "file_path": None, "error": "Download cancelled by user."}
                if not isinstance(info, dict):
                    raise RuntimeError("The site did not return the downloaded video's details.")
                file_path = self._find_output(info, before_files, started_at, ydl)
                # Never mark a row Completed without a real, existing media file.
                # Otherwise History can display a false 100% completion and Open
                # File Location/Delete actions have no valid target.
                if not file_path or not Path(file_path).is_file():
                    return {"status": "Failed", "file_path": None,
                            "error": "The download ended, but the final video file could not be located.",
                            "requested_height": self.max_height,
                            "actual_height": _downloaded_height(info)}
                file_path = str(Path(file_path).resolve())
                # Subtitles are a best-effort extra. When the video itself is
                # saved, a missing or non-embeddable subtitle track must not mark
                # the whole download as Failed; the video is complete and is kept.
                subtitle_note = None
                if languages:
                    requested_subtitles = info.get("requested_subtitles")
                    subtitle_count = _subtitle_stream_count(file_path)
                    _subs_trace(f"main download: requested={languages} "
                                f"requested_subtitles={list((info or {}).get('requested_subtitles') or {})} "
                                f"subtitle_streams={subtitle_count}")
                    for _m in list(dl_logger.messages)[-8:]:
                        _subs_trace("main download yt-dlp: " + _m[:300])
                    # yt-dlp can report requested_subtitles even when its embed
                    # postprocessor did not leave any subtitle streams in the final
                    # file. Recover in either case: no requested tracks, or a verified
                    # zero subtitle-stream count.
                    needs_recovery = (
                        not isinstance(requested_subtitles, dict)
                        or not requested_subtitles
                        or subtitle_count == 0
                    )
                    if needs_recovery:
                        if self._add_subtitles_separately(yt_dlp, languages, file_path):
                            subtitle_note = None
                        elif not isinstance(requested_subtitles, dict) or not requested_subtitles:
                            subtitle_note = ("Saved the video. The selected subtitles could not be "
                                             "retrieved or added, so none were added.")
                            try:
                                manual_keys, original_keys = _real_subtitle_keys(info or {})
                                listed = ", ".join(sorted(manual_keys | original_keys)) or "none"
                                asked = ", ".join(languages)
                                reasons = [m for m in dl_logger.messages
                                           if any(t in m.lower() for t in ("subtitle", "timedtext", "429", "sub"))]
                                subtitle_note += f" Requested: {asked}. Video lists: {listed}."
                                if reasons:
                                    subtitle_note += " yt-dlp: " + reasons[-1][:250]
                            except Exception:
                                pass
                        else:
                            subtitle_note = ("Saved the video. The selected subtitles could not be added "
                                             "to the file, so the video was kept without them.")
                discard_partial_folder(self.out_dir, self.url)
                if on_progress:
                    try:
                        on_progress({"overall": 100.0, "downloaded": None, "total": None,
                                     "total_estimated": False, "speed": None, "eta": None,
                                     "status": "finished"})
                    except Exception:
                        pass
                return {"status": "Completed", "file_path": file_path, "error": None,
                        "warning": subtitle_note,
                        "requested_height": self.max_height,
                        "actual_height": _downloaded_height(info)}
        except Exception as exc:
            try:
                yt_dlp = _yt_dlp()
                cancelled_type = getattr(getattr(yt_dlp, "utils", None), "DownloadCancelled", ())
                is_cancelled = bool(self._cancel_event.is_set()) or (
                    isinstance(cancelled_type, type) and isinstance(exc, cancelled_type)
                )
            except Exception:
                is_cancelled = self._cancel_event.is_set()
            technical_message = str(exc).strip() or exc.__class__.__name__
            technical_message = re.sub(r"^(ERROR:\s*)+", "", technical_message, flags=re.IGNORECASE)
            message = plain_error(technical_message, "download")
            if any(term in technical_message.casefold() for term in ("ffmpeg", "ffprobe", "remux", "merger")):
                # Keep a concise technical hint for dependency/postprocessor failures;
                # the full traceback remains in last_error.log.
                message += " Technical detail: " + technical_message[:350]
            if is_cancelled:
                result = {"status": "Cancelled", "file_path": None, "error": "Download cancelled by user."}
            else:
                # A subtitle/FFmpeg postprocessor can fail after the media file has
                # already been written. Keep and report that file instead of
                # hiding it or deleting it as part of error handling.
                preserved_path = file_path
                if not preserved_path:
                    try:
                        preserved_path = self._find_output(info or {}, before_files, started_at)
                    except Exception:
                        preserved_path = None
                if preserved_path and Path(preserved_path).is_file():
                    preserved_path = str(Path(preserved_path).resolve())
                    if languages and _is_subtitle_processing_error(exc):
                        result = {
                            "status": "Completed",
                            "file_path": preserved_path,
                            "error": None,
                            "warning": ("The video was saved, but the selected subtitles could not be "
                                        "downloaded or embedded. The video was kept without them. Details: "
                                        + message[:700]),
                            "requested_height": self.max_height,
                            "actual_height": _downloaded_height(info or {}),
                        }
                    else:
                        result = {"status": "Failed", "file_path": preserved_path,
                                  "error": message + " The downloaded video was kept; check the subtitle/FFmpeg step."}
                else:
                    result = {"status": "Failed", "file_path": None, "error": message}
            return result


def _register_running(run_method):
    """Track a job from the moment it starts running until run() returns."""
    @functools.wraps(run_method)
    def tracked_run(self, *args, **kwargs):
        with _RUNNING_LOCK:
            _RUNNING_JOBS.append(self)
        try:
            return run_method(self, *args, **kwargs)
        finally:
            with _RUNNING_LOCK:
                if self in _RUNNING_JOBS:
                    _RUNNING_JOBS.remove(self)
    return tracked_run


DownloadJob.run = _register_running(DownloadJob.run)


def _prewarm_js_runtime() -> None:
    try:
        _js_runtime_options()
    except Exception:
        pass


threading.Thread(target=_prewarm_js_runtime, name="lumo-runtime-prewarm", daemon=True).start()
