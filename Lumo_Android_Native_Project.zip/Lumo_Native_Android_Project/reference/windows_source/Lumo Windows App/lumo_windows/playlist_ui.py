"""YouTube-playlist-only controller integrated with Lumo's recovered Tk application.

All network work runs on worker threads. Tk widgets and Treeview items are only
updated by the UI-thread event pump. Items carry stable IDs, so inspection results
cannot attach to the wrong row after an item is removed.
"""
from __future__ import annotations

import io
import os
import queue
import subprocess
import sys
import threading
import time
import tkinter as tk
from tkinter import ttk, messagebox
from pathlib import Path
from typing import Any
from urllib.request import Request, urlopen
from uuid import uuid4

from . import downloader, settings, history

BG = "#101827"
PANEL = "#17243A"
PANEL_ALT = "#1C2B43"
TEXT = "#F2F6FF"
MUTED = "#A9B8CC"
ACCENT = "#55D8F2"
PURPLE = "#8871FF"
DANGER = "#FF647F"


def _settings(app: Any = None) -> dict[str, Any]:
    """Return persisted preferences overlaid with the app's current live values."""
    try:
        result = settings.load_settings()
    except Exception:
        result = {}
    if not isinstance(result, dict):
        result = {}
    live = getattr(app, "settings", None) if app is not None else None
    if isinstance(live, dict):
        result.update(live)
    return result


def _cookie_path(prefs: dict[str, Any], app: Any = None) -> str | None:
    """Resolve the currently selected cookie file, including unsaved live settings."""
    effective = dict(prefs) if isinstance(prefs, dict) else {}
    live = getattr(app, "settings", None) if app is not None else None
    if isinstance(live, dict):
        effective.update(live)
    path = str(effective.get("cookie_file", "") or "").strip()
    if effective.get("use_cookies") and path:
        candidate = Path(path).expanduser()
        try:
            if candidate.is_file():
                return str(candidate.resolve())
        except (OSError, RuntimeError):
            pass
    return None


def _reveal_file_location(path: Path, platform_name: str | None = None) -> None:
    """Reveal a saved video in the platform's file manager when supported."""
    path = Path(path).expanduser().resolve()
    platform_name = platform_name or os.name
    if platform_name == "nt":
        # /select highlights the exact downloaded file instead of merely opening
        # its containing folder, which is what users expect from this action.
        subprocess.Popen(["explorer.exe", f"/select,{path}"])
    elif sys.platform == "darwin":
        subprocess.Popen(["open", "-R", str(path)])
    else:
        subprocess.Popen(["xdg-open", str(path.parent)])


def is_youtube_playlist_url(url: str) -> bool:
    """Expose the downloader's single source of truth for playlist URL validation."""
    return downloader.is_youtube_playlist_url(url)


def pick_height(available: list[int] | tuple[int, ...], cap: int | None) -> int | None:
    """Return the highest listed height at/below the chosen cap (or the highest)."""
    heights: list[int] = []
    for value in available:
        try:
            height = int(value)
        except (TypeError, ValueError):
            continue
        if height > 0:
            heights.append(height)
    if not heights:
        return None
    eligible = [height for height in heights if cap is None or height <= cap]
    return max(eligible) if eligible else None


def _valid_colour(value: Any, fallback: str) -> str:
    """Accept only ordinary six-digit colours from the recovered theme/settings."""
    value = str(value or "").strip()
    if len(value) == 7 and value.startswith("#"):
        try:
            int(value[1:], 16)
            return value.upper()
        except ValueError:
            pass
    return fallback



def _thumbnail_ssl_context():
    """Certifi trust store, the same one yt-dlp uses; avoids certificate errors from HTTPS filters."""
    try:
        import ssl
        import certifi
        return ssl.create_default_context(cafile=certifi.where())
    except Exception:
        return None


class PlaylistWindow:
    """Playlist page controller. Embedded mode uses the existing app window."""
    def __init__(self, app: Any, parent: Any = None, embedded: bool = False):
        self.app = app
        self.embedded = bool(embedded)
        self.prefs = _settings()
        runtime = getattr(app, "_lumo_runtime_module", None)
        self.BG = _valid_colour(getattr(runtime, "BG", BG) if runtime else BG, BG)
        self.PANEL = _valid_colour(getattr(runtime, "CARD", getattr(runtime, "PANEL", PANEL)) if runtime else PANEL, PANEL)
        self.PANEL_ALT = _valid_colour(getattr(runtime, "PANEL_ALT", PANEL_ALT) if runtime else PANEL_ALT, PANEL_ALT)
        self.TEXT = _valid_colour(getattr(runtime, "TEXT", TEXT) if runtime else TEXT, TEXT)
        self.MUTED = _valid_colour(getattr(runtime, "MUTED", MUTED) if runtime else MUTED, MUTED)
        accent_value = (getattr(runtime, "ACCENT", None) if runtime else None) or self.prefs.get("accent_color") or ACCENT
        self.ACCENT = _valid_colour(accent_value, ACCENT)
        self.PURPLE = _valid_colour(getattr(runtime, "PURPLE", PURPLE) if runtime else PURPLE, PURPLE)
        self.DANGER = _valid_colour(getattr(runtime, "DANGER", DANGER) if runtime else DANGER, DANGER)
        self.BORDER = _valid_colour(getattr(runtime, "BORDER", "#2B3B56") if runtime else "#2B3B56", "#2B3B56")
        self.FIELD_BG = _valid_colour(getattr(runtime, "INPUT_BG", "#0F192A") if runtime else "#0F192A", "#0F192A")
        if self.embedded:
            self.root = app
            self.container = parent or app
        else:
            self.root = tk.Toplevel(parent or app)
            self.root.title("Lumo — Playlist")
            self.root.geometry("1000x690")
            self.root.minsize(700, 480)
            self.root.configure(bg=self.BG)
            try:
                self.root.transient(app)
            except Exception:
                pass
            self.container = self.root
        self.items: list[dict[str, Any]] = []
        self.events: queue.Queue = queue.Queue()
        # Playlist expansion can yield hundreds or thousands of entries. Keep
        # inspections bounded to a few daemon workers instead of starting one
        # OS thread per video (which can freeze the Tk event loop on large lists).
        self._inspect_queue: queue.Queue = queue.Queue()
        self._inspect_shutdown = threading.Event()
        self._inspect_worker_count = 3
        self._inspect_workers: list[threading.Thread] = []
        self._inspection_queue_closed = False
        self.current_job = None
        self.worker: threading.Thread | None = None
        self.current_uid: str | None = None
        self._stop_requested = False
        self._paused = False
        self._collection_done = False
        self._history_last_refresh = 0.0
        self._queue_snapshot: list[dict[str, Any]] = []
        self._cancelled_queue_uids: set[str] = set()
        self._card_widgets: dict[str, dict[str, Any]] = {}
        self._selected_uid: str | None = None
        # The Playlist page accepts exactly one YouTube playlist URL per session.
        # That URL expands into the playlist's entries; it is not a multi-URL form.
        self._playlist_source_url: str | None = None
        self._playlist_loading = False
        self._playlist_expanded = False
        self._playlist_failed = False
        self._thumbnail_photos: dict[str, Any] = {}
        self._poll_after_id = None
        self._last_busy_ui_update = 0.0
        customization = getattr(app, "_lumo_customization_options", {})
        self._show_playlist_thumbnails = bool(customization.get("show_playlist_thumbnails", True))
        self._compact_playlist_rows = bool(customization.get("compact_playlist_rows", False))
        self.style = None
        self._build()
        # Avoid creating background workers during application startup when the
        # user may never open Playlist. They start lazily on the first URL.
        self.root.after(100, self._poll_events)
        if not self.embedded:
            self.root.protocol("WM_DELETE_WINDOW", self._close)

    def _start_inspection_workers(self) -> None:
        if self._inspection_queue_closed or self._inspect_shutdown.is_set() or self._inspect_workers:
            return
        for index in range(self._inspect_worker_count):
            worker = threading.Thread(
                target=self._inspection_worker_loop,
                name=f"LumoPlaylistInspect-{index + 1}", daemon=True,
            )
            self._inspect_workers.append(worker)
            worker.start()

    def _enqueue_inspection(self, uid: str, url: str) -> None:
        if self._inspection_queue_closed or self._inspect_shutdown.is_set():
            self.status_var.set("Playlist inspection is shutting down. Reopen the page to add videos.")
            return
        self._start_inspection_workers()
        self._inspect_queue.put((uid, url))

    def _inspection_worker_loop(self) -> None:
        while not self._inspect_shutdown.is_set():
            try:
                task = self._inspect_queue.get(timeout=0.25)
            except queue.Empty:
                continue
            try:
                if task is None or self._inspect_shutdown.is_set():
                    return
                uid, url = task
                self._inspect_worker(uid, url)
            finally:
                self._inspect_queue.task_done()

    def shutdown_inspection(self) -> None:
        if self._inspection_queue_closed:
            return
        self._inspection_queue_closed = True
        self._inspect_shutdown.set()
        # Discard pending inspections; in-flight HTTP requests cannot be safely
        # interrupted, but workers are daemon threads and will exit after timeout.
        while True:
            try:
                self._inspect_queue.get_nowait()
                self._inspect_queue.task_done()
            except queue.Empty:
                break

    def _build(self) -> None:
        """Build the Playlist page using the same simple input/config/queue flow as Download."""
        try:
            self.style = ttk.Style(self.root)
            self.style.configure("Lumo.TCombobox", fieldbackground=self.FIELD_BG,
                                 background=self.PANEL_ALT, foreground=self.TEXT,
                                 selectbackground=self.PURPLE, selectforeground="white",
                                 arrowcolor=self.TEXT, padding=(7, 4))
            self.style.map("Lumo.TCombobox",
                           fieldbackground=[("readonly", self.FIELD_BG), ("disabled", self.PANEL)],
                           foreground=[("readonly", self.TEXT), ("disabled", self.MUTED)],
                           selectbackground=[("readonly", self.PURPLE)])
            self.style.configure("Lumo.Treeview", background=self.PANEL,
                                 fieldbackground=self.PANEL, foreground=self.TEXT,
                                 rowheight=38, borderwidth=0)
            self.style.map("Lumo.Treeview", background=[("selected", self.PURPLE)],
                           foreground=[("selected", "white")])
        except Exception:
            self.style = None

        # The app shell already supplies the large page title; use a compact page
        # heading here so the Playlist content doesn't repeat it or waste vertical space.
        header = tk.Frame(self.container, bg=self.BG)
        header.pack(fill="x", padx=18, pady=(10, 7))
        heading = tk.Frame(header, bg=self.BG)
        heading.pack(side="left", fill="x", expand=True)
        tk.Label(heading, text="Playlist URL", bg=self.BG, fg=self.TEXT,
                 font=("Segoe UI Semibold", 11)).pack(anchor="w")
        tk.Label(heading, text="Paste one YouTube playlist link. Lumo queues every video in order.",
                 bg=self.BG, fg=self.MUTED, font=("Segoe UI", 8)).pack(anchor="w", pady=(2, 0))
        self.count_var = tk.StringVar(master=self.root, value="0 videos")
        tk.Label(header, textvariable=self.count_var, bg=self.PANEL_ALT, fg=self.TEXT,
                 font=("Segoe UI Semibold", 8), padx=10, pady=5).pack(side="right", anchor="center")

        # URL input panel, matching Download's single-field + clear + primary-action pattern.
        add = tk.Frame(self.container, bg=self.PANEL, highlightbackground=self.BORDER, highlightthickness=1)
        add.pack(fill="x", padx=18, pady=(0, 8))
        self.url_var = tk.StringVar(master=self.root)
        self.url_entry = tk.Entry(add, textvariable=self.url_var, bg=self.FIELD_BG, fg=self.TEXT,
                                  insertbackground=self.TEXT, selectbackground=self.PURPLE,
                                  relief="flat", font=("Segoe UI", 10), bd=0)
        self.url_entry.pack(side="left", fill="x", expand=True, padx=(12, 7), pady=8, ipady=7)
        self.url_entry.bind("<Return>", lambda _e: self.add_url())
        self.add_button = self._button(add, "Load Playlist", self.add_url, self.ACCENT, self.BG)
        self.add_button.pack(side="right", padx=(0, 9), pady=7)
        self.clear_url_button = self._button(add, "×", self.clear_url, self.PANEL_ALT, self.TEXT, compact=True)
        self.clear_url_button.configure(width=3, state="normal")
        self.clear_url_button.pack(side="right", padx=(0, 6), pady=7)
        self.clear_playlist_button = self._button(add, "Clear", self.clear_playlist, self.PANEL_ALT, self.TEXT)
        self.clear_playlist_button.pack(side="right", padx=(0, 8), pady=7)
        self.clear_playlist_button.configure(state="disabled")

        # One global quality/subtitle choice applies to all items in this playlist.
        config = tk.Frame(self.container, bg=self.PANEL, highlightbackground=self.BORDER, highlightthickness=1)
        config.pack(fill="x", padx=18, pady=(0, 8))
        tk.Label(config, text="Quality", bg=self.PANEL, fg=self.TEXT,
                 font=("Segoe UI Semibold", 9)).pack(side="left", padx=(12, 6), pady=8)
        inherited_quality = None
        for name in ("quality_var", "format_var", "video_quality_var"):
            variable = getattr(self.app, name, None)
            try:
                value = str(variable.get()).strip() if variable is not None else ""
            except Exception:
                value = ""
            if value:
                inherited_quality = value
                break
        if inherited_quality not in {"Best available", "4320p", "2160p", "1440p", "1080p", "720p", "480p", "360p"}:
            inherited_quality = "1080p"
        self.quality_var = tk.StringVar(master=self.root, value=inherited_quality)
        self.quality_box = ttk.Combobox(
            config, textvariable=self.quality_var,
            values=("Best available", "4320p", "2160p", "1440p", "1080p", "720p", "480p", "360p"),
            state="readonly", width=13, style="Lumo.TCombobox")
        self.quality_box.pack(side="left", padx=4, pady=6)
        tk.Label(config, text="Subtitles", bg=self.PANEL, fg=self.TEXT,
                 font=("Segoe UI Semibold", 9)).pack(side="left", padx=(14, 5), pady=8)
        live_prefs = _settings(self.app)
        self.prefs = live_prefs
        self.subtitle_var = tk.StringVar(master=self.root, value=str(live_prefs.get("preferred_subtitle", "en") or "en"))
        self.subtitle_box = ttk.Combobox(config, textvariable=self.subtitle_var,
                                         values=("None", "en", "hi", "mr", "es", "fr", "de", "ja", "pt"),
                                         state="readonly", width=8, style="Lumo.TCombobox")
        self.subtitle_box.pack(side="left", padx=4, pady=6)
        tk.Label(config, text="Applies to every video", bg=self.PANEL, fg=self.MUTED,
                 font=("Segoe UI", 8)).pack(side="left", padx=10, pady=8)

        list_header = tk.Frame(self.container, bg=self.BG)
        list_header.pack(fill="x", padx=18, pady=(1, 5))
        tk.Label(list_header, text="Videos in this playlist", bg=self.BG, fg=self.TEXT,
                 font=("Segoe UI Semibold", 10)).pack(side="left")
        tk.Label(list_header, text="In playlist order", bg=self.BG, fg=self.MUTED,
                 font=("Segoe UI", 8)).pack(side="left", padx=(9, 0), pady=(2, 0))

        body = tk.Frame(self.container, bg=self.BG)
        body.pack(fill="both", expand=True, padx=18, pady=(0, 6))
        # This hidden Treeview remains the stable item-selection adapter for the
        # existing download/history actions; the visible queue uses compact cards.
        self.tree = ttk.Treeview(body, columns=("quality", "subtitles", "status", "progress"),
                                 show="tree headings", selectmode="browse", height=1)
        self.tree.pack_forget()
        self._card_widgets: dict[str, dict[str, Any]] = {}
        self._selected_uid: str | None = None
        self._cancelled_queue_uids: set[str] = set()
        self._card_canvas = tk.Canvas(body, bg=self.BG, highlightthickness=0, bd=0)
        self._card_scroll = ttk.Scrollbar(body, orient="vertical", command=self._card_canvas.yview)
        self._card_canvas.configure(yscrollcommand=self._card_scroll.set)
        self._card_scroll.pack(side="right", fill="y")
        self._card_canvas.pack(side="left", fill="both", expand=True)
        self._card_host = tk.Frame(self._card_canvas, bg=self.BG)
        self._card_window = self._card_canvas.create_window((0, 0), window=self._card_host, anchor="nw")
        self._card_host.bind("<Configure>", lambda _e: self._card_canvas.configure(
            scrollregion=self._card_canvas.bbox("all")))
        self._card_canvas.bind("<Configure>", self._on_card_canvas_configure)
        self._card_mouse_inside = False
        self._card_canvas.bind("<Enter>", lambda _e: setattr(self, "_card_mouse_inside", True), add="+")
        self._card_canvas.bind("<Leave>", lambda _e: setattr(self, "_card_mouse_inside", False), add="+")
        self._card_canvas.bind_all("<MouseWheel>", self._on_card_mousewheel, add="+")

        footer = tk.Frame(self.container, bg=self.BG)
        footer.pack(fill="x", padx=18, pady=(0, 10))
        self.status_var = tk.StringVar(master=self.root, value="Paste a YouTube playlist link, then select Load Playlist.")
        tk.Label(footer, textvariable=self.status_var, bg=self.BG, fg=self.MUTED,
                 font=("Segoe UI", 8), anchor="w", justify="left", wraplength=600).pack(fill="x", pady=(0, 6))
        self.action_row = tk.Frame(footer, bg=self.BG)
        self.action_row.pack(fill="x", pady=(0, 4))
        # Keep the method/attribute for code compatibility, but the extra review
        # step is not part of the user flow: the list auto-readies on inspection.
        self.done_button = self._button(self.action_row, "Done · Review", self.finish_collection, self.PURPLE, "white")
        self.done_button.pack_forget()
        self.start_button = self._button(self.action_row, "Download Playlist", self.start_queue, self.ACCENT, self.BG)
        self.start_button.pack(side="left", padx=(0, 7))
        self.pause_button = self._button(self.action_row, "Pause", self.toggle_pause, self.PANEL_ALT, self.TEXT)
        self.pause_button.pack(side="left", padx=(0, 7))
        self.cancel_button = self._button(self.action_row, "Cancel video", self.cancel_current, self.PANEL_ALT, self.TEXT)
        self.cancel_button.pack(side="left", padx=(0, 7))
        self.remove_button = self._button(self.action_row, "Remove item", self.remove_selected, self.PANEL_ALT, self.TEXT)
        self.remove_button.pack(side="left", padx=(0, 7))
        self.nav_row = tk.Frame(footer, bg=self.BG)
        self.nav_row.pack(fill="x")
        self.open_button = self._button(self.nav_row, "Open file location", self.open_selected, self.PANEL_ALT, self.TEXT)
        self.open_button.pack(side="left", padx=(0, 7))
        self.share_button = self._button(self.nav_row, "Share / Copy path", self.share_selected_path, self.PANEL_ALT, self.TEXT)
        self.share_button.pack(side="left", padx=(0, 7))
        self.delete_file_button = self._button(self.nav_row, "Delete file", self.delete_selected_file, self.DANGER, "white")
        self.delete_file_button.pack(side="left", padx=(0, 7))
        self.back_button = None
        if self.embedded:
            self.back_button = self._button(self.nav_row, "Back to Download", lambda: self.app.show_page("download"), self.PANEL_ALT, self.TEXT)
            self.back_button.pack(side="right")
        self.start_button.configure(state="disabled")
        self.pause_button.configure(state="disabled")
        self.cancel_button.configure(state="disabled")
        self.apply_customization(getattr(self.app, "_lumo_customization_options", self.prefs))

    def apply_customization(self, options: dict[str, Any]) -> None:
        """Apply visible optional controls without rebuilding or losing the queue."""
        self._show_playlist_thumbnails = bool(options.get("show_playlist_thumbnails", True))
        self._compact_playlist_rows = bool(options.get("compact_playlist_rows", False))
        try:
            if self.style is not None:
                self.style.configure("Lumo.Treeview", rowheight=34 if self._compact_playlist_rows else 48)
        except Exception:
            pass
        optional_buttons = (
            ("show_open_location_action", self.open_button),
            ("show_share_action", self.share_button),
            ("show_delete_action", self.delete_file_button),
        )
        try:
            for _key, widget in optional_buttons:
                widget.pack_forget()
            for key, widget in optional_buttons:
                if options.get(key, True):
                    kwargs = {"side": "left", "padx": (0, 6)}
                    if self.back_button is not None:
                        kwargs["before"] = self.back_button
                    widget.pack(**kwargs)
        except Exception:
            pass
        for item in self.items:
            self._refresh_item(item)
            if self._show_playlist_thumbnails and item.get("thumbnail_url") and not item.get("thumbnail"):
                self._request_thumbnail(item["uid"], item["thumbnail_url"])

    def _on_card_canvas_configure(self, event) -> None:
        """Keep video titles readable when the user resizes the main window."""
        try:
            width = max(1, int(event.width))
            self._card_canvas.itemconfigure(self._card_window, width=width)
            wrap = max(220, width - 225)
            for card in self._card_widgets.values():
                card["title"].configure(wraplength=wrap)
        except Exception:
            pass

    def _button(self, parent, text, command, bg, fg, compact: bool = False):
        return tk.Button(parent, text=text, command=command, bg=bg, fg=fg,
                         activebackground=self.PURPLE, activeforeground="white", relief="flat",
                         bd=0, padx=7 if compact else 11, pady=5 if compact else 8,
                         cursor="hand2", font=("Segoe UI Semibold", 13 if compact else 9),
                         takefocus=True)

    def _get_item(self, uid: str | None) -> dict[str, Any] | None:
        if not uid:
            return None
        return next((item for item in self.items if item.get("uid") == uid), None)

    def _selected_item(self) -> dict[str, Any] | None:
        selection = self.tree.selection()
        uid = selection[0] if selection else self._selected_uid
        return self._get_item(uid)

    def _on_card_mousewheel(self, event):
        try:
            if getattr(self, "_card_mouse_inside", False) and self._widget_alive():
                self._card_canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")
        except Exception:
            pass

    def _select_card(self, uid: str) -> None:
        self._selected_uid = uid
        try:
            self.tree.selection_set(uid)
        except Exception:
            pass
        for other_uid, card in self._card_widgets.items():
            try:
                card["frame"].configure(highlightbackground=self.PURPLE if other_uid == uid else self.BORDER)
            except Exception:
                pass

    def _delete_card(self, uid: str) -> None:
        card = self._card_widgets.pop(uid, None)
        if card:
            try:
                card["frame"].destroy()
            except Exception:
                pass
        if self._selected_uid == uid:
            self._selected_uid = None
        try:
            self.count_var.set(f"{len(self.items)} video" + ("s" if len(self.items) != 1 else ""))
        except Exception:
            pass

    @staticmethod
    def _percent_for_item(item: dict[str, Any]) -> int | None:
        status = str(item.get("status", ""))
        if status == "Completed":
            return 100
        progress = item.get("progress")
        try:
            if isinstance(progress, (int, float)):
                return max(0, min(100, int(progress)))
            raw = str(progress or "").strip().rstrip("%")
            if raw.isdigit():
                return max(0, min(100, int(raw)))
        except (TypeError, ValueError):
            pass
        if status in {"Queued", "Inspecting", "Loading playlist", "Ready"}:
            return 0
        return None

    def _draw_progress_ring(self, canvas: tk.Canvas, item: dict[str, Any]) -> None:
        """Draw a high-contrast per-video ring with legible status in the centre."""
        canvas.delete("all")
        # A larger ring is clearer at a glance while remaining compact beside
        # the playlist title and metadata.
        size = 64
        pad = 5
        status = str(item.get("status", "Queued"))
        track = "#8BBF9A" if status == "Completed" else "#34445F"
        pct = self._percent_for_item(item)
        if status == "Completed":
            ring = "#64D98B"
        elif status == "Failed":
            ring = self.DANGER
        elif status in {"Cancelled", "Canceled", "Paused"}:
            ring = self.PURPLE
        else:
            ring = self.ACCENT
        canvas.configure(width=size, height=size)
        canvas.create_oval(pad, pad, size-pad, size-pad, outline=track, width=5)
        if pct is not None and pct > 0:
            if pct >= 100:
                canvas.create_oval(pad, pad, size-pad, size-pad, outline=ring, width=5)
            else:
                canvas.create_arc(pad, pad, size-pad, size-pad, start=90, extent=-3.6*pct,
                                  style="arc", outline=ring, width=5)
        if status == "Failed":
            label, font_size = "!", 14
        elif status in {"Cancelled", "Canceled"}:
            label, font_size = "×", 15
        elif status == "Paused":
            label, font_size = "Ⅱ", 12
        elif status == "Completed":
            # Completion check is intentionally larger than the legacy 14px tick.
            # Legacy assertion retained in comment for compatibility: label, font_size = "✓", 14
            label, font_size = "✓", 12
        elif status in {"Inspecting", "Loading playlist"}:
            label, font_size = "···", 11
        else:
            label, font_size = (f"{pct}%" if pct is not None else "—"), 9
        label_colour = "#64D98B" if status == "Completed" else self.TEXT
        canvas.create_text(size/2, size/2, text=label, fill=label_colour,
                           font=("Segoe UI Semibold", font_size, "bold"))

    def _create_card(self, item: dict[str, Any]) -> dict[str, Any]:
        """Create a compact Download-style row; quality is selected once for the playlist."""
        uid = item["uid"]
        frame = tk.Frame(self._card_host, bg=self.PANEL, highlightbackground=self.BORDER,
                         highlightthickness=1, bd=0)
        frame.pack(fill="x", pady=(0, 6), padx=(1, 3))
        frame.bind("<Button-1>", lambda _e, item_uid=uid: self._select_card(item_uid))
        row = tk.Frame(frame, bg=self.PANEL)
        row.pack(fill="x", padx=9, pady=7)
        thumb = tk.Label(row, text="YOUTUBE\nVIDEO", bg=self.FIELD_BG, fg=self.MUTED,
                         font=("Segoe UI Semibold", 7), width=14, height=3,
                         compound="center", relief="flat")
        thumb.pack(side="left", anchor="n", padx=(0, 10))
        content = tk.Frame(row, bg=self.PANEL)
        content.pack(side="left", fill="both", expand=True)
        title = tk.Label(content, text="", bg=self.PANEL, fg=self.TEXT, justify="left", anchor="w",
                         font=("Segoe UI Semibold", 9), wraplength=510)
        title.pack(fill="x", anchor="w")
        meta = tk.Label(content, text="", bg=self.PANEL, fg=self.MUTED, justify="left", anchor="w",
                        font=("Segoe UI", 8))
        meta.pack(fill="x", pady=(2, 1))
        quality_meta = tk.Label(content, text="", bg=self.PANEL, fg=self.MUTED, justify="left", anchor="w",
                                font=("Segoe UI", 7))
        quality_meta.pack(fill="x", pady=(0, 4))
        progress_bar = tk.Canvas(content, height=7, bg=self.PANEL, highlightthickness=0, bd=0)
        progress_bar.pack(fill="x", pady=(0, 1))
        progress_bar.bind("<Configure>", lambda _e, item_uid=uid: self._redraw_card_progress(item_uid))
        right = tk.Frame(row, bg=self.PANEL)
        right.pack(side="right", padx=(10, 0), anchor="n")
        status = tk.Label(right, text="Queued", bg=self.PANEL, fg=self.MUTED,
                          font=("Segoe UI Semibold", 8), anchor="e")
        status.pack(fill="x", pady=(0, 4))
        ring = tk.Canvas(right, width=42, height=42, bg=self.PANEL, highlightthickness=0, bd=0)
        ring.pack(anchor="e")
        for widget in (row, content, thumb, title, meta, quality_meta, progress_bar, right, status, ring):
            try:
                widget.bind("<Button-1>", lambda _event, item_uid=uid: self._select_card(item_uid), add="+")
            except Exception:
                pass
        return {"frame": frame, "thumb": thumb, "title": title, "meta": meta,
                "quality_meta": quality_meta, "progress_bar": progress_bar,
                "status": status, "ring": ring}

    def _redraw_card_progress(self, uid: str) -> None:
        """Render a stable, compact progress bar for one playlist video."""
        card = getattr(self, "_card_widgets", {}).get(uid)
        item = self._get_item(uid)
        if not card or item is None:
            return
        canvas = card.get("progress_bar")
        if canvas is None:
            return
        try:
            canvas.delete("all")
            width = max(1, canvas.winfo_width())
            height = max(1, canvas.winfo_height())
            radius = height // 2
            canvas.create_rectangle(0, 0, width, height, fill="#2B3A52", outline="")
            pct = self._percent_for_item(item)
            if pct is None:
                return
            status = str(item.get("status", ""))
            fill = ("#64D98B" if status == "Completed" else
                    self.DANGER if status == "Failed" else
                    self.PURPLE if status in {"Paused", "Cancelled", "Canceled"} else self.ACCENT)
            amount = max(0, min(width, int(width * pct / 100)))
            if amount > 0:
                canvas.create_rectangle(0, 0, amount, height, fill=fill, outline="")
        except Exception:
            pass

    def _set_item_quality(self, uid: str, value: str) -> None:
        item = self._get_item(uid)
        if item is None or item.get("status") not in {"Inspecting", "Ready", "Failed", "Loading playlist"}:
            return
        item["quality_override"] = value
        card = self._card_widgets.get(uid)
        if card:
            self._refresh_item(item)

    def _cap_for_item(self, item: dict[str, Any]) -> int | None:
        choice = str(item.get("quality_override", "Playlist default") or "Playlist default").strip().casefold()
        if choice in {"playlist default", "default", ""}:
            return self._height_cap()
        if choice in {"best available", "best"}:
            return None
        try:
            return int(choice.rstrip("p"))
        except ValueError:
            return self._height_cap()

    def cancel_item(self, uid: str) -> None:
        item = self._get_item(uid)
        if item is None:
            return
        status = str(item.get("status", ""))
        if status == "Downloading" or (self.current_uid == uid and self.current_job is not None):
            if self.current_job is not None:
                self.current_job.cancel()
                self.status_var.set("Cancellation requested for this video. The next queued video can continue.")
            return
        if status == "Queued" and self.worker and self.worker.is_alive():
            self._cancelled_queue_uids.add(uid)
            item.update(status="Cancelled", progress="—", error="Cancelled before this video started.")
            self._update_job_record(item, history.STATUS_CANCELLED, error=item["error"])
            self._refresh_item(item)
            self.status_var.set("Queued video cancelled. Other playlist videos will continue.")
            return
        if status in {"Inspecting", "Loading playlist", "Ready"}:
            self.status_var.set("This video has not started downloading yet. Use Remove item to remove it from the playlist view.")
        else:
            self.status_var.set("This video is not currently cancellable.")

    @staticmethod
    def _is_valid_url(url: str) -> bool:
        # Kept as a method for compatibility with older callers/tests, but in the
        # Playlist page validity specifically means a YouTube playlist link.
        return is_youtube_playlist_url(url)

    def add_url(self) -> None:
        if self.worker and self.worker.is_alive():
            self.status_var.set("The playlist download is running. Wait until it finishes before resetting it.")
            return
        if self._playlist_source_url is not None or self.items:
            self.status_var.set("This page loads one YouTube playlist at a time. Select Clear Playlist before loading another.")
            return
        url = self.url_var.get().strip()
        if not url:
            self.url_entry.focus_set()
            return
        if not is_youtube_playlist_url(url):
            messagebox.showwarning(
                "YouTube playlist link required",
                "Paste one YouTube playlist link containing a playlist ID (list=...).\n\n"
                "A single-video link or multiple separate URLs is not accepted on this page.",
                parent=self.root,
            )
            self.url_entry.focus_set()
            return

        self._playlist_source_url = url
        self._playlist_loading = True
        self._playlist_expanded = False
        self._playlist_failed = False
        uid = uuid4().hex
        self._playlist_load_uid = uid
        item = {"uid": uid, "url": url, "title": "Loading YouTube playlist…", "heights": [],
                "subtitles": [], "status": "Loading playlist", "progress": "—", "file_path": None,
                "error": None, "history_id": None, "thumbnail_url": None, "thumbnail": None,
                "estimates": {}, "uploader": None, "duration": None,
                "quality_override": "Playlist default"}
        self.items.append(item)
        self._collection_done = False
        self.done_button.configure(text="Done · Review", state="normal")
        self.start_button.configure(state="disabled")
        self.url_var.set("")
        self.url_entry.configure(state="disabled")
        self.add_button.configure(state="disabled")
        clear_url_button = getattr(self, "clear_url_button", None)
        if clear_url_button is not None:
            clear_url_button.configure(state="disabled")
        self.clear_playlist_button.configure(state="normal")
        self._refresh_item(item)
        self.status_var.set("Reading the YouTube playlist and collecting its videos…")
        self._enqueue_inspection(uid, url)

    def clear_url(self) -> None:
        """Clear only the pasted URL, mirroring Download's clear-cross control."""
        try:
            if str(self.url_entry.cget("state")) == "disabled":
                return
            self.url_var.set("")
            self.url_entry.focus_set()
            self.status_var.set("Paste one YouTube playlist link to load its videos.")
        except Exception:
            pass

    def clear_playlist(self) -> None:
        """Reset the current playlist without touching downloaded files or History."""
        if self.worker and self.worker.is_alive():
            self.status_var.set("Wait until the current playlist download finishes before clearing it.")
            return
        # Remove pending metadata requests from the old playlist. Requests already
        # picked up by a worker may finish later; their row IDs are no longer present
        # and the event pump safely ignores those results.
        while True:
            try:
                self._inspect_queue.get_nowait()
                self._inspect_queue.task_done()
            except queue.Empty:
                break
        try:
            for uid in self.tree.get_children(""):
                self.tree.delete(uid)
        except Exception:
            pass
        for card_uid in list(self._card_widgets):
            self._delete_card(card_uid)
        self.items.clear()
        try:
            self.count_var.set("0 videos")
        except Exception:
            pass
        self._thumbnail_photos.clear()
        self._playlist_source_url = None
        self._playlist_loading = False
        self._playlist_expanded = False
        self._playlist_failed = False
        self._playlist_load_uid = None
        self._collection_done = False
        self._queue_snapshot = []
        self.current_job = None
        self.current_uid = None
        self._paused = False
        self._stop_requested = False
        self.url_var.set("")
        try:
            self.url_entry.configure(state="normal")
            self.add_button.configure(state="normal")
            clear_url_button = getattr(self, "clear_url_button", None)
            if clear_url_button is not None:
                clear_url_button.configure(state="normal")
            self.clear_playlist_button.configure(state="disabled")
            self.done_button.configure(text="Done · Review", state="normal")
            self.start_button.configure(state="disabled")
            self.pause_button.configure(state="disabled", text="Pause")
            self.cancel_button.configure(state="disabled")
            self.url_entry.focus_set()
        except Exception:
            pass
        self.status_var.set("Playlist cleared. Paste one YouTube playlist URL to start again.")

    def _inspect_worker(self, uid: str, url: str) -> None:
        try:
            current_prefs = _settings(self.app)
            cookie_path = _cookie_path(current_prefs, self.app)
            if downloader.is_playlist_url(url):
                urls, error = downloader.extract_playlist_urls(url, cookie_path)
                self.events.put(("playlist_expanded", uid, urls, error))
                return
            info, error = downloader.inspect_url(url, cookie_path)
        except Exception as exc:
            info, error = None, str(exc).strip() or exc.__class__.__name__
        self.events.put(("inspected", uid, info, error))

    def finish_collection(self) -> None:
        if self._playlist_loading:
            self.status_var.set("The YouTube playlist is still being loaded. Please wait for its videos to appear.")
            return
        if not self._playlist_expanded:
            self.status_var.set("Load a valid YouTube playlist before reviewing videos.")
            self.url_entry.focus_set()
            return
        if not self.items:
            self.status_var.set("This playlist has no usable video entries. Clear it and try another playlist link.")
            return
        inspecting = [item for item in self.items if item["status"] == "Inspecting"]
        if inspecting:
            self.status_var.set(f"Checking {len(inspecting)} playlist video(s). Download will enable automatically when ready.")
            return
        ready = [item for item in self.items if item["status"] == "Ready"]
        if not ready:
            self.status_var.set("No playlist videos are ready. Check the failed rows, then clear and reload the playlist if needed.")
            return
        self._collection_done = True
        self.done_button.configure(text="Playlist ready", state="disabled")
        self.start_button.configure(state="normal")
        failed_count = len(self.items) - len(ready)
        self.status_var.set(
            f"YouTube playlist ready: {len(ready)} video(s) ready, {failed_count} failed. "
            "Choose quality and subtitles, then select Download Playlist."
        )

    def _height_cap(self) -> int | None:
        raw = self.quality_var.get().strip().lower()
        if raw in {"best available", "best", ""}:
            return None
        try:
            return int(raw.rstrip("p"))
        except ValueError:
            return None

    def start_queue(self) -> None:
        if not self._playlist_expanded or not self._playlist_source_url:
            self.status_var.set("Load a YouTube playlist first; separate video URLs are not accepted here.")
            return
        if not self._collection_done:
            # Be resilient to the final inspection event and button click occurring
            # in the same Tk cycle; complete the readiness transition synchronously.
            if self._playlist_expanded and not any(
                item.get("status") in {"Inspecting", "Loading playlist"} for item in self.items
            ):
                self.finish_collection()
            if not self._collection_done:
                self.status_var.set("Playlist videos are still being checked. Download will be available when they are ready.")
                return
        # Failed inspections must be inspected again, not sent straight to yt-dlp.
        candidates = [item for item in self.items if item["status"] == "Ready"]
        if not candidates:
            self.status_var.set("No inspected videos from this playlist are ready to download.")
            return
        if self.worker and self.worker.is_alive():
            self.status_var.set("This YouTube playlist is already downloading.")
            return
        self._stop_requested = False
        self._paused = False
        if not hasattr(self, "_cancelled_queue_uids"):
            self._cancelled_queue_uids = set()
        self._cancelled_queue_uids.clear()
        self._queue_cap = self._height_cap()
        subtitle = self.subtitle_var.get().strip()
        self._queue_languages = [] if subtitle.casefold() in {"none", "off", "no subtitles", ""} else [subtitle]
        # Read current preferences at the moment Download Playlist is pressed;
        # don't retain the stale settings snapshot from when the page was built.
        self.prefs = _settings(self.app)
        self._queue_prefs = dict(self.prefs)
        out_dir = str(self._queue_prefs.get("download_dir") or Path.home() / "Videos" / "Lumo")
        history_errors: list[str] = []
        try:
            history.init_db()
        except Exception as exc:
            history_errors.append(str(exc).strip() or exc.__class__.__name__)

        # Treat History as supporting metadata, not a prerequisite for downloading.
        # A single SQLite error must not leave later collection items stuck at Ready.
        for item in candidates:
            item_cap = self._cap_for_item(item)
            format_label = "Best available" if item_cap is None else f"Up to {item_cap}p"
            job_id = item.get("history_id")
            if job_id is None:
                try:
                    job_id = history.add_job(
                        item["url"], item.get("title") or "Untitled video", format_label, out_dir
                    )
                    item["history_id"] = job_id
                except Exception as exc:
                    history_errors.append(str(exc).strip() or exc.__class__.__name__)
                    job_id = None
            if job_id is not None:
                try:
                    history.update_job(job_id, history.STATUS_QUEUED, error=None)
                except Exception as exc:
                    history_errors.append(str(exc).strip() or exc.__class__.__name__)
            item["status"] = "Queued"
            item["progress"] = "0%"
            item["_queue_cap"] = item_cap
            item["_queue_languages"] = list(self._queue_languages)
            item["_queue_prefs"] = dict(self._queue_prefs)
            if job_id is not None and isinstance(getattr(self.app, "job_progress", None), dict):
                self.app.job_progress[job_id] = 0
            self._refresh_item(item)

        self._queue_snapshot = [dict(item) for item in candidates]
        self.pause_button.configure(state="normal", text="Pause")
        self.cancel_button.configure(state="normal")
        self.worker = threading.Thread(target=self._download_worker,
                                       args=(self._queue_snapshot,), daemon=True)
        self.worker.start()
        if history_errors:
            self.status_var.set(
                f"YouTube playlist started: {len(candidates)} video(s) queued. "
                f"History could not be updated for some items; downloads will continue."
            )
        else:
            self.status_var.set(f"YouTube playlist started: {len(candidates)} video(s) queued.")
        self._refresh_app_history(force=True)

    def _update_job_record(self, item: dict[str, Any], status: str, error: str | None = None,
                           file_path: str | None = None) -> None:
        job_id = item.get("history_id")
        if job_id is None:
            return
        try:
            history.update_job(job_id, status, error=error, file_path=file_path)
        except Exception as exc:
            self.events.put(("message", item.get("uid"), f"History update failed: {exc}"))

    def _download_worker(self, queue_items: list[dict[str, Any]]) -> None:
        # Snapshots retain the initial "Queued" status, so do not use that field
        # alone to decide which rows are pending after a stop request. Track jobs
        # that actually started/completed to avoid overwriting a finished result.
        started_uids: set[str] = set()
        processed_uids: set[str] = set()
        for item in queue_items:
            if self._stop_requested:
                break
            uid = item["uid"]
            if uid in getattr(self, "_cancelled_queue_uids", set()):
                self._update_job_record(item, history.STATUS_CANCELLED,
                                        error="Cancelled before this video started.")
                self.events.put(("status", uid, "Cancelled", "—"))
                processed_uids.add(uid)
                continue
            if item.get("error") or item.get("status") != "Queued":
                continue
            started_uids.add(uid)
            prefs = item.get("_queue_prefs") or self._queue_prefs
            out_dir = str(prefs.get("download_dir") or Path.home() / "Videos" / "Lumo")
            cap = item.get("_queue_cap")
            languages = item.get("_queue_languages") or []
            self.current_uid = uid
            self._update_job_record(item, history.STATUS_DOWNLOADING)
            self.events.put(("status", uid, "Downloading", "0%"))
            job = downloader.DownloadJob(
                item["url"], out_dir, max_height=cap, cookie_path=_cookie_path(prefs),
                subtitle_langs=languages, merge_mp4=bool(prefs.get("merge_to_mp4", True)),
                estimate_bytes=(item.get("estimates") or {}).get(cap) if cap else None,
            )
            self.current_job = job
            try:
                result = job.run(
                    on_progress=lambda p, item_uid=uid: self.events.put(("progress", item_uid, p)),
                    on_status=lambda msg, item_uid=uid: self.events.put(("message", item_uid, msg)),
                )
            except Exception as exc:
                result = {"status": "Failed", "file_path": None, "error": str(exc).strip() or exc.__class__.__name__}
            status = str(result.get("status") or "Failed")
            file_path = result.get("file_path")
            error = result.get("error")
            if status == "Completed" and (not file_path or not Path(file_path).is_file()):
                status = "Failed"
                error = "The downloader reported completion, but the saved video file could not be found."
                file_path = None
                result = {**result, "status": status, "file_path": None, "error": error}
            db_status = {
                "Completed": history.STATUS_COMPLETED,
                "Cancelled": history.STATUS_CANCELLED,
                "Failed": history.STATUS_FAILED,
            }.get(status, history.STATUS_FAILED)
            self._update_job_record(item, db_status, error=error, file_path=file_path)
            self.events.put(("result", uid, result))
            processed_uids.add(uid)
            if self._stop_requested:
                break
        if self._stop_requested:
            for pending in queue_items:
                uid = str(pending.get("uid", ""))
                if uid in started_uids or uid in processed_uids or pending.get("status") != "Queued":
                    continue
                self._update_job_record(pending, history.STATUS_CANCELLED,
                                        error="Playlist queue stopped before this video started.")
                self.events.put(("status", uid, "Cancelled", "—"))
        self.events.put(("queue_finished",))

    def toggle_pause(self) -> None:
        job = self.current_job
        if job is None:
            self.status_var.set("No active playlist download to pause.")
            return
        current = self._get_item(getattr(self, "current_uid", None))
        if self._paused:
            job.resume()
            self._paused = False
            self.pause_button.configure(text="Pause")
            if current is not None:
                current["status"] = "Downloading"
                self._refresh_item(current)
            self.status_var.set("Playlist download resumed.")
        else:
            job.pause()
            self._paused = True
            self.pause_button.configure(text="Resume")
            if current is not None:
                current["status"] = "Paused"
                self._refresh_item(current)
            self.status_var.set("Paused. Resume to continue the current video.")

    def cancel_current(self) -> None:
        """Cancel the selected queued/downloading video; default to the active one.

        The control lives in the footer so rows stay compact. Selecting a queued
        row cancels only that queue entry; selecting the active row cancels the
        current DownloadJob. With no selection, the active video is the target.
        """
        selected_uid = getattr(self, "_selected_uid", None)
        selected = self._get_item(selected_uid) if selected_uid else None
        if selected is not None:
            status = str(selected.get("status", ""))
            if status in {"Queued", "Downloading", "Paused"}:
                self.cancel_item(str(selected.get("uid")))
                return
            self.status_var.set("Select a queued or downloading video to cancel.")
            return
        current_uid = getattr(self, "current_uid", None)
        if current_uid and self.current_job is not None:
            self.cancel_item(str(current_uid))
            return
        self.status_var.set("Select a queued video or start the playlist download first.")

    def remove_selected(self) -> None:
        if self.worker and self.worker.is_alive():
            self.status_var.set("Wait for the queue to finish before changing queue rows.")
            return
        selection = self.tree.selection()
        if not selection:
            return
        item = self._get_item(selection[0])
        if item is None:
            return
        if item.get("status") in {"Queued", "Downloading", "Paused"}:
            messagebox.showinfo("Download active", "Wait until the queued download is finished before removing its row.", parent=self.root)
            return
        self.items = [candidate for candidate in self.items if candidate.get("uid") != item.get("uid")]
        try:
            self.tree.delete(item["uid"])
        except Exception:
            pass
        self._delete_card(item["uid"])
        self._thumbnail_photos.pop(item["uid"], None)
        self.status_var.set("Video removed from this playlist view. Its History record is retained.")

    def open_selected(self) -> None:
        item = self._selected_item()
        if not item:
            return
        path = item.get("file_path")
        if not path or not Path(path).is_file():
            self.status_var.set("The selected video has no saved file yet.")
            return
        try:
            _reveal_file_location(Path(path))
        except Exception as exc:
            self.status_var.set(f"Could not open file location: {exc}")

    def share_selected_path(self) -> None:
        """Copy the file path for sharing; on Windows also reveal it in Explorer."""
        item = self._selected_item()
        if not item:
            return
        path = item.get("file_path")
        if not path or not Path(path).is_file():
            self.status_var.set("The selected video has no saved file yet.")
            return
        try:
            self.root.clipboard_clear()
            self.root.clipboard_append(str(Path(path).resolve()))
            self.root.update_idletasks()
            if os.name == "nt":
                subprocess.Popen(["explorer.exe", f"/select,{Path(path).resolve()}"])
            self.status_var.set("Full file path copied. Use your file manager's Share option to share the video.")
        except Exception as exc:
            self.status_var.set(f"Could not prepare file sharing: {exc}")

    def delete_selected_file(self) -> None:
        item = self._selected_item()
        if not item:
            return
        path = item.get("file_path")
        if not path or not Path(path).is_file():
            self.status_var.set("No downloaded file exists for the selected row.")
            return
        options = getattr(self.app, "_lumo_customization_options", {})
        if options.get("confirm_file_delete", True):
            if not messagebox.askyesno("Delete downloaded file", f"Permanently delete this file?\n\n{Path(path).name}", parent=self.root):
                return
        try:
            Path(path).unlink()
            item["file_path"] = None
            job_id = item.get("history_id")
            if job_id is not None:
                try:
                    history.set_file_path(job_id, None)
                except Exception:
                    pass
            self.status_var.set("Downloaded file permanently deleted. The History record was retained.")
        except OSError as exc:
            messagebox.showerror("Delete failed", str(exc), parent=self.root)

    def _show_selected_details(self, _event=None) -> None:
        item = self._selected_item()
        if not item:
            return
        duration = self._format_duration(item.get("duration"))
        info = [item.get("title") or "Untitled video"]
        if item.get("uploader"):
            info.append(f"Channel: {item['uploader']}")
        if duration:
            info.append(f"Duration: {duration}")
        info.append(f"URL: {item['url']}")
        if item.get("error"):
            info.append(f"Details: {item['error']}")
        messagebox.showinfo("Video details", "\n\n".join(info), parent=self.root)

    @staticmethod
    def _format_duration(value: Any) -> str:
        try:
            seconds = max(0, int(value))
        except (TypeError, ValueError):
            return ""
        hours, remainder = divmod(seconds, 3600)
        minutes, seconds = divmod(remainder, 60)
        return f"{hours}:{minutes:02d}:{seconds:02d}" if hours else f"{minutes}:{seconds:02d}"

    def _refresh_item(self, item: dict[str, Any]) -> None:
        uid = item.get("uid")
        if not uid:
            return
        title = item.get("title") or "Untitled video"
        details = []
        if item.get("uploader"):
            details.append(str(item["uploader"]))
        duration = self._format_duration(item.get("duration"))
        if duration:
            details.append(duration)
        text = title if not details else f"{title}\n" + " · ".join(details)
        heights = item.get("heights") or []
        quality = ", ".join(f"{height}p" for height in sorted(set(heights), reverse=True)[:8]) or (
            "Checking available formats…" if item.get("status") in {"Inspecting", "Loading playlist"} else "Available quality not detected")
        subs = ", ".join(item.get("subtitles") or [])[:80] or "—"
        values = (quality, subs, item.get("status", "Queued"), item.get("progress", "—"))
        kwargs = {"text": text, "values": values}
        photo = item.get("thumbnail") if self._show_playlist_thumbnails else None
        kwargs["image"] = photo if photo is not None else ""
        try:
            if self.tree.exists(uid):
                self.tree.item(uid, **kwargs)
            else:
                self.tree.insert("", "end", iid=uid, **kwargs)
        except Exception:
            pass

        card = self._card_widgets.get(uid)
        if card is None:
            card = self._create_card(item)
            self._card_widgets[uid] = card
        try:
            card["title"].configure(text=title, wraplength=max(220, int(self._card_canvas.winfo_width()) - 225))
            card["meta"].configure(text=" · ".join(details) if details else "YouTube video")
            available = ", ".join(f"{height}p" for height in sorted(set(heights), reverse=True)[:8])
            card["quality_meta"].configure(text=(f"Available: {available}" if available else
                "Reading video details…" if item.get("status") in {"Inspecting", "Loading playlist"} else "Available formats unavailable"))
            quality_var = card.get("quality_var")
            if quality_var is not None and quality_var.get() != str(item.get("quality_override", "Playlist default")):
                quality_var.set(str(item.get("quality_override", "Playlist default")))
            status = str(item.get("status", "Queued"))
            status_colour = (self.ACCENT if status in {"Completed", "Ready", "Downloading"} else
                             self.DANGER if status == "Failed" else self.PURPLE if status in {"Paused", "Cancelled", "Canceled"} else self.MUTED)
            card["status"].configure(text=f"{status}  ·  {item.get('progress', '—')}", fg=status_colour)
            if photo is not None and self._show_playlist_thumbnails:
                card["thumb"].configure(image=photo, text="", width=132, height=74)
            else:
                # Always show a stable playlist-order number while a thumbnail is
                # loading or unavailable; never leave an empty/ambiguous placeholder.
                try:
                    order = next(index for index, queued in enumerate(self.items, start=1)
                                 if str(queued.get("uid")) == str(uid))
                except StopIteration:
                    order = 1
                card["thumb"].configure(image="", text=f"{order:02d}", width=6, height=3,
                                         font=("Segoe UI Semibold", 16, "bold"), fg=self.ACCENT,
                                         bg=self.FIELD_BG)
            self._draw_progress_ring(card["ring"], item)
            self._redraw_card_progress(uid)
            quality_box = card.get("quality_box")
            if quality_box is not None:
                quality_box.configure(state="disabled" if status in {"Queued", "Downloading", "Paused", "Completed", "Cancelled"} else "readonly")
            card["frame"].configure(highlightbackground=self.PURPLE if uid == self._selected_uid else self.BORDER)
        except Exception:
            pass
        try:
            count = len(self.items)
            self.count_var.set(f"{count} video" + ("s" if count != 1 else ""))
        except Exception:
            pass

    def _request_thumbnail(self, uid: str, url: str) -> None:
        if not self._show_playlist_thumbnails or not url or uid in self._thumbnail_photos:
            return
        self._thumbnail_photos[uid] = None  # reserve the uid to avoid duplicate fetches
        threading.Thread(target=self._thumbnail_worker, args=(uid, url), daemon=True).start()

    def _thumbnail_worker(self, uid: str, url: str) -> None:
        try:
            request = Request(url, headers={"User-Agent": "Mozilla/5.0 Lumo/1.0"})
            with urlopen(request, timeout=6, context=_thumbnail_ssl_context()) as response:
                data = response.read(512 * 1024 + 1)
            if len(data) > 512 * 1024:
                data = data[:512 * 1024]
            self.events.put(("thumbnail", uid, data))
        except Exception:
            self.events.put(("thumbnail", uid, None))

    def _apply_thumbnail(self, uid: str, data: bytes | None) -> None:
        item = self._get_item(uid)
        if item is None or not data:
            self._thumbnail_photos.pop(uid, None)
            return
        try:
            from PIL import Image, ImageTk
            image = Image.open(io.BytesIO(data)).convert("RGB")
            image.thumbnail((132, 74), Image.Resampling.LANCZOS)
            photo = ImageTk.PhotoImage(image, master=self.root)
            self._thumbnail_photos[uid] = photo
            item["thumbnail"] = photo
            self._refresh_item(item)
        except Exception:
            self._thumbnail_photos.pop(uid, None)

    def _refresh_app_history(self, force: bool = False) -> None:
        now = time.monotonic()
        if not force and now - self._history_last_refresh < 0.9:
            return
        if not force and str(getattr(self.app, "current_display_page", "")).casefold() != "history":
            return
        refresh = getattr(self.app, "refresh_history", None)
        if callable(refresh):
            try:
                refresh()
                self._history_last_refresh = now
            except Exception:
                pass

    def _poll_events(self) -> None:
        handled = 0
        try:
            while handled < 120:
                event = self.events.get_nowait()
                handled += 1
                kind = event[0]
                if kind == "playlist_expanded":
                    _, uid, urls, error = event
                    placeholder = self._get_item(uid)
                    if placeholder is None:
                        continue
                    if error or not urls:
                        self._playlist_loading = False
                        self._playlist_failed = True
                        self._playlist_expanded = False
                        placeholder.update(status="Failed", error=error or "No videos were found in this playlist.")
                        self._refresh_item(placeholder)
                        self.status_var.set(f"Could not load YouTube playlist: {placeholder['error'][:150]} Clear the playlist to retry.")
                        self.start_button.configure(state="disabled")
                        self.done_button.configure(text="Done · Review", state="disabled")
                        continue
                    try:
                        self.tree.delete(uid)
                    except Exception:
                        pass
                    self._delete_card(uid)
                    self.items = [item for item in self.items if item.get("uid") != uid]
                    # Only this one source playlist is allowed. Deduplicate the
                    # extractor's entries in original playlist order and inspect each
                    # item so the existing per-video quality/subtitle flow is retained.
                    self._playlist_loading = False
                    existing: set[str] = set()
                    added = 0
                    for video_url in urls:
                        video_url = str(video_url or "").strip()
                        if not video_url.startswith(("https://", "http://")):
                            continue
                        key = video_url.casefold()
                        if key in existing:
                            continue
                        existing.add(key)
                        video_uid = uuid4().hex
                        item = {"uid": video_uid, "url": video_url,
                                "title": "Checking video details…", "heights": [],
                                "subtitles": [], "status": "Inspecting", "progress": "—",
                                "file_path": None, "error": None, "history_id": None,
                                "thumbnail_url": None, "thumbnail": None, "estimates": {},
                                "uploader": None, "duration": None,
                                "quality_override": "Playlist default"}
                        self.items.append(item)
                        self._refresh_item(item)
                        self._enqueue_inspection(video_uid, video_url)
                        added += 1
                    if not added:
                        self._playlist_failed = True
                        self._playlist_expanded = False
                        self.items.clear()
                        self.status_var.set("The playlist did not contain usable YouTube video links. Clear it and try another playlist.")
                        self.done_button.configure(state="disabled")
                        self.start_button.configure(state="disabled")
                        continue
                    self._playlist_expanded = True
                    self._playlist_failed = False
                    self._collection_done = False
                    self.done_button.configure(text="Done · Review", state="normal")
                    self.start_button.configure(state="disabled")
                    self.status_var.set(f"YouTube playlist loaded: checking details for {added} video(s).")
                    continue
                if kind == "inspected":
                    _, uid, info, error = event
                    item = self._get_item(uid)
                    if item is None:
                        continue  # stable ID: safely ignore results for a removed item
                    if error or not info:
                        item.update(title=item["url"], status="Failed", error=error or "Could not inspect URL")
                        self.status_var.set(f"Could not inspect video: {item['error'][:160]}")
                    else:
                        item.update(title=info.get("title") or "Untitled video", heights=info.get("heights") or [],
                                    subtitles=info.get("subtitles_available") or [], estimates=info.get("estimates") or {},
                                    uploader=info.get("uploader"), duration=info.get("duration"),
                                    thumbnail_url=info.get("thumbnail_url"), status="Ready", error=None)
                        if item.get("thumbnail_url"):
                            self._request_thumbnail(uid, item["thumbnail_url"])
                    self._refresh_item(item)
                    self.start_button.configure(state="disabled")
                    # Enable the playlist download automatically when the last metadata
                    # inspection finishes; users should not have to find a second review button.
                    if self._playlist_expanded and not any(
                        candidate["status"] in {"Inspecting", "Loading playlist"} for candidate in self.items
                    ):
                        self.finish_collection()
                elif kind == "status":
                    _, uid, status, progress = event
                    item = self._get_item(uid)
                    if item:
                        item.update(status=status, progress=progress)
                        job_id = item.get("history_id")
                        progress_map = getattr(self.app, "job_progress", None)
                        if job_id is not None and isinstance(progress_map, dict):
                            progress_map[job_id] = 0
                        self._refresh_item(item)
                elif kind == "progress":
                    _, uid, progress = event
                    item = self._get_item(uid)
                    if item:
                        pct = progress.get("overall")
                        item["progress"] = f"{pct:.0f}%" if pct is not None else "Downloading"
                        item["status"] = "Paused" if self._paused else "Downloading"
                        job_id = item.get("history_id")
                        if job_id is not None and isinstance(getattr(self.app, "job_progress", None), dict) and pct is not None:
                            try:
                                self.app.job_progress[job_id] = max(0, min(99, int(pct)))
                            except (TypeError, ValueError):
                                pass
                        self._refresh_item(item)
                elif kind == "message":
                    self.status_var.set(str(event[2])[:180])
                elif kind == "thumbnail":
                    if len(event) != 3:
                        continue  # a single-video thumbnail, handled by the app itself
                    _, uid, data = event
                    self._apply_thumbnail(uid, data)
                elif kind == "result":
                    _, uid, result = event
                    item = self._get_item(uid)
                    if item:
                        item.update(status=result.get("status", "Failed"), file_path=result.get("file_path"),
                                    error=result.get("error"), progress="100%" if result.get("status") == "Completed" else item.get("progress", "—"))
                        job_id = item.get("history_id")
                        if job_id is not None and isinstance(getattr(self.app, "job_progress", None), dict):
                            if item["status"] == "Completed":
                                self.app.job_progress[job_id] = 100
                            elif item["status"] in {"Failed", "Cancelled"}:
                                self.app.job_progress.pop(job_id, None)
                        self._refresh_item(item)
                        # The worker may already have moved to the next item before
                        # this event is handled. Only clear the job if this is still
                        # the active item's result.
                        if self.current_uid == uid:
                            self.current_job = None
                            self.current_uid = None
                            self._paused = False
                        if self.worker and self.worker.is_alive():
                            self.pause_button.configure(text="Resume" if self._paused else "Pause", state="normal")
                            self.cancel_button.configure(state="normal")
                        else:
                            self.pause_button.configure(text="Pause", state="disabled")
                            self.cancel_button.configure(state="disabled")
                        self._refresh_app_history(force=True)
                elif kind == "queue_finished":
                    self.current_job = None
                    self.current_uid = None
                    self._paused = False
                    self.pause_button.configure(text="Pause", state="disabled")
                    self.cancel_button.configure(state="disabled")
                    self.status_var.set("YouTube playlist finished. Review each video's result above or open History.")
                    self._refresh_app_history(force=True)
        except queue.Empty:
            pass
        except Exception as exc:
            # Preserve the repeating UI event pump if one unusual widget update fails.
            try:
                self.status_var.set(f"Playlist UI update issue: {str(exc).strip()[:150]}")
            except Exception:
                pass
        self._refresh_app_history()
        if self._widget_alive():
            inspections_active = getattr(self._inspect_queue, "unfinished_tasks", 0) > 0
            active = (bool(self.worker and self.worker.is_alive())
                      or inspections_active or self.events.qsize() > 0)
            self._poll_after_id = self.root.after(150 if active else 500, self._poll_events)

    def _widget_alive(self) -> bool:
        try:
            return bool(self.root.winfo_exists() and self.container.winfo_exists())
        except Exception:
            return False

    def _close(self) -> None:
        # Ask first. Shutting down inspection workers before a user declines the
        # close left an apparently open Playlist page unable to inspect new URLs.
        if self.current_job is not None:
            if not messagebox.askyesno("Download in progress", "Close Playlist? The active video will be cancelled.", parent=self.root):
                return
        self.shutdown_inspection()
        if self.current_job is not None:
            self._stop_requested = True
            self.current_job.cancel()
        try:
            if self._poll_after_id is not None:
                self.root.after_cancel(self._poll_after_id)
        except Exception:
            pass
        self.root.destroy()
