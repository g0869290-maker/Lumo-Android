"""In-memory patcher for the recovered Lumo UI bytecode.

Used by main.py at startup, so the app always runs the Lumo names from
main_original.pyc and can never load a stale patched copy.
"""
from __future__ import annotations

import importlib.util
import marshal
import re
import sys
from pathlib import Path
from types import CodeType


REPLACEMENTS = {
    "YTD": ("Lumo", "brand_label"),
    "YTD Windows": ("Lumo", "brand_name"),

    "ytd_windows": ("lumo_windows", "package_root"),
    "ytd_windows.downloader": (
        "lumo_windows.downloader", "package_downloader"
    ),
    "ytd_windows.settings": (
        "lumo_windows.settings", "package_settings"
    ),

    "Explain when YTD saved a lower height than the one the user chose.": (
        "Explain when Lumo saved a lower height than the one the user chose.",
        "quality_help",
    ),
    "Choose the language YTD preselects when it is available. Each video can still use a different choice.": (
        "Choose the language Lumo preselects when it is available. Each video can still use a different choice.",
        "subtitle_help",
    ),
    "Paste a link and let YTD inspect it.": (
        "Paste a link and let Lumo inspect it.",
        "download_hint",
    ),
    "YTD Windows needs the Pillow package.\n\nInstall it once with:\n    pip install pillow": (
        "Lumo needs the Pillow package.\n\nInstall it once with:\n    pip install pillow",
        "pillow_error",
    ),
    "Dark or Light mode for the whole app. Applies when you save.": (
        "Dark mode only. Changes apply when you save.",
        "mode_description",
    ),
    "Dark uses a near-black background. Light uses an off-white background.": (
        "Dark mode uses a near-black background.",
        "mode_help",
    ),
}

# These are confirmed phrases embedded in longer recovered messages.
EMBEDDED_REPLACEMENTS = (
    (
        "YTD Windows could not find its ytd_windows folder.",
        "Lumo could not find its lumo_windows package.",
        "package_error_title",
    ),
    (
        "Copy the ytd_windows folder next to main.pyw and start the app again.",
        "Ensure the lumo_windows package is next to the Lumo launcher and start the app again.",
        "package_error_help",
    ),
    (
        "YTD Windows could not start.",
        "Lumo could not start.",
        "startup_error",
    ),
    (
        "Mozilla/5.0 YTD Windows",
        "Mozilla/5.0 Lumo",
        "user_agent",
    ),
    (
        "YTD Windows - video downloader GUI",
        "Lumo - video downloader GUI",
        "module_doc",
    ),
)


def generic_rename(value: str) -> str:
    """Catch-all rename for brand text and internal names in the recovered UI."""
    value = value.replace("YTD Windows", "Lumo")
    value = re.sub(r"\bYTD\b", "Lumo", value)
    value = value.replace("ytd_windows", "lumo_windows")
    value = value.replace("Vidzy", "Lumo").replace("VidZy", "Lumo").replace("vidzy", "lumo")
    value = value.replace("_ytd_", "_lumo_").replace("_YTD_", "_LUMO_")
    value = value.replace("_YTDLogger", "_LumoLogger")
    return value


def replace_text(value: str, stats: dict[str, int]) -> str:
    replacement = REPLACEMENTS.get(value)

    if replacement is not None:
        new_value, label = replacement
        stats[label] += 1
        return new_value

    for old, new, label in EMBEDDED_REPLACEMENTS:
        count = value.count(old)

        if count:
            value = value.replace(old, new)
            stats[label] += count

    # Handle deeper package paths such as ytd_windows.submodule.
    if value.startswith("ytd_windows."):
        stats["package_root"] += 1
        value = "lumo_windows" + value[len("ytd_windows"):]

    return generic_rename(value)


def patch_constant(
    value: object,
    stats: dict[str, int],
    is_poll_events: bool,
) -> object:

    if isinstance(value, CodeType):
        return patch_code(value, stats)

    if isinstance(value, str):
        return replace_text(value, stats)

    if isinstance(value, tuple):
        return tuple(
            patch_constant(item, stats, is_poll_events)
            for item in value
        )

    if isinstance(value, frozenset):
        return frozenset(
            patch_constant(item, stats, is_poll_events)
            for item in value
        )

    if is_poll_events and type(value) is int and value == 120:
        stats["poll"] += 1
        return 160

    return value


def patch_code(code: CodeType, stats: dict[str, int]) -> CodeType:
    is_poll_events = (
        getattr(code, "co_qualname", "").endswith("App.poll_events")
    )

    constants = tuple(
        patch_constant(value, stats, is_poll_events)
        for value in code.co_consts
    )

    names = tuple(
        replace_text(name, stats) if isinstance(name, str) else name
        for name in code.co_names
    )

    return code.replace(
        co_consts=constants,
        co_names=names,
    )


def collect_import_names(
    code: CodeType,
    found: set[str],
    obsolete: set[str],
) -> None:

    expected = {
        "lumo_windows",
        "lumo_windows.downloader",
        "lumo_windows.settings",
    }

    old_names = {
        "ytd_windows",
        "ytd_windows.downloader",
        "ytd_windows.settings",
    }

    for name in code.co_names:
        if name in expected:
            found.add(name)

        if name in old_names or name.startswith("ytd_windows."):
            obsolete.add(name)

    for value in code.co_consts:
        if isinstance(value, CodeType):
            collect_import_names(value, found, obsolete)


def patch_module_code(raw: bytes, *, require_recovered_ui: bool = True) -> tuple[CodeType, dict[str, int]]:
    """Patch the recovered UI bytecode in memory and validate the result.

    Raises ValueError if the bytecode does not match this Python version or any
    confirmed reference is missing. Nothing is written to disk.
    """
    if len(raw) < 17:
        raise ValueError("Bytecode file is too short.")

    expected_magic = importlib.util.MAGIC_NUMBER

    if raw[:4] != expected_magic:
        raise ValueError(
            "Python bytecode version mismatch. "
            f"Found {raw[:4].hex(' ')}, "
            f"expected {expected_magic.hex(' ')} for Python "
            f"{sys.version_info.major}.{sys.version_info.minor}."
        )

    module_code = marshal.loads(raw[16:])

    if not isinstance(module_code, CodeType):
        raise TypeError("Original file does not contain a module code object.")

    stats = {label: 0 for _, label in REPLACEMENTS.values()}

    for _, _, label in EMBEDDED_REPLACEMENTS:
        stats[label] = 0

    stats["poll"] = 0

    patched = patch_code(module_code, stats)

    # Require the confirmed recovered references.
    required = (
        "brand_label",
        "brand_name",
        "package_error_title",
        "package_error_help",
        "package_root",
        "package_downloader",
        "package_settings",
        "startup_error",
        "pillow_error",
        "quality_help",
        "subtitle_help",
        "download_hint",
        "mode_description",
        "mode_help",
        "poll",
    )

    missing = [label for label in required if stats.get(label, 0) == 0]

    if require_recovered_ui and missing:
        raise ValueError(
            "Recovered bytecode validation failed. Missing confirmed "
            "references: " + ", ".join(missing)
        )

    # Verify all three package imports in the patched code.
    found: set[str] = set()
    obsolete: set[str] = set()

    collect_import_names(patched, found, obsolete)

    expected_imports = {
        "lumo_windows",
        "lumo_windows.downloader",
        "lumo_windows.settings",
    }

    missing_imports = expected_imports - found if require_recovered_ui else set()

    if missing_imports:
        raise ValueError(
            "Missing package imports: " + ", ".join(sorted(missing_imports))
        )

    if require_recovered_ui and obsolete:
        raise ValueError(
            "Obsolete package imports remain: " + ", ".join(sorted(obsolete))
        )

    stats["verified_imports"] = len(found)
    return patched, stats


def patch_pyc(source: Path, destination: Path, *, require_recovered_ui: bool = True) -> dict[str, int]:
    """Patch a bytecode file on disk (used by the build step as a check)."""
    raw = source.read_bytes()
    patched, stats = patch_module_code(raw, require_recovered_ui=require_recovered_ui)
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(raw[:16] + marshal.dumps(patched))
    return stats


