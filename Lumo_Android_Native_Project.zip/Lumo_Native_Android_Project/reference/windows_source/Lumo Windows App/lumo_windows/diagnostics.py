import shutil
import sqlite3
import subprocess
import sys
from datetime import datetime
from pathlib import Path

from lumo_windows.settings import DATA_DIR, load_settings

CREATE_NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)
LOG_DIR = DATA_DIR / "logs"
LOG_FILE = LOG_DIR / "diagnostics.log"
MAX_LOG_BYTES = 512 * 1024


def run_command(cmd):
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace", creationflags=CREATE_NO_WINDOW, timeout=60)
    except (OSError, subprocess.TimeoutExpired) as error:
        return False, str(error)
    output = (result.stdout or result.stderr or "").strip()
    first_line = output.splitlines()[0] if output else "no output"
    return result.returncode == 0, first_line


def check_all():
    results = []
    results.append(("Python", True, sys.version.split()[0] + " at " + sys.executable))
    try:
        import tkinter
        results.append(("Tkinter", True, "available"))
    except ImportError as error:
        results.append(("Tkinter", False, str(error)))
    results.append(("SQLite", True, sqlite3.sqlite_version))
    ok, text = run_command([sys.executable, "-m", "yt_dlp", "--version"])
    results.append(("yt-dlp", ok, text))
    # Check the portable app/vendor copies as well as PATH. Lumo's source run
    # expects vendor\ and the packaged app expects the executables beside Lumo.exe.
    app_dir = Path(sys.executable).resolve().parent
    project_dir = Path(__file__).resolve().parents[1]
    for name in ("ffmpeg", "ffprobe", "deno"):
        exe = name + (".exe" if sys.platform == "win32" else "")
        path = shutil.which(name) or shutil.which(exe)
        if not path:
            for candidate in (app_dir / exe, project_dir / exe,
                              project_dir / "vendor" / exe):
                if candidate.is_file():
                    path = str(candidate)
                    break
        results.append((name, path is not None, path or "NOT FOUND"))
    for name in ("node",):
        path = shutil.which(name)
        results.append((name + " (JS runtime, optional)", path is not None, path or "NOT FOUND"))
    try:
        import curl_cffi
        version = getattr(curl_cffi, "__version__", "installed")
        results.append(("YouTube impersonation (curl_cffi)", True, str(version)))
    except ImportError:
        results.append(("YouTube impersonation (curl_cffi)", False,
                        'MISSING — run: python -m pip install -U "yt-dlp[default,curl-cffi]"'))
    cookie = Path(load_settings()["cookie_file"])
    found = cookie.is_file()
    results.append(("Cookie file", found, "found (contents never read)" if found else "not found"))
    return results


def write_log(lines):
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    if LOG_FILE.exists() and LOG_FILE.stat().st_size > MAX_LOG_BYTES:
        LOG_FILE.replace(LOG_DIR / "diagnostics.old.log")
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")


if __name__ == "__main__":
    stamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    lines = [f"--- Diagnostics {stamp} ---"]
    for name, ok, detail in check_all():
        status = "OK" if ok else "MISSING"
        lines.append(f"{status:8} {name}: {detail}")
    write_log(lines)
    print("\n".join(lines))
    print("\nLog saved to:", LOG_FILE)
