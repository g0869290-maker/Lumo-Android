import sqlite3
from contextlib import closing
from datetime import datetime
from pathlib import Path

try:
    from .settings import DATA_DIR
except ImportError:  # when run directly as a script
    from settings import DATA_DIR
DB_FILE = DATA_DIR / "history.db"

STATUS_QUEUED = "Queued"
STATUS_DOWNLOADING = "Downloading"
STATUS_COMPLETED = "Completed"
STATUS_FAILED = "Failed"
STATUS_CANCELLED = "Cancelled"
STATUS_INTERRUPTED = "Interrupted"


def _now():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def _connect():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    with closing(_connect()) as conn, conn:
        conn.execute("""CREATE TABLE IF NOT EXISTS jobs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            url TEXT NOT NULL,
            title TEXT,
            format_label TEXT,
            output_dir TEXT,
            file_path TEXT,
            status TEXT NOT NULL,
            error TEXT,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL)""")


def add_job(url, title, format_label, output_dir):
    now = _now()
    with closing(_connect()) as conn, conn:
        cursor = conn.execute("INSERT INTO jobs (url, title, format_label, output_dir, status, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)", (url, title, format_label, output_dir, STATUS_QUEUED, now, now))
        return cursor.lastrowid


def update_job(job_id, status, error=None, file_path=None):
    with closing(_connect()) as conn, conn:
        conn.execute("UPDATE jobs SET status = ?, error = ?, file_path = COALESCE(?, file_path), updated_at = ? WHERE id = ?", (status, error, file_path, _now(), job_id))


def set_file_path(job_id, file_path):
    """Set/clear the saved-file pointer without deleting the History record."""
    with closing(_connect()) as conn, conn:
        conn.execute("UPDATE jobs SET file_path = ?, updated_at = ? WHERE id = ?",
                     (str(file_path) if file_path else None, _now(), job_id))


def get_job(job_id):
    with closing(_connect()) as conn:
        row = conn.execute("SELECT * FROM jobs WHERE id = ?", (job_id,)).fetchone()
        return dict(row) if row else None


def list_jobs():
    with closing(_connect()) as conn:
        rows = conn.execute("SELECT * FROM jobs ORDER BY id DESC").fetchall()
        return [dict(row) for row in rows]


def delete_job(job_id):
    # Removes only the database record. Downloaded files are never touched.
    with closing(_connect()) as conn, conn:
        conn.execute("DELETE FROM jobs WHERE id = ?", (job_id,))


def mark_interrupted_jobs():
    # Called at startup: jobs left in Downloading state were not finished.
    with closing(_connect()) as conn, conn:
        cursor = conn.execute("UPDATE jobs SET status = ?, error = ?, updated_at = ? WHERE status = ?", (STATUS_INTERRUPTED, "Application closed during download", _now(), STATUS_DOWNLOADING))
        return cursor.rowcount


if __name__ == "__main__":
    init_db()
    job_id = add_job("https://example.com/test", "Test title", "Best available", str(DATA_DIR.parent / "Downloads"))
    update_job(job_id, STATUS_COMPLETED)
    job = get_job(job_id)
    if job and job["status"] == STATUS_COMPLETED:
        delete_job(job_id)
        if get_job(job_id) is None:
            print("History test OK")
        else:
            print("History test FAILED: record not deleted")
    else:
        print("History test FAILED: status not saved")


def clear_all_jobs():
    """Remove every History row. Used so no download history is kept at all."""
    init_db()
    with closing(_connect()) as conn, conn:
        conn.execute("DELETE FROM jobs")
