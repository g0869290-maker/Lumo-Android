"""Motion timing for the sidebar Playlist icon. Pure Python, no Tk dependency."""
from __future__ import annotations

from typing import Callable, Optional


def _cubic_out(t: float) -> float:
    return 1.0 - (1.0 - t) ** 3


def playlist_icon_rotation(progress: float, ease: Optional[Callable[[float], float]] = None) -> float:
    """Return the clockwise rotation (0 to 360 degrees) for one Playlist icon tween.

    History uses the same eased spin, 360 * ease_out_cubic(t). Pass the app's own
    easing function so the two icons share a curve; otherwise the standard cubic
    ease-out is used. The tween starts at 0 and finishes at exactly 360.
    """
    t = max(0.0, min(1.0, float(progress)))
    eased = ease(t) if callable(ease) else _cubic_out(t)
    return 360.0 * max(0.0, min(1.0, float(eased)))
