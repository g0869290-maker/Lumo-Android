@echo off
setlocal EnableExtensions EnableDelayedExpansion
title Lumo - build

REM ============================================================
REM  build.bat  -  BUILD ONLY
REM  Run check_and_install.bat once first (it installs everything).
REM  Produces:  dist\Lumo\Lumo.exe   and   installer_output\LumoSetup.exe
REM  Usage:  build.bat            (waits for a key at the end)
REM          build.bat /nopause   (no wait)
REM ============================================================

set "NOPAUSE=0"
for %%A in (%*) do (
    if /I "%%~A"=="/nopause" set "NOPAUSE=1"
)

cd /d "%~dp0"
set "ROOT=%CD%"
set "APP_VERSION=1.0.1"
set "VENV=%ROOT%\.venv312"
set "PY=%VENV%\Scripts\python.exe"
set "DIST=%ROOT%\dist\Lumo"
set "OUT=%ROOT%\installer_output"

echo ============================================================
echo  Lumo build   version %APP_VERSION%
echo  Folder: %ROOT%
echo ============================================================
echo.

REM ---------- 1. Project files ----------
echo [1/5] Checking project files
for %%F in (main.py main_original.pyc Lumo_icon.ico Lumo.spec requirements.txt Lumo_Setup.iss tools\patch_main_pyc.py lumo_windows\__init__.py lumo_windows\ui_patch.py lumo_windows\downloader.py lumo_windows\settings.py lumo_windows\history.py lumo_windows\diagnostics.py lumo_windows\playlist_ui.py lumo_windows\playlist_motion.py vendor\ffmpeg.exe vendor\ffprobe.exe vendor\deno.exe) do (
    if not exist "%ROOT%\%%F" (
        echo ERROR: missing %%F
        echo        Run check_and_install.bat first, and copy missing files from the zip.
        set "EXITCODE=1"
        goto done
    )
)
echo       OK
echo.

REM ---------- 2. Python 3.12 environment ----------
echo [2/5] Python 3.12 environment
if not exist "%PY%" (
    call :find_py
    if not defined PYCMD (
        echo ERROR: Python 3.12 not found. Run check_and_install.bat first.
        set "EXITCODE=2"
        goto done
    )
    !PYCMD! -m venv "%VENV%"
    if errorlevel 1 (
        echo ERROR: could not create .venv312.
        set "EXITCODE=2"
        goto done
    )
)
"%PY%" -c "import sys; raise SystemExit(0 if sys.version_info[:2] == (3, 12) else 1)"
if errorlevel 1 (
    echo ERROR: .venv312 is not Python 3.12. Delete the .venv312 folder and run again.
    set "EXITCODE=2"
    goto done
)
"%PY%" -m pip install -r "%ROOT%\requirements.txt" pyinstaller
if errorlevel 1 (
    echo ERROR: package install failed. Check the internet connection, then run again.
    set "EXITCODE=2"
    goto done
)
echo       OK
echo.

REM ---------- 3. Patch the recovered UI bytecode ----------
echo [3/5] Patching recovered UI bytecode
if not exist "%ROOT%\build" mkdir "%ROOT%\build"
"%PY%" "%ROOT%\tools\patch_main_pyc.py" "%ROOT%\main_original.pyc" "%ROOT%\build\original_main_patched.pyc"
if errorlevel 1 (
    echo ERROR: bytecode patch failed.
    set "EXITCODE=3"
    goto done
)
echo       OK
echo.

REM ---------- 4. PyInstaller ----------
echo [4/5] Building Lumo.exe with PyInstaller
if exist "%ROOT%\dist" rmdir /s /q "%ROOT%\dist"
"%PY%" -m PyInstaller --noconfirm --clean --distpath "%ROOT%\dist" --workpath "%ROOT%\build\pyinstaller" "%ROOT%\Lumo.spec"
if errorlevel 1 (
    echo ERROR: PyInstaller failed. Read the messages above.
    set "EXITCODE=4"
    goto done
)
if not exist "%DIST%\Lumo.exe" (
    echo ERROR: dist\Lumo\Lumo.exe was not created.
    set "EXITCODE=4"
    goto done
)
REM Never ship user data from a build folder.
if exist "%DIST%\Data" rmdir /s /q "%DIST%\Data"
for %%R in (ffmpeg.exe ffprobe.exe deno.exe) do (
    copy /y "%ROOT%\vendor\%%R" "%DIST%\%%R" >nul
    if errorlevel 1 (
        echo ERROR: could not copy %%R into dist\Lumo.
        set "EXITCODE=4"
        goto done
    )
)
echo       OK
echo.

REM ---------- 5. Installer ----------
echo [5/5] Building the installer
call :find_iscc
if not defined ISCC (
    echo ERROR: Inno Setup not found. Run check_and_install.bat first.
    echo        The app folder dist\Lumo is ready; only the installer is missing.
    set "EXITCODE=5"
    goto done
)
if not exist "%OUT%" mkdir "%OUT%"
if exist "%OUT%\LumoSetup.exe" del /q "%OUT%\LumoSetup.exe"
"%ISCC%" /Qp "/DMyAppVersion=%APP_VERSION%" "%ROOT%\Lumo_Setup.iss"
if errorlevel 1 (
    echo ERROR: Inno Setup failed. Read the messages above.
    set "EXITCODE=5"
    goto done
)
if not exist "%OUT%\LumoSetup.exe" (
    echo ERROR: installer_output\LumoSetup.exe was not created.
    set "EXITCODE=5"
    goto done
)
echo       OK
echo.

echo ============================================================
echo  BUILD FINISHED
echo  App folder : dist\Lumo\Lumo.exe
echo  Installer  : installer_output\LumoSetup.exe
echo ============================================================
set "EXITCODE=0"

:done
echo.
if not "%EXITCODE%"=="0" echo BUILD FAILED with code %EXITCODE%. Read the messages above.
if "%NOPAUSE%"=="0" pause
exit /b %EXITCODE%


REM ============================================================
REM  Helpers
REM ============================================================

:find_py
set "PYCMD="
where py >nul 2>&1
if not errorlevel 1 (
    py -3.12 -c "import sys" >nul 2>&1
    if not errorlevel 1 set "PYCMD=py -3.12"
)
if not defined PYCMD (
    python -c "import sys; raise SystemExit(0 if sys.version_info[:2] == (3, 12) else 1)" >nul 2>&1
    if not errorlevel 1 set "PYCMD=python"
)
exit /b 0

:find_iscc
set "ISCC="
for %%P in ("%ProgramFiles(x86)%\Inno Setup 7\ISCC.exe" "%ProgramFiles%\Inno Setup 7\ISCC.exe" "%LOCALAPPDATA%\Programs\Inno Setup 7\ISCC.exe" "%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe" "%ProgramFiles%\Inno Setup 6\ISCC.exe" "%LOCALAPPDATA%\Programs\Inno Setup 6\ISCC.exe") do (
    if exist "%%~P" if not defined ISCC set "ISCC=%%~P"
)
exit /b 0
