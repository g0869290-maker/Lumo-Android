"""Regression tests for the concrete Settings, History and first-click fixes."""
from __future__ import annotations

import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

import main


class FakeVar:
    def __init__(self, value):
        self.value = value
        self.traces = []

    def get(self):
        return self.value

    def set(self, value):
        self.value = value
        for callback in tuple(self.traces):
            callback("", "", "write")

    def trace_add(self, _mode, callback):
        self.traces.append(callback)
        return f"trace-{len(self.traces)}"


class FakeDialog:
    def __init__(self, directory=None, filename=None):
        self.directory = directory
        self.filename = filename
        self.directory_args = None
        self.filename_args = None

    def askdirectory(self, **kwargs):
        self.directory_args = kwargs
        return self.directory

    def askopenfilename(self, **kwargs):
        self.filename_args = kwargs
        return self.filename


class FakeAppBase:
    def build_settings_page(self):
        return None

    def _show_settings_tab(self):
        return None

    def save_app_settings(self):
        self.rebuild_saves = getattr(self, "rebuild_saves", 0) + 1
        return "full rebuild save"

    def browse_download_dir(self):
        return None

    def browse_cookie_file(self):
        return None

    def rebuild_ui(self):
        self.rebuild_count = getattr(self, "rebuild_count", 0) + 1

    def after(self, _delay, callback):
        self.pending_callback = callback
        return "after-id"

    def after_cancel(self, _after_id):
        self.pending_callback = None

    def after_idle(self, callback):
        self.pending_idle = callback
        return "idle-id"

    def winfo_children(self):
        return []


def make_module(dialog, backing):
    # A fresh class prevents wrappers installed by one test from leaking into another.
    class FakeApp(FakeAppBase):
        pass

    module = SimpleNamespace(
        App=FakeApp,
        filedialog=dialog,
        load_settings=lambda: dict(backing),
        save_settings=lambda values: backing.update(dict(values)),
        log_line=lambda _message: None,
        MUTED="#9AA4B5",
        BG="#0E0F14",
    )
    return module, FakeApp


def new_app(app_class):
    app = app_class()
    app.settings = {
        "download_dir": str(Path.home()),
        "cookie_file": "",
        "use_cookies": True,
        "merge_to_mp4": True,
        "preferred_subtitle": "en",
    }
    app.settings_tab_var = FakeVar("downloads")
    app.download_dir_var = FakeVar(str(Path.home()))
    app.cookie_file_var = FakeVar("")
    app.cookie_var = FakeVar(True)
    app.merge_var = FakeVar(True)
    app.preferred_subtitle_var = FakeVar("en")
    return app


class RequestedUiFixTests(unittest.TestCase):
    def test_browse_download_directory_uses_parent_and_persists_without_rebuild(self):
        with tempfile.TemporaryDirectory() as temporary:
            chosen = Path(temporary) / "Lumo downloads"
            chosen.mkdir()
            backing = {"download_dir": str(Path.home()), "cookie_file": "", "use_cookies": True}
            dialog = FakeDialog(directory=str(chosen))
            module, app_class = make_module(dialog, backing)
            main._install_settings_ui_repairs(module)
            app = new_app(app_class)

            app.browse_download_dir()

            self.assertIs(dialog.directory_args["parent"], app)
            self.assertEqual(app.download_dir_var.get(), str(chosen))
            self.assertEqual(backing["download_dir"], str(chosen))
            self.assertEqual(app.settings["download_dir"], str(chosen))
            self.assertEqual(getattr(app, "rebuild_saves", 0), 0)

    def test_browse_cookie_file_uses_parent_and_persists_without_rebuild(self):
        with tempfile.TemporaryDirectory() as temporary:
            cookie = Path(temporary) / "cookies.txt"
            cookie.write_text("# Netscape HTTP Cookie File\n", encoding="utf-8")
            backing = {"download_dir": str(Path.home()), "cookie_file": "", "use_cookies": True}
            dialog = FakeDialog(filename=str(cookie))
            module, app_class = make_module(dialog, backing)
            main._install_settings_ui_repairs(module)
            app = new_app(app_class)

            app.browse_cookie_file()

            self.assertIs(dialog.filename_args["parent"], app)
            self.assertEqual(app.cookie_file_var.get(), str(cookie))
            self.assertEqual(backing["cookie_file"], str(cookie))
            self.assertEqual(app.settings["cookie_file"], str(cookie))
            self.assertEqual(getattr(app, "rebuild_saves", 0), 0)

    def test_turning_youtube_access_off_saves_false_without_rebuilding_ui(self):
        backing = {"use_cookies": True, "download_dir": str(Path.home()), "cookie_file": ""}
        module, app_class = make_module(FakeDialog(), backing)
        main._install_settings_ui_repairs(module)
        app = new_app(app_class)
        app.settings["use_cookies"] = True
        app.cookie_var.set(False)

        app.save_app_settings()

        self.assertIs(backing["use_cookies"], False)
        self.assertIs(app.settings["use_cookies"], False)
        self.assertEqual(getattr(app, "rebuild_saves", 0), 0)
        self.assertEqual(getattr(app, "rebuild_count", 0), 0)

    def test_color_labels_are_normalized_to_requested_capitalization(self):
        tabs = (("theme", "Appearance"), ("accent", "Accent & indicator"),
                ("downloads", "Downloads"), ("subtitles", "Subtitles"))
        self.assertEqual(main._filter_choice_collection(tabs), (
            ("accent", "Accent & Indicator"), ("downloads", "Downloads"),
            ("subtitles", "Subtitles"), ("progress", "Progress Bar"),
        ))

    def test_selected_swatch_keeps_selected_state_but_renders_without_tick(self):
        class FakeSwatch:
            selected = True
            def _render(self):
                return self.selected

        module = SimpleNamespace(Squircle=FakeSwatch)
        main._install_selected_swatch_tick_removal(module)
        swatch = FakeSwatch()
        self.assertIs(swatch._render(), True)  # selected state is preserved
        self.assertIs(swatch.selected, True)
        self.assertTrue(getattr(swatch._render, "_lumo_no_selected_tick", False) or
                        getattr(FakeSwatch._render, "_lumo_no_selected_tick", False))

    def test_history_actions_are_plain_text_and_have_separate_spacing(self):
        class Button:
            def __init__(self, label):
                self.label = label
                self.padx = None
                self.children = []
            def winfo_children(self):
                return self.children
            def winfo_exists(self):
                return True
            def pack_configure(self, **kwargs):
                self.padx = kwargs.get("padx")
            def refresh_look(self):
                pass

        remove = Button("Remove from History")
        refresh = Button("Refresh")
        root = SimpleNamespace(winfo_children=lambda: [remove, refresh])
        app = SimpleNamespace(pages={"history": root}, _lumo_customization_options={
            "show_history_action_icons": True, "animate_history_action_icons": True,
        })
        main._decorate_history_actions(app)

        self.assertEqual(remove.label, "Remove from History")
        self.assertEqual(refresh.label, "Refresh")
        self.assertEqual(remove.padx, (4, 10))
        self.assertEqual(refresh.padx, (8, 0))
        self.assertFalse(hasattr(remove, "_lumo_icon_animation_bound"))
        self.assertFalse(hasattr(refresh, "_lumo_icon_animation_bound"))

    def test_first_cold_tab_click_skips_nav_icon_tween_until_cache_is_ready(self):
        source = Path(main.__file__).read_text(encoding="utf-8")
        self.assertIn('if not bool(getattr(app, "_lumo_nav_icon_warmup_complete", True))', source)
        self.assertIn("_lumo_last_ui_interaction = time.monotonic()", source)


if __name__ == "__main__":
    unittest.main()
