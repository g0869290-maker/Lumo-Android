"""Regression test for optional pose arguments in the recovered icon renderer wrapper."""
import ast
from pathlib import Path
import unittest


class NavIconProbeSignatureTests(unittest.TestCase):
    def test_navigation_icon_probe_keeps_pose_arguments_optional(self):
        source = (Path(__file__).resolve().parents[1] / "main.py").read_text(encoding="utf-8")
        tree = ast.parse(source)
        matches = []
        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef) and node.name == "icon_photo_with_nav_probe":
                matches.append(node)
        self.assertEqual(len(matches), 1, "expected one nav icon photo probe wrapper")
        fn = matches[0]
        arg_names = [arg.arg for arg in fn.args.args]
        self.assertEqual(arg_names[-4:], ["ss", "rot", "sc", "oy"])
        defaults = fn.args.defaults
        defaulted_names = arg_names[len(arg_names) - len(defaults):]
        self.assertEqual(defaulted_names, ["rot", "sc", "oy"])


if __name__ == "__main__":
    unittest.main()
