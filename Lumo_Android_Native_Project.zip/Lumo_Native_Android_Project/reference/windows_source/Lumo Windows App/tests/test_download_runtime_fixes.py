from __future__ import annotations

import tempfile
import unittest
from pathlib import Path
from types import ModuleType, SimpleNamespace
from unittest.mock import patch

import main as launcher
from lumo_windows import downloader
from lumo_windows.downloader import DownloadJob


class _FakeChip:
    def __init__(self):
        self.enabled = True
        self.selected = True

    def set_enabled(self, enabled):
        self.enabled = bool(enabled)

    def set_selected(self, selected):
        self.selected = bool(selected)


class _FakeCaptionWidget:
    def __init__(self, text=""):
        self.text = text
        self.children = []

    def cget(self, key):
        if key == "text":
            return self.text
        raise KeyError(key)

    def configure(self, **kwargs):
        self.text = kwargs.get("text", self.text)

    def winfo_children(self):
        return self.children


class DownloadUiRepairTests(unittest.TestCase):
    def test_status_filter_suppresses_only_the_redundant_download_captions(self):
        class App:
            def __init__(self):
                self.last_status = None

            def set_status(self, text, color=None):
                self.last_status = (text, color)

        module = SimpleNamespace(App=App)
        launcher._install_status_caption_filter(module)
        app = App()
        for text in (
            "Downloading video…  Progress details are below.",
            "Preparing video and audio streams…",
            "Resolving video formats. If this persists, check the final yt-dlp warning below.",
        ):
            app.set_status(text, "white")
            self.assertEqual(app.last_status, ("", "white"))
        app.set_status("Starting download…", "white")
        self.assertEqual(app.last_status, ("Starting download…", "white"))

    def test_compiled_caption_replacement_reaches_nested_callbacks(self):
        caption = "Preparing video and audio streams…"

        class App:
            def begin_worker(self):
                def deferred_caption():
                    return "Preparing video and audio streams…"
                return deferred_caption()

        module = ModuleType("caption_fixture")
        module.App = App
        launcher._strip_compiled_text(module, "App.begin_worker", caption)
        self.assertEqual(App().begin_worker(), "")

    def test_caption_cleanup_clears_existing_widgets(self):
        page = _FakeCaptionWidget()
        first = _FakeCaptionWidget("Preparing video and audio streams…")
        second = _FakeCaptionWidget("Resolving video formats. If this persists, check the final yt-dlp warning below.")
        other = _FakeCaptionWidget("Starting download…")
        page.children = [first, second, other]
        app = SimpleNamespace(pages={"download": page})
        launcher._blank_extra_caption(app)
        self.assertEqual(first.text, "")
        self.assertEqual(second.text, "")
        self.assertEqual(other.text, "Starting download…")

    def test_completed_subtitle_warning_is_shown_in_existing_status_area(self):
        class App:
            def __init__(self):
                self.last_status = None
            def handle_event(self, kind, payload):
                self.event_handled = (kind, payload)
            def set_status(self, text, color=None):
                self.last_status = (text, color)

        module = SimpleNamespace(App=App, WARN="#FFB45F")
        launcher._install_subtitle_warning_notice(module)
        app = App()
        payload = {
            "status": "Completed",
            "warning": "The video was saved, but subtitles could not be embedded.",
        }
        app.handle_event("done", payload)
        self.assertEqual(app.event_handled, ("done", payload))
        self.assertEqual(app.last_status, (payload["warning"], "#FFB45F"))

    def test_no_subtitle_warning_is_shown_for_normal_completion(self):
        class App:
            def __init__(self):
                self.last_status = None
            def handle_event(self, kind, payload):
                pass
            def set_status(self, text, color=None):
                self.last_status = (text, color)

        module = SimpleNamespace(App=App, WARN="#FFB45F")
        launcher._install_subtitle_warning_notice(module)
        app = App()
        app.handle_event("done", {"status": "Completed"})
        self.assertIsNone(app.last_status)

    def test_unavailable_subtitle_chips_are_disabled_and_deselected(self):
        english = _FakeChip()
        hindi = _FakeChip()
        app = SimpleNamespace(
            video_info={"subtitles_available": ["en-US"], "_subtitle_tracks_known": True},
            subtitle_chips={"en": english, "hi": hindi},
            subtitle_selection={"en", "hi"},
        )
        launcher._apply_subtitle_availability(app)
        self.assertTrue(english.enabled)
        self.assertFalse(hindi.enabled)
        self.assertTrue(english.selected)
        self.assertFalse(hindi.selected)
        self.assertEqual(app.subtitle_selection, {"en"})

    def test_known_empty_tracks_disable_all_language_chips_but_not_none(self):
        english = _FakeChip()
        none_chip = _FakeChip()
        app = SimpleNamespace(
            video_info={"subtitles_available": [], "_subtitle_tracks_known": True},
            subtitle_chips={"en": english, "none": none_chip},
            subtitle_selection={"en"},
        )
        launcher._apply_subtitle_availability(app)
        self.assertFalse(english.enabled)
        self.assertFalse(english.selected)
        self.assertTrue(none_chip.enabled)


    def test_url_change_invalidates_old_metadata_and_reenables_unknown_chips(self):
        class Entry:
            def __init__(self):
                self.value = "https://example.com/old"
                self.bindings = {}
            def get(self):
                return self.value
            def bind(self, event, callback, add=None):
                self.bindings[event] = callback

        class App:
            def __init__(self):
                self.url_entry = Entry()
                self.video_info = {"subtitles_available": ["en"], "_subtitle_tracks_known": True}
                self.subtitle_chips = {"en": _FakeChip(), "hi": _FakeChip()}
                self.subtitle_selection = {"en"}
            def inspect(self):
                self.inspect_called = True
            def handle_event(self, kind, payload):
                self.video_info = payload

        module = SimpleNamespace(App=App)
        launcher._install_subtitle_availability_refresh(module)
        app = App()
        app._lumo_subtitle_availability_url = "https://example.com/old"
        app.url_entry.value = "https://example.com/new"
        app.url_entry.bindings["<KeyRelease>"]()
        self.assertIsNone(app.video_info)
        self.assertTrue(all(chip.enabled for chip in app.subtitle_chips.values()))
        self.assertEqual(app.subtitle_selection, {"en"})
        app.inspect()
        app.handle_event("inspected", {
            "subtitles_available": ["hi"], "_subtitle_tracks_known": True
        })
        self.assertFalse(app.subtitle_chips["en"].enabled)
        self.assertTrue(app.subtitle_chips["hi"].enabled)
        self.assertEqual(app.subtitle_selection, set())

    def test_old_inspection_result_is_not_applied_after_url_changes(self):
        class Entry:
            def __init__(self):
                self.value = "https://example.com/new"
            def get(self):
                return self.value

        class App:
            def handle_event(self, kind, payload):
                self.video_info = payload
            def __init__(self):
                self.url_entry = Entry()
                self.video_info = None
                self.subtitle_chips = {"en": _FakeChip()}
                self.subtitle_selection = {"en"}
                self._lumo_subtitle_request_url = "https://example.com/old"

        module = SimpleNamespace(App=App)
        launcher._install_subtitle_availability_refresh(module)
        app = App()
        app.handle_event("inspected", {
            "subtitles_available": [], "_subtitle_tracks_known": True
        })
        self.assertTrue(app.subtitle_chips["en"].enabled)
        self.assertEqual(app.subtitle_selection, {"en"})
        self.assertIsNone(app.video_info)


class DownloaderProgressAccuracyTests(unittest.TestCase):
    class _Utils:
        class DownloadCancelled(Exception):
            pass

    def _make_hook(self, job, events):
        fake_yt_dlp = SimpleNamespace(utils=self._Utils)
        with patch.object(downloader, "_yt_dlp", return_value=fake_yt_dlp):
            return job._make_progress_hook(events.append)

    def test_video_and_audio_with_same_filename_are_counted_as_two_streams(self):
        with tempfile.TemporaryDirectory() as temporary:
            job = DownloadJob("https://example.com/video", temporary, estimate_bytes=2000)
            events = []
            hook = self._make_hook(job, events)
            filename = str(Path(temporary) / "final.mp4")
            with patch.object(downloader, "_PROGRESS_INTERVAL", 0):
                hook({
                    "status": "downloading", "filename": filename,
                    "downloaded_bytes": 1000, "total_bytes": 1000,
                    "info_dict": {"format_id": "137", "vcodec": "avc1", "acodec": "none", "height": 1080},
                })
                self.assertEqual(events[-1]["overall"], 50.0)
                self.assertTrue(events[-1]["total_estimated"])
                self.assertEqual(events[-1]["total"], 2000)
                hook({
                    "status": "downloading", "filename": filename,
                    "downloaded_bytes": 500, "total_bytes": 1000,
                    "info_dict": {"format_id": "140", "vcodec": "none", "acodec": "mp4a.40.2"},
                })
            self.assertEqual(events[-1]["overall"], 75.0)
            self.assertFalse(events[-1]["total_estimated"])
            self.assertEqual(events[-1]["downloaded"], 1500)
            self.assertEqual(events[-1]["total"], 2000)
            self.assertEqual(len(job._progress_by_stream), 2)

    def test_separate_video_stream_never_reports_complete_before_audio_starts(self):
        with tempfile.TemporaryDirectory() as temporary:
            job = DownloadJob("https://example.com/video", temporary)
            events = []
            hook = self._make_hook(job, events)
            with patch.object(downloader, "_PROGRESS_INTERVAL", 0):
                hook({
                    "status": "finished", "filename": str(Path(temporary) / "final.mp4"),
                    "downloaded_bytes": 1000, "total_bytes": 1000,
                    "info_dict": {"format_id": "137", "vcodec": "avc1", "acodec": "none", "height": 720},
                })
            self.assertLess(events[-1]["overall"], 50.0)
            self.assertIsNone(events[-1]["total"])
            self.assertTrue(events[-1]["total_estimated"])


    def test_unknown_total_uses_indeterminate_progress_without_estimate(self):
        with tempfile.TemporaryDirectory() as temporary:
            job = DownloadJob("https://example.com/video", temporary)
            events = []
            hook = self._make_hook(job, events)
            with patch.object(downloader, "_PROGRESS_INTERVAL", 0):
                hook({
                    "status": "downloading", "filename": str(Path(temporary) / "unknown.mp4"),
                    "downloaded_bytes": 128, "total_bytes": None, "total_bytes_estimate": None,
                    "info_dict": {"format_id": "muxed", "vcodec": "avc1", "acodec": "mp4a.40.2"},
                })
            self.assertIsNone(events[-1]["overall"])
            self.assertIsNone(events[-1]["total"])
            self.assertTrue(events[-1]["total_estimated"])

    def test_repeated_callbacks_replace_stream_measurement_and_clamp_progress(self):
        with tempfile.TemporaryDirectory() as temporary:
            job = DownloadJob("https://example.com/video", temporary, estimate_bytes=1000)
            events = []
            hook = self._make_hook(job, events)
            filename = str(Path(temporary) / "sample.mp4")
            info = {"format_id": "muxed", "vcodec": "avc1", "acodec": "mp4a.40.2"}
            with patch.object(downloader, "_PROGRESS_INTERVAL", 0):
                hook({"status": "downloading", "filename": filename,
                      "downloaded_bytes": 500, "total_bytes": 1000, "info_dict": info})
                hook({"status": "downloading", "filename": filename,
                      "downloaded_bytes": 600, "total_bytes": 1000, "info_dict": info})
                self.assertEqual(events[-1]["downloaded"], 600)
                self.assertEqual(events[-1]["overall"], 60.0)
                hook({"status": "downloading", "filename": filename,
                      "downloaded_bytes": -50, "total_bytes": 1000, "info_dict": info})
            # A negative reading is ignored: the last good size and the bar stay.
            self.assertEqual(events[-1]["downloaded"], 600)
            self.assertEqual(events[-1]["overall"], 60.0)
            self.assertGreaterEqual(events[-1]["overall"], 0.0)
            self.assertLessEqual(events[-1]["overall"], 100.0)


class SubtitleFailureCompletionTests(unittest.TestCase):
    class _Utils:
        class DownloadCancelled(Exception):
            pass

    def _run_with_failure(self, temporary, failure_message):
        seen = {}
        class FakeYoutubeDL:
            def __init__(self, options):
                seen.update(options)
            def __enter__(self):
                return self
            def __exit__(self, exc_type, exc, traceback):
                return False

        video = Path(temporary) / "sample.mp4"
        video.write_bytes(b"video file")
        fake_yt_dlp = SimpleNamespace(YoutubeDL=FakeYoutubeDL, utils=self._Utils)
        job = DownloadJob("https://example.com/video", temporary, subtitle_langs=["en"])
        def raise_subtitle_error(*_args, **_kwargs):
            raise RuntimeError(failure_message)
        with patch.object(downloader, "_yt_dlp", return_value=fake_yt_dlp), \
             patch.object(downloader, "_js_runtime_options", return_value=({}, "test runtime")), \
             patch.object(downloader, "_cookie_option", return_value={}), \
             patch.object(job, "_make_progress_hook", return_value=lambda _data: None), \
             patch.object(job, "_download_with", side_effect=raise_subtitle_error), \
             patch.object(job, "_find_output", return_value=str(video)):
            result = job.run()
        return result, seen

    def test_subtitle_postprocessing_failure_keeps_video_completed_with_warning(self):
        with tempfile.TemporaryDirectory() as temporary:
            result, _seen = self._run_with_failure(temporary, "FFmpegEmbedSubtitle failed: subtitles could not be embedded")
            self.assertTrue(Path(result["file_path"]).is_file())
        self.assertEqual(result["status"], "Completed")
        self.assertIsNone(result["error"])
        self.assertIn("could not be downloaded or embedded", result["warning"])

    def test_video_remux_failure_is_not_misreported_as_subtitle_warning(self):
        with tempfile.TemporaryDirectory() as temporary:
            result, _seen = self._run_with_failure(temporary, "FFmpegVideoRemuxer failed")
        self.assertEqual(result["status"], "Failed")
        self.assertIn("FFmpegVideoRemuxer failed", result["error"])

    def test_manual_tracks_disable_automatic_caption_downloading(self):
        with tempfile.TemporaryDirectory() as temporary:
            video = Path(temporary) / "sample.mp4"
            video.write_bytes(b"video file")
            seen = {}
            class FakeYoutubeDL:
                def __init__(self, options):
                    seen.update(options)
                def __enter__(self):
                    return self
                def __exit__(self, exc_type, exc, traceback):
                    return False
            fake_yt_dlp = SimpleNamespace(YoutubeDL=FakeYoutubeDL, utils=self._Utils)
            job = DownloadJob("https://example.com/video", temporary, subtitle_langs=["en"])
            job._prefetched = {"subtitles": {"en": [{}]}, "automatic_captions": {"en": [{}]}}
            with patch.object(downloader, "_yt_dlp", return_value=fake_yt_dlp), \
                 patch.object(downloader, "_js_runtime_options", return_value=({}, "test runtime")), \
                 patch.object(downloader, "_cookie_option", return_value={}), \
                 patch.object(job, "_make_progress_hook", return_value=lambda _data: None), \
                 patch.object(job, "_download_with", return_value={"title": "sample", "requested_subtitles": {"en": {"ext": "srt"}}}), \
                 patch.object(job, "_find_output", return_value=str(video)), \
                 patch.object(downloader, "_subtitle_stream_count", return_value=1):
                result = job.run()
        self.assertEqual(result["status"], "Completed")
        self.assertTrue(seen["writesubtitles"])
        self.assertFalse(seen["writeautomaticsubtitles"])


if __name__ == "__main__":
    unittest.main()
