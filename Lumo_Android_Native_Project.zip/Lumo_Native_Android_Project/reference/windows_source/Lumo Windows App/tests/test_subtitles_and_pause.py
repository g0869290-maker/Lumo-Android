"""Real subtitle tracks, exact-language resolution, and pause that follows the running job."""
import shutil
import tempfile
import threading
import time
import types
import unittest
from pathlib import Path

import main as launcher
from lumo_windows import downloader


class SubtitleResolverTests(unittest.TestCase):
    INFO = {
        "subtitles": {"en": [{}]},
        "automatic_captions": {"hi": [{}], "hi-orig": [{}], "mr-orig": [{}]},
    }

    def test_exact_code_is_used_even_when_a_manual_track_exists(self):
        self.assertEqual(downloader._resolve_subtitle_languages(["hi-orig"], self.INFO), ["hi-orig"])

    def test_automatic_only_language_is_not_replaced_by_english(self):
        self.assertEqual(downloader._resolve_subtitle_languages(["mr-orig"], self.INFO), ["mr-orig"])
        self.assertEqual(downloader._resolve_subtitle_languages(["en"], self.INFO), ["en"])

    def test_unavailable_language_is_dropped_not_swapped(self):
        self.assertEqual(downloader._resolve_subtitle_languages(["fr"], self.INFO), [])

    def test_no_metadata_keeps_the_selection(self):
        self.assertEqual(downloader._resolve_subtitle_languages(["fr"], None), ["fr"])


class SubtitleTrackListingTests(unittest.TestCase):
    def test_manual_tracks_and_common_automatic_languages_are_shown_with_names(self):
        tracks = [
            {"code": "en", "kind": "manual"},
            {"code": "hi-orig", "kind": "auto"},
            {"code": "hi", "kind": "auto"},
            {"code": "mr-orig", "kind": "auto"},
            {"code": "xx", "kind": "auto"},
        ]
        shown, total = launcher._subtitle_tracks_to_show({"subtitle_tracks": tracks})
        codes = [t["code"] for t in shown]
        self.assertEqual(total, 5)
        self.assertIn("en", codes)
        self.assertIn("hi-orig", codes)
        self.assertNotIn("hi", codes)      # one entry per language
        self.assertNotIn("xx", codes)      # uncommon automatic language is not offered
        labels = {t["code"]: launcher._subtitle_label(t["code"], t["kind"]) for t in shown}
        self.assertEqual(labels["en"], "English")
        self.assertEqual(labels["hi-orig"], "Hindi · auto")
        self.assertEqual(labels["mr-orig"], "Marathi · auto")


class PauseFollowsRunningJobTests(unittest.TestCase):
    def _fake_ydl(self):
        class FakeYDL:
            def __init__(self, opts):
                self.opts = opts

            def __enter__(self):
                return self

            def __exit__(self, *args):
                return False

            def extract_info(self, url, download=True):
                if download:
                    hook = self.opts["progress_hooks"][0]
                    for i in range(150):
                        hook({"status": "downloading", "downloaded_bytes": i, "total_bytes": 9000,
                              "filename": "v.mp4",
                              "info_dict": {"format_id": "1", "vcodec": "avc1", "acodec": "none"}})
                        time.sleep(0.02)
                return {"title": "t"}

            def process_ie_result(self, *args, **kwargs):
                return {"title": "t"}

            def prepare_filename(self, *args, **kwargs):
                return "/tmp/x"
        return types.SimpleNamespace(YoutubeDL=FakeYDL,
                                     utils=types.SimpleNamespace(DownloadCancelled=RuntimeError))

    def test_running_job_is_registered_and_pause_resume_toggle_it(self):
        original = (downloader._yt_dlp, downloader._js_runtime_options)
        downloader._yt_dlp = lambda: self._fake_ydl()
        downloader._js_runtime_options = lambda: ({}, None)
        out = Path(tempfile.mkdtemp())
        try:
            job = downloader.DownloadJob("https://www.youtube.com/watch?v=pause", out, max_height=720)
            thread = threading.Thread(target=job.run)
            thread.start()
            time.sleep(0.3)
            self.assertIs(downloader.current_job(), job)
            job.pause()
            self.assertTrue(job.is_paused())
            job.resume()
            self.assertFalse(job.is_paused())
            job.cancel()
            thread.join(30)
            self.assertIsNone(downloader.current_job())
        finally:
            downloader._yt_dlp, downloader._js_runtime_options = original
            shutil.rmtree(out, ignore_errors=True)


if __name__ == "__main__":
    unittest.main()
