"""Tab logo plays once and download chunk size."""
import types
import unittest

import main as launcher
from lumo_windows import downloader


class TabLogoTests(unittest.TestCase):
    def test_logo_play_is_one_900ms_tween_at_normal_pace(self):
        calls = []

        def start_tween(owner, attr, duration, on_frame, easing=None, on_done=None):
            calls.append((attr, duration, easing))

        def ease_out_cubic(t):
            return t

        class NavRow:
            def play_icon(self):
                pass

            def _set_icon(self, value):
                pass

        module = types.SimpleNamespace(App=type("App", (), {}), NavRow=NavRow,
                                       start_tween=start_tween, ease_out_cubic=ease_out_cubic)
        launcher._install_v3_polish(module)
        NavRow().play_icon()
        self.assertEqual(len(calls), 1)
        self.assertEqual(calls[0][:2], ("_icon_tween", 900))


class DownloadSpeedOptionTests(unittest.TestCase):
    def test_download_asks_for_large_chunks(self):
        captured = {}

        class FakeYDL:
            def __init__(self, opts):
                captured.update(opts)

            def __enter__(self):
                return self

            def __exit__(self, *a):
                return False

            def process_ie_result(self, *a, **k):
                return {"title": "t"}

            def extract_info(self, url, download=True):
                return {"title": "t"}
        fake = types.SimpleNamespace(YoutubeDL=FakeYDL,
                                     utils=types.SimpleNamespace(DownloadCancelled=Exception))
        import tempfile
        from pathlib import Path
        original = (downloader._yt_dlp, downloader._js_runtime_options, downloader.DownloadJob._find_output)
        downloader._yt_dlp = lambda: fake
        downloader._js_runtime_options = lambda: ({}, None)
        downloader.DownloadJob._find_output = lambda self, *a, **k: None
        try:
            downloader.DownloadJob("https://www.youtube.com/watch?v=speed", Path(tempfile.mkdtemp())).run()
        finally:
            (downloader._yt_dlp, downloader._js_runtime_options,
             downloader.DownloadJob._find_output) = original
        self.assertEqual(captured.get("http_chunk_size"), 10 * 1024 * 1024)
        self.assertEqual(captured.get("concurrent_fragment_downloads"), 4)


if __name__ == "__main__":
    unittest.main()
