"""Progress never goes backwards, stays under 98% while downloading, and ends at 100%."""
import shutil
import tempfile
import types
import unittest
from pathlib import Path

from lumo_windows import downloader


class _TwoStreamYDL:
    def __init__(self, opts):
        self.opts = opts

    def __enter__(self):
        return self

    def __exit__(self, *args):
        return False

    def _run(self):
        progress = self.opts["progress_hooks"][0]
        post = self.opts["postprocessor_hooks"][0]
        video = {"format_id": "137", "vcodec": "avc1", "acodec": "none"}
        audio = {"format_id": "140", "vcodec": "none", "acodec": "mp4a"}
        info = {"requested_formats": [video, audio]}
        for total, name in ((50_000_000, "v.mp4"), (2_000_000, "a.m4a")):
            for step in range(1, 11):
                progress({"status": "downloading", "downloaded_bytes": total * step // 10,
                          "total_bytes": total, "filename": name, "info_dict": info})
            progress({"status": "finished", "downloaded_bytes": total, "total_bytes": total,
                      "filename": name, "info_dict": info})
        post({"status": "started", "postprocessor": "Merger"})
        post({"status": "finished", "postprocessor": "Merger"})

    def process_ie_result(self, *args, **kwargs):
        self._run()
        return {"title": "t"}

    def extract_info(self, url, download=True):
        if download:
            self._run()
        return {"title": "t", "requested_downloads": [{"filepath": "/tmp/x"}]}

    def prepare_filename(self, *args, **kwargs):
        return "/tmp/x"


class ProgressTests(unittest.TestCase):
    def test_progress_is_monotonic_capped_then_completes(self):
        fake = types.SimpleNamespace(YoutubeDL=_TwoStreamYDL,
                                     utils=types.SimpleNamespace(DownloadCancelled=RuntimeError))
        original = (downloader._yt_dlp, downloader._js_runtime_options, downloader.DownloadJob._find_output)
        downloader._yt_dlp = lambda: fake
        downloader._js_runtime_options = lambda: ({}, None)
        downloader.DownloadJob._find_output = lambda self, *a, **k: None
        out = Path(tempfile.mkdtemp())
        updates = []
        try:
            job = downloader.DownloadJob("https://www.youtube.com/watch?v=progress", out, max_height=720)
            job.run(on_progress=lambda u: updates.append((u.get("status"), u.get("overall"))))
        finally:
            (downloader._yt_dlp, downloader._js_runtime_options,
             downloader.DownloadJob._find_output) = original
            shutil.rmtree(out, ignore_errors=True)

        values = [v for _, v in updates if v is not None]
        self.assertTrue(values)
        self.assertEqual(values, sorted(values), "progress moved backwards")
        during = [v for st, v in updates if st not in ("postprocessing", "finished") and v is not None]
        self.assertLessEqual(max(during), 98.0)
        self.assertEqual(values[-1], 100.0)


class WeightedProgressTests(unittest.TestCase):
    """With yt-dlp's per-stream sizes, the bar follows the bytes (not a 0-49% first stream)."""

    def test_bar_reflects_real_bytes_when_video_finishes(self):
        video = {"format_id": "137", "vcodec": "avc1", "acodec": "none", "filesize": 50_000_000}
        audio = {"format_id": "140", "vcodec": "none", "acodec": "mp4a", "filesize": 2_000_000}

        class YDL(_TwoStreamYDL):
            def _run(self):
                progress = self.opts["progress_hooks"][0]
                info = {"requested_formats": [video, audio]}
                for total, name in ((50_000_000, "v.mp4"), (2_000_000, "a.m4a")):
                    for step in range(1, 11):
                        progress({"status": "downloading", "downloaded_bytes": total * step // 10,
                                  "total_bytes": total, "filename": name, "info_dict": info})
                    progress({"status": "finished", "downloaded_bytes": total, "total_bytes": total,
                              "filename": name, "info_dict": info})
                self.opts["postprocessor_hooks"][0]({"status": "finished", "postprocessor": "Merger"})

        fake = types.SimpleNamespace(YoutubeDL=YDL,
                                     utils=types.SimpleNamespace(DownloadCancelled=RuntimeError))
        original = (downloader._yt_dlp, downloader._js_runtime_options, downloader.DownloadJob._find_output)
        downloader._yt_dlp = lambda: fake
        downloader._js_runtime_options = lambda: ({}, None)
        downloader.DownloadJob._find_output = lambda self, *a, **k: None
        out = Path(tempfile.mkdtemp())
        updates = []
        try:
            job = downloader.DownloadJob("https://www.youtube.com/watch?v=weighted", out, max_height=720)
            job.run(on_progress=lambda u: updates.append((u.get("status"), u.get("overall"))))
        finally:
            (downloader._yt_dlp, downloader._js_runtime_options,
             downloader.DownloadJob._find_output) = original
            shutil.rmtree(out, ignore_errors=True)
        when_video_done = [v for st, v in updates if st == "finished"][0]
        self.assertGreater(when_video_done, 90.0)
        values = [v for _, v in updates if v is not None]
        self.assertEqual(values, sorted(values))


if __name__ == "__main__":
    unittest.main()
