from pathlib import Path
import queue
import tempfile
import unittest
from unittest.mock import patch
from types import SimpleNamespace

import main
from lumo_windows.downloader import DownloadJob
from lumo_windows import downloader, playlist_ui


class AddedControlsTests(unittest.TestCase):
    def test_url_clear_and_history_animation_hooks_are_registered(self):
        source = Path(main.__file__).read_text(encoding="utf-8")
        self.assertIn("def _install_url_clear_button", source)
        self.assertIn("def _clear_url_with_animation", source)
        self.assertIn("def _install_history_icon_animations", source)
        self.assertIn("def _animate_history_icon", source)
        self.assertIn("def _draw_history_action_icon", source)

    def test_playlist_window_uses_per_video_quality_cap_and_subtitle_selection(self):
        source = Path(playlist_ui.__file__).read_text(encoding="utf-8")
        self.assertIn("max_height=cap", source)
        self.assertIn("subtitle_langs=languages", source)
        self.assertIn("Load Playlist", source)
        self.assertIn("Done · Review", source)
        self.assertIn("Delete file", source)
        self.assertIn("Share / Copy path", source)
        self.assertIn("history.add_job", source)
        self.assertIn("_get_item(uid)", source)
        self.assertIn("embedded: bool = False", source)

    def test_playlist_uses_app_palette_clear_url_control_and_circular_status_ring(self):
        source = Path(playlist_ui.__file__).read_text(encoding="utf-8")
        self.assertIn("self.ACCENT = _valid_colour", source)
        self.assertIn('self.clear_url_button = self._button', source)
        self.assertIn('def clear_url(self)', source)
        self.assertIn('size = 64', source)
        self.assertIn('label, font_size = "✓", 14', source)
        self.assertIn('text="Resume"', source)
        self.assertIn('text="Pause"', source)

    def test_playlist_quality_cap_never_exceeds_selected_maximum(self):
        self.assertEqual(playlist_ui.pick_height([480, 720, 1080], 1080), 1080)
        self.assertEqual(playlist_ui.pick_height([480, 720, 1080], 720), 720)
        self.assertEqual(playlist_ui.pick_height([480, 720, 1080], 500), 480)
        self.assertEqual(playlist_ui.pick_height([2160, 4320], 1080), None)
        self.assertEqual(playlist_ui.pick_height([480, 720, 1080], None), 1080)


    def test_history_action_decorator_supports_custom_canvas_softbuttons(self):
        class FakeButton:
            def __init__(self, label):
                self.label = label
                self.bindings = []
                self.refreshed = 0
            def bind(self, *args, **kwargs):
                self.bindings.append((args, kwargs))
            def refresh_look(self):
                self.refreshed += 1
            def winfo_children(self):
                return []
        class FakeApp:
            def __init__(self):
                self.button = FakeButton("Retry / Resume")
            def winfo_children(self):
                return [self.button]
        app = FakeApp()
        main._decorate_history_actions(app)
        self.assertEqual(app.button.label, "Retry / Resume")
        self.assertEqual(app.button._lumo_action_kind, "retry")
        self.assertFalse(app.button._lumo_show_icon)
        self.assertFalse(hasattr(app.button, "_lumo_icon_animation_bound"))
        self.assertEqual(app.button.refreshed, 0)

    def test_previous_repair_regressions_are_explicitly_fixed(self):
        main_source = Path(main.__file__).read_text(encoding="utf-8")
        playlist_source = Path(playlist_ui.__file__).read_text(encoding="utf-8")
        # The URL clear control is a drawn rounded X (canvas), not a text label.
        self.assertIn("def _draw_url_clear", main_source)
        self.assertIn("def _url_clear_release", main_source)
        self.assertNotIn("canvas._lumo_animating", main_source)
        self.assertIn("app_class_original_rebuild", main_source)
        self.assertIn("module.NAV_ITEMS = tuple(replacement)", main_source)
        self.assertIn("self._update_job_record(item, db_status", playlist_source)
        downloader_source = Path(DownloadJob.__module__.replace(".", "/") + ".py")
        downloader_source = Path(__import__(DownloadJob.__module__, fromlist=["__file__"]).__file__).read_text(encoding="utf-8")
        self.assertIn("if not file_path or not Path(file_path).is_file()", downloader_source)
        self.assertIn("processed_uids: set[str] = set()", playlist_source)
        self.assertIn("if uid in started_uids or uid in processed_uids", playlist_source)


    def test_stopping_playlist_does_not_overwrite_completed_row(self):
        with tempfile.TemporaryDirectory() as temporary:
            finished_file = Path(temporary) / "finished.mp4"
            finished_file.write_bytes(b"test")
            controller = playlist_ui.PlaylistWindow.__new__(playlist_ui.PlaylistWindow)
            controller.events = queue.Queue()
            controller.current_job = None
            controller.current_uid = None
            controller._stop_requested = False
            controller._queue_prefs = {"download_dir": temporary, "merge_to_mp4": True}
            updates = []
            controller._update_job_record = lambda item, status, error=None, file_path=None: updates.append(
                (item["uid"], status, error, file_path)
            )

            def item(uid, job_id):
                return {"uid": uid, "history_id": job_id, "url": f"https://example.com/{uid}",
                        "status": "Queued", "title": uid, "error": None,
                        "_queue_prefs": {"download_dir": temporary, "merge_to_mp4": True},
                        "_queue_cap": 1080, "_queue_languages": []}

            first, second = item("first", 1), item("second", 2)

            class FakeJob:
                def __init__(self, *args, **kwargs):
                    pass
                def run(self, **kwargs):
                    controller._stop_requested = True
                    return {"status": "Completed", "file_path": str(finished_file), "error": None}

            with patch.object(playlist_ui.downloader, "DownloadJob", FakeJob),                  patch.object(playlist_ui, "_cookie_path", return_value=None):
                controller._download_worker([first, second])

            statuses = [(uid, status) for uid, status, _error, _path in updates]
            self.assertIn(("first", "Completed"), statuses)
            self.assertIn(("second", "Cancelled"), statuses)
            self.assertNotIn(("first", "Cancelled"), statuses)
            events = []
            while not controller.events.empty():
                events.append(controller.events.get_nowait())
            self.assertIn(("queue_finished",), events)

    def test_downloader_never_completes_without_an_existing_media_file(self):
        class FakeYoutubeDL:
            def __init__(self, options):
                self.options = options
            def __enter__(self):
                return self
            def __exit__(self, exc_type, exc, traceback):
                return False

        with tempfile.TemporaryDirectory() as temporary:
            job = DownloadJob("https://example.com/video", temporary)
            fake_yt_dlp = SimpleNamespace(YoutubeDL=FakeYoutubeDL)
            with patch.object(downloader, "_yt_dlp", return_value=fake_yt_dlp), \
                 patch.object(downloader, "_js_runtime_options", return_value=({}, "test runtime")), \
                 patch.object(downloader, "_cookie_option", return_value={}), \
                 patch.object(downloader, "_ffmpeg_dir", return_value=temporary), \
                 patch.object(job, "_make_progress_hook", return_value=lambda _data: None), \
                 patch.object(job, "_download_with", return_value={"title": "Test video", "height": 720}), \
                 patch.object(job, "_find_output", return_value=None):
                result = job.run()
            self.assertEqual(result["status"], "Failed")
            self.assertIsNone(result["file_path"])
            self.assertIn("could not be located", result["error"])

    def test_download_job_pause_resume_and_cancel_release_pause_wait(self):
        job = DownloadJob("https://example.com/video", ".")
        job.pause()
        self.assertFalse(job._resume_event.is_set())
        job.resume()
        self.assertTrue(job._resume_event.is_set())
        job.pause()
        job.cancel()
        self.assertTrue(job._cancel_event.is_set())
        self.assertTrue(job._resume_event.is_set())

    def test_open_file_location_reveals_the_exact_file_on_windows(self):
        saved = Path("/tmp/lumo-sample.mp4")
        with patch.object(playlist_ui.subprocess, "Popen") as popen:
            playlist_ui._reveal_file_location(saved, platform_name="nt")
        args = popen.call_args.args[0]
        self.assertEqual(args[0], "explorer.exe")
        self.assertTrue(args[1].startswith("/select,"))
        self.assertTrue(args[1].endswith("lumo-sample.mp4"))

    def test_playlist_cards_bind_visible_content_to_video_selection(self):
        source = Path(playlist_ui.__file__).read_text(encoding="utf-8")
        self.assertIn('widget.bind("<Button-1>"', source)
        self.assertIn('lambda _event, item_uid=uid: self._select_card(item_uid)', source)
        self.assertIn('_reveal_file_location(Path(path))', source)

    def test_playlist_styles_do_not_change_the_entire_application_ttk_theme(self):
        source = Path(playlist_ui.__file__).read_text(encoding="utf-8")
        self.assertNotIn("style.theme_use(\"clam\")", source)
        self.assertIn("style.configure(\"Lumo.Treeview\"", source)

    def test_history_animation_respects_turning_icons_off(self):
        class FakeButton:
            def __init__(self):
                self.label = "Copy URL"
                self.refreshed = 0
            def refresh_look(self):
                self.refreshed += 1
        app = SimpleNamespace(_lumo_customization_options={
            "show_history_action_icons": False,
            "animate_history_action_icons": True,
        })
        button = FakeButton()
        button._lumo_original_action_label = "Copy URL"
        module_stub = SimpleNamespace(ease_out_cubic=lambda t: t)
        main._animate_history_icon(app, button, module_stub, "copy")
        self.assertEqual(button.label, "Copy URL")
        self.assertFalse(hasattr(button, "_lumo_icon_after_id"))

    def test_history_circle_is_crisp_and_has_room_for_three_digit_percentage(self):
        source = Path(main.__file__).read_text(encoding="utf-8")
        self.assertIn("width=32, height=32", source)
        self.assertIn("font=(\"Segoe UI Semibold\", 7)", source)

    def test_cookie_failure_guidance_is_only_added_for_signin_restrictions(self):
        self.assertIn("import or refresh your own exported cookies.txt",
                      downloader._cookie_guidance("Sign in to confirm you are not a bot"))
        self.assertEqual(downloader._cookie_guidance("Network timed out"), "Network timed out")

    def test_one_time_cookie_prompt_is_registered_and_cookie_path_autosaves(self):
        source = Path(main.__file__).read_text(encoding="utf-8")
        self.assertIn("def _install_cookie_prompt", source)
        self.assertIn("cookie_prompt_seen", source)
        self.assertIn("cookie_file_var", source)

    def test_cookie_prompt_is_marked_seen_only_after_the_dialog_was_created(self):
        source = Path(main.__file__).read_text(encoding="utf-8")
        start = source.index("def _maybe_show_cookie_prompt")
        dialog = source.index("dialog = tk.Toplevel(app)", start)
        setup = source[start:dialog]
        self.assertNotIn('prefs["cookie_prompt_seen"] = True', setup)
        self.assertNotIn("module.save_settings(prefs)", setup)
        close_start = source.index("def close_prompt()", dialog)
        import_start = source.index("def import_cookie_file()", close_start)
        close_block = source[close_start:import_start]
        self.assertIn('current["cookie_prompt_seen"] = True', close_block)
        self.assertIn("module.save_settings(current)", close_block)

    def test_playlist_rows_keep_cancel_out_of_the_card_and_in_footer(self):
        source = Path(playlist_ui.__file__).read_text(encoding="utf-8")
        self.assertIn('"Cancel video", self.cancel_current', source)
        self.assertNotIn('_button(right, "Cancel"', source)
        self.assertNotIn('card["cancel"]', source)

    def test_playlist_footer_cancel_targets_selected_queued_video(self):
        controller = playlist_ui.PlaylistWindow.__new__(playlist_ui.PlaylistWindow)
        controller._selected_uid = "queued-1"
        controller.items = [{"uid": "queued-1", "status": "Queued"}]
        controller.current_uid = "active-1"
        controller.current_job = object()
        messages = []
        calls = []
        controller.status_var = SimpleNamespace(set=messages.append)
        controller.cancel_item = calls.append
        controller.cancel_current()
        self.assertEqual(calls, ["queued-1"])
        self.assertEqual(messages, [])

    def test_playlist_footer_cancel_defaults_to_active_video_only_without_selection(self):
        controller = playlist_ui.PlaylistWindow.__new__(playlist_ui.PlaylistWindow)
        controller._selected_uid = None
        controller.items = [{"uid": "active-1", "status": "Downloading"}]
        controller.current_uid = "active-1"
        controller.current_job = object()
        messages = []
        calls = []
        controller.status_var = SimpleNamespace(set=messages.append)
        controller.cancel_item = calls.append
        controller.cancel_current()
        self.assertEqual(calls, ["active-1"])
        self.assertEqual(messages, [])

    def test_playlist_footer_does_not_cancel_active_video_when_a_completed_row_is_selected(self):
        controller = playlist_ui.PlaylistWindow.__new__(playlist_ui.PlaylistWindow)
        controller._selected_uid = "done-1"
        controller.items = [{"uid": "done-1", "status": "Completed"},
                            {"uid": "active-1", "status": "Downloading"}]
        controller.current_uid = "active-1"
        controller.current_job = object()
        messages = []
        calls = []
        controller.status_var = SimpleNamespace(set=messages.append)
        controller.cancel_item = calls.append
        controller.cancel_current()
        self.assertEqual(calls, [])
        self.assertIn("Select a queued or downloading video", messages[0])


if __name__ == "__main__":
    unittest.main()
