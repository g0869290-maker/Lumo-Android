"""Button and hover animations keep the recovered UI's easing default.

Passing easing=None to the original tween crashes every button press, so the launcher's
wrapper must forward what the caller gave and only fill in easing for the progress bar.
"""
import unittest
import types

import main as launcher


class TweenDefaultTests(unittest.TestCase):
    def _module(self):
        calls = []

        def ease_out_cubic(t):
            return t

        def start_tween(owner, attr, duration_ms, on_frame, easing=ease_out_cubic, on_done=None):
            calls.append((owner.__class__.__name__, easing, on_done))

        class GlowProgress:
            def __init__(self, parent, height=5, *args, **kwargs):
                self.parent = parent

            def draw_content(self):
                pass

        module = types.ModuleType("fake_recovered_ui")
        module.start_tween = start_tween
        module.GlowProgress = GlowProgress
        module.glow_layer = lambda *a, **k: "glow"
        module.load_settings = lambda: {"progress_thickness_default_v2": True}
        module.save_settings = lambda settings: None
        module.ease_out_cubic = ease_out_cubic
        launcher._install_progress_rendering_repairs(module)
        return module, calls, ease_out_cubic

    def test_button_tween_without_easing_keeps_original_default(self):
        module, calls, ease = self._module()
        module.start_tween(types.SimpleNamespace(), "hover", 180, lambda v: None)
        self.assertIs(calls[0][1], ease)

    def test_progress_tween_gets_a_real_easing(self):
        module, calls, ease = self._module()
        module.start_tween(module.GlowProgress(None), "_value_tween", 300, lambda v: None)
        self.assertIsNotNone(calls[0][1])
        self.assertIs(calls[0][1], ease)


if __name__ == "__main__":
    unittest.main()
