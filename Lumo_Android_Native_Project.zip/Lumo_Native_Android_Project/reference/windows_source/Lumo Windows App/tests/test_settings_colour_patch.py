from __future__ import annotations

import importlib.util
import sys
import tempfile
import types
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from lumo_windows import settings as package_settings


def load_launcher():
    spec = importlib.util.spec_from_file_location("lumo_launcher_under_test", ROOT / "main.py")
    module = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


class FakeVar:
    def __init__(self, value=""):
        self.value = value
        self.traces = []

    def get(self):
        return self.value

    def set(self, value):
        self.value = value
        for callback in tuple(self.traces):
            callback("", "", "write")

    def trace_add(self, mode, callback):
        self.traces.append(callback)
        return f"trace{len(self.traces)}"


class FakeWidget:
    def __init__(self, master=None, **kwargs):
        self.master = master
        self.kwargs = dict(kwargs)
        self.children = []
        self.hidden = False
        self.destroyed = False
        self.packed = False
        self.command = kwargs.get("command")
        if master is not None and hasattr(master, "children"):
            master.children.append(self)

    def pack(self, **kwargs):
        self.packed = True
        self.pack_kwargs = kwargs

    def pack_forget(self):
        self.hidden = True

    def place(self, **kwargs):
        self.hidden = False
        self.place_kwargs = kwargs

    def place_forget(self):
        self.hidden = True

    def grid_remove(self):
        self.hidden = True

    def destroy(self):
        self.destroyed = True
        self.hidden = True

    def configure(self, **kwargs):
        self.kwargs.update(kwargs)

    config = configure

    def bind(self, sequence, callback, add=None):
        self.bindings = getattr(self, "bindings", {})
        self.bindings[sequence] = callback

    def delete(self, *args):
        self.deleted = True

    def _create_draw_item(self, kind, args, kwargs):
        self.draw_items = getattr(self, "draw_items", [])
        self.draw_items.append((kind, args, dict(kwargs)))
        return len(self.draw_items)

    def create_line(self, *args, **kwargs):
        return self._create_draw_item("line", args, kwargs)

    def create_oval(self, *args, **kwargs):
        return self._create_draw_item("oval", args, kwargs)

    def create_arc(self, *args, **kwargs):
        return self._create_draw_item("arc", args, kwargs)

    def create_text(self, *args, **kwargs):
        return self._create_draw_item("text", args, kwargs)

    def coords(self, item, *coords):
        self.coords_calls = getattr(self, "coords_calls", [])
        self.coords_calls.append((item, coords))

    def itemconfigure(self, *args, **kwargs):
        self.itemconfigure_calls = getattr(self, "itemconfigure_calls", [])
        self.itemconfigure_calls.append((args, kwargs))

    def winfo_width(self):
        return 420

    def winfo_children(self):
        return list(self.children)


class FakeTk:
    Frame = FakeWidget
    Label = FakeWidget
    Entry = FakeWidget
    Button = FakeWidget
    Checkbutton = FakeWidget
    Scale = FakeWidget
    Canvas = FakeWidget
    StringVar = FakeVar
    BooleanVar = FakeVar
    IntVar = FakeVar


class SettingsColourPatchTests(unittest.TestCase):
    def test_package_settings_round_trip_progress_colour(self):
        settings_module = package_settings
        with tempfile.TemporaryDirectory() as tmp:
            old_dir, old_file = settings_module.DATA_DIR, settings_module.SETTINGS_FILE
            settings_module.DATA_DIR = Path(tmp)
            settings_module.SETTINGS_FILE = Path(tmp) / "settings.json"
            try:
                values = settings_module.load_settings()
                values["progress_color"] = "#12aBcD"
                settings_module.save_settings(values)
                reloaded = settings_module.load_settings()
                self.assertEqual(reloaded["progress_color"], "#12ABCD")
                self.assertEqual(reloaded["appearance"], "Dark")
            finally:
                settings_module.DATA_DIR, settings_module.SETTINGS_FILE = old_dir, old_file

    def test_invalid_progress_colour_falls_back_to_default(self):
        with tempfile.TemporaryDirectory() as tmp:
            old_dir, old_file = package_settings.DATA_DIR, package_settings.SETTINGS_FILE
            package_settings.DATA_DIR = Path(tmp)
            package_settings.SETTINGS_FILE = Path(tmp) / "settings.json"
            try:
                package_settings.save_settings({"progress_color": "not-a-colour"})
                self.assertEqual(package_settings.load_settings()["progress_color"],
                                 package_settings.DEFAULTS["progress_color"])
            finally:
                package_settings.DATA_DIR, package_settings.SETTINGS_FILE = old_dir, old_file

    def test_appearance_is_removed_but_colour_tabs_remain_and_preferences_autosave(self):
        launcher = load_launcher()
        launcher.tk = FakeTk

        class FakeApp:
            def __init__(self):
                self.settings_tabs = {
                    "theme": FakeWidget(), "customization": FakeWidget(),
                    "accent": FakeWidget(), "progress": FakeWidget(),
                    "downloads": FakeWidget(), "subtitles": FakeWidget(),
                }
                self.settings_tab_var = FakeVar("theme")
                self.settings = {}
                self.cookie_badge = FakeWidget()
                self.preferred_subtitle_var = FakeVar("en")
                self.last_shown = None
                self.next_id = 0
                self.scheduled = {}
                self.saved = 0

            def build_settings_page(self):
                return "built"

            def _show_settings_tab(self):
                self.last_shown = self.settings_tab_var.get()

            def after(self, delay, callback):
                self.next_id += 1
                self.scheduled[self.next_id] = callback
                return self.next_id

            def after_cancel(self, callback_id):
                self.scheduled.pop(callback_id, None)

            def save_app_settings(self):
                self.saved += 1
                return "saved"

        fake_module = types.SimpleNamespace(App=FakeApp, MUTED="#9AA4B5", log_line=lambda _message: None)
        launcher._install_settings_ui_repairs(fake_module)
        app = FakeApp()
        self.assertEqual(app.build_settings_page(), "built")
        self.assertEqual(set(app.settings_tabs), {"accent", "progress", "downloads", "subtitles"})
        self.assertTrue(app.cookie_badge.hidden)
        self.assertEqual(app.settings_tab_var.get(), "downloads")
        self.assertEqual(app.last_shown, "downloads")

        app.preferred_subtitle_var.set("hi")
        self.assertEqual(len(app.scheduled), 1)
        next(iter(app.scheduled.values()))()
        self.assertEqual(app.saved, 1)

    def test_chip_choice_filter_keeps_colour_controls_and_removes_appearance_and_light(self):
        launcher = load_launcher()
        tabs = (("theme", "Appearance"), ("accent", "Accent & indicator"),
                ("downloads", "Downloads"), ("subtitles", "Subtitles"))
        filtered_tabs = launcher._filter_choice_collection(tabs)
        self.assertEqual(filtered_tabs, (("accent", "Accent & Indicator"),
                                         ("downloads", "Downloads"), ("subtitles", "Subtitles"),
                                         ("progress", "Progress Bar")))
        theme_options = (("Dark", "Dark"), ("Light", "Light"))
        self.assertEqual(launcher._filter_choice_collection(theme_options), (("Dark", "Dark"),))


    def test_progress_customisation_options_persist_and_normalise(self):
        settings_module = package_settings
        with tempfile.TemporaryDirectory() as tmp:
            old_dir, old_file = settings_module.DATA_DIR, settings_module.SETTINGS_FILE
            settings_module.DATA_DIR = Path(tmp)
            settings_module.SETTINGS_FILE = Path(tmp) / "settings.json"
            try:
                values = settings_module.load_settings()
                values.update({
                    "progress_glow_enabled": False,
                    "progress_glow_intensity": 145,
                    "progress_animation_enabled": False,
                    "progress_animation_speed": "very-fast",
                    "progress_thickness": 99,
                })
                settings_module.save_settings(values)
                saved = settings_module.load_settings()
                self.assertFalse(saved["progress_glow_enabled"])
                self.assertFalse(saved["progress_animation_enabled"])
                self.assertEqual(saved["progress_glow_intensity"], 100)
                self.assertEqual(saved["progress_animation_speed"], "normal")
                self.assertEqual(saved["progress_thickness"], 16)
            finally:
                settings_module.DATA_DIR, settings_module.SETTINGS_FILE = old_dir, old_file

    def test_customization_options_persist_and_clamp_to_boolean_values(self):
        with tempfile.TemporaryDirectory() as tmp:
            old_dir, old_file = package_settings.DATA_DIR, package_settings.SETTINGS_FILE
            package_settings.DATA_DIR = Path(tmp)
            package_settings.SETTINGS_FILE = Path(tmp) / "settings.json"
            try:
                values = package_settings.load_settings()
                values.update({"show_open_location_action": False,
                               "show_share_action": False,
                               "show_delete_action": True,
                               "show_playlist_thumbnails": False,
                               "compact_playlist_rows": True,
                               "confirm_file_delete": False})
                package_settings.save_settings(values)
                saved = package_settings.load_settings()
                self.assertFalse(saved["show_open_location_action"])
                self.assertFalse(saved["show_share_action"])
                self.assertTrue(saved["show_delete_action"])
                self.assertFalse(saved["show_playlist_thumbnails"])
                self.assertTrue(saved["compact_playlist_rows"])
                self.assertFalse(saved["confirm_file_delete"])
            finally:
                package_settings.DATA_DIR, package_settings.SETTINGS_FILE = old_dir, old_file

    def test_active_history_row_gets_a_circular_progress_indicator(self):
        launcher = load_launcher()
        launcher.tk = FakeTk

        class FakeTree(FakeWidget):
            def __init__(self):
                super().__init__()
                self.rows = {"7": ("Test video", "Downloading", "today", "42%")}
            def get_children(self, _root=""):
                return list(self.rows)
            def item(self, iid, option=None, **kwargs):
                if "values" in kwargs:
                    self.rows[iid] = tuple(kwargs["values"])
                if option == "values":
                    return self.rows[iid]
                return {"values": self.rows[iid]}
            def bbox(self, iid, column):
                return (0, 0, 145, 32) if iid in self.rows else ()
            def cget(self, option):
                return "#15171E"

        class HistoryApp:
            def __init__(self):
                self.tree = FakeTree()
                self.job_progress = {7: 42}
                self._row_cache = {}

        app = HistoryApp()
        module = types.SimpleNamespace(PROGRESS_COLOR="#12AB34", CARD="#15171E",
                                       TEXT="#F4F6FB", BORDER="#292D38")
        launcher._refresh_progress_circles(app, module)
        self.assertEqual(app.tree.rows["7"][3], "")
        self.assertIn("7", app._lumo_progress_circles)
        circle = app._lumo_progress_circles["7"]
        self.assertFalse(circle.hidden)
        self.assertTrue(any("extent" in kwargs and abs(float(kwargs["extent"]) + 151.2) < 1e-6
                            for _args, kwargs in circle.itemconfigure_calls))

    def test_manual_save_preferences_button_is_hidden(self):
        launcher = load_launcher()

        class SoftButton(FakeWidget):
            def __init__(self, label):
                super().__init__()
                self.label = label

        root = FakeWidget()
        save_button = SoftButton("Save preferences")
        other_button = SoftButton("Browse")
        root.children.extend((save_button, other_button))
        app = types.SimpleNamespace(
            pages={"settings": root}, settings_tabs={},
            settings_note=FakeWidget(),
        )
        module = types.SimpleNamespace(MUTED="#9AA4B5")

        launcher._hide_manual_save_ui(app, module)
        self.assertTrue(save_button.hidden)
        self.assertFalse(other_button.hidden)

    def test_existing_settings_variables_schedule_automatic_save(self):
        launcher = load_launcher()
        scheduled = {}
        saved = []

        class AutoSaveApp:
            def __init__(self):
                self.accent_var = FakeVar("#8871FF")
                self.preferred_subtitle_var = FakeVar("en")
                self.settings = {"preferred_subtitle": "en"}
                self.next_id = 0
            def after(self, delay, callback):
                self.next_id += 1
                scheduled[self.next_id] = callback
                return self.next_id
            def after_cancel(self, callback_id):
                scheduled.pop(callback_id, None)
            def save_app_settings(self):
                saved.append(True)

        app = AutoSaveApp()
        launcher._wire_automatic_settings_save(app, types.SimpleNamespace(MUTED="#9AA4B5"))
        app.accent_var.set("#4C8DFF")
        self.assertEqual(len(scheduled), 1, "accent colour changes must autosave")
        app.preferred_subtitle_var.set("hi")
        self.assertEqual(saved, [], "autosave should debounce rapid setting changes")
        self.assertEqual(len(scheduled), 1)
        callback = next(iter(scheduled.values()))
        callback()
        self.assertEqual(saved, [True])

    def test_history_filter_options_are_patched_to_completed_active_failed(self):
        launcher = load_launcher()
        namespace = {}
        exec(
            "def build_history_page(self):\n"
            "    return (('all', 'All'), ('downloading', 'Active'), ('failed', 'Failed'))\n",
            namespace,
        )

        class FakeHistoryApp:
            build_history_page = namespace["build_history_page"]
            def __init__(self):
                self.history_filter = FakeVar("all")
                self.tree = None
                self.pages = {}
            def refresh_history(self):
                return None

        fake_module = types.SimpleNamespace(App=FakeHistoryApp)
        launcher._install_history_ui_repairs(fake_module)
        app = FakeHistoryApp()
        self.assertEqual(
            app.build_history_page(),
            (("completed", "Completed"), ("downloading", "Active"), ("failed", "Failed")),
        )
        self.assertEqual(app.history_filter.get(), "completed")

    def test_url_focus_helper_only_focuses_download_page(self):
        launcher = load_launcher()

        class FocusEntry:
            def __init__(self):
                self.focused = False
                self.selection = None
            def focus_set(self):
                self.focused = True
            def selection_range(self, start, end):
                self.selection = (start, end)

        class FocusApp:
            def __init__(self):
                self.current_display_page = "download"
                self.stage = "idle"
                self.url_entry = FocusEntry()
            def after(self, delay, callback):
                callback()

        app = FocusApp()
        launcher._schedule_url_focus(app, 0)
        self.assertTrue(app.url_entry.focused)
        self.assertEqual(app.url_entry.selection, (0, "end"))
        app.url_entry.focused = False
        app.stage = "quality"
        launcher._schedule_url_focus(app, 0)
        self.assertTrue(app.url_entry.focused, "returning to Download from another step should restore URL focus")
        self.assertEqual(app.url_entry.selection, (0, "end"))
        app.url_entry.focused = False
        app.stage = "active"
        launcher._schedule_url_focus(app, 0)
        self.assertFalse(app.url_entry.focused, "do not steal focus during an active download")
        app.current_display_page = "history"
        app.stage = "idle"
        launcher._schedule_url_focus(app, 0)
        self.assertFalse(app.url_entry.focused)

    def test_completed_history_filter_removes_only_non_completed_rows(self):
        launcher = load_launcher()

        class FakeTree:
            def __init__(self):
                self.rows = {
                    "1": ("Finished video", "Completed", "today", "100%"),
                    "2": ("Active video", "Downloading", "today", "38%"),
                    "3": ("Failed video", "Failed", "today", "12%"),
                }
            def get_children(self, _root=""):
                return list(self.rows)
            def item(self, iid, option):
                return {"values": self.rows[iid]}[option]
            def delete(self, iid):
                self.rows.pop(iid, None)

        class FakeVarNoop:
            def set(self, _value):
                pass

        class FakeEmptyState:
            def place_forget(self):
                self.hidden = True
            def place(self, **kwargs):
                self.placed = kwargs

        class HistoryApp:
            def __init__(self):
                self.tree = FakeTree()
                self._row_cache = {"1": 1, "2": 2, "3": 3}
                self.history_count_var = FakeVar("3 items")
                self.empty_var = FakeVarNoop()
                self.empty_state = FakeEmptyState()

        app = HistoryApp()
        launcher._keep_completed_rows_only(app)
        self.assertEqual(list(app.tree.rows), ["1"])
        self.assertEqual(app.history_count_var.get(), "1 item")
        self.assertNotIn("2", app._row_cache)

    def test_progress_setting_saves_are_debounced_during_rapid_changes(self):
        launcher = load_launcher()

        class ScheduledApp:
            def __init__(self):
                self.settings = {"progress_color": "#8871FF"}
                self.callbacks = {}
                self.next_id = 0

            def after(self, delay, callback):
                self.next_id += 1
                callback_id = f"after{self.next_id}"
                self.callbacks[callback_id] = (delay, callback)
                return callback_id

            def after_cancel(self, callback_id):
                self.callbacks.pop(callback_id, None)

            def winfo_children(self):
                return []

        app = ScheduledApp()
        stored = {"progress_color": "#8871FF"}
        saves = []

        def save_settings(value):
            stored.clear()
            stored.update(value)
            saves.append(dict(value))

        module = types.SimpleNamespace(
            load_settings=lambda: dict(stored), save_settings=save_settings,
            log_line=lambda message: None,
        )
        launcher._persist_progress_setting(app, module, "progress_color", "#111111")
        launcher._persist_progress_setting(app, module, "progress_color", "#222222")
        self.assertFalse(saves, "writes should wait while changes are arriving")
        delayed_saves = [(key, delay, callback) for key, (delay, callback) in app.callbacks.items() if delay == 320]
        self.assertEqual(len(delayed_saves), 1, "rapid changes should leave only one pending save")
        delayed_saves[0][2]()
        self.assertEqual(len(saves), 1)
        self.assertEqual(stored["progress_color"], "#222222")
        self.assertEqual(module.PROGRESS_COLOR, "#222222")


if __name__ == "__main__":
    unittest.main()
