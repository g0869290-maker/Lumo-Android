"""Settings and history use one data folder, and it works on machines without D:."""
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


class DataPathTests(unittest.TestCase):
    def _run(self, code, env_extra):
        env = dict(os.environ, **env_extra)
        return subprocess.run([sys.executable, "-c", code], cwd=ROOT, env=env,
                              capture_output=True, text=True, timeout=60)

    def test_override_moves_settings_and_history_together(self):
        home = tempfile.mkdtemp()
        result = self._run(
            "from lumo_windows import settings, history;"
            "print(settings.DATA_DIR);print(history.DB_FILE)",
            {"LUMO_HOME": home},
        )
        self.assertEqual(result.returncode, 0, result.stderr)
        data_dir, db_file = result.stdout.split()
        self.assertEqual(Path(data_dir), Path(home) / "Data")
        self.assertEqual(Path(db_file).parent, Path(data_dir))

    def test_default_folders_do_not_point_at_missing_d_drive(self):
        result = self._run(
            "from lumo_windows import settings as s;print(s.DEFAULTS['download_dir'])",
            {"LUMO_HOME": tempfile.mkdtemp()},
        )
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertTrue(result.stdout.strip().endswith("Downloads"))


if __name__ == "__main__":
    unittest.main()
