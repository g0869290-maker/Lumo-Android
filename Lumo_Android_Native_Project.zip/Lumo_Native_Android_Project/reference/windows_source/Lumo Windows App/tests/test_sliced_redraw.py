"""Redraws run through one queue: sliced, visible page first, never stalled."""
import time
import types
import unittest

import main as launcher


class FakeRoot:
    def __init__(self):
        self.timers = []

    def after(self, ms, fn):
        self.timers.append((ms, fn))

    def run_all(self):
        rounds = 0
        while self.timers:
            _ms, fn = self.timers.pop(0)
            fn()
            rounds += 1
            if rounds > 1000:
                raise AssertionError("timers never drained")
        return rounds


class FakeApp:
    def __init__(self):
        self.pages = {}
        self.current_display_page = "download"

    def winfo_toplevel(self):
        return self


class Card:
    """Stands in for a Painted widget."""
    order = []

    def __init__(self, root, app, master, cost=0.0, name=""):
        self.root, self.app, self.master, self.cost, self.name = root, app, master, cost, name
        self._redraw_id = None
        self.draws = 0

    def _root(self):
        return self.root

    def winfo_toplevel(self):
        return self.app

    def _flush(self):
        self._redraw_id = None
        self.draws += 1
        Card.order.append(self.name)
        if self.cost:
            end = time.perf_counter() + self.cost
            while time.perf_counter() < end:
                pass


class Page:
    def __init__(self):
        self.master = None


class SlicedRedrawTests(unittest.TestCase):
    def setUp(self):
        Card.order = []
        launcher._SLICED_REDRAW["queue"].clear()
        launcher._SLICED_REDRAW["scheduled"] = False
        self.module = types.SimpleNamespace(Painted=Card)
        Card.request_redraw = lambda self: None
        launcher._install_sliced_redraw(self.module)
        self.root, self.app = FakeRoot(), FakeApp()
        self.visible, self.hidden = Page(), Page()
        self.app.pages = {"download": self.visible, "settings": self.hidden}

    def card(self, page, **kw):
        return Card(self.root, self.app, page, **kw)

    def test_repeated_requests_draw_once(self):
        card = self.card(self.visible, name="a")
        for _ in range(5):
            card.request_redraw()
        self.root.run_all()
        self.assertEqual(card.draws, 1)
        card.request_redraw()
        self.root.run_all()
        self.assertEqual(card.draws, 2)

    def test_visible_page_is_drawn_first(self):
        under = [self.card(self.hidden, name=f"h{i}") for i in range(3)]
        top = [self.card(self.visible, name=f"v{i}") for i in range(3)]
        for card in under + top:
            card.request_redraw()
        self.root.run_all()
        self.assertEqual(Card.order[:3], ["v0", "v1", "v2"])

    def test_work_is_split_into_slices_when_it_is_heavy(self):
        cards = [self.card(self.visible, cost=0.004, name=str(i)) for i in range(12)]
        for card in cards:
            card.request_redraw()
        rounds = self.root.run_all()
        self.assertTrue(all(c.draws == 1 for c in cards))
        self.assertGreaterEqual(rounds, 3)  # control returned to the event loop in between

    def test_a_failing_card_does_not_stall_the_queue(self):
        bad = self.card(self.visible, name="bad")
        bad._flush = lambda: (_ for _ in ()).throw(RuntimeError("boom"))
        good = self.card(self.visible, name="good")
        bad.request_redraw()
        good.request_redraw()
        self.root.run_all()
        self.assertEqual(good.draws, 1)
        self.assertFalse(launcher._SLICED_REDRAW["scheduled"])

    def test_install_is_idempotent(self):
        first = Card.request_redraw
        launcher._install_sliced_redraw(self.module)
        self.assertIs(Card.request_redraw, first)


if __name__ == "__main__":
    unittest.main()
