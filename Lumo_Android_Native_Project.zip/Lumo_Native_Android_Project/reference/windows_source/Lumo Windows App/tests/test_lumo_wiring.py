"""Wiring checks that catch old-name and broken-reference drift before the app runs.

These do not start the GUI. They read the source, the build files, and the
recovered UI bytecode, and fail when a name, import, attribute or file path
points at something that does not exist under the Lumo naming.
"""
from __future__ import annotations

import ast
import os
import re
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from lumo_windows.ui_patch import patch_module_code  # noqa: E402

SKIP_DIRS = {"__pycache__", ".venv", ".venv312", "venv", "build", "dist", ".pytest_cache", ".git"}
SHIPPED_PY = [
    p for p in ROOT.rglob("*.py")
    if not (set(p.relative_to(ROOT).parts[:-1]) & SKIP_DIRS) and p.name != "recovered_main.py"
]  # recovered_main.py is a disassembly listing, not source code
OLD_NAME = re.compile(r"\bYTD\b|ytd_windows|YTD_|_YTD|_ytd_|ytd_(?!dl)|YTD Windows|vidzy|VidZy|VIDZY", re.IGNORECASE)
# Places where an old name is intentional, with the reason.
OLD_NAME_ALLOWED = {
    # Legacy names the patcher must find in the original bytecode, and the
    # one-time migration from the old per-user folder.
    "lumo_windows/ui_patch.py",
    "tools/inspect_main_pyc.py",
    "tests/test_lumo_wiring.py",
    "tests/test_patcher.py",
    "tests/test_runtime_patch.py",
}
# Data folder kept on purpose (existing settings and history live there), yt-dlp's .ytdl extension.
DATA_FOLDER_KEPT = re.compile(r"D:\\\\?YTD|\.ytdl|VIDZY_HOME|Vidzy\"\)|base / \"Vidzy\"")


def _rel(path: Path) -> str:
    return path.relative_to(ROOT).as_posix()


def _strings(tree: ast.AST):
    for node in ast.walk(tree):
        if isinstance(node, ast.Constant) and isinstance(node.value, str):
            yield node.value


class OldNameTests(unittest.TestCase):
    def test_no_old_names_in_shipped_python(self):
        offenders = []
        for path in SHIPPED_PY:
            rel = _rel(path)
            if rel in OLD_NAME_ALLOWED:
                continue
            for number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
                cleaned = DATA_FOLDER_KEPT.sub("", line)
                if OLD_NAME.search(cleaned):
                    offenders.append(f"{rel}:{number}: {line.strip()[:100]}")
        self.assertEqual([], offenders, "Old names found:\n" + "\n".join(offenders[:40]))

    def test_no_old_names_in_patched_ui(self):
        raw = (ROOT / "main_original.pyc").read_bytes()
        code, _ = patch_module_code(raw)
        bad = []

        def walk(obj):
            for name in obj.co_names:
                if OLD_NAME.search(name):
                    bad.append(("name", name))
            for value in obj.co_consts:
                if hasattr(value, "co_names"):
                    walk(value)
                elif isinstance(value, str) and OLD_NAME.search(DATA_FOLDER_KEPT.sub("", value)):
                    bad.append(("text", value[:100]))

        walk(code)
        self.assertEqual([], bad)

    def test_main_never_reads_a_prepatched_ui_file(self):
        text = (ROOT / "main.py").read_text(encoding="utf-8")
        self.assertNotIn("original_main_patched", text)


class ImportTests(unittest.TestCase):
    def _module_exists(self, dotted: str) -> bool:
        parts = dotted.split(".")
        base = ROOT.joinpath(*parts)
        return base.with_suffix(".py").is_file() or (base / "__init__.py").is_file()

    def test_every_lumo_windows_import_resolves(self):
        missing = []
        for path in SHIPPED_PY:
            tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
            for node in ast.walk(tree):
                names = []
                if isinstance(node, ast.ImportFrom) and node.module and node.level == 0:
                    names.append(node.module)
                elif isinstance(node, ast.Import):
                    names += [a.name for a in node.names]
                for name in names:
                    if name.split(".")[0] == "lumo_windows" and not self._module_exists(name):
                        missing.append(f"{_rel(path)}: {name}")
        self.assertEqual([], missing)

    def test_patched_ui_imports_resolve(self):
        code, _ = patch_module_code((ROOT / "main_original.pyc").read_bytes())
        found = set()

        def walk(obj):
            for name in obj.co_names:
                if name == "lumo_windows" or name.startswith("lumo_windows."):
                    found.add(name)
            for value in obj.co_consts:
                if hasattr(value, "co_names"):
                    walk(value)

        walk(code)
        missing = [name for name in found if not self._module_exists(name)]
        self.assertEqual([], missing)

    def test_package_modules_exist(self):
        for module in ("downloader", "settings", "history", "diagnostics",
                       "playlist_ui", "playlist_motion", "ui_patch"):
            self.assertTrue((ROOT / "lumo_windows" / f"{module}.py").is_file(), module)


    def test_spec_hidden_imports_point_at_real_modules(self):
        text = (ROOT / "Lumo.spec").read_text(encoding="utf-8")
        missing = []
        for name in re.findall(r"[\"'](lumo_windows(?:\.\w+)*)[\"']", text):
            if not self._module_exists(name):
                missing.append(name)
        self.assertEqual([], missing, "Lumo.spec names a module that does not exist")

    def test_main_imports_the_package_it_patches_with(self):
        text = (ROOT / "main.py").read_text(encoding="utf-8")
        self.assertIn("from lumo_windows.ui_patch import patch_module_code", text)


class AttributeDriftTests(unittest.TestCase):
    """A _lumo_ attribute that is read but never written is a rename that drifted."""

    def test_every_lumo_attribute_read_is_written_somewhere(self):
        reads, writes = set(), set()
        for path in SHIPPED_PY:
            if _rel(path).startswith("tests/"):
                continue
            tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
            for node in ast.walk(tree):
                if isinstance(node, ast.Assign):
                    for target in node.targets:
                        if isinstance(target, ast.Name) and target.id.lower().startswith("_lumo"):
                            writes.add(target.id)  # class-body marker, read back via getattr
                if isinstance(node, ast.Attribute) and node.attr.lower().startswith("_lumo"):
                    (writes if isinstance(node.ctx, ast.Store) else reads).add(node.attr)
                if isinstance(node, ast.Call) and isinstance(node.func, ast.Name):
                    if node.func.id in {"getattr", "hasattr"} and len(node.args) >= 2:
                        arg = node.args[1]
                        if isinstance(arg, ast.Constant) and isinstance(arg.value, str) \
                                and arg.value.lower().startswith("_lumo"):
                            reads.add(arg.value)
                    if node.func.id == "setattr" and len(node.args) >= 2:
                        arg = node.args[1]
                        if isinstance(arg, ast.Constant) and isinstance(arg.value, str) \
                                and arg.value.lower().startswith("_lumo"):
                            writes.add(arg.value)
        code, _ = patch_module_code((ROOT / "main_original.pyc").read_bytes())

        def walk(obj):
            for name in obj.co_names:
                if name.lower().startswith("_lumo"):
                    writes.add(name)
            for value in obj.co_consts:
                if hasattr(value, "co_names"):
                    walk(value)

        walk(code)
        self.assertEqual([], sorted(reads - writes), "Read but never written:")


class BuildFileTests(unittest.TestCase):
    def test_files_named_by_build_and_spec_exist(self):
        allowed_generated = re.compile(r"patched|Setup\.exe|^Lumo\.exe$|REPORT")
        missing = []
        for name in ("build.bat", "Lumo.spec", "Lumo_Setup.iss", "main.py"):
            text = (ROOT / name).read_text(encoding="utf-8", errors="replace")
            for ref in re.findall(r"[A-Za-z_][\w\-]*\.(?:ico|pyc|iss|ps1|spec|bat|py)\b", text):
                if allowed_generated.search(ref) or ref.startswith("Lumo_Setup"):
                    continue
                if not (ROOT / ref).exists() and not any(ROOT.rglob(ref)):
                    missing.append(f"{name}: {ref}")
        self.assertEqual([], sorted(set(missing)))

    def test_build_validates_the_new_package_files(self):
        text = (ROOT / "build.bat").read_text(encoding="utf-8")
        self.assertIn("lumo_windows\\ui_patch.py", text)


class LocationTests(unittest.TestCase):
    def test_per_user_folder_is_lumo_on_c_drive(self):
        import importlib
        settings = importlib.import_module("lumo_windows.settings")
        with tempfile.TemporaryDirectory() as tmp:
            old = dict(os.environ)
            try:
                os.environ.pop("LUMO_HOME", None)
                os.environ.pop("VIDZY_HOME", None)
                os.environ["LOCALAPPDATA"] = tmp
                if os.name != "nt":
                    self.assertEqual(Path(tmp) / "Lumo", settings._resolve_base_dir())
                    (Path(tmp) / "Vidzy").mkdir()
                    self.assertEqual(Path(tmp) / "Vidzy", settings._resolve_base_dir())
                    (Path(tmp) / "Lumo").mkdir()
                    self.assertEqual(Path(tmp) / "Lumo", settings._resolve_base_dir())
            finally:
                os.environ.clear()
                os.environ.update(old)

    def test_default_download_folder_is_lumo(self):
        for name in ("playlist_ui.py", "settings.py", "downloader.py"):
            text = (ROOT / "lumo_windows" / name).read_text(encoding="utf-8")
            for match in re.findall(r'"Videos" / "([^"]+)"', text):
                self.assertEqual("Lumo", match, name)


if __name__ == "__main__":
    unittest.main()
