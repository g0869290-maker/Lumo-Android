"""Subtitle row (English/Hindi/Marathi only, greyed when missing), quiet completion,
quality list style, and one-time progress thickness migration."""
import types
import unittest

import main as launcher


class _Chip:
    def __init__(self, parent, text, command, **kw):
        self.text = text
        self.command = command
        self.enabled = kw.get("enabled", True)
        self.selected = kw.get("selected", False)
        self.indicator = kw.get("indicator", False)

    def pack(self, **kwargs):
        pass

    def set_selected(self, value):
        self.selected = value

    def set_indicator(self, value):
        self.indicator = value


class _Holder:
    def winfo_children(self):
        return []

    def destroy(self):
        pass


class _Note:
    def __init__(self):
        self.text = ""

    def configure(self, text):
        self.text = text


def _app_class():
    class App:
        pass
    return App


class SubtitleRowTests(unittest.TestCase):
    def setUp(self):
        self.module = types.SimpleNamespace(ChoiceChip=_Chip, App=_app_class())
        launcher._install_detected_subtitles(self.module)
        self.app = self.module.App()
        self.app.subtitle_chip_holder = _Holder()
        self.app.subtitle_note = _Note()
        self.app.subtitle_selection = set()
        self.app.video_info = {"subtitle_tracks": [
            {"code": "en", "kind": "manual"},
            {"code": "hi-orig", "kind": "auto"},
        ]}

    def test_only_three_languages_are_shown_and_missing_one_is_greyed(self):
        self.app.build_subtitle_chips()
        names = [c.text for c in self.app.subtitle_chips.values()]
        self.assertEqual(names, ["English", "Hindi", "Marathi"])
        self.assertTrue(self.app.subtitle_chips["en"].enabled)
        self.assertTrue(self.app.subtitle_chips["hi"].enabled)
        self.assertFalse(self.app.subtitle_chips["mr"].enabled)
        self.assertIn("Marathi", self.app.subtitle_note.text)

    def test_selecting_shows_the_active_bar_and_greyed_chip_cannot_be_picked(self):
        self.app.build_subtitle_chips()
        self.app.toggle_subtitle("hi")
        # English is selected by default when the video has it; chips are multi-select,
        # so toggling Hindi adds it rather than replacing English.
        self.assertEqual(self.app.subtitle_selection, {"en", "hi"})
        self.assertTrue(self.app.subtitle_chips["hi"].selected)
        self.assertTrue(self.app.subtitle_chips["hi"].indicator)
        self.app.toggle_subtitle("mr")
        self.assertNotIn("mr", self.app.subtitle_selection)

    def test_missing_selection_is_dropped_on_rebuild(self):
        self.app.subtitle_selection = {"mr", "en"}
        self.app.build_subtitle_chips()
        self.assertEqual(self.app.subtitle_selection, {"en"})


class CompletionAndStyleTests(unittest.TestCase):
    def test_completion_popup_is_replaced_by_a_status_line(self):
        class App:
            def __init__(self):
                self.status = None

            def set_status(self, text, colour=None):
                self.status = text
        module = types.SimpleNamespace(App=App, GOOD="g")
        launcher._install_quiet_completion(module)
        app = App()
        app.show_completion_popup()
        self.assertIn("Download complete", app.status)

    def test_quality_list_gets_accent_selection_colour(self):
        calls = {}

        class App:
            def build_download_page(self, *a, **k):
                return "built"

            def option_add(self, key, value):
                calls[key] = value
        module = types.SimpleNamespace(App=App, CARD="#111", TEXT="#eee", ACCENT="#4f8cff")
        launcher._install_quality_list_style(module)
        app = App()
        self.assertEqual(app.build_download_page(), "built")
        self.assertEqual(calls["*TCombobox*Listbox.selectBackground"], "#4f8cff")


class ProgressThicknessMigrationTests(unittest.TestCase):
    def test_old_thickness_is_raised_once_and_flags_survive(self):
        saves = []
        stored = {"progress_thickness": 10}
        module = types.SimpleNamespace(
            load_settings=lambda: dict(stored),
            save_settings=lambda s: saves.append(dict(s)),
            GlowProgress=type("GlowProgress", (), {"__init__": lambda self, *a, **k: None}),
            glow_layer=lambda *a, **k: None,
            start_tween=lambda *a, **k: None,
        )
        launcher._install_progress_rendering_repairs(module)
        self.assertEqual(len(saves), 1)
        self.assertEqual(saves[0]["progress_thickness"], 14)
        self.assertTrue(saves[0]["progress_thickness_default_v3"])
        self.assertTrue(saves[0]["progress_thickness_default_v2"])


if __name__ == "__main__":
    unittest.main()
