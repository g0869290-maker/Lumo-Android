"""Regression tests for the Download page quality dropdown visuals.

These tests deliberately do not import tkinter, so they run on any Python 3.12
environment. They do three things:

* read the launcher source with ``ast`` and check the visual-only contract
  (no value, variable, or selection wiring is touched);
* check that every palette name the dropdown reads actually exists in the
  recovered UI bytecode (``main_original.pyc``);
* execute the real dropdown helper functions, extracted from ``main.py``,
  against a small fake Tk with its own event loop, to check the chevron state
  machine and palette choice.

They do not prove real Tk/Windows rendering. That still needs the manual checks
listed in QUALITY_DROPDOWN_FIX_REPORT.md.
"""
from __future__ import annotations

import ast
import marshal
import sys
import types
import unittest
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
MAIN_PATH = ROOT / "main.py"
ORIGINAL_PYC = ROOT / "main_original.pyc"

FUNCTION_NAMES = (
    "_install_quality_dropdown_visuals",
    "_schedule_quality_visuals",
    "_apply_quality_visuals",
    "_quality_arrow_store",
    "_style_quality_combo",
)
HELPER_NAMES = ("_is_hex_colour", "_quality_colour", "_with_quality_arrow", "_after_or_none")
CONSTANT_NAMES = ("_QUALITY_FALLBACKS", "_QUALITY_ARROW_ANGLES")
NAVY_FALLBACKS = ("#152239", "#101827", "#0F192A")


def _main_tree() -> tuple[str, ast.Module]:
    source = MAIN_PATH.read_text(encoding="utf-8")
    return source, ast.parse(source)


def _top_level_node(tree: ast.Module, name: str) -> ast.AST:
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.ClassDef)) and node.name == name:
            return node
        if isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name) and target.id == name:
                    return node
    raise AssertionError(f"{name} not found at module level in main.py")


def _segment(source: str, node: ast.AST) -> str:
    segment = ast.get_source_segment(source, node)
    assert segment is not None
    return segment


def _recovered_constants() -> tuple[set[str], set[str]]:
    """Return (string constants, hex colour constants) found in the recovered UI."""
    raw = ORIGINAL_PYC.read_bytes()
    code = marshal.loads(raw[16:])
    strings: set[str] = set()
    tuples: list[tuple] = []

    def walk(co: types.CodeType) -> None:
        for const in co.co_consts:
            if isinstance(const, str):
                strings.add(const)
            elif isinstance(const, tuple):
                tuples.append(const)
            elif isinstance(const, types.CodeType):
                walk(const)

    walk(code)
    for item in tuples:
        strings.update(v for v in item if isinstance(v, str))
    hex_colours = {s for s in strings if len(s) == 7 and s.startswith("#")}
    return strings, hex_colours


class FakeLoop:
    """A tiny deterministic scheduler standing in for Tk's after() queue."""

    def __init__(self) -> None:
        self.now = 0
        self._next_id = 0
        self._queue: list[tuple[int, int, object]] = []

    def after(self, delay_ms: int, callback) -> str:
        self._next_id += 1
        self._queue.append((self.now + int(delay_ms), self._next_id, callback))
        return f"after#{self._next_id}"

    def after_cancel(self, identifier: str) -> None:
        self._queue = [item for item in self._queue if f"after#{item[1]}" != identifier]

    def run_for(self, duration_ms: int) -> None:
        end = self.now + duration_ms
        while True:
            due = [item for item in self._queue if item[0] <= end]
            if not due:
                break
            item = min(due, key=lambda entry: (entry[0], entry[1]))
            self._queue.remove(item)
            self.now = max(self.now, item[0])
            item[2]()
        self.now = end


class FakeStyle:
    def __init__(self) -> None:
        self.configured: dict[str, dict] = {}
        self.mapped: dict[str, dict] = {}

    def configure(self, name, **options) -> None:
        self.configured.setdefault(name, {}).update(options)

    def map(self, name, **options) -> None:
        self.mapped.setdefault(name, {}).update(options)


class FakeTkRoot:
    def __init__(self, loop: FakeLoop) -> None:
        self.loop = loop
        self.popdown_mapped = False
        self.listbox_config: list[tuple] = []
        self.tk = self

    def call(self, *args):
        if args[0] == "ttk::combobox::PopdownWindow":
            return f"{args[1]}.popdown"
        if args[0] == "winfo" and args[1] == "ismapped":
            return 1 if self.popdown_mapped else 0
        if args[0] == "winfo" and args[1] == "exists":
            return 1
        if len(args) >= 2 and args[1] == "configure":
            self.listbox_config.append(args)
            return ""
        raise RuntimeError(f"unexpected Tcl call: {args}")


class FakeCombo:
    _w = ".quality"

    def __init__(self, loop: FakeLoop, root: FakeTkRoot) -> None:
        self.loop = loop
        self.root = root
        self.disabled = False
        self.style_log: list[str] = []
        self.bindings: dict[str, list] = {}

    # Tk widget surface used by the helper.
    def winfo_exists(self) -> bool:
        return True

    def winfo_toplevel(self):
        return self.root

    def configure(self, **options) -> None:
        if "style" in options:
            self.style_log.append(options["style"])

    def bind(self, sequence, handler, add=None) -> None:
        if add != "+":
            self.bindings[sequence] = [handler]
        else:
            self.bindings.setdefault(sequence, []).append(handler)

    def instate(self, states) -> bool:
        return self.disabled and "disabled" in states

    def after(self, delay_ms, callback):
        return self.loop.after(delay_ms, callback)

    def after_idle(self, callback):
        return self.loop.after(0, callback)

    def after_cancel(self, identifier):
        return self.loop.after_cancel(identifier)

    # Simulated user input, mirroring how ttk's class bindings behave.
    def _fire(self, sequence) -> None:
        for handler in list(self.bindings.get(sequence, [])):
            handler(None)

    def press(self, latency_ms: int = 40) -> None:
        self._fire("<ButtonPress-1>")  # instance bindings run before ttk's class binding
        if self.root.popdown_mapped:
            self.root.popdown_mapped = False  # clicking again unposts the popup
        elif not self.disabled:
            self.loop.after(latency_ms, lambda: setattr(self.root, "popdown_mapped", True))

    def escape(self) -> None:
        self._fire("<Escape>")
        self.root.popdown_mapped = False

    def choose_item(self) -> None:
        self.root.popdown_mapped = False
        self._fire("<<ComboboxSelected>>")

    def dismiss_outside(self) -> None:
        # The popup closes without any event on the combobox itself.
        self.root.popdown_mapped = False

    def last_style_index(self) -> int:
        return int(self.style_log[-1].split("LumoQualityArrow")[1].split(".")[0])


def _module_with(**palette):
    return SimpleNamespace(**palette)


class QualityDropdownContractTests(unittest.TestCase):
    """Static checks that the visuals do not touch the selection contract."""

    @classmethod
    def setUpClass(cls) -> None:
        cls.source, cls.tree = _main_tree()
        cls.quality_nodes = [_top_level_node(cls.tree, name) for name in FUNCTION_NAMES]

    def _all_calls(self):
        for node in self.quality_nodes:
            for sub in ast.walk(node):
                if isinstance(sub, ast.Call):
                    yield sub

    def test_visuals_never_change_values_variables_or_selection(self) -> None:
        forbidden_keywords = {"values", "textvariable", "variable", "command", "state"}
        forbidden_methods = {"set", "current", "delete", "insert", "set_menu", "pack", "grid", "place"}
        for call in self._all_calls():
            if isinstance(call.func, ast.Attribute):
                method = call.func.attr
                self.assertNotIn(method, forbidden_methods, f"quality visuals call .{method}()")
                if method == "configure":
                    keys = {kw.arg for kw in call.keywords}
                    self.assertFalse(
                        keys & forbidden_keywords,
                        f"quality visuals configure() touches {keys & forbidden_keywords}",
                    )

    def test_every_widget_binding_is_additive(self) -> None:
        bind_calls = [c for c in self._all_calls()
                      if isinstance(c.func, ast.Attribute) and c.func.attr == "bind"]
        self.assertGreaterEqual(len(bind_calls), 4)
        for call in bind_calls:
            add = [kw for kw in call.keywords if kw.arg == "add"]
            self.assertTrue(add, "bind() without add= would replace the app's own binding")
            self.assertIsInstance(add[0].value, ast.Constant)
            self.assertEqual(add[0].value.value, "+")

    def test_no_navy_fallbacks_remain(self) -> None:
        for name in FUNCTION_NAMES + HELPER_NAMES + CONSTANT_NAMES:
            text = _segment(self.source, _top_level_node(self.tree, name))
            for colour in NAVY_FALLBACKS:
                self.assertNotIn(colour, text, f"{name} still uses navy fallback {colour}")

    @unittest.skipUnless(sys.version_info[:2] == (3, 12), "recovered UI bytecode is Python 3.12")
    def test_every_palette_name_read_by_the_visuals_exists_in_recovered_ui(self) -> None:
        strings, _ = _recovered_constants()
        read_names: set[str] = set()
        for node in self.quality_nodes + [_top_level_node(self.tree, n) for n in HELPER_NAMES]:
            for sub in ast.walk(node):
                if (isinstance(sub, ast.Call) and isinstance(sub.func, ast.Name)
                        and sub.func.id == "getattr" and len(sub.args) >= 2
                        and isinstance(sub.args[1], ast.Constant)
                        and isinstance(sub.args[1].value, str)
                        and sub.args[1].value.isupper()):
                    read_names.add(sub.args[1].value)
                if (isinstance(sub, ast.Call) and isinstance(sub.func, ast.Name)
                        and sub.func.id == "_quality_colour" and len(sub.args) >= 2
                        and isinstance(sub.args[1], ast.Constant)):
                    read_names.add(sub.args[1].value)
        self.assertTrue({"ACCENT", "CARD_ALT", "CARD", "TEXT", "MUTED"} <= read_names)
        missing = sorted(name for name in read_names if name not in strings)
        self.assertEqual(missing, [], f"palette names the recovered UI never defines: {missing}")

    @unittest.skipUnless(sys.version_info[:2] == (3, 12), "recovered UI bytecode is Python 3.12")
    def test_fallback_colours_are_the_recovered_dark_palette(self) -> None:
        _, hex_colours = _recovered_constants()
        for key, value in {"CARD_ALT": "#15171E", "CARD": "#0E0F14"}.items():
            self.assertIn(value, hex_colours, f"{key} fallback {value} is not in the recovered palette")
        self.assertIn("#15171E", hex_colours)

    def test_install_hook_chains_on_build_download_page_and_is_idempotent(self) -> None:
        install = _top_level_node(self.tree, "_install_quality_dropdown_visuals")
        text = _segment(self.source, install)
        self.assertIn("app_class.build_download_page = build_download_with_quality_visuals", text)
        self.assertIn("_lumo_quality_visuals_installed", text)
        self.assertNotIn("app_class.__init__", text)

    def test_run_installs_quality_visuals_after_other_hooks(self) -> None:
        run = _top_level_node(self.tree, "run")
        calls = [n.value.func.id for n in run.body
                 if isinstance(n, ast.Expr) and isinstance(n.value, ast.Call)
                 and isinstance(n.value.func, ast.Name)]
        self.assertIn("_install_quality_dropdown_visuals", calls)
        # The quality hook wraps build_download_page, so it must run after the
        # pause-button hook that also wraps it.
        self.assertLess(calls.index("_install_global_pause_resume"),
                        calls.index("_install_quality_dropdown_visuals"))


class _HelperLoader:
    """Execute the pure helper functions from main.py without importing tkinter."""

    @staticmethod
    def load(names):
        source, tree = _main_tree()
        pieces = ["from __future__ import annotations", "from typing import Any",
                  "from types import ModuleType"]
        for name in CONSTANT_NAMES + HELPER_NAMES + tuple(names):
            pieces.append(_segment(source, _top_level_node(tree, name)))
        namespace: dict = {}
        exec("\n\n".join(pieces), namespace)  # noqa: S102 - trusted local source file
        return namespace


class PaletteSelectionTests(unittest.TestCase):

    @classmethod
    def setUpClass(cls) -> None:
        cls.ns = _HelperLoader.load(())

    def test_live_palette_value_wins(self) -> None:
        module = _module_with(CARD_ALT="#222222", CARD="#111111", TEXT="#FFFFFF", MUTED="#888888",
                              ACCENT="#8871FF")
        self.assertEqual(self.ns["_quality_colour"](module, "CARD_ALT"), "#222222")

    def test_missing_names_fall_back_to_dark_palette_not_navy(self) -> None:
        module = _module_with()  # the recovered UI defines none of these yet
        self.assertEqual(self.ns["_quality_colour"](module, "CARD_ALT"), "#15171E")
        self.assertEqual(self.ns["_quality_colour"](module, "CARD"), "#0E0F14")

    def test_invalid_values_are_rejected(self) -> None:
        module = _module_with(CARD_ALT="not-a-colour", CARD=None)
        self.assertEqual(self.ns["_quality_colour"](module, "CARD_ALT"), "#15171E")
        self.assertEqual(self.ns["_quality_colour"](module, "CARD"), "#0E0F14")

    def test_arrow_layout_rewrite_replaces_nested_downarrow_only(self) -> None:
        layout = [("Combobox.field", {"children": [
            ("Combobox.downarrow", {"side": "right", "sticky": "ns"}),
            ("Combobox.padding", {"children": [("Combobox.textarea", {})]}),
        ]})]
        rewritten = self.ns["_with_quality_arrow"](layout, "LumoQuality.downarrow.3")
        children = rewritten[0][1]["children"]
        self.assertEqual(children[0][0], "LumoQuality.downarrow.3")
        self.assertEqual(children[0][1], {"side": "right", "sticky": "ns"})
        self.assertEqual(children[1][0], "Combobox.padding")
        self.assertEqual(children[1][1]["children"][0][0], "Combobox.textarea")
        # The input layout must not be mutated.
        self.assertEqual(layout[0][1]["children"][0][0], "Combobox.downarrow")


class ChevronBehaviourTests(unittest.TestCase):
    """Runs the real _style_quality_combo against a fake Tk event loop."""

    STYLE_FULLY_UP = "LumoQualityArrow6.TCombobox"
    STYLE_DOWN = "LumoQualityArrow0.TCombobox"

    @classmethod
    def setUpClass(cls) -> None:
        cls.ns = _HelperLoader.load(("_style_quality_combo",))
        cls.module = _module_with(ACCENT="#8871FF", CARD_ALT="#15171E", CARD="#0E0F14",
                                  TEXT="#F4F6FB", MUTED="#9AA4B5")

    def _build(self, arrow_ready: bool = True):
        loop = FakeLoop()
        root = FakeTkRoot(loop)
        combo = FakeCombo(loop, root)
        style = FakeStyle()
        names = [f"LumoQualityArrow{i}.TCombobox" for i in range(7)]
        store = {"style_names": names, "custom": arrow_ready, "images": []}
        # Simulate the recovered app's own binding, which must survive.
        selection_handler = lambda _e=None: None  # noqa: E731 - stands in for App._quality_changed
        combo.bind("<<ComboboxSelected>>", selection_handler)
        self.ns["_style_quality_combo"](combo, style, store, self.module)
        return loop, root, combo, style, selection_handler

    def test_chevron_rises_when_popup_opens_and_falls_when_it_closes(self) -> None:
        loop, root, combo, _style, _sel = self._build()
        combo.press()
        loop.run_for(400)
        self.assertTrue(root.popdown_mapped)
        self.assertEqual(combo.style_log[-1], self.STYLE_FULLY_UP)
        combo.press()  # second click closes the popup
        loop.run_for(400)
        self.assertFalse(root.popdown_mapped)
        self.assertEqual(combo.style_log[-1], self.STYLE_DOWN)

    def test_chevron_falls_after_outside_dismiss_without_any_combobox_event(self) -> None:
        loop, root, combo, _style, _sel = self._build()
        combo.press()
        loop.run_for(400)
        self.assertEqual(combo.style_log[-1], self.STYLE_FULLY_UP)
        combo.dismiss_outside()  # no press, no focus change on the combobox
        loop.run_for(400)
        self.assertEqual(combo.style_log[-1], self.STYLE_DOWN)

    def test_disabled_combobox_never_raises_the_chevron(self) -> None:
        loop, root, combo, _style, _sel = self._build()
        combo.disabled = True
        combo.press()
        loop.run_for(400)
        self.assertFalse(root.popdown_mapped)
        self.assertNotIn(self.STYLE_FULLY_UP, combo.style_log)

    def test_choosing_an_item_collapses_the_chevron_and_keeps_the_app_handler(self) -> None:
        loop, root, combo, _style, selection_handler = self._build()
        combo.press()
        loop.run_for(400)
        combo.choose_item()
        loop.run_for(400)
        self.assertEqual(combo.style_log[-1], self.STYLE_DOWN)
        self.assertIn(selection_handler, combo.bindings["<<ComboboxSelected>>"])
        self.assertGreaterEqual(len(combo.bindings["<<ComboboxSelected>>"]), 2)

    def test_escape_collapses_the_chevron(self) -> None:
        loop, root, combo, _style, _sel = self._build()
        combo.press()
        loop.run_for(400)
        combo.escape()
        loop.run_for(400)
        self.assertEqual(combo.style_log[-1], self.STYLE_DOWN)

    def test_slow_popup_mapping_still_raises_the_chevron(self) -> None:
        loop, root, combo, _style, _sel = self._build()
        combo.press(latency_ms=150)  # popup maps well after the first check
        loop.run_for(600)
        self.assertTrue(root.popdown_mapped)
        self.assertEqual(combo.style_log[-1], self.STYLE_FULLY_UP)

    def test_popup_listbox_gets_the_dark_palette_when_it_opens(self) -> None:
        loop, root, combo, _style, _sel = self._build()
        combo.press()
        loop.run_for(200)
        listbox_calls = [c for c in root.listbox_config if c[0].endswith(".f.l")]
        self.assertTrue(listbox_calls, "popup listbox was never styled")
        flat = list(listbox_calls[-1])
        self.assertEqual(flat[flat.index("-background") + 1], "#15171E")
        self.assertEqual(flat[flat.index("-foreground") + 1], "#F4F6FB")

    def test_combobox_and_style_use_the_dark_palette(self) -> None:
        _loop, _root, _combo, style, _sel = self._build()
        configured = style.configured["LumoQualityArrow0.TCombobox"]
        self.assertEqual(configured["fieldbackground"], "#15171E")
        self.assertEqual(configured["background"], "#0E0F14")
        self.assertEqual(configured["selectbackground"], "#8871FF")

    def test_without_custom_layout_no_arrow_animation_runs_and_nothing_breaks(self) -> None:
        loop, root, combo, _style, _sel = self._build(arrow_ready=False)
        combo.press()
        loop.run_for(400)
        self.assertTrue(root.popdown_mapped)
        self.assertEqual(combo.style_log, [self.STYLE_DOWN])


if __name__ == "__main__":
    if sys.version_info[:2] != (3, 12):
        print("Run with Python 3.12: the recovered UI bytecode is 3.12-specific.")
    unittest.main()
