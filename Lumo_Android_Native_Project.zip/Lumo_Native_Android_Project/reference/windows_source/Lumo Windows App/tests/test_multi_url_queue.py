from __future__ import annotations

import importlib.util
import sys
import types
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def load_launcher():
    spec = importlib.util.spec_from_file_location("lumo_multi_queue_launcher_test", ROOT / "main.py")
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


class FakeVar:
    def __init__(self, value=""):
        self.value = value
    def get(self):
        return self.value
    def set(self, value):
        self.value = value


class FakeWidget:
    def __init__(self, master=None, text="", command=None, **kwargs):
        self.master = master
        self.text = text
        self.label = text
        self.command = command
        self.kwargs = dict(kwargs)
        self.children = []
        self.values = kwargs.get("values", ())
        self.state = kwargs.get("state", "normal")
        if master is not None and hasattr(master, "children"):
            master.children.append(self)
    def pack(self, **kwargs):
        self.pack_kwargs = kwargs
    def configure(self, **kwargs):
        self.kwargs.update(kwargs)
        if "state" in kwargs:
            self.state = kwargs["state"]
        if "text" in kwargs:
            self.text = kwargs["text"]
            self.label = kwargs["text"]
    config = configure
    def destroy(self):
        self.destroyed = True
    def cget(self, key):
        return self.values if key == "values" else self.kwargs.get(key)


class FakeSoftButton(FakeWidget):
    def __init__(self, master, text, command, *_style_size, **kwargs):
        super().__init__(master=master, text=text, command=command, **kwargs)


class FakeEntry(FakeWidget):
    def __init__(self, master=None, value=""):
        super().__init__(master)
        self.value = value
        self.focused = False
    def get(self):
        return self.value
    def delete(self, _start, _end=None):
        self.value = ""
    def insert(self, _index, value):
        self.value = str(value)
    def focus_set(self):
        self.focused = True


class FakeApp:
    def __init__(self):
        self.content = FakeWidget()
        self.pages = {"download": self.content}
        self.url_row = FakeWidget(master=self.content)
        self.stage_area = FakeWidget(master=self.content)
        self.url_entry = FakeEntry(master=self.url_row)
        self.quality_var = FakeVar("Best available")
        self.quality_combo = FakeWidget(values=("Best available", "1080p", "720p"))
        self.active_job_id = None
        self.stage = "idle"
        self.video_info = None
        self.scheduled = []
        self.inspect_urls = []
        self.started_urls = []
        self.log_messages = []
        self.showed_page = None
    def build_download_page(self):
        return "built"
    def handle_event(self, kind, payload):
        if kind == "inspected":
            if payload.get("error"):
                self.stage = "error"
                self.video_info = None
            else:
                self.stage = "quality"
                self.video_info = payload.get("info", {"title": "video"})
        elif kind == "done":
            self.active_job_id = None
            self.stage = "complete"
        elif kind == "error":
            self.active_job_id = None
            self.stage = "error"
        return (kind, payload)
    def after(self, delay, callback):
        self.scheduled.append((delay, callback))
        return len(self.scheduled)
    def after_idle(self, callback):
        self.scheduled.append((0, callback))
        return len(self.scheduled)
    def new_download(self):
        self.active_job_id = None
        self.video_info = None
        self.stage = "idle"
        self.url_entry.delete(0, "end")
        self.show_page("download")
    def inspect(self):
        self.inspect_urls.append(self.url_entry.get())
        self.stage = "loading"
    def start_download(self):
        self.started_urls.append(self.url_entry.get())
        self.active_job_id = f"job-{len(self.started_urls)}"
        self.stage = "active"
    def show_page(self, page):
        self.showed_page = page


def _make_launcher():
    launcher = load_launcher()
    launcher.tk = types.SimpleNamespace(Frame=FakeWidget, Label=FakeWidget)
    module = types.SimpleNamespace(
        App=FakeApp,
        tk=types.SimpleNamespace(Frame=FakeWidget, Label=FakeWidget),
        SoftButton=FakeSoftButton,
        BG="#0E0F14", TEXT="#F4F6FB", MUTED="#9AA4B5",
        log_line=lambda message: None,
    )
    launcher._install_multi_url_queue(module)
    return launcher, module


def _drain(app, limit=20):
    count = 0
    while app.scheduled and count < limit:
        _delay, callback = app.scheduled.pop(0)
        callback()
        count += 1
    if app.scheduled:
        raise AssertionError("scheduled callbacks did not settle")


@unittest.skip("multi-URL queue installer (_install_multi_url_queue) is not part of this main.py")
class MultiURLQueueTests(unittest.TestCase):
    def _ready_app(self):
        _launcher, module = _make_launcher()
        app = module.App()
        app.build_download_page()
        return app

    def test_next_collects_and_clears_url_without_starting_download(self):
        app = self._ready_app()
        first = "https://example.test/video-1"
        app.url_entry.insert(0, first)
        app._lumo_multi_next_button.command()
        self.assertEqual(app._lumo_multi_queue_urls, [first])
        self.assertEqual(app.url_entry.get(), "")
        self.assertEqual(app.inspect_urls, [])
        self.assertEqual(app.started_urls, [])
        self.assertIn("1 URL(s) saved", app._lumo_multi_url_label.text)

    def test_done_downloads_collected_urls_sequentially_via_existing_methods(self):
        app = self._ready_app()
        first = "https://example.test/video-1"
        second = "https://example.test/video-2"
        app.url_entry.insert(0, first)
        app._lumo_multi_next_button.command()
        app.url_entry.insert(0, second)
        app._lumo_multi_done_button.command()
        self.assertEqual(app.inspect_urls, [first])
        self.assertTrue(app._lumo_multi_queue_active)
        self.assertEqual(app._lumo_multi_queue_total, 2)
        self.assertEqual(app._lumo_multi_next_button.state, "disabled")

        app.handle_event("inspected", {"info": {"title": "first"}})
        _drain(app)
        self.assertEqual(app.started_urls, [first])
        app.handle_event("done", {"file_path": "first.mp4"})
        _drain(app)
        self.assertEqual(app.inspect_urls, [first, second])

        app.handle_event("inspected", {"info": {"title": "second"}})
        _drain(app)
        self.assertEqual(app.started_urls, [first, second])
        app.handle_event("done", {"file_path": "second.mp4"})
        _drain(app)
        self.assertFalse(app._lumo_multi_queue_active)
        self.assertEqual(app._lumo_multi_queue_completed, 2)
        self.assertIn("Queue finished · 2/2 completed", app._lumo_multi_url_label.text)
        self.assertEqual(app._lumo_multi_next_button.state, "normal")

    def test_failed_inspection_advances_to_the_next_url(self):
        app = self._ready_app()
        first = "https://example.test/bad-video"
        second = "https://example.test/good-video"
        app.url_entry.insert(0, first)
        app._lumo_multi_next_button.command()
        app.url_entry.insert(0, second)
        app._lumo_multi_done_button.command()
        app.handle_event("inspected", {"error": "unavailable"})
        _drain(app)
        self.assertEqual(app._lumo_multi_queue_failed, 1)
        self.assertEqual(app.inspect_urls, [first, second])
        app.handle_event("inspected", {"info": {"title": "good"}})
        _drain(app)
        self.assertEqual(app.started_urls, [second])
        app.handle_event("done", {"file_path": "good.mp4"})
        _drain(app)
        self.assertFalse(app._lumo_multi_queue_active)
        self.assertIn("1/2 completed, 1 failed", app._lumo_multi_url_label.text)

    def test_invalid_url_is_not_added(self):
        app = self._ready_app()
        app.url_entry.insert(0, "not-a-url")
        app._lumo_multi_next_button.command()
        self.assertEqual(app._lumo_multi_queue_urls, [])
        self.assertEqual(app.url_entry.get(), "not-a-url")
        self.assertIn("full HTTPS", app._lumo_multi_url_label.text)

    def test_single_url_download_path_is_not_replaced(self):
        _launcher, module = _make_launcher()
        app = module.App()
        original_start = app.start_download
        self.assertTrue(callable(original_start))
        self.assertEqual(app._lumo_multi_queue_urls if hasattr(app, "_lumo_multi_queue_urls") else [], [])
        self.assertEqual(app.start_download.__func__, FakeApp.start_download)


if __name__ == "__main__":
    unittest.main()
