from __future__ import annotations
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

from lumo_windows.playlist_ui import _cookie_path


class LiveCookieSettingsTests(unittest.TestCase):
    def test_cookie_path_uses_live_app_settings(self):
        with tempfile.TemporaryDirectory() as temporary:
            cookie = Path(temporary) / "cookies.txt"
            cookie.write_text("# Netscape HTTP Cookie File\n", encoding="utf-8")
            app = SimpleNamespace(settings={"use_cookies": True, "cookie_file": str(cookie)})
            self.assertEqual(_cookie_path({"use_cookies": False, "cookie_file": ""}, app),
                             str(cookie.resolve()))

    def test_cookie_path_ignores_missing_or_disabled_file(self):
        with tempfile.TemporaryDirectory() as temporary:
            missing = Path(temporary) / "missing.txt"
            self.assertIsNone(_cookie_path({"use_cookies": True, "cookie_file": str(missing)}))
            cookie = Path(temporary) / "cookies.txt"
            cookie.write_text("cookies", encoding="utf-8")
            self.assertIsNone(_cookie_path({"use_cookies": False, "cookie_file": str(cookie)}))


if __name__ == "__main__":
    unittest.main()
