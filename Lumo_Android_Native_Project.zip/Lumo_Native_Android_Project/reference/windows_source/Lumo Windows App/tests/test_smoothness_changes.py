"""Smoothness changes: cheaper download-controls repair and the resize-aware glow bar.

Uses small fake widgets only (no Tk window is created).
"""
import time
import types
import unittest

import main as launcher


class FakeWidget:
    visits = {}

    def __init__(self, name, text="", children=()):
        self.name, self._text, self._children = name, text, list(children)
        self.command = None

    def winfo_children(self):
        FakeWidget.visits[self.name] = FakeWidget.visits.get(self.name, 0) + 1
        return self._children

    def cget(self, key):
        if key == "text":
            return self._text
        raise Exception("no such option")

    def configure(self, **kwargs):
        if "command" in kwargs:
            self.command = kwargs["command"]

    def bind(self, *args, **kwargs):
        pass


class RepairDownloadControlsTests(unittest.TestCase):
    def setUp(self):
        FakeWidget.visits = {}
        self.paste = FakeWidget("paste", "Paste")
        self.cont = FakeWidget("cont", "Continue  \u2192")
        self.stage = FakeWidget("stage", "", [self.cont])
        self.download = FakeWidget("download", "", [self.paste, self.stage])
        self.history = FakeWidget("history", "", [
            FakeWidget(f"hist{i}", "", [FakeWidget(f"hist{i}_{j}", "x") for j in range(5)])
            for i in range(40)])
        self.settings = FakeWidget("settings", "", [FakeWidget(f"set{i}", "y") for i in range(30)])
        self.content = FakeWidget("content", "", [self.download, self.history, self.settings])
        app = FakeWidget("app", "", [self.content])
        app.pages = {"download": self.download, "history": self.history, "settings": self.settings}
        app.content, app.stage_area = self.content, self.stage
        app.url_entry = None
        app.quality_combo = None
        app.paste_url = lambda: "paste"
        app.continue_to_extras = lambda: "continue"
        self.app = app
        self._saved = (launcher._apply_quality_visuals, launcher._bind_enter_to_continue,
                       launcher._set_runtime_button_command)
        launcher._apply_quality_visuals = lambda *a, **k: None
        launcher._bind_enter_to_continue = lambda *a, **k: None
        launcher._set_runtime_button_command = lambda w, cb: (setattr(w, "command", cb), True)[1]

    def tearDown(self):
        (launcher._apply_quality_visuals, launcher._bind_enter_to_continue,
         launcher._set_runtime_button_command) = self._saved

    def test_paste_and_continue_are_still_bound(self):
        launcher._repair_download_controls(self.app, types.SimpleNamespace(_LUMO_PROGRESS_OPTIONS={}))
        self.assertIs(self.paste.command, self.app.paste_url)
        self.assertIs(self.cont.command, self.app.continue_to_extras)

    def test_history_and_settings_are_not_scanned(self):
        launcher._repair_download_controls(self.app, types.SimpleNamespace(_LUMO_PROGRESS_OPTIONS={}))
        scanned = [n for n in FakeWidget.visits if n.startswith(("hist", "set"))]
        self.assertEqual(scanned, [])

    def test_each_download_widget_is_walked_once(self):
        launcher._repair_download_controls(self.app, types.SimpleNamespace(_LUMO_PROGRESS_OPTIONS={}))
        for name in ("content", "download", "stage"):
            self.assertEqual(FakeWidget.visits.get(name), 1, name)


class GlowAnimationResizeTests(unittest.TestCase):
    def make_class(self):
        calls = {"original": 0}

        class Glow:
            active = True

            def __init__(self, app):
                self._app = app
                self.scheduled = []
                self._after_id = None

            def winfo_toplevel(self):
                return self._app

            def winfo_viewable(self):
                return True

            def after(self, ms, fn):
                self.scheduled.append(ms)
                return "id"

            def animate(self):
                calls["original"] += 1

        return Glow, calls

    def test_glow_holds_during_resize_and_resumes_after(self):
        Glow, calls = self.make_class()
        launcher._install_hidden_animation_pause(types.SimpleNamespace(GlowProgress=Glow))
        app = types.SimpleNamespace(pages={}, current_display_page="download")
        glow = Glow(app)
        app._lumo_resizing_until = time.monotonic() + 5
        glow.animate()
        self.assertEqual(calls["original"], 0)       # held while resizing
        self.assertEqual(glow.scheduled, [60])       # and it keeps polling
        app._lumo_resizing_until = 0.0
        glow.animate()
        self.assertEqual(calls["original"], 1)       # normal animation resumes


if __name__ == "__main__":
    unittest.main()
