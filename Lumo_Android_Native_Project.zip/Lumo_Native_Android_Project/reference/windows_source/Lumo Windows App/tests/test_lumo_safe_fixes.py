from __future__ import annotations

import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from lumo_windows import downloader
from lumo_windows.downloader import DownloadJob


class ClearLinkBehaviourTests(unittest.TestCase):
    def test_clear_control_only_clears_link_and_restores_focus(self):
        from main import _clear_url_with_animation

        class FakeEntry:
            def __init__(self):
                self.deleted = False
                self.focused = False
            def delete(self, start, end):
                self.deleted = (start, end) == (0, "end")
            def focus_set(self):
                self.focused = True

        entry = FakeEntry()
        app = SimpleNamespace()
        _clear_url_with_animation(app, entry, object())
        self.assertTrue(entry.deleted)
        self.assertTrue(entry.focused)


class SubtitleLanguageResolutionTests(unittest.TestCase):
    def test_manual_track_is_used_for_its_language_and_auto_track_for_the_rest(self):
        # Each selected language resolves to a track the video really has. A language
        # with only an automatic caption (Hindi here) keeps its own track instead of
        # being replaced by the manual English one.
        info = {"subtitles": {"en": [{}]}, "automatic_captions": {"hi-IN": [{}]}}
        self.assertEqual(downloader._resolve_subtitle_languages(["en-US", "hi"], info), ["en", "hi-IN"])

    def test_automatic_track_is_used_when_no_manual_track_exists_for_that_language(self):
        info = {"subtitles": {}, "automatic_captions": {"hi-IN": [{}], "en-US": [{}]}}
        self.assertEqual(downloader._resolve_subtitle_languages(["en", "hi"], info), ["en-US", "hi-IN"])

    def test_known_empty_subtitle_metadata_drops_unavailable_selection(self):
        info = {"subtitles": {}, "automatic_captions": {}}
        self.assertEqual(downloader._resolve_subtitle_languages(["en"], info), [])

    def test_keeps_exact_track_when_available(self):
        info = {"subtitles": {"en": [{}], "en-US": [{}]}}
        self.assertEqual(downloader._resolve_subtitle_languages(["en-US"], info), ["en-US"])

    def test_rejects_invalid_language_selector(self):
        self.assertEqual(downloader._resolve_subtitle_languages(["en", "../bad", ""], {}), ["en"])


class SubtitleEmbeddingOptionsTests(unittest.TestCase):
    def test_selected_subtitles_enable_embedding_without_burning_in(self):
        seen = {}

        class FakeYoutubeDL:
            def __init__(self, options):
                seen.update(options)
            def __enter__(self):
                return self
            def __exit__(self, exc_type, exc, traceback):
                return False

        with tempfile.TemporaryDirectory() as temporary:
            video = Path(temporary) / "sample.mp4"
            video.write_bytes(b"test video placeholder")
            job = DownloadJob("https://example.com/video", temporary, subtitle_langs=["en"])
            info = {"title": "sample", "height": 720, "requested_subtitles": {"en": {"ext": "srt"}}}
            fake_yt_dlp = SimpleNamespace(YoutubeDL=FakeYoutubeDL)
            with patch.object(downloader, "_yt_dlp", return_value=fake_yt_dlp), \
                 patch.object(downloader, "_js_runtime_options", return_value=({}, "test runtime")), \
                 patch.object(downloader, "_cookie_option", return_value={}), \
                 patch.object(job, "_make_progress_hook", return_value=lambda _data: None), \
                 patch.object(job, "_download_with", return_value=info), \
                 patch.object(job, "_find_output", return_value=str(video)), \
                 patch.object(downloader, "_subtitle_stream_count", return_value=1):
                result = job.run()

        self.assertEqual(result["status"], "Completed")
        self.assertTrue(seen["embedsubtitles"])
        self.assertTrue(seen["writesubtitles"])
        self.assertTrue(seen["writeautomaticsubtitles"])
        self.assertEqual(seen["subtitleslangs"], ["en"])

    def test_no_subtitle_selection_does_not_enable_embedding(self):
        seen = {}

        class FakeYoutubeDL:
            def __init__(self, options):
                seen.update(options)
            def __enter__(self):
                return self
            def __exit__(self, exc_type, exc, traceback):
                return False

        with tempfile.TemporaryDirectory() as temporary:
            video = Path(temporary) / "sample.mp4"
            video.write_bytes(b"test video placeholder")
            job = DownloadJob("https://example.com/video", temporary)
            fake_yt_dlp = SimpleNamespace(YoutubeDL=FakeYoutubeDL)
            with patch.object(downloader, "_yt_dlp", return_value=fake_yt_dlp), \
                 patch.object(downloader, "_js_runtime_options", return_value=({}, "test runtime")), \
                 patch.object(downloader, "_cookie_option", return_value={}), \
                 patch.object(job, "_make_progress_hook", return_value=lambda _data: None), \
                 patch.object(job, "_download_with", return_value={"title": "sample", "height": 720}), \
                 patch.object(job, "_find_output", return_value=str(video)):
                result = job.run()

        self.assertEqual(result["status"], "Completed")
        self.assertFalse(seen["writesubtitles"])
        self.assertFalse(seen["writeautomaticsubtitles"])
        self.assertNotIn("embedsubtitles", seen)


if __name__ == "__main__":
    unittest.main()
