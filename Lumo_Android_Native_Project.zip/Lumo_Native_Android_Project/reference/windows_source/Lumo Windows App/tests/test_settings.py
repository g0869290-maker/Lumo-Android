from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

from lumo_windows import settings


class SettingsRegressionTests(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.old_data_dir = settings.DATA_DIR
        self.old_settings_file = settings.SETTINGS_FILE
        settings.DATA_DIR = Path(self.tmp.name)
        settings.SETTINGS_FILE = settings.DATA_DIR / "settings.json"

    def tearDown(self) -> None:
        settings.DATA_DIR = self.old_data_dir
        settings.SETTINGS_FILE = self.old_settings_file
        self.tmp.cleanup()

    def test_defaults_include_visual_settings_and_preferred_subtitle(self) -> None:
        loaded = settings.load_settings()
        self.assertEqual(loaded["appearance"], "Dark")
        self.assertIn("accent", loaded)
        self.assertIn("indicator", loaded)
        self.assertIn("preferred_subtitle", loaded)

    def test_custom_accent_and_indicator_survive_save_and_restart(self) -> None:
        candidate = settings.load_settings()
        candidate["appearance"] = "Dark"
        candidate["accent"] = "#12ab34"
        candidate["indicator"] = "#fedcba"
        candidate["preferred_subtitle"] = "hi"
        settings.save_settings(candidate)

        # Simulate a fresh application startup by loading from disk again.
        loaded = settings.load_settings()
        self.assertEqual(loaded["accent"], "#12AB34")
        self.assertEqual(loaded["indicator"], "#FEDCBA")
        self.assertEqual(loaded["appearance"], "Dark")
        self.assertEqual(loaded["preferred_subtitle"], "hi")

    def test_legacy_light_value_is_normalised_to_dark(self) -> None:
        settings.DATA_DIR.mkdir(parents=True, exist_ok=True)
        settings.SETTINGS_FILE.write_text(
            json.dumps({"appearance": "Light", "accent": "#AA22CC", "indicator": "#33BB44"}),
            encoding="utf-8",
        )
        loaded = settings.load_settings()
        self.assertEqual(loaded["appearance"], "Dark")
        self.assertEqual(loaded["accent"], "#AA22CC")
        self.assertEqual(loaded["indicator"], "#33BB44")

    def test_invalid_colour_values_fall_back_without_crashing(self) -> None:
        settings.DATA_DIR.mkdir(parents=True, exist_ok=True)
        settings.SETTINGS_FILE.write_text(
            json.dumps({"accent": "not-a-colour", "indicator": 123}), encoding="utf-8"
        )
        loaded = settings.load_settings()
        self.assertEqual(loaded["accent"], settings.DEFAULTS["accent"])
        self.assertEqual(loaded["indicator"], settings.DEFAULTS["indicator"])

    def test_unknown_fields_and_wrong_types_do_not_corrupt_settings(self) -> None:
        settings.DATA_DIR.mkdir(parents=True, exist_ok=True)
        settings.SETTINGS_FILE.write_text(
            json.dumps({"download_dir": ["wrong type"], "accent": "#abcdef", "future": True}),
            encoding="utf-8",
        )
        loaded = settings.load_settings()
        self.assertEqual(loaded["download_dir"], settings.DEFAULTS["download_dir"])
        self.assertEqual(loaded["accent"], "#ABCDEF")
        self.assertNotIn("future", loaded)


if __name__ == "__main__":
    unittest.main()
