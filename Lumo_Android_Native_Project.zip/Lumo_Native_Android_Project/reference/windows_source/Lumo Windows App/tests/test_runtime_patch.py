from __future__ import annotations

import unittest
from types import ModuleType

import main as launcher


class _Var:
    def __init__(self, value: str = "Light") -> None:
        self.value = value

    def set(self, value: str) -> None:
        self.value = value


class _FakeApp:
    def __init__(self) -> None:
        self.appearance_var = _Var()
        self.saved = False
        self.choices = None
        self.notified = False

    def _chip_group(self, parent, choices, variable=None, *args, **kwargs):
        self.choices = choices
        return choices

    def save_app_settings(self):
        self.saved = True
        return self.appearance_var.value

    def _notify(self, *args, **kwargs):
        self.notified = True

    def show_toast(self, *args, **kwargs):
        self.notified = True

    def show_completion_popup(self, *args, **kwargs):
        self.notified = True


class RuntimePatchTests(unittest.TestCase):
    def test_dark_palette_wrapper_forces_dark_without_touching_colours(self) -> None:
        module = ModuleType("fake_original")
        calls = []
        module.apply_palette = lambda appearance, accent, indicator: calls.append((appearance, accent, indicator))
        module.App = _FakeApp
        launcher._install_repairs(module)
        module.apply_palette("Light", "#112233", "#445566")
        self.assertEqual(calls, [("Dark", "#112233", "#445566")])

    def test_light_chip_is_filtered_but_dark_chip_is_retained(self) -> None:
        module = ModuleType("fake_original")
        module.apply_palette = lambda *args: None
        module.App = _FakeApp
        launcher._install_repairs(module)
        app = module.App()
        result = app._chip_group("parent", [("Dark", "Dark"), ("Light", "Light")], None)
        self.assertEqual(result, [("Dark", "Dark")])

    def test_notifications_are_preserved_and_save_forces_dark(self) -> None:
        module = ModuleType("fake_original")
        module.apply_palette = lambda *args: None
        module.App = _FakeApp
        launcher._install_repairs(module)
        app = module.App()
        self.assertEqual(app.save_app_settings(), "Dark")
        self.assertTrue(app.saved)
        self.assertEqual(app.appearance_var.value, "Dark")
        app._notify("title", "message")
        app.show_toast("title", "message", "warn")
        app.show_completion_popup()
        self.assertTrue(app.notified, "download success/error notifications must remain available")

    def test_progress_constructor_adds_the_six_pixel_canvas_inset(self) -> None:
        module = ModuleType("fake_progress_thickness")
        seen = []

        class GlowProgress:
            def __init__(self, parent=None, height=5):
                seen.append(height)
                self.height = height

            def draw_content(self, width, height):
                return "ACCENT CYAN"

        module.GlowProgress = GlowProgress
        module.load_settings = lambda: {"progress_thickness": 14}
        module.start_tween = lambda *args, **kwargs: None
        module.glow_layer = lambda *args, **kwargs: None
        launcher._install_progress_rendering_repairs(module)
        GlowProgress(parent=None)
        self.assertEqual(seen, [20], "14 px fill plus 3 px inset on each side requires a 20 px canvas")

    def test_progress_tween_fallback_does_not_change_other_animation_easing(self) -> None:
        module = ModuleType("fake_progress")
        seen = []

        class GlowProgress:
            def __init__(self, parent=None, height=5):
                self.height = height

            def draw_content(self, width, height):
                return "ACCENT CYAN"

        module.GlowProgress = GlowProgress
        module.load_settings = lambda: {"progress_animation_speed": "fast"}
        module.start_tween = lambda owner, attr, duration, on_frame, easing=None, on_done=None: seen.append(
            (owner.__class__.__name__, attr, duration, easing)
        )
        module.ease_out_cubic = object()
        launcher._install_progress_rendering_repairs(module)

        other = type("OtherWidget", (), {})()
        module.start_tween(other, "_move_tween", 300, lambda value: None)
        progress = GlowProgress(parent=None)
        module.start_tween(progress, "_value_tween", 420, lambda value: None)

        self.assertIsNone(seen[0][3], "non-progress easing must remain untouched")
        self.assertEqual(seen[1][2], 220, "fast progress animation should use its configured duration")
        self.assertIs(seen[1][3], module.ease_out_cubic)


if __name__ == "__main__":
    unittest.main()
