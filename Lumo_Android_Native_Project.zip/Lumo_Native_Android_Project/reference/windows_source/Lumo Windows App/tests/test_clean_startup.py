"""The main window stays hidden while it is built, then appears once, fully built."""
import types
import unittest

import main as launcher


class FakeTk:
    def __init__(self):
        self.calls = []
        self.shown = True
        self.afters = []

    def configure(self, **kw):
        self.calls.append(("configure", kw))

    def withdraw(self):
        self.calls.append(("withdraw",))
        self.shown = False

    def deiconify(self):
        self.calls.append(("deiconify",))
        self.shown = True

    def state(self):
        return "normal" if self.shown else "withdrawn"

    def update_idletasks(self):
        self.calls.append(("update_idletasks",))

    def after(self, ms, fn=None):
        self.afters.append((ms, fn))


class CleanStartupTests(unittest.TestCase):
    def setUp(self):
        self._real_tk = launcher.tk
        launcher.tk = types.SimpleNamespace(Tk=FakeTk)
        self.warmups = []
        self._real_warm = launcher._start_backend_warmup
        launcher._start_backend_warmup = lambda: self.warmups.append(1)

    def tearDown(self):
        launcher.tk = self._real_tk
        launcher._start_backend_warmup = self._real_warm

    def _module(self):
        seen = {}

        class App(FakeTk):
            def __init__(self):
                launcher.tk.Tk.__init__(self)
                seen["hidden_during_build"] = not self.shown

        return types.SimpleNamespace(App=App, BG="#101216"), seen

    def test_window_hidden_during_build_then_shown_once(self):
        module, seen = self._module()
        self.assertTrue(launcher._install_clean_startup(module))
        app = module.App()
        self.assertTrue(seen["hidden_during_build"])
        self.assertTrue(app.shown)
        names = [c[0] for c in app.calls]
        self.assertIn("update_idletasks", names)
        self.assertEqual(names.count("deiconify"), 1)
        self.assertIn(("configure", {"bg": "#101216"}), app.calls)

    def test_tk_init_is_restored_and_install_is_idempotent(self):
        module, _ = self._module()
        original = launcher.tk.Tk.__init__
        launcher._install_clean_startup(module)
        first = module.App.__init__
        launcher._install_clean_startup(module)
        self.assertIs(module.App.__init__, first)
        module.App()
        self.assertIs(launcher.tk.Tk.__init__, original)

    def test_backend_warmup_is_delayed_until_after_the_window_exists(self):
        module, _ = self._module()
        launcher._install_clean_startup(module)
        app = module.App()
        self.assertEqual(self.warmups, [])
        self.assertEqual(len(app.afters), 2)

    def test_no_app_class_returns_false(self):
        self.assertFalse(launcher._install_clean_startup(types.SimpleNamespace()))


if __name__ == "__main__":
    unittest.main()
