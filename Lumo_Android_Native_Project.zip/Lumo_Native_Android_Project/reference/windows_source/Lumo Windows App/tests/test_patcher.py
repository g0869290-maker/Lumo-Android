from __future__ import annotations

import importlib.util
import py_compile
import tempfile
import unittest
from pathlib import Path

from tools.patch_main_pyc import patch_code, patch_pyc


class BytecodePatchTests(unittest.TestCase):
    def _source(self) -> str:
        return '''
class App:
    def poll_events(self):
        return 120
    def build_settings_page(self):
        return ("Dark or Light mode for the whole app. Applies when you save.",
                "Dark uses a near-black background. Light uses an off-white background.")
    def animation_duration(self):
        return 300

def main():
    return App()
'''

    def test_patch_changes_only_the_requested_text_and_idle_poll_constant(self) -> None:
        source = self._source()
        original = compile(source, "synthetic_main.py", "exec")
        stats = {"mode_description": 0, "mode_help": 0, "poll": 0}
        from tools.patch_main_pyc import patch_code
        patched = patch_code(original, stats)
        namespace: dict[str, object] = {}
        exec(patched, namespace)
        app = namespace["App"]()
        self.assertEqual(app.poll_events(), 160)
        self.assertEqual(app.animation_duration(), 300)
        self.assertEqual(
            app.build_settings_page(),
            ("Dark mode only. Changes apply when you save.", "Dark mode uses a near-black background."),
        )
        self.assertEqual(stats["mode_description"], 1)
        self.assertEqual(stats["mode_help"], 1)
        self.assertEqual(stats["poll"], 1)

    def test_pyc_patch_can_be_loaded_back(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source_file = root / "main_source.py"
            original_pyc = root / "main_original.pyc"
            patched_pyc = root / "main_patched.pyc"
            source_file.write_text(self._source(), encoding="utf-8")
            py_compile.compile(str(source_file), cfile=str(original_pyc), doraise=True)
            stats = patch_pyc(original_pyc, patched_pyc, require_recovered_ui=False)  # synthetic fixture
            self.assertEqual(stats["mode_description"], 1)
            self.assertEqual(stats["mode_help"], 1)
            self.assertEqual(stats["poll"], 1)
            spec = importlib.util.spec_from_file_location("synthetic_patched", patched_pyc)
            self.assertIsNotNone(spec)
            self.assertIsNotNone(spec.loader)
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            self.assertEqual(module.App().poll_events(), 160)
            self.assertEqual(module.App().animation_duration(), 300)


if __name__ == "__main__":
    unittest.main()
