"""Partial-download reuse rules and plain-language error messages."""
import shutil
import tempfile
import types
import unittest
from pathlib import Path

from lumo_windows import downloader


class PlainErrorTests(unittest.TestCase):
    def test_common_failures_get_one_actionable_sentence(self):
        cases = {
            "urlopen error [Errno -2] Name or service not known": "internet problem",
            "HTTP Error 429: Too Many Requests": "limiting requests",
            "HTTP Error 403: Forbidden": "out of date",
            "Unable to extract nsig function": "update",
            "Sign in to confirm you're not a bot": "signed in",
            "[Errno 28] No space left on device": "disk space",
            "[Errno 13] Permission denied": "cannot write",
            "Video unavailable. This video has been removed": "unavailable",
        }
        for raw, expected in cases.items():
            with self.subTest(raw=raw):
                text = downloader.plain_error(raw, "download").casefold()
                self.assertIn(expected, text)

    def test_technical_text_is_not_shown_to_the_user(self):
        text = downloader.plain_error("urlopen error [Errno -2] Name or service not known", "download")
        visible = text.split(" (Details")[0]
        self.assertNotIn("urlopen", visible)
        self.assertNotIn("Errno", visible)


class PartialReuseTests(unittest.TestCase):
    URL = "https://www.youtube.com/watch?v=abc"

    def setUp(self):
        self.base = Path(tempfile.mkdtemp())

    def tearDown(self):
        shutil.rmtree(self.base, ignore_errors=True)

    def test_same_quality_resumes_and_different_quality_starts_fresh(self):
        folder, resumed = downloader.prepare_partial_folder(self.base, self.URL, 720)
        self.assertFalse(resumed)
        (folder / "video.mp4.part").write_bytes(b"partial")

        folder, resumed = downloader.prepare_partial_folder(self.base, self.URL, 720)
        self.assertTrue(resumed)
        self.assertTrue((folder / "video.mp4.part").exists())

        folder, resumed = downloader.prepare_partial_folder(self.base, self.URL, 1080)
        self.assertFalse(resumed)
        self.assertFalse((folder / "video.mp4.part").exists())

    def test_best_quality_is_its_own_key(self):
        folder, _ = downloader.prepare_partial_folder(self.base, self.URL, 720)
        (folder / "video.mp4.part").write_bytes(b"partial")
        folder, resumed = downloader.prepare_partial_folder(self.base, self.URL, None)
        self.assertFalse(resumed)

    def test_completed_download_discards_the_partial_folder(self):
        folder, _ = downloader.prepare_partial_folder(self.base, self.URL, 720)
        (folder / "video.mp4.part").write_bytes(b"partial")
        downloader.discard_partial_folder(self.base, self.URL)
        self.assertFalse(downloader.partial_folder_for(self.base, self.URL).exists())


class DownloadOptionsTests(unittest.TestCase):
    def test_subtitles_do_not_change_the_partial_folder_and_are_embedded(self):
        captured = {}

        class FakeYDL:
            def __init__(self, opts):
                captured.update(opts)

            def __enter__(self):
                return self

            def __exit__(self, *args):
                return False

            def process_ie_result(self, *args, **kwargs):
                return {"title": "t", "requested_subtitles": {"en": {}}}

            def extract_info(self, url, download=True):
                return {"title": "t"}

        fake = types.SimpleNamespace(YoutubeDL=FakeYDL,
                                     utils=types.SimpleNamespace(DownloadCancelled=Exception))
        original = (downloader._yt_dlp, downloader._js_runtime_options,
                    downloader.DownloadJob._find_output)
        downloader._yt_dlp = lambda: fake
        downloader._js_runtime_options = lambda: ({}, None)
        downloader.DownloadJob._find_output = lambda self, *args, **kwargs: None
        base = Path(tempfile.mkdtemp())
        try:
            job = downloader.DownloadJob("https://www.youtube.com/watch?v=abc", base / "out",
                                         max_height=720, subtitle_langs=["en"])
            job.run()
        finally:
            (downloader._yt_dlp, downloader._js_runtime_options,
             downloader.DownloadJob._find_output) = original
            shutil.rmtree(base, ignore_errors=True)

        keys = [p["key"] for p in captured["postprocessors"]]
        self.assertIn("FFmpegEmbedSubtitle", keys)
        self.assertIn("FFmpegSubtitlesConvertor", keys)
        self.assertTrue(captured["paths"]["temp"].endswith(downloader.partial_folder_for(
            base / "out", "https://www.youtube.com/watch?v=abc").name))


if __name__ == "__main__":
    unittest.main()
