"""Regression tests for the dedicated YouTube-playlist-only page."""
from pathlib import Path
import unittest
from types import SimpleNamespace
from unittest.mock import patch

from lumo_windows import downloader, playlist_ui


class YouTubePlaylistUrlTests(unittest.TestCase):
    def test_accepts_canonical_playlist_url(self):
        self.assertTrue(playlist_ui.is_youtube_playlist_url(
            "https://www.youtube.com/playlist?list=PL_example123"))

    def test_accepts_watch_url_that_carries_playlist_context(self):
        self.assertTrue(playlist_ui.is_youtube_playlist_url(
            "https://www.youtube.com/watch?v=video123&list=PL_example123"))

    def test_accepts_mobile_and_music_youtube_playlist_urls(self):
        self.assertTrue(playlist_ui.is_youtube_playlist_url(
            "https://m.youtube.com/playlist?list=PL_example123"))
        self.assertTrue(playlist_ui.is_youtube_playlist_url(
            "https://music.youtube.com/playlist?list=PL_example123"))

    def test_accepts_short_video_link_only_when_playlist_context_is_present(self):
        self.assertTrue(playlist_ui.is_youtube_playlist_url(
            "https://youtu.be/video123?list=PL_example123"))
        self.assertFalse(playlist_ui.is_youtube_playlist_url(
            "https://youtu.be/video123"))

    def test_rejects_unrelated_youtube_paths_with_list_parameter(self):
        self.assertFalse(playlist_ui.is_youtube_playlist_url(
            "https://www.youtube.com/shorts/video123?list=PL_example123"))

    def test_rejects_single_video_without_playlist_id(self):
        self.assertFalse(playlist_ui.is_youtube_playlist_url(
            "https://www.youtube.com/watch?v=video123"))

    def test_rejects_non_youtube_domains_even_with_list_parameter(self):
        self.assertFalse(playlist_ui.is_youtube_playlist_url(
            "https://example.com/playlist?list=PL_example123"))
        self.assertFalse(playlist_ui.is_youtube_playlist_url(
            "https://youtube.com.attacker.example/playlist?list=PL_example123"))

    def test_rejects_empty_id_malformed_url_and_multiple_pasted_urls(self):
        self.assertFalse(playlist_ui.is_youtube_playlist_url(
            "https://www.youtube.com/playlist?list="))
        self.assertFalse(playlist_ui.is_youtube_playlist_url("not a URL"))
        self.assertFalse(playlist_ui.is_youtube_playlist_url(
            "https://www.youtube.com/playlist?list=PL_1 https://youtu.be/video2"))

    def test_playlist_page_is_explicitly_single_source_not_multi_url(self):
        source = Path(playlist_ui.__file__).read_text(encoding="utf-8")
        self.assertIn("self._playlist_source_url is not None or self.items", source)
        self.assertIn("self._playlist_expanded", source)
        self.assertIn("def clear_playlist(self)", source)
        self.assertIn("Load Playlist", source)
        self.assertIn("Download Playlist", source)
        self.assertIn("A single-video link or multiple separate URLs is not accepted", source)


class FakeVar:
    def __init__(self, value=""):
        self.value = value
    def get(self):
        return self.value
    def set(self, value):
        self.value = value


class FakeWidget:
    def __init__(self):
        self.options = {}
    def configure(self, **options):
        self.options.update(options)
    def focus_set(self):
        pass


class PlaylistPageWorkflowTests(unittest.TestCase):
    def make_controller(self, url):
        controller = playlist_ui.PlaylistWindow.__new__(playlist_ui.PlaylistWindow)
        controller.worker = None
        controller._playlist_source_url = None
        controller.items = []
        controller.url_var = FakeVar(url)
        controller.url_entry = FakeWidget()
        controller.add_button = FakeWidget()
        controller.clear_playlist_button = FakeWidget()
        controller.done_button = FakeWidget()
        controller.start_button = FakeWidget()
        controller.status_var = FakeVar()
        controller.root = object()
        controller._refresh_item = lambda _item: None
        queued = []
        controller._enqueue_inspection = lambda uid, source: queued.append((uid, source))
        return controller, queued

    def test_single_video_link_is_rejected_by_playlist_workflow(self):
        controller, queued = self.make_controller("https://www.youtube.com/watch?v=video123")
        with patch.object(playlist_ui.messagebox, "showwarning") as warning:
            controller.add_url()
        warning.assert_called_once()
        self.assertEqual(controller.items, [])
        self.assertEqual(queued, [])
        self.assertIsNone(controller._playlist_source_url)

    def test_only_one_playlist_source_can_be_loaded_without_reset(self):
        first_url = "https://www.youtube.com/playlist?list=PL_first"
        second_url = "https://www.youtube.com/playlist?list=PL_second"
        controller, queued = self.make_controller(first_url)
        # These UI-state dependencies are touched by add_url().
        controller._playlist_loading = False
        controller._playlist_expanded = False
        controller._playlist_failed = False
        controller.add_url()
        self.assertEqual(controller._playlist_source_url, first_url)
        self.assertEqual(len(queued), 1)
        controller.url_var.set(second_url)
        controller.add_url()
        self.assertEqual(controller._playlist_source_url, first_url)
        self.assertEqual(len(queued), 1)
        self.assertIn("one YouTube playlist at a time", controller.status_var.get())


class PlaylistExtractionTests(unittest.TestCase):
    def test_extraction_keeps_playlist_order_and_removes_duplicate_urls(self):
        class FakeYoutubeDL:
            def __init__(self, options):
                self.options = options
            def __enter__(self):
                return self
            def __exit__(self, exc_type, exc, tb):
                return False
            def extract_info(self, url, download=False):
                self.request_url = url
                self.download_flag = download
                return {"entries": [
                    {"id": "video_a", "url": "video_a", "ie_key": "Youtube"},
                    {"id": "video_b", "url": "https://www.youtube.com/watch?v=video_b", "ie_key": "Youtube"},
                    {"id": "video_a", "url": "https://www.youtube.com/watch?v=video_a", "ie_key": "Youtube"},
                ]}

        fake_module = SimpleNamespace(YoutubeDL=FakeYoutubeDL)
        with patch.object(downloader, "_yt_dlp", return_value=fake_module), \
             patch.object(downloader, "_js_runtime_options", return_value=({}, "test runtime")), \
             patch.object(downloader, "_cookie_option", return_value={}):
            urls, error = downloader.extract_playlist_urls(
                "https://www.youtube.com/playlist?list=PL_example123")

        self.assertIsNone(error)
        self.assertEqual(urls, [
            "https://www.youtube.com/watch?v=video_a",
            "https://www.youtube.com/watch?v=video_b",
        ])

    def test_invalid_playlist_url_is_rejected_before_yt_dlp_is_loaded(self):
        with patch.object(downloader, "_yt_dlp", side_effect=AssertionError("must not be called")):
            urls, error = downloader.extract_playlist_urls("https://www.youtube.com/watch?v=video123")
        self.assertEqual(urls, [])
        self.assertIn("playlist link", error)

    def test_extractor_never_downgrades_a_playlist_link_to_a_single_video(self):
        class FakeYoutubeDL:
            def __init__(self, options):
                pass
            def __enter__(self):
                return self
            def __exit__(self, exc_type, exc, tb):
                return False
            def extract_info(self, url, download=False):
                # Simulates a server/extractor response that returned video info
                # rather than a playlist's entries collection.
                return {"id": "current_video_only", "title": "Current video"}
        with patch.object(downloader, "_yt_dlp", return_value=SimpleNamespace(YoutubeDL=FakeYoutubeDL)), \
             patch.object(downloader, "_js_runtime_options", return_value=({}, "test runtime")), \
             patch.object(downloader, "_cookie_option", return_value={}):
            urls, error = downloader.extract_playlist_urls(
                "https://www.youtube.com/watch?v=current_video_only&list=PL_example123")
        self.assertEqual(urls, [])
        self.assertIn("single video instead of playlist entries", error)

    def test_youtube_playlist_extractor_keeps_playlist_mode_enabled(self):
        seen = {}
        class FakeYoutubeDL:
            def __init__(self, options):
                seen.update(options)
            def __enter__(self):
                return self
            def __exit__(self, exc_type, exc, tb):
                return False
            def extract_info(self, url, download=False):
                return {"entries": [{"id": "one", "url": "https://www.youtube.com/watch?v=one"}]}
        with patch.object(downloader, "_yt_dlp", return_value=SimpleNamespace(YoutubeDL=FakeYoutubeDL)), \
             patch.object(downloader, "_js_runtime_options", return_value=({}, "test runtime")), \
             patch.object(downloader, "_cookie_option", return_value={}):
            urls, error = downloader.extract_playlist_urls(
                "https://www.youtube.com/playlist?list=PL_example123")
        self.assertIsNone(error)
        self.assertEqual(len(urls), 1)
        self.assertFalse(seen["noplaylist"])
        self.assertEqual(seen["extract_flat"], "in_playlist")
        self.assertTrue(seen["skip_download"])


if __name__ == "__main__":
    unittest.main()
