"""Audit regressions that run without tkinter.

main.py imports tkinter at module load, so these checks read its source with ast
and test the pure motion helper directly.
"""
from __future__ import annotations

import ast
import pathlib
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
MAIN_SOURCE = (ROOT / "main.py").read_text(encoding="utf-8")
MAIN_TREE = ast.parse(MAIN_SOURCE)

from lumo_windows.playlist_motion import playlist_icon_rotation  # noqa: E402


def _top_functions() -> dict[str, ast.FunctionDef]:
    return {node.name: node for node in MAIN_TREE.body if isinstance(node, ast.FunctionDef)}


class PlaylistIconMotionTests(unittest.TestCase):
    def test_motion_starts_at_rest_and_finishes_one_full_turn(self) -> None:
        self.assertEqual(playlist_icon_rotation(0.0), 0.0)
        self.assertEqual(playlist_icon_rotation(1.0), 360.0)

    def test_motion_is_eased_out_like_history_not_linear(self) -> None:
        # Linear motion would reach 180 degrees at t=0.5. Ease-out is already past it.
        self.assertGreater(playlist_icon_rotation(0.5), 180.0)
        self.assertNotAlmostEqual(playlist_icon_rotation(0.5), 180.0, places=3)

    def test_motion_never_decreases_across_the_tween(self) -> None:
        samples = [playlist_icon_rotation(i / 100) for i in range(101)]
        self.assertEqual(samples, sorted(samples))

    def test_app_easing_function_is_used_when_supplied(self) -> None:
        self.assertEqual(playlist_icon_rotation(0.5, ease=lambda t: t), 180.0)

    def test_out_of_range_progress_is_clamped(self) -> None:
        self.assertEqual(playlist_icon_rotation(-1.0), 0.0)
        self.assertEqual(playlist_icon_rotation(2.0), 360.0)

    def test_launcher_uses_the_helper_instead_of_linear_motion(self) -> None:
        self.assertIn("playlist_icon_rotation(progress, ease)", MAIN_SOURCE)
        self.assertNotIn('"rot": 360.0 * progress', MAIN_SOURCE)


class CustomizationRemovalTests(unittest.TestCase):
    def test_customization_builders_are_removed_from_the_launcher(self) -> None:
        names = _top_functions()
        for removed in ("_add_customization_tab", "_install_customization_ui_repairs",
                        "_save_customization_option", "_read_customization_options"):
            self.assertNotIn(removed, names)

    def test_footer_label_text_is_absent_from_the_launcher(self) -> None:
        # The hide-list in _hide_manual_save_ui still names the phrase without a full stop.
        self.assertNotIn("Changes save automatically.", MAIN_SOURCE)

    def test_run_pins_defaults_and_never_calls_the_removed_installer(self) -> None:
        run_body = _top_functions()["run"]
        calls = {node.func.id for node in ast.walk(run_body)
                 if isinstance(node, ast.Call) and isinstance(node.func, ast.Name)}
        self.assertIn("_pin_customization_defaults", calls)
        self.assertNotIn("_install_customization_ui_repairs", calls)

    def test_fixed_defaults_cover_exactly_the_eight_optional_controls(self) -> None:
        assign = next(node for node in MAIN_TREE.body
                      if isinstance(node, ast.AnnAssign)
                      and getattr(node.target, "id", "") == "_CUSTOMIZATION_DEFAULTS")
        self.assertEqual(ast.literal_eval(assign.value), {
            "show_history_action_icons": False,
            "animate_history_action_icons": False,
            "show_open_location_action": True,
            "show_share_action": True,
            "show_delete_action": True,
            "show_playlist_thumbnails": True,
            "compact_playlist_rows": False,
            "confirm_file_delete": True,
        })

    def test_playlist_page_receives_the_same_fixed_options_as_history(self) -> None:
        pin = MAIN_SOURCE.index("self._lumo_customization_options = dict(_CUSTOMIZATION_DEFAULTS)")
        build = MAIN_SOURCE.index("PlaylistWindow(a, parent=f, embedded=True)")
        self.assertLess(pin, build)


if __name__ == "__main__":
    unittest.main()


class PrimaryNavigationAnimationTests(unittest.TestCase):
    def test_existing_icon_animation_is_replayed_without_redrawing_icons(self):
        from types import SimpleNamespace
        import main

        calls = []
        row = SimpleNamespace(play_icon=lambda: calls.append("played"))
        app = SimpleNamespace(nav_rows={"download": row})
        main._play_navigation_icon(app, "download")
        self.assertEqual(calls, ["played"])

    def test_missing_or_failing_icon_animation_never_blocks_navigation(self):
        from types import SimpleNamespace
        import main

        main._play_navigation_icon(SimpleNamespace(nav_rows={}), "history")
        row = SimpleNamespace(play_icon=lambda: (_ for _ in ()).throw(RuntimeError("animation failed")))
        main._play_navigation_icon(SimpleNamespace(nav_rows={"settings": row}), "settings")

    def test_all_non_playlist_primary_tabs_use_the_same_animation_helper(self):
        from pathlib import Path
        import main

        source = Path(main.__file__).read_text(encoding="utf-8")
        self.assertIn("_play_navigation_icon(self, requested_page)", source)
        self.assertIn('{"download", "history", "settings"}', source)
        self.assertIn('_play_navigation_icon(self, "playlist")', source)  # Same trigger for Playlist.

    def test_primary_tabs_animate_once_on_change_and_again_on_same_tab_clicks(self):
        import types
        from types import SimpleNamespace
        import main

        calls = {key: 0 for key in ("download", "history", "settings", "playlist")}
        rows = {
            key: SimpleNamespace(play_icon=lambda k=key: calls.__setitem__(k, calls[k] + 1))
            for key in calls
        }

        class FakeApp:
            def __init__(self):
                self.current_display_page = "download"
                self.nav_rows = rows
                self.pages = {}
                self.content = None
            def show_page(self, page, *args, **kwargs):
                # Model the recovered handler: it animates when the active page changes,
                # but returns early for the already-selected tab.
                if str(page).casefold() != self.current_display_page:
                    row = self.nav_rows.get(str(page).casefold())
                    if row is not None:
                        row.play_icon()
                    self.current_display_page = str(page).casefold()
                return page
            def __init_original(self, *args, **kwargs):
                pass
            def rebuild_ui(self, *args, **kwargs):
                pass

        fake_module = types.SimpleNamespace(App=FakeApp, NAV_ITEMS=())
        main._install_playlist_navigation(fake_module)
        app = FakeApp()
        app.show_page("history")
        self.assertEqual(calls["history"], 1, "tab changes must not double-start the animation")
        app.show_page("history")
        self.assertEqual(calls["history"], 2, "clicking the active tab must replay the animation")
        app.show_page("settings")
        self.assertEqual(calls["settings"], 1, "tab changes still animate once")
        app.show_page("settings")
        self.assertEqual(calls["settings"], 2, "same-tab click must retrigger exactly once")

    def test_settings_tabs_keep_colour_controls_but_hide_appearance(self):
        import main
        tabs = (("theme", "Appearance"), ("accent", "Accent & indicator"),
                ("downloads", "Downloads"), ("subtitles", "Subtitles"))
        self.assertEqual(main._filter_choice_collection(tabs),
                         (("accent", "Accent & Indicator"),
                          ("downloads", "Downloads"), ("subtitles", "Subtitles"),
                          ("progress", "Progress Bar")))
