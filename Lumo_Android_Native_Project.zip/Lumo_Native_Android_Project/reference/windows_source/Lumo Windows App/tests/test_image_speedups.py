"""The faster card/gradient/down-scale helpers must draw the same pictures as the originals.

The reference functions below are the original UI's helpers (recovered from
main_original.pyc), kept here only to compare against.
"""
import time
import types
import unittest

from PIL import Image, ImageChops, ImageDraw

import main as launcher

SS = 4


def _rgb(value):
    value = value.lstrip("#")
    return (int(value[0:2], 16), int(value[2:4], 16), int(value[4:6], 16))


def _ref_premul(img, w, h):
    return img.convert("RGBa").resize((w, h), Image.BOX).convert("RGBA")


def _ref_rounded(w, h, radius, fill=None, outline=None, line=1.0, ss=SS):
    w, h = max(1, int(round(w))), max(1, int(round(h)))
    W, H = w * ss, h * ss
    base = _rgb(fill or outline or "#000000") + (0,)
    img = Image.new("RGBA", (W, H), base)
    d = ImageDraw.Draw(img)
    r = int(round(max(0.0, min(radius * ss, W / 2, H / 2))))
    if outline and line > 0:
        lw = max(1, int(round(line * ss)))
        d.rounded_rectangle((0, 0, W - 1, H - 1), radius=r, fill=_rgb(outline) + (255,))
        inner = (lw, lw, W - 1 - lw, H - 1 - lw)
        if inner[2] > inner[0] and inner[3] > inner[1]:
            d.rounded_rectangle(inner, radius=max(0, r - lw), fill=_rgb(fill) + (255,) if fill else base)
    elif fill:
        d.rounded_rectangle((0, 0, W - 1, H - 1), radius=r, fill=_rgb(fill) + (255,))
    return _ref_premul(img, w, h)


def _ref_gradient(w, h, c1, c2, ss=SS):
    w, h = max(1, int(round(w))), max(1, int(round(h)))
    W, H = w * ss, h * ss
    a, b = _rgb(c1), _rgb(c2)
    strip = Image.new("RGBA", (W, 1))
    px = strip.load()
    for x in range(W):
        t = x / max(1, W - 1)
        px[x, 0] = tuple(round(a[i] + (b[i] - a[i]) * t) for i in range(3)) + (255,)
    mask = Image.new("L", (W, H), 0)
    ImageDraw.Draw(mask).rounded_rectangle((0, 0, W - 1, H - 1), radius=int(round(min(H / 2, W / 2))), fill=255)
    out = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    out.paste(strip.resize((W, H)), (0, 0), mask)
    return _ref_premul(out, w, h)


def _ref_rounded_gradient(w, h, radius, c1, c2, ss=SS):
    W, H = w * ss, h * ss
    a, b = _rgb(c1), _rgb(c2)
    strip = Image.new("RGBA", (W, 1))
    px = strip.load()
    for x in range(W):
        t = x / max(1, W - 1)
        px[x, 0] = tuple(round(a[i] + (b[i] - a[i]) * t) for i in range(3)) + (255,)
    mask = Image.new("L", (W, H), 0)
    r = int(round(max(0.0, min(radius * ss, W / 2, H / 2))))
    ImageDraw.Draw(mask).rounded_rectangle((0, 0, W - 1, H - 1), radius=r, fill=255)
    out = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    out.paste(strip.resize((W, H)), (0, 0), mask)
    return _ref_premul(out, w, h)


def _fake_module():
    module = types.ModuleType("fake_original")
    module._rgb = _rgb
    module._premul_down = _ref_premul
    module.rounded_rgba = _ref_rounded
    module.gradient_rgba = _ref_gradient
    module._rounded_gradient_rgba = _ref_rounded_gradient
    return module


def _max_difference(a, b):
    """Largest per-channel difference of what is actually visible (premultiplied)."""
    diff = ImageChops.difference(a.convert("RGBa"), b.convert("RGBa"))
    return max(max(band) for band in diff.getextrema())


class ImageSpeedupTests(unittest.TestCase):
    def setUp(self):
        self.reference = _fake_module()
        self.patched = _fake_module()
        launcher._install_image_speedups(self.patched)

    def test_functions_are_replaced_once(self):
        first = self.patched.rounded_rgba
        launcher._install_image_speedups(self.patched)
        self.assertIs(self.patched.rounded_rgba, first)
        self.assertTrue(getattr(first, "_lumo_fast", False))

    def test_rounded_cards_match_the_original(self):
        cases = [
            ((300, 60, 14, "#1a1c26"), {}),
            ((900, 120, 16, "#1a1c26", "#2a2d3a", 1), {}),
            ((500, 80, 20, None, "#2a2d3a", 1.5), {}),
            ((400, 90, 18, "#12141c", "#2a2d3a", 2), {"ss": 3}),
            ((8, 8, 16, "#12141c", "#2a2d3a", 2), {}),
            ((3, 3, 0, "#ffffff"), {}),
            ((120.4, 33.6, 12, "#222533"), {}),
            ((200, 40, 10), {}),
        ]
        for args, kwargs in cases:
            with self.subTest(args=args, kwargs=kwargs):
                want = self.reference.rounded_rgba(*args, **kwargs)
                got = self.patched.rounded_rgba(*args, **kwargs)
                self.assertEqual(got.size, want.size)
                self.assertEqual(got.mode, "RGBA")
                self.assertLessEqual(_max_difference(got, want), 3)

    def test_gradients_match_the_original(self):
        for args in [(300, 12, "#8871FF", "#3ad1ff"), (900, 14, "#8871FF", "#ff5fa2"), (7, 5, "#000000", "#ffffff")]:
            with self.subTest(args=args):
                want = self.reference.gradient_rgba(*args)
                got = self.patched.gradient_rgba(*args)
                self.assertEqual(got.size, want.size)
                self.assertLessEqual(_max_difference(got, want), 3)

    def test_rounded_gradients_match_the_original(self):
        for args in [(300, 20, 8, "#8871FF", "#3ad1ff"), (640, 36, 18, "#202020", "#ffd700")]:
            with self.subTest(args=args):
                want = self.reference._rounded_gradient_rgba(*args)
                got = self.patched._rounded_gradient_rgba(*args)
                self.assertEqual(got.size, want.size)
                self.assertLessEqual(_max_difference(got, want), 3)

    def test_premul_down_matches_and_falls_back(self):
        big = Image.new("RGBA", (400, 280), (20, 22, 30, 200))
        self.assertLessEqual(_max_difference(self.patched._premul_down(big, 100, 70), _ref_premul(big, 100, 70)), 1)
        # A scale that is not a whole number goes through the original code.
        odd = self.patched._premul_down(big, 130, 91)
        self.assertEqual(odd.size, (130, 91))

    def test_unusual_calls_use_the_original(self):
        # A non-integer supersampling factor is not understood by the fast path, so the
        # original function must receive the call untouched.
        seen = []
        module = _fake_module()
        module.rounded_rgba = lambda *a, **k: seen.append((a, k)) or "original"
        launcher._install_image_speedups(module)
        self.assertEqual(module.rounded_rgba(60, 20, 6, "#1a1c26", None, 1.0, 2.5), "original")
        self.assertEqual(len(seen), 1)

    def test_big_card_is_much_faster(self):
        args = (1000, 700, 18, "#12141c", "#2a2d3a", 1)
        start = time.perf_counter()
        self.reference.rounded_rgba(*args)
        slow = time.perf_counter() - start
        start = time.perf_counter()
        self.patched.rounded_rgba(*args)
        fast = time.perf_counter() - start
        self.assertLess(fast, slow / 2)


if __name__ == "__main__":
    unittest.main()
