from __future__ import annotations

import queue
import threading
import time
import unittest
from pathlib import Path
from types import SimpleNamespace, MethodType
from unittest.mock import patch

import main
from lumo_windows import playlist_ui, downloader


class FakeWidget:
    def __init__(self, label="", children=None):
        self.label = label
        self.children = list(children or [])
        self.bindings = []
        self.refreshed = 0
        self.enabled = True
        self._fg = "#FFFFFF"
        self.items = []

    def winfo_children(self):
        return list(self.children)

    def winfo_exists(self):
        return True

    def bind(self, sequence, callback, add=None):
        self.bindings.append((sequence, callback, add))

    def refresh_look(self):
        self.refreshed += 1

    def configure(self, **kwargs):
        pass

    def delete(self, *args):
        self.items = []

    def winfo_width(self):
        return 120

    def winfo_height(self):
        return 34

    def create_line(self, *args, **kwargs):
        self.items.append(("line", args, kwargs))
        return len(self.items)

    def create_oval(self, *args, **kwargs):
        self.items.append(("oval", args, kwargs))
        return len(self.items)

    def create_arc(self, *args, **kwargs):
        self.items.append(("arc", args, kwargs))
        return len(self.items)

    def create_polygon(self, *args, **kwargs):
        self.items.append(("polygon", args, kwargs))
        return len(self.items)

    def create_rectangle(self, *args, **kwargs):
        self.items.append(("rectangle", args, kwargs))
        return len(self.items)

    def create_text(self, *args, **kwargs):
        self.items.append(("text", args, kwargs))
        return len(self.items)


class FakeVar:
    def __init__(self, value=""):
        self.value = value

    def get(self):
        return self.value

    def set(self, value):
        self.value = value


class JitterAndHistoryTests(unittest.TestCase):
    def test_history_decoration_does_not_walk_or_modify_playlist_actions(self):
        history_button = FakeWidget("Retry / Resume")
        playlist_button = FakeWidget("Copy URL")
        app = SimpleNamespace(
            pages={"history": FakeWidget(children=[history_button]),
                   "playlist": FakeWidget(children=[playlist_button])},
            _lumo_customization_options={"show_history_action_icons": True,
                                          "animate_history_action_icons": True},
        )
        main._decorate_history_actions(app)
        self.assertEqual(history_button._lumo_action_kind, "retry")
        self.assertFalse(history_button._lumo_show_icon)
        self.assertFalse(history_button._lumo_animate_icon)
        self.assertFalse(hasattr(history_button, "_lumo_icon_animation_bound"))
        self.assertFalse(hasattr(playlist_button, "_lumo_action_kind"))
        self.assertEqual(history_button.label, "Retry / Resume")

    def test_remove_record_is_distinguished_from_file_delete(self):
        button = FakeWidget("Remove record")
        app = SimpleNamespace(
            pages={"history": FakeWidget(children=[button])},
            _lumo_customization_options={"show_history_action_icons": True,
                                          "animate_history_action_icons": True},
        )
        main._decorate_history_actions(app)
        self.assertEqual(button._lumo_action_kind, "delete_record")
        self.assertIn("Remove from History", button.label)
        self.assertNotIn("Remove record", button.label)

    def test_real_remove_from_history_caption_receives_its_own_icon_kind(self):
        button = FakeWidget("Remove from History")
        app = SimpleNamespace(
            pages={"history": FakeWidget(children=[button])},
            _lumo_customization_options={"show_history_action_icons": True,
                                          "animate_history_action_icons": True},
        )
        main._decorate_history_actions(app)
        self.assertEqual(button._lumo_action_kind, "delete_record")
        self.assertFalse(button._lumo_show_icon)
        self.assertFalse(hasattr(button, "_lumo_icon_animation_bound"))

    def test_history_delete_file_and_remove_record_have_distinct_visuals(self):
        module = SimpleNamespace(WHITE="#FFFFFF", ACCENT="#FF647F",
                                 CYAN="#55D8F2", PURPLE="#8871FF",
                                 DANGER="#FF647F", AMBER="#FFB45F")
        delete_file = FakeWidget("Delete file")
        remove_record = FakeWidget("Remove from History")
        main._draw_history_action_icon(delete_file, module, "delete", 0.5)
        main._draw_history_action_icon(remove_record, module, "delete_record", 0.5)
        self.assertTrue(any(kind == "rectangle" for kind, _args, _kwargs in delete_file.items))
        self.assertTrue(any(kind == "rectangle" for kind, _args, _kwargs in remove_record.items))
        self.assertNotEqual(
            [(kind, args) for kind, args, _kwargs in delete_file.items],
            [(kind, args) for kind, args, _kwargs in remove_record.items],
            "Deleting the media file and removing a History record must not use the same glyph.",
        )

    def test_history_icons_draw_vector_shapes_without_changing_button_label(self):
        widget = FakeWidget("\u2003  Delete")
        main._draw_history_action_icon(widget, SimpleNamespace(WHITE="#FFFFFF", ACCENT="#FF647F"), "delete", 0.5)
        kinds = {item[0] for item in widget.items}
        self.assertIn("rectangle", kinds)
        self.assertIn("line", kinds)
        self.assertTrue(any(item[2].get("fill") == "#FF647F" or item[2].get("outline") == "#FF647F"
                            for item in widget.items), "History glyphs should use Lumo's accent colour")
        self.assertEqual(widget.label, "\u2003  Delete")

    def test_inspection_workers_start_only_when_a_url_is_enqueued(self):
        controller = playlist_ui.PlaylistWindow.__new__(playlist_ui.PlaylistWindow)
        controller._inspect_queue = queue.Queue()
        controller._inspect_shutdown = threading.Event()
        controller._inspection_queue_closed = False
        controller._inspect_workers = []
        controller.status_var = FakeVar()
        starts = []
        controller._start_inspection_workers = lambda: starts.append("started")
        self.assertEqual(starts, [])
        controller._enqueue_inspection("uid1", "https://youtube.com/watch?v=one")
        self.assertEqual(starts, ["started"])
        self.assertEqual(controller._inspect_queue.get_nowait(),
                         ("uid1", "https://youtube.com/watch?v=one"))
        controller._inspect_queue.task_done()

    def test_playlist_inspection_concurrency_is_bounded(self):
        controller = playlist_ui.PlaylistWindow.__new__(playlist_ui.PlaylistWindow)
        controller._inspect_queue = queue.Queue()
        controller._inspect_shutdown = threading.Event()
        controller._inspect_worker_count = 3
        controller._inspect_workers = []
        controller._inspection_queue_closed = False
        lock = threading.Lock()
        state = {"active": 0, "max": 0, "completed": 0}

        def fake_inspect(self, uid, url):
            with lock:
                state["active"] += 1
                state["max"] = max(state["max"], state["active"])
            time.sleep(0.006)
            with lock:
                state["active"] -= 1
                state["completed"] += 1

        controller._inspect_worker = MethodType(fake_inspect, controller)
        controller._start_inspection_workers()
        for index in range(36):
            controller._enqueue_inspection(str(index), f"https://example.com/{index}")
        controller._inspect_queue.join()
        controller.shutdown_inspection()
        self.assertEqual(state["completed"], 36)
        self.assertLessEqual(state["max"], 3)

    def test_history_storage_failure_does_not_leave_playlist_items_unqueued(self):
        controller = playlist_ui.PlaylistWindow.__new__(playlist_ui.PlaylistWindow)
        controller._collection_done = True
        controller._playlist_expanded = True
        controller._playlist_source_url = "https://www.youtube.com/playlist?list=PL_test"
        controller.items = [
            {"uid": "a", "url": "https://youtube.com/watch?v=a", "title": "A",
             "status": "Ready", "history_id": None, "estimates": {}},
            {"uid": "b", "url": "https://youtube.com/watch?v=b", "title": "B",
             "status": "Ready", "history_id": None, "estimates": {}},
        ]
        controller.worker = None
        controller._stop_requested = False
        controller._paused = False
        controller.quality_var = FakeVar("1080p")
        controller.subtitle_var = FakeVar("en")
        controller.prefs = {"download_dir": ".", "merge_to_mp4": True}
        controller.app = SimpleNamespace(job_progress={})
        controller.status_var = FakeVar()
        controller.pause_button = FakeWidget()
        controller.cancel_button = FakeWidget()
        controller._refresh_item = lambda item: None
        controller._refresh_app_history = lambda force=False: None
        controller._download_worker = MethodType(lambda self, items: None, controller)
        controller._height_cap = MethodType(lambda self: 1080, controller)

        with patch.object(playlist_ui.history, "init_db", side_effect=OSError("database unavailable")), \
             patch.object(playlist_ui.history, "add_job", side_effect=OSError("database unavailable")):
            controller.start_queue()
            controller.worker.join(timeout=1)

        self.assertEqual([item["status"] for item in controller.items], ["Queued", "Queued"])
        self.assertIn("downloads will continue", controller.status_var.get())

    def test_playlist_page_recognises_watch_links_with_playlist_context(self):
        self.assertTrue(downloader.is_playlist_url("https://www.youtube.com/playlist?list=PL123"))
        self.assertTrue(downloader.is_playlist_url("https://www.youtube.com/watch?v=video1&list=PL123"))
        self.assertFalse(downloader.is_playlist_url("https://www.youtube.com/watch?v=video1"))

    def test_playlist_progress_ring_shows_completed_and_paused_states_clearly(self):
        controller = playlist_ui.PlaylistWindow.__new__(playlist_ui.PlaylistWindow)
        controller.ACCENT = "#55D8F2"
        controller.PURPLE = "#8871FF"
        controller.DANGER = "#FF647F"
        controller.TEXT = "#F2F6FF"
        completed = FakeWidget()
        playlist_ui.PlaylistWindow._draw_progress_ring(
            controller, completed, {"status": "Completed", "progress": "100%"})
        completed_text = [kwargs.get("text") for kind, _args, kwargs in completed.items if kind == "text"]
        self.assertIn("✓", completed_text)
        self.assertTrue(any(kind == "oval" for kind, _args, _kwargs in completed.items))

        paused = FakeWidget()
        playlist_ui.PlaylistWindow._draw_progress_ring(
            controller, paused, {"status": "Paused", "progress": "42%"})
        paused_text = [kwargs.get("text") for kind, _args, kwargs in paused.items if kind == "text"]
        self.assertIn("Ⅱ", paused_text)
        self.assertTrue(any(kind == "arc" and kwargs.get("outline") == "#8871FF"
                            for kind, _args, kwargs in paused.items))

    def test_playlist_expansion_normalises_entries_and_deduplicates(self):
        class FakeYDL:
            def __init__(self, options):
                self.options = options
            def __enter__(self):
                return self
            def __exit__(self, *_args):
                return False
            def extract_info(self, _url, download=False):
                self_download = download
                return {"entries": [
                    {"id": "one", "url": "https://www.youtube.com/watch?v=one"},
                    {"id": "one", "url": "https://www.youtube.com/watch?v=one"},
                    {"id": "two", "url": "https://www.youtube.com/watch?v=two"},
                ]}
        fake_yt_dlp = SimpleNamespace(YoutubeDL=FakeYDL)
        with patch.object(downloader, "_yt_dlp", return_value=fake_yt_dlp), \
             patch.object(downloader, "_js_runtime_options", return_value=({}, "test runtime")), \
             patch.object(downloader, "_cookie_option", return_value={}):
            urls, error = downloader.extract_playlist_urls("https://www.youtube.com/playlist?list=PL123")
        self.assertIsNone(error)
        self.assertEqual(urls, ["https://www.youtube.com/watch?v=one", "https://www.youtube.com/watch?v=two"])

    def test_declining_playlist_window_close_keeps_inspection_workers_usable(self):
        class FakeRoot:
            def __init__(self):
                self.destroyed = False
            def after_cancel(self, _after_id):
                pass
            def destroy(self):
                self.destroyed = True
        class FakeJob:
            def __init__(self):
                self.cancelled = False
            def cancel(self):
                self.cancelled = True
        controller = playlist_ui.PlaylistWindow.__new__(playlist_ui.PlaylistWindow)
        controller.root = FakeRoot()
        controller.current_job = FakeJob()
        controller._poll_after_id = None
        controller._inspection_queue_closed = False
        controller._inspect_shutdown = threading.Event()
        controller._inspect_queue = queue.Queue()
        controller._stop_requested = False
        with patch.object(playlist_ui.messagebox, "askyesno", return_value=False):
            controller._close()
        self.assertFalse(controller.root.destroyed)
        self.assertFalse(controller._inspect_shutdown.is_set())
        self.assertFalse(controller.current_job.cancelled)

    def test_nav_icon_cache_warmup_renders_frames_in_small_batches_and_restores_pose(self):
        from main import _schedule_nav_icon_cache_warmup
        calls = []
        scheduled = []
        class FakeRow:
            icon_name = "history"
            icon_t = 0.37
            def _icon_pose(self):
                return {"rot": 360.0 * self.icon_t, "sc": 1.0, "oy": 0.0}
        row = FakeRow()
        module = SimpleNamespace(
            _lumo_original_icon_photo=lambda *args: calls.append(args),
            _lumo_nav_icon_photo_params={"history": ("#FFFFFF", "#101827", 24, 2)},
        )
        app = SimpleNamespace(nav_rows={"history": row})
        app.after = lambda delay, callback: scheduled.append((delay, callback)) or len(scheduled)
        _schedule_nav_icon_cache_warmup(app, module)
        self.assertEqual(calls, [])
        self.assertEqual(scheduled[0][0], 380)
        while scheduled:
            _delay, callback = scheduled.pop(0)
            before = len(calls)
            callback()
            self.assertLessEqual(len(calls) - before, 1, "warm-up must yield after each rendered frame")
            if scheduled:
                self.assertEqual(scheduled[0][0], 12)
        self.assertEqual(len(calls), 9)
        self.assertTrue(all(len(args) == 8 for args in calls))
        self.assertAlmostEqual(row.icon_t, 0.37)
        self.assertTrue(app._lumo_nav_icon_warmup_complete)

    def test_primary_tab_warmup_is_deferred_and_maps_hidden_page_behind_current(self):
        source = Path(main.__file__).read_text(encoding="utf-8")
        self.assertIn("def _schedule_primary_tab_warmup", source)
        self.assertIn("target.lower(visible)", source)
        self.assertIn("app.after(45, finish_warm)", source)
        warmup_source = source[source.index("def _schedule_primary_tab_warmup"):source.index("def _play_navigation_icon")]
        self.assertNotIn("update_idletasks()", warmup_source)
        self.assertIn("_schedule_primary_tab_warmup(self)", source)


if __name__ == "__main__":
    unittest.main()
