"""The animation loop redraws at a sane rate and can be tuned with LUMO_FRAME_MS."""
import os
import types
import unittest

import main as launcher


class AnimationRateTests(unittest.TestCase):
    def setUp(self):
        self._saved = os.environ.pop("LUMO_FRAME_MS", None)

    def tearDown(self):
        os.environ.pop("LUMO_FRAME_MS", None)
        if self._saved is not None:
            os.environ["LUMO_FRAME_MS"] = self._saved

    def test_default_is_about_60_fps(self):
        module = types.SimpleNamespace()
        launcher._install_animation_frame_rate(module)
        self.assertEqual(module.FRAME_MS, 16)

    def test_override_is_clamped_and_bad_values_fall_back(self):
        module = types.SimpleNamespace()
        os.environ["LUMO_FRAME_MS"] = "33"
        launcher._install_animation_frame_rate(module)
        self.assertEqual(module.FRAME_MS, 33)
        os.environ["LUMO_FRAME_MS"] = "999"
        launcher._install_animation_frame_rate(module)
        self.assertEqual(module.FRAME_MS, 50)
        os.environ["LUMO_FRAME_MS"] = "not-a-number"
        launcher._install_animation_frame_rate(module)
        self.assertEqual(module.FRAME_MS, 16)


if __name__ == "__main__":
    unittest.main()
