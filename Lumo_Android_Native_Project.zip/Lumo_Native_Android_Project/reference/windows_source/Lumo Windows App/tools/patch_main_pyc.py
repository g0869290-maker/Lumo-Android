"""Command-line wrapper: python tools/patch_main_pyc.py main_original.pyc build/out.pyc

The real code lives in lumo_windows/ui_patch.py so the app and the build share it.
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from lumo_windows.ui_patch import (  # noqa: E402  (re-exported for tests and tools)
    EMBEDDED_REPLACEMENTS,
    REPLACEMENTS,
    collect_import_names,
    generic_rename,
    patch_code,
    patch_constant,
    patch_module_code,
    patch_pyc,
    replace_text,
)


def main() -> int:
    if len(sys.argv) != 3:
        print(
            "Usage: python tools\\patch_main_pyc.py "
            "main_original.pyc build\\original_main_patched.pyc"
        )
        return 2

    source = Path(sys.argv[1])
    destination = Path(sys.argv[2])

    if not source.is_file():
        print(f"ERROR: Original bytecode not found: {source}")
        return 2

    try:
        stats = patch_pyc(source, destination)

    except Exception as error:
        print(f"ERROR: {error}")
        return 1

    print(f"Patched recovered UI: {destination}")
    print("\nReplacement counts:")

    for label in sorted(stats):
        if stats[label]:
            print(f"  {label}: {stats[label]}")

    print("\nVerified package imports:")
    print("  lumo_windows")
    print("  lumo_windows.downloader")
    print("  lumo_windows.settings")

    print("\nNo obsolete package imports remain in code names.")
    print("Original UI structure and download logic were not rewritten.")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
