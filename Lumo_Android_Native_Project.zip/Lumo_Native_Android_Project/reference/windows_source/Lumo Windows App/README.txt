LUMO - FINAL REPLACEMENT FILES
==============================
Copy every file here over the file with the same path in your Lumo project folder
(keep the folders; say Yes to "Replace the file in the destination").

  main.py                          (project root)
  lumo_debug.py                    (project root): the ONE diagnostic tool. Replaces lumo_diagnose.py.
  build.bat                        (project root)
  check_and_install.bat            (project root)
  lumo_windows\downloader.py
  lumo_windows\playlist_ui.py
  tests\test_ui_step2.py
  tests\test_runtime_patch.py
  tests\test_settings_colour_patch.py
  tests\test_requested_ui_fixes.py
  tests\test_lumo_wiring.py
  tests\test_vidzy_safe_fixes.py

Then run:  check_and_install.bat   and then   build.bat
Files that are NOT here (they are unchanged): icons, Lumo.spec, Lumo_Setup.iss,
requirements.txt, main_original.pyc, lumo_windows\other modules, tools\, vendor\.
If you have a full kit, use Lumo_Files_ALL.zip instead.
