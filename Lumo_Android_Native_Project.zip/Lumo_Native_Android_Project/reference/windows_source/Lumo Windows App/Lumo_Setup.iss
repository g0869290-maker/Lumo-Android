; Lumo installer (Inno Setup 6).
; Fully offline: everything the app needs is copied from dist\Lumo, so the
; installer never downloads anything on the target PC.
;
; Build with build.bat (it passes MyAppVersion). To compile by hand:
;   ISCC.exe /DMyAppVersion=1.0.1 Lumo_Setup.iss

#ifndef MyAppVersion
  #define MyAppVersion "1.0.1"
#endif
#define MyAppName "Lumo"
#define MyAppExeName "Lumo.exe"
#define SourceDir "dist\Lumo"

[Setup]
; Keep this AppId forever. Same AppId = upgrades replace the old install cleanly.
AppId={{B4C352F3-98F0-4666-9B8D-0EAF914F3C82}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppVerName={#MyAppName} {#MyAppVersion}
AppPublisher=Lumo
DefaultDirName={localappdata}\Programs\Lumo
DefaultGroupName=Lumo
DisableProgramGroupPage=yes
UsePreviousAppDir=no
UninstallDisplayName={#MyAppName}
UninstallDisplayIcon={app}\{#MyAppExeName}
SetupIconFile=Lumo_icon.ico
OutputDir=installer_output
OutputBaseFilename=LumoSetup
; Per-user install: no admin rights needed, works on locked-down PCs.
PrivilegesRequired=lowest
PrivilegesRequiredOverridesAllowed=dialog
; 64-bit build only. Windows 10 (1809) or newer.
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
MinVersion=10.0.17763
Compression=lzma2/max
SolidCompression=yes
WizardStyle=modern
; Close a running Lumo before upgrading, so its files can be replaced.
CloseApplications=yes
RestartApplications=no

[Tasks]
Name: "desktopicon"; Description: "Create a desktop shortcut"; GroupDescription: "Additional shortcuts:"; Flags: unchecked

[Files]
; Whole app folder: Lumo.exe, _internal (Python + libraries), ffmpeg.exe,
; ffprobe.exe and deno.exe. Nothing here needs internet access.
Source: "{#SourceDir}\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{autoprograms}\Lumo"; Filename: "{app}\{#MyAppExeName}"
Name: "{autodesktop}\Lumo"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "Launch Lumo"; Flags: postinstall nowait skipifsilent

; Uninstall removes the program files only. User data (settings, history,
; downloads) lives in %LOCALAPPDATA%\Lumo and is intentionally kept.
