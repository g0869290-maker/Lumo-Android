"""Launcher-side repairs and focused UI enhancements for the recovered Lumo UI.

The original compiled application remains the source of the interface. This
launcher applies targeted runtime changes while keeping the recovered app intact.
The reduced UI exposes Download and Settings only and removes two legacy
Download toggles without deleting shared download logic.
"""
from __future__ import annotations

import importlib.util
import math
import os
import re
import time
import subprocess
import sys
import threading
import hashlib
import tempfile
import urllib.request
import tkinter as tk
import tkinter.font as tkfont
from tkinter import colorchooser, filedialog, messagebox, ttk
from pathlib import Path
from types import ModuleType
from typing import Any

from lumo_windows.ui_patch import patch_module_code

DEFAULT_PROGRESS_COLOR = "#8871FF"


def _find_original_module() -> Path:
    """Locate main_original.pyc, the untouched recovered UI bytecode.

    The Lumo names are applied in memory at startup (see lumo_windows/ui_patch.py),
    so no pre-patched copy is ever read. That removes stale-file problems.
    """
    roots = []
    if getattr(sys, "_MEIPASS", None):
        roots.append(Path(sys._MEIPASS))
    here = Path(__file__).resolve().parent
    roots.append(here)
    for root in roots:
        candidate = root / "main_original.pyc"
        if candidate.is_file():
            return candidate
    raise FileNotFoundError(
        "Cannot locate main_original.pyc next to main.py. Copy the project folder "
        "again, keeping main_original.pyc in the top folder."
    )


def _load_original() -> ModuleType:
    path = _find_original_module()
    code, _stats = patch_module_code(path.read_bytes())
    spec = importlib.util.spec_from_file_location("_lumo_original_main", path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot create a loader for the original UI: {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    exec(code, module.__dict__)
    return module


def _noop_notification(self: Any, *args: Any, **kwargs: Any) -> None:
    """Suppress only app-generated toast-style notifications."""
    return None


def _appearance_choice(item: Any) -> bool:
    return (
        isinstance(item, (list, tuple))
        and len(item) >= 2
        and (str(item[0]).casefold() == "theme" or str(item[1]).casefold() == "appearance")
    )


def _light_choice(item: Any) -> bool:
    return isinstance(item, (list, tuple)) and len(item) >= 2 and (
        str(item[0]).casefold() == "light" or str(item[1]).casefold() == "light"
    )


def _customization_choice(item: Any) -> bool:
    return (
        isinstance(item, (list, tuple)) and len(item) >= 1
        and (
            str(item[0]).strip().casefold() in {"customization", "customisation"}
            or (len(item) >= 2 and str(item[1]).strip().casefold() in {"customization", "customisation"})
        )
    )


def _filter_choice_collection(choices: Any) -> Any:
    """Keep practical Settings tabs, add Progress Bar, and force Dark-only appearance."""
    if not isinstance(choices, (tuple, list)):
        return choices
    items = list(choices)
    has_dark_light = (
        any(isinstance(item, (tuple, list)) and len(item) >= 2 and
            (str(item[0]).casefold() == "dark" or str(item[1]).casefold() == "dark")
            for item in items)
        and any(_light_choice(item) for item in items)
    )
    identifiers = {
        str(item[0]).strip().casefold() for item in items
        if isinstance(item, (tuple, list)) and len(item) >= 2
    }
    is_settings_tab_list = {"accent", "downloads", "subtitles"}.issubset(identifiers)
    filtered = [item for item in items if not (
        _appearance_choice(item) or _customization_choice(item)
        or (has_dark_light and _light_choice(item))
    )]

    # The recovered Settings page builds its tab frames from this exact choice
    # list. Merely adding a frame after the page is built leaves no selectable
    # tab, so inject Progress Bar before the recovered chip/tab row is created.
    if is_settings_tab_list and not any(
        isinstance(item, (tuple, list)) and item and
        str(item[0]).strip().casefold() in {"progress", "progress_bar", "progress bar"}
        for item in filtered
    ):
        filtered.append(("progress", "Progress Bar"))

    # Normalize both labels without changing the underlying ids/commands.
    # Older recovered builds ship "Accent & indicator" with a lowercase I.
    renamed = []
    for item in filtered:
        if isinstance(item, (tuple, list)) and len(item) >= 2:
            key = str(item[0]).strip().casefold()
            label = str(item[1]).strip().casefold()
            wanted_label = None
            if key == "indicator":
                wanted_label = "Active Bar"
            elif key == "accent" and label.replace("and", "&").replace(" ", "") in {
                "accent&indicator", "accent&activeindicator"
            }:
                wanted_label = "Accent & Indicator"
            if wanted_label is not None and str(item[1]) != wanted_label:
                values = list(item)
                values[1] = wanted_label
                item = tuple(values) if isinstance(item, tuple) else values
        renamed.append(item)
    if renamed == items:
        return choices
    return tuple(renamed) if isinstance(choices, tuple) else renamed


def _install_repairs(module: ModuleType) -> None:
    """Apply the existing conservative Dark-mode and notification repairs."""
    original_palette = module.apply_palette

    def dark_palette(appearance: str, accent: str, indicator: str) -> None:
        original_palette("Dark", accent, indicator)

    module.apply_palette = dark_palette
    app_class = module.App

    original_chip_group = app_class._chip_group

    def repaired_chip_group(self: Any, *args: Any, **kwargs: Any) -> Any:
        mutable_args = list(args)
        mutable_kwargs = dict(kwargs)
        # App._chip_group(parent, options, variable, width, height): inspect all
        # arguments so this remains safe if the call uses a keyword instead.
        for index, value in enumerate(mutable_args):
            mutable_args[index] = _filter_choice_collection(value)
        for key, value in tuple(mutable_kwargs.items()):
            mutable_kwargs[key] = _filter_choice_collection(value)
        return original_chip_group(self, *mutable_args, **mutable_kwargs)

    app_class._chip_group = repaired_chip_group

    if hasattr(app_class, "_show_settings_tab"):
        original_show_tab = app_class._show_settings_tab

        def show_available_settings_tab(self: Any, *args: Any, **kwargs: Any) -> Any:
            variable = getattr(self, "settings_tab_var", None)
            if variable is not None:
                try:
                    current = str(variable.get()).casefold()
                    if current in {"theme", "appearance", "customization", "customisation"}:
                        variable.set("downloads")
                except Exception:
                    pass
            return original_show_tab(self, *args, **kwargs)

        app_class._show_settings_tab = show_available_settings_tab

    original_save = app_class.save_app_settings

    def save_dark_settings(self: Any, *args: Any, **kwargs: Any) -> Any:
        variable = getattr(self, "appearance_var", None)
        if variable is not None:
            try:
                variable.set("Dark")
            except Exception:
                pass
        return original_save(self, *args, **kwargs)

    app_class.save_app_settings = save_dark_settings

    # Keep the recovered notification methods. Earlier repair iterations replaced
    # these with no-ops, which unintentionally hid useful success/failure feedback.
    # Settings autosave already avoids success toasts, so broad suppression is not needed.


def _safe_hide_widget(widget: Any) -> None:
    """Hide a widget without assuming which Tk geometry manager owns it."""
    for method_name in ("pack_forget", "place_forget", "grid_remove"):
        try:
            method = getattr(widget, method_name, None)
            if callable(method):
                method()
        except Exception:
            # A widget can only be managed by one geometry manager. Errors from
            # the other two methods are expected and do not affect functionality.
            pass


_PROGRESS_SETTING_DEFAULTS: dict[str, Any] = {
    "progress_color": DEFAULT_PROGRESS_COLOR,
    "progress_glow_enabled": True,
    "progress_glow_intensity": 45,
    "progress_animation_enabled": True,
    "progress_animation_speed": "normal",
    "progress_thickness": 14,
}


_PROGRESS_GLIDE_MS = {"slow": 480, "normal": 320, "fast": 220}


def _progress_glide_ms(module: ModuleType) -> int:
    """How long the progress bar takes to glide to a new value, from the Settings speed."""
    options = getattr(module, "_LUMO_PROGRESS_OPTIONS", None)
    if not isinstance(options, dict):
        try:
            options = module.load_settings()
        except Exception:
            options = {}
    speed = str((options or {}).get("progress_animation_speed", "normal")).casefold()
    return _PROGRESS_GLIDE_MS.get(speed, _PROGRESS_GLIDE_MS["normal"])


def _install_progress_rendering_repairs(module: ModuleType) -> None:
    """Connect supported progress customisation values to the recovered renderer."""
    try:
        stored = module.load_settings()
    except Exception:
        stored = {}
    options = dict(_PROGRESS_SETTING_DEFAULTS)
    if isinstance(stored, dict):
        options.update({key: stored.get(key, default)
                        for key, default in _PROGRESS_SETTING_DEFAULTS.items()})
        # One-time move of saved thickness values below 14 px (for example the old 10 px)
        # to the slightly thicker 14 px default. Values of 14 px and above are kept.
        if not stored.get("progress_thickness_default_v4"):
            try:
                if int(options.get("progress_thickness", 14)) < 14:
                    options["progress_thickness"] = 14
                migrated = dict(stored)
                migrated["progress_thickness"] = options["progress_thickness"]
                migrated["progress_thickness_default_v2"] = True
                migrated["progress_thickness_default_v3"] = True
                migrated["progress_thickness_default_v4"] = True
                module.save_settings(migrated)
            except Exception:
                pass
    module._LUMO_PROGRESS_OPTIONS = options
    module.PROGRESS_COLOR = str(options.get("progress_color", DEFAULT_PROGRESS_COLOR)).upper()

    # The recovered bar is drawn as a two-colour gradient. Point both ends at
    # the chosen progress colour so the custom colour is independent of Accent.
    try:
        draw = module.GlowProgress.draw_content
        code = draw.__code__
        if "PROGRESS_COLOR" not in code.co_names:
            code = code.replace(co_names=tuple(
                "PROGRESS_COLOR" if name in {"ACCENT", "CYAN"} else name
                for name in code.co_names
            ))
            draw.__code__ = code
        module._LUMO_PROGRESS_DRAW_CODE = draw.__code__
    except Exception:
        module._LUMO_PROGRESS_DRAW_CODE = None

    # Scale only the glow generated by GlowProgress. Other app glows keep their
    # original appearance because the caller-code check excludes other widgets.
    try:
        original_glow_layer = module.glow_layer
        original_glow_code = getattr(original_glow_layer, "__code__", None)
        glow_parameters = (
            original_glow_code.co_varnames[:original_glow_code.co_argcount]
            if original_glow_code is not None else ()
        )

        def tuned_glow_layer(*args: Any, **kwargs: Any) -> Any:
            try:
                is_progress_draw = (
                    sys._getframe(1).f_code is getattr(module, "_LUMO_PROGRESS_DRAW_CODE", None)
                )
            except Exception:
                is_progress_draw = False
            if not is_progress_draw:
                return original_glow_layer(*args, **kwargs)
            settings = getattr(module, "_LUMO_PROGRESS_OPTIONS", {})
            glow_on = bool(settings.get("progress_glow_enabled", True))
            try:
                intensity = max(0, min(100, int(settings.get("progress_glow_intensity", 45))))
            except (TypeError, ValueError):
                intensity = 45
            mutable_args = list(args)
            alpha_index = glow_parameters.index("alpha") if "alpha" in glow_parameters else 6
            if len(mutable_args) > alpha_index:
                try:
                    current_alpha = float(mutable_args[alpha_index])
                except (TypeError, ValueError):
                    current_alpha = 0.0
                mutable_args[alpha_index] = current_alpha * (intensity / 100.0) if glow_on else 0.0
            elif "alpha" in kwargs:
                try:
                    current_alpha = float(kwargs["alpha"])
                except (TypeError, ValueError):
                    current_alpha = 0.0
                kwargs["alpha"] = current_alpha * (intensity / 100.0) if glow_on else 0.0
            return original_glow_layer(*mutable_args, **kwargs)

        module.glow_layer = tuned_glow_layer
    except Exception:
        pass

    # The original progress tween calls start_tween(..., "_value_tween", 420,
    # ...). Adjust only that tween, leaving navigation/button animations alone.
    try:
        original_start_tween = module.start_tween

        def tuned_start_tween(owner: Any, attr: str, duration_ms: Any, on_frame: Any,
                              *args: Any, **kwargs: Any) -> Any:
            # Every other tween (buttons, hover, page changes) is forwarded exactly as
            # the caller wrote it, so the original defaults still apply. An earlier
            # version passed easing=None by default, which crashed every button press.
            # Page changes show at once: no slide or fade. The shortest tween still runs
            # the original completion path, so the page is switched in the first frame.
            if attr == "_page_tween":
                return original_start_tween(owner, attr, 1, on_frame, *args, **kwargs)
            is_progress_tween = owner.__class__.__name__ == "GlowProgress" and attr == "_value_tween"
            if not is_progress_tween:
                return original_start_tween(owner, attr, duration_ms, on_frame, *args, **kwargs)
            # The bar glides to each new progress value over a short, speed-dependent
            # time. A 1 ms tween made it jump, which looked like jerky pushing; the
            # durations below stay short so the bar still tracks the real value closely.
            duration_ms = _progress_glide_ms(module)
            easing = kwargs.pop("easing", args[0] if args else None)
            on_done = kwargs.pop("on_done", args[1] if len(args) > 1 else None)
            if easing is None:
                easing = getattr(module, "ease_out_cubic", None) or (lambda t: t)
            return original_start_tween(owner, attr, duration_ms, on_frame, easing, on_done)

        module.start_tween = tuned_start_tween
    except Exception:
        pass

    # The height argument is already the renderer's native thickness control;
    # keep the original layout by using 5 px as the default.
    try:
        progress_class = module.GlowProgress
        original_init = progress_class.__init__

        def tuned_progress_init(self: Any, parent: Any, height: Any = 5, *args: Any,
                                **kwargs: Any) -> Any:
            settings = getattr(module, "_LUMO_PROGRESS_OPTIONS", {})
            try:
                fill = max(9, min(16, int(settings.get("progress_thickness", 14))))
            except (TypeError, ValueError):
                fill = 12
            # The bar fills its canvas minus a 3 px inset on each side, so add that back.
            return original_init(self, parent, fill + 6, *args, **kwargs)

        progress_class.__init__ = tuned_progress_init
    except Exception:
        pass


def _widget_text(widget: Any) -> str:
    try:
        value = widget.cget("text")
        if value:
            return str(value)
    except Exception:
        pass
    for name in ("text", "label", "label_text", "title"):
        value = getattr(widget, name, None)
        if value:
            return str(value)
    return ""


def _descendants(widget: Any) -> list[Any]:
    result = []
    try:
        children = widget.winfo_children()
    except Exception:
        children = []
    for child in children:
        result.append(child)
        result.extend(_descendants(child))
    return result


def _add_settings_tab_button(app: Any, module: ModuleType, label: str,
                             key: str, anchor: Any) -> None:
    """Add a tab button next to an existing colour-tab button when discoverable."""
    candidates = _descendants(app)
    # Avoid creating a second Progress Bar button when the recovered chip row
    # already received the option through _filter_choice_collection.
    if any(_widget_text(widget).strip().casefold() in {"progress bar", "progress"}
           for widget in candidates):
        return
    target = None
    for widget in candidates:
        text = _widget_text(widget).strip().casefold()
        if text in {"accent", "indicator", "accent & indicator", "accent and indicator"}:
            target = widget
            break
    if target is None:
        return
    options = {}
    for option in ("background", "foreground", "activebackground", "activeforeground",
                   "font", "relief", "bd", "highlightthickness", "padx", "pady",
                   "cursor", "anchor"):
        try:
            options[option] = target.cget(option)
        except Exception:
            pass
    options.setdefault("background", getattr(module, "PANEL", getattr(module, "BG", "#0E0F14")))
    options.setdefault("foreground", getattr(module, "TEXT", "#F4F6FB"))
    options.setdefault("font", ("Segoe UI", 9, "bold"))
    options.setdefault("relief", "flat")
    options.setdefault("bd", 0)
    options.setdefault("cursor", "hand2")

    def select_tab() -> None:
        variable = getattr(app, "settings_tab_var", None)
        if variable is not None:
            try:
                variable.set(key)
            except Exception:
                pass
        try:
            app._show_settings_tab()
        except Exception:
            pass

    button = tk.Button(target.master, text=label, command=select_tab, **options)
    try:
        pack_info = target.pack_info()
        side = pack_info.get("side", "left")
        padx = pack_info.get("padx", 4)
        pady = pack_info.get("pady", 0)
        button.pack(side=side, padx=padx, pady=pady, after=target)
    except Exception:
        try:
            button.pack(side="left", padx=4, pady=0)
        except Exception:
            button.destroy()
            return
    app._lumo_progress_tab_button = button


def _rename_indicator_labels(app: Any) -> None:
    """Use the concise, consistent label 'Indicator' in Settings."""
    for widget in _descendants(app):
        label = _widget_text(widget).strip()
        if label.casefold().startswith(("active indicator", "active bar")):
            try:
                widget.configure(text="Active Bar")
            except Exception:
                pass


def _canonical_settings_tab_key(value: Any) -> str:
    """Normalize display labels and stored IDs to stable Settings-tab keys."""
    compact = "".join(ch for ch in str(value).strip().casefold() if ch.isalnum())
    aliases = {
        "progressbar": "progress", "progresscolour": "progress",
        "progresscolor": "progress", "progress": "progress",
        "accentcolour": "accent", "accentcolor": "accent",
        "accentindicator": "accent", "accentandindicator": "accent",
        "activebar": "indicator", "activeindicator": "indicator",
        "indicatorcolour": "indicator", "indicatorcolor": "indicator",
        "downloads": "downloads", "download": "downloads",
        "subtitles": "subtitles", "subtitle": "subtitles",
        "history": "history", "playlist": "playlist",
        "theme": "theme", "appearance": "theme",
        "customization": "customization", "customisation": "customization",
    }
    return aliases.get(compact, compact)


def _resolve_settings_tab_key(tabs: Any, value: Any) -> Any:
    """Return the real key for a Settings tab, accepting old/display aliases."""
    if not isinstance(tabs, dict):
        return None
    wanted = _canonical_settings_tab_key(value)
    for key in tabs:
        if _canonical_settings_tab_key(key) == wanted:
            return key
    # In this recovered UI Accent and Active Indicator share one page.
    if wanted == "indicator":
        for key in tabs:
            if _canonical_settings_tab_key(key) == "accent":
                return key
    return None


def _restore_primary_page_without_animation(
    app: Any, page_key: Any, module: ModuleType,
    title_text: Any = None, hint_text: Any = None,
) -> None:
    """Restore the main navigation selection after a settings rebuild, without a tween.

    Rebuilding the recovered UI recreates all primary pages and normally defaults
    to Download. That left Download's sidebar marker selected even when the user
    had just changed a colour inside Settings. This restores the page and its
    active marker in one pass; it deliberately does not start another animation.
    """
    key = str(page_key or "download").strip().casefold()
    pages = getattr(app, "pages", None)
    if not isinstance(pages, dict) or key not in pages:
        return

    cancel_tween = getattr(module, "cancel_tween", None)
    if callable(cancel_tween):
        try:
            cancel_tween(app, "_page_tween")
        except Exception:
            pass

    target = pages.get(key)
    for name, frame in tuple(pages.items()):
        try:
            if str(name).casefold() == key:
                frame.place(x=0, y=0, relwidth=1, relheight=1)
            else:
                _safe_hide_widget(frame)
        except Exception:
            if str(name).casefold() != key:
                _safe_hide_widget(frame)
    try:
        app.current_display_page = key
    except Exception:
        pass

    rows = getattr(app, "nav_rows", {})
    if isinstance(rows, dict):
        for name, row in rows.items():
            setter = getattr(row, "set_active", None)
            if callable(setter):
                try:
                    setter(str(name).casefold() == key)
                except Exception:
                    pass

    if title_text is None:
        title_text = {
            "download": "Download", "history": "History",
            "settings": "Settings", "playlist": "Playlist",
        }.get(key, key.title())
    try:
        page_title = getattr(app, "page_title", None)
        if page_title is not None:
            page_title.configure(text=str(title_text))
    except Exception:
        pass
    try:
        top_hint = getattr(app, "top_hint", None)
        if top_hint is not None and hint_text is not None:
            top_hint.configure(text=str(hint_text))
    except Exception:
        pass
    try:
        dot = getattr(app, "page_status_dot", None)
        if dot is not None:
            downloading = getattr(app, "active_job_id", None) is not None
            dot.configure(
                text="●  DOWNLOADING" if downloading else "●  READY",
                fg=getattr(module, "CYAN" if downloading else "GOOD", "#55D8F2"),
            )
    except Exception:
        pass
    # Do not add the page to _lumo_warmed_pages here. A direct restore is not
    # evidence that its hidden first-map/layout work completed; the warm-up job
    # owns that state, otherwise the first visit remains cold and jitters.


def _install_selected_swatch_tick_removal(module: ModuleType) -> None:
    """Remove the selected-colour checkmark while retaining the selected outline.

    The recovered Squircle draws its selected marker into a supersampled Pillow
    image (not as a Tk text item). Intercept the small, centre-local line/polygon
    only while that image is being rendered; the large squircle fill and outline
    still render normally. The direct Canvas fallback also catches text markers
    in alternate recovered builds.
    """
    swatch_class = getattr(module, "Squircle", None)
    original_render = getattr(swatch_class, "_render", None) if swatch_class is not None else None
    if not callable(original_render) or getattr(original_render, "_lumo_no_selected_tick", False):
        return

    tick_glyphs = {"✓", "✔", "☑", "√", "✔️"}

    def point_values(points: Any) -> list[tuple[float, float]]:
        """Normalize Pillow line/polygon coordinates to point pairs."""
        result: list[tuple[float, float]] = []
        try:
            values = list(points)
            if values and isinstance(values[0], (tuple, list)) and len(values[0]) >= 2:
                for value in values:
                    if isinstance(value, (tuple, list)) and len(value) >= 2:
                        result.append((float(value[0]), float(value[1])))
            elif len(values) >= 4:
                result = [(float(values[i]), float(values[i + 1]))
                          for i in range(0, len(values) - 1, 2)]
        except (TypeError, ValueError, OverflowError):
            return []
        return result

    def is_centre_mark(points: Any, width: int, height: int) -> bool:
        # The source marker is a small check drawn at the centre. The swatch fill
        # and selected ring span most of the image, so they fail this size test.
        pairs = point_values(points)
        if len(pairs) < 2 or width <= 0 or height <= 0:
            return False
        xs = [point[0] for point in pairs]
        ys = [point[1] for point in pairs]
        left, right = min(xs), max(xs)
        top, bottom = min(ys), max(ys)
        mark_w, mark_h = right - left, bottom - top
        cx, cy = (left + right) / 2.0, (top + bottom) / 2.0
        return (
            width * 0.07 <= mark_w <= width * 0.52
            and height * 0.07 <= mark_h <= height * 0.52
            and abs(cx - width / 2.0) <= width * 0.17
            and abs(cy - height / 2.0) <= height * 0.17
        )

    def render_without_selected_tick(self: Any, *args: Any, **kwargs: Any) -> Any:
        canvases = []
        for candidate in (self, getattr(self, "canvas", None), getattr(self, "_canvas", None),
                          getattr(self, "surface", None)):
            if candidate is not None and callable(getattr(candidate, "create_text", None)):
                if all(candidate is not seen for seen in canvases):
                    canvases.append(candidate)
        restored_canvas_methods = []
        render_globals = getattr(original_render, "__globals__", {})
        draw_module = render_globals.get("ImageDraw") if isinstance(render_globals, dict) else None
        original_draw_factory = getattr(draw_module, "Draw", None) if draw_module is not None else None
        original_draw_binding = render_globals.get("ImageDraw") if isinstance(render_globals, dict) else None

        class DrawWithoutCentreTick:
            def __init__(self, delegate: Any, image_size: tuple[int, int]):
                self._delegate = delegate
                self._width, self._height = image_size

            def line(self, points: Any, *draw_args: Any, **draw_kwargs: Any) -> Any:
                if is_centre_mark(points, self._width, self._height):
                    return None
                return self._delegate.line(points, *draw_args, **draw_kwargs)

            def polygon(self, points: Any, *draw_args: Any, **draw_kwargs: Any) -> Any:
                if is_centre_mark(points, self._width, self._height):
                    return None
                return self._delegate.polygon(points, *draw_args, **draw_kwargs)

            def __getattr__(self, name: str) -> Any:
                return getattr(self._delegate, name)

        try:
            # Pillow's Draw factory is resolved from the recovered module globals.
            # Scope the interception to this render and restore it even on errors.
            if callable(original_draw_factory) and draw_module is not None and isinstance(render_globals, dict):
                class ImageDrawWithoutCentreTick:
                    def Draw(_proxy, image: Any, *draw_args: Any, **draw_kwargs: Any) -> Any:
                        delegate = original_draw_factory(image, *draw_args, **draw_kwargs)
                        try:
                            image_size = tuple(image.size)
                            return DrawWithoutCentreTick(delegate, (int(image_size[0]), int(image_size[1])))
                        except Exception:
                            return delegate

                    def __getattr__(_proxy, name: str) -> Any:
                        return getattr(draw_module, name)

                render_globals["ImageDraw"] = ImageDrawWithoutCentreTick()

            for canvas in canvases:
                had_own = "create_text" in getattr(canvas, "__dict__", {})
                old_own = getattr(canvas, "__dict__", {}).get("create_text")
                original_method = getattr(canvas, "create_text")
                def create_text_filtered(*draw_args: Any, __original=original_method, **draw_kwargs: Any) -> Any:
                    text_value = draw_kwargs.get("text")
                    if str(text_value or "").strip() in tick_glyphs:
                        return None
                    return __original(*draw_args, **draw_kwargs)
                try:
                    setattr(canvas, "create_text", create_text_filtered)
                    restored_canvas_methods.append((canvas, had_own, old_own))
                except Exception:
                    pass
            result = original_render(self, *args, **kwargs)
            for canvas in canvases:
                try:
                    for item_id in canvas.find_all():
                        if str(canvas.type(item_id)).casefold() == "text" and str(
                            canvas.itemcget(item_id, "text")
                        ).strip() in tick_glyphs:
                            canvas.delete(item_id)
                except Exception:
                    pass
            return result
        finally:
            if isinstance(render_globals, dict):
                try:
                    render_globals["ImageDraw"] = original_draw_binding
                except Exception:
                    pass
            for canvas, had_own, old_own in reversed(restored_canvas_methods):
                try:
                    if had_own:
                        setattr(canvas, "create_text", old_own)
                    else:
                        delattr(canvas, "create_text")
                except Exception:
                    pass

    render_without_selected_tick._lumo_no_selected_tick = True
    swatch_class._render = render_without_selected_tick

    # Settings tabs are ChoiceChip Canvas widgets. Their recovered draw_content()
    # hard-codes a leading "✓  " for the selected chip, so patching only Squircle
    # colour swatches (the old implementation) cannot remove the visible tick.
    chip_class = getattr(module, "ChoiceChip", None)
    original_chip_draw = getattr(chip_class, "draw_content", None) if chip_class is not None else None
    if callable(original_chip_draw) and not getattr(original_chip_draw, "_lumo_no_settings_tick", False):
        def draw_choice_without_tick(self: Any, *args: Any, **kwargs: Any) -> Any:
            original_create_text = getattr(self, "create_text", None)
            restored_own = "create_text" in getattr(self, "__dict__", {})
            previous_own = getattr(self, "__dict__", {}).get("create_text")
            if callable(original_create_text):
                def create_text_without_tick(*draw_args: Any, **draw_kwargs: Any) -> Any:
                    value = draw_kwargs.get("text")
                    if isinstance(value, str) and value.startswith("✓"):
                        draw_kwargs["text"] = value.lstrip("✓ 	")
                    return original_create_text(*draw_args, **draw_kwargs)
                try:
                    self.create_text = create_text_without_tick
                except Exception:
                    original_text = original_create_text
                    def create_text_without_tick(*draw_args: Any, **draw_kwargs: Any) -> Any:
                        value = draw_kwargs.get("text")
                        if isinstance(value, str) and value.startswith("✓"):
                            draw_kwargs["text"] = value.lstrip("✓ 	")
                        return original_text(*draw_args, **draw_kwargs)
                    try:
                        self.bind("<Expose>", lambda _event: None, add="+")
                    except Exception:
                        pass
                    # A descriptor-only widget is unlikely in the recovered Canvas
                    # build; continue with its native draw function if it cannot be
                    # safely intercepted per instance.
                    return original_chip_draw(self, *args, **kwargs)
            try:
                return original_chip_draw(self, *args, **kwargs)
            finally:
                try:
                    if restored_own:
                        self.create_text = previous_own
                    else:
                        delattr(self, "create_text")
                except Exception:
                    pass
        draw_choice_without_tick._lumo_no_settings_tick = True  # type: ignore[attr-defined]
        chip_class.draw_content = draw_choice_without_tick


def _install_settings_ui_repairs(module: ModuleType) -> None:
    """Keep Dark-only appearance, restore colour controls, and auto-save settings."""
    app_class = module.App
    original_build_settings = app_class.build_settings_page
    original_show_settings_tab = getattr(app_class, "_show_settings_tab", None)

    def show_settings_tab_without_bouncing(self: Any, *args: Any, **kwargs: Any) -> Any:
        """Normalize the selected key, then let the recovered handler update both page and chip visuals."""
        tabs = getattr(self, "settings_tabs", None)
        variable = getattr(self, "settings_tab_var", None)
        if not isinstance(tabs, dict) or variable is None:
            return original_show_settings_tab(self, *args, **kwargs) if callable(original_show_settings_tab) else None

        try:
            requested = variable.get()
        except Exception:
            requested = "downloads"
        target_key = _resolve_settings_tab_key(tabs, requested)
        if target_key is None:
            target_key = _resolve_settings_tab_key(tabs, "downloads")
        if target_key is None:
            return original_show_settings_tab(self, *args, **kwargs) if callable(original_show_settings_tab) else None

        # The original handler updates the active chip/highlight as well as the page.
        # The previous direct-pack-only workaround displayed the right page but left
        # the old Downloads chip selected, making two tabs look active at once.
        try:
            if str(variable.get()).strip() != str(target_key):
                variable.set(str(target_key))
        except Exception:
            pass
        if callable(original_show_settings_tab):
            try:
                result = original_show_settings_tab(self, *args, **kwargs)
                try:
                    selected_after = _resolve_settings_tab_key(tabs, variable.get())
                except Exception:
                    selected_after = None
                target = tabs.get(target_key)
                try:
                    target_visible = target is not None and target.winfo_manager() in {"pack", "grid", "place"}
                except Exception:
                    target_visible = target is not None
                if selected_after == target_key and target_visible:
                    return result
                # Some recovered builds reject an alias even after normalization.
                # Restore the requested key and fall through to a safe page switch.
                try:
                    variable.set(str(target_key))
                except Exception:
                    pass
            except Exception:
                pass

        target = tabs.get(target_key)
        for key, frame in tuple(tabs.items()):
            if frame is target:
                continue
            try:
                frame.pack_forget()
            except Exception:
                _safe_hide_widget(frame)
        try:
            target.pack(fill="both", expand=True)
        except Exception:
            try:
                manager = getattr(target, "winfo_manager", lambda: "")()
                if manager == "grid":
                    target.grid(sticky="nsew")
                elif manager == "place":
                    target.place(x=0, y=0, relwidth=1, relheight=1)
            except Exception:
                pass
        return None

    if callable(original_show_settings_tab):
        app_class._show_settings_tab = show_settings_tab_without_bouncing

    def hide_cookie_status(self: Any, on: bool = False) -> None:
        # Cookie import/use is untouched; only the visible status label is hidden.
        badge = getattr(self, "cookie_badge", None)
        if badge is not None:
            _safe_hide_widget(badge)

    app_class.set_cookie_badge = hide_cookie_status

    def has_progress_colour_control(root: Any) -> bool:
        for widget in _walk_widgets(root):
            text = str(getattr(widget, "label", getattr(widget, "text", ""))).casefold()
            if not text:
                try:
                    text = str(widget.cget("text")).casefold()
                except Exception:
                    pass
            if "progress bar colour" in text or "progress bar color" in text:
                return True
        return False

    def build_settings_page(self: Any) -> Any:
        result = original_build_settings(self)
        tabs = getattr(self, "settings_tabs", None)
        # Remove only appearance/theme choices. Accent/indicator and progress
        # colour controls are practical customisation settings and must remain.
        removed_keys = {"theme", "appearance", "customization", "customisation"}
        if isinstance(tabs, dict):
            for key in tuple(tabs):
                if str(key).casefold() not in removed_keys:
                    continue
                frame = tabs.pop(key, None)
                if frame is not None:
                    try:
                        frame.destroy()
                    except Exception:
                        _safe_hide_widget(frame)

            # Keep Progress Bar as its own Settings tab beside Accent and
            # Indicator. The recovered build may not have a Progress tab, so
            # create only that missing tab and a matching tab button.
            progress_parent = tabs.get("progress") or tabs.get("Progress")
            if progress_parent is None:
                anchor = next((tabs.get(key) for key in
                               ("downloads", "subtitles", "accent", "indicator", "Accent", "Indicator")
                               if tabs.get(key) is not None), None)
                if anchor is not None:
                    try:
                        # All recovered tab pages are siblings under the Settings
                        # content host. Using a sibling's master makes the new
                        # frame reachable by the original _show_settings_tab().
                        progress_parent = tk.Frame(
                            anchor.master, bg=getattr(module, "BG", "#0E0F14"),
                            bd=0, highlightthickness=0,
                        )
                        tabs["progress"] = progress_parent
                        _add_settings_tab_button(self, module, "Progress Bar", "progress", anchor)
                    except Exception:
                        progress_parent = None
            if progress_parent is not None and not has_progress_colour_control(progress_parent):
                try:
                    _add_progress_customisation(self, module, progress_parent)
                except Exception as exc:
                    logger = getattr(module, "log_line", None)
                    if callable(logger):
                        try:
                            logger(f"Could not restore progress colour controls: {exc}")
                        except Exception:
                            pass
            _rename_indicator_labels(self)

        # Keep an existing subtab by meaning, not by exact spelling. Accent variants
        # used by recovered builds (for example "Accent & Indicator") must not be
        # treated as invalid and silently replaced by Downloads.
        selector = getattr(self, "settings_tab_var", None)
        if selector is not None:
            try:
                # During a full palette rebuild, use the tab the user was on
                # before the rebuild creates a fresh StringVar. Otherwise the
                # new chip group briefly defaults to Downloads and leaves its
                # active underline visible beside Accent/Indicator.
                preferred = getattr(self, "_lumo_settings_tab_restore_key", None)
                selected = preferred if preferred is not None else selector.get()
                resolved = _resolve_settings_tab_key(tabs, selected)
                if resolved is None:
                    resolved = _resolve_settings_tab_key(tabs, "downloads")
                if resolved is None and isinstance(tabs, dict) and tabs:
                    resolved = next(iter(tabs))
                if resolved is not None:
                    selector.set(str(resolved))
            except Exception:
                pass

        hide_cookie_status(self, False)
        _hide_manual_save_ui(self, module)
        _wire_automatic_settings_save(self, module)
        try:
            self._show_settings_tab()
        except Exception:
            pass
        return result

    app_class.build_settings_page = build_settings_page

    # Accent/Indicator changes make the recovered save handler call rebuild_ui().
    # That creates a NEW settings_tab_var; restoring the old StringVar cannot stop
    # the rebuilt page from defaulting to Downloads. Restore against the new tabs.
    original_rebuild_settings_ui = getattr(app_class, "rebuild_ui", None)
    if callable(original_rebuild_settings_ui) and not getattr(original_rebuild_settings_ui, "_lumo_settings_tab_restore", False):
        def rebuild_ui_preserving_settings_tab(self: Any, *args: Any, **kwargs: Any) -> Any:
            old_page = str(getattr(self, "current_display_page", "download") or "download").casefold()
            old_var = getattr(self, "settings_tab_var", None)
            try:
                selected_before = old_var.get() if old_var is not None else None
            except Exception:
                selected_before = None
            old_title = old_hint = None
            try:
                old_title = self.page_title.cget("text")
            except Exception:
                pass
            try:
                old_hint = self.top_hint.cget("text")
            except Exception:
                pass

            # Let build_settings_page select the previous subtab before it draws
            # its chips. This avoids a transient Downloads highlight on every
            # Accent/Indicator colour update.
            try:
                self._lumo_settings_tab_restore_key = selected_before
            except Exception:
                pass
            try:
                result = original_rebuild_settings_ui(self, *args, **kwargs)
            finally:
                try:
                    del self._lumo_settings_tab_restore_key
                except Exception:
                    pass

            new_var = getattr(self, "settings_tab_var", None)
            new_tabs = getattr(self, "settings_tabs", None)
            if selected_before is not None and new_var is not None and isinstance(new_tabs, dict):
                key = _resolve_settings_tab_key(new_tabs, selected_before)
                if key is not None:
                    try:
                        current = _resolve_settings_tab_key(new_tabs, new_var.get())
                        frame = new_tabs.get(key)
                        try:
                            visible = frame is not None and frame.winfo_manager() in {"pack", "grid", "place"}
                        except Exception:
                            visible = frame is not None
                        # Reapply the selected subtab after rebuild. The frame can be
                        # correct while a stale Downloads chip still appears active.
                        new_var.set(str(key))
                        self._show_settings_tab()
                    except Exception:
                        pass

            # save_app_settings rebuilds the entire application, not just the
            # colour palette. Preserve the user's primary page (especially
            # Settings) without running a second animated navigation transition.
            if old_page in {"download", "history", "settings", "playlist"}:
                _restore_primary_page_without_animation(
                    self, old_page, module, title_text=old_title, hint_text=old_hint
                )
            return result
        rebuild_ui_preserving_settings_tab._lumo_settings_tab_restore = True
        app_class.rebuild_ui = rebuild_ui_preserving_settings_tab

    original_save_settings = app_class.save_app_settings
    def save_settings_preserving_subtab(self: Any, *args: Any, **kwargs: Any) -> Any:
        # The recovered folder-picker and access-toggle callbacks call this method
        # directly. If the only pending edits are download/cookie paths or simple
        # toggles, persist them without destroying/rebuilding the UI mid-click.
        try:
            current_settings = getattr(self, "settings", {})
            if isinstance(current_settings, dict):
                path_toggle_map = {
                    "cookie_var": "use_cookies", "use_cookies_var": "use_cookies",
                    "youtube_access_var": "use_cookies", "youtube_access_toggle_var": "use_cookies",
                    "merge_var": "merge_to_mp4", "merge_to_mp4_var": "merge_to_mp4",
                    "preferred_subtitle_var": "preferred_subtitle",
                    "download_dir_var": "download_dir", "download_path_var": "download_dir",
                    "download_folder_var": "download_dir", "cookie_file_var": "cookie_file",
                    "cookies_file_var": "cookie_file",
                }
                pending_keys = set()
                for attribute, key in path_toggle_map.items():
                    variable = getattr(self, attribute, None)
                    if variable is None or not callable(getattr(variable, "get", None)):
                        continue
                    value = variable.get()
                    if key in {"use_cookies", "merge_to_mp4"}:
                        value = (str(value).strip().casefold() in {"1", "true", "yes", "on"}
                                 if isinstance(value, str) else bool(value))
                    elif key in {"download_dir", "cookie_file"}:
                        value = str(value or "").strip()
                    # False is a real switch change. Only an empty download
                    # folder is rejected; an empty cookie path intentionally clears it.
                    value_is_usable = key != "download_dir" or bool(value)
                    if value_is_usable and current_settings.get(key) != value:
                        pending_keys.add(key)
                if pending_keys and pending_keys.issubset({"use_cookies", "merge_to_mp4", "download_dir", "cookie_file", "preferred_subtitle"}):
                    if _persist_current_path_and_toggle_settings(self, module):
                        _hide_manual_save_ui(self, module)
                        return None
        except Exception:
            pass

        before_var = getattr(self, "settings_tab_var", None)
        try:
            selected = before_var.get() if before_var is not None else None
        except Exception:
            selected = None
        result = original_save_settings(self, *args, **kwargs)
        # save_app_settings can rebuild the whole UI and replace settings_tab_var.
        current_var = getattr(self, "settings_tab_var", None)
        current_tabs = getattr(self, "settings_tabs", None)
        if selected is not None and current_var is not None:
            key = _resolve_settings_tab_key(current_tabs, selected)
            if key is not None:
                try:
                    current = _resolve_settings_tab_key(current_tabs, current_var.get())
                    frame = current_tabs.get(key) if isinstance(current_tabs, dict) else None
                    try:
                        visible = frame is not None and frame.winfo_manager() in {"pack", "grid", "place"}
                    except Exception:
                        visible = frame is not None
                    if current != key or not visible:
                        current_var.set(str(key))
                        self._show_settings_tab()
                except Exception:
                    pass
        return result
    app_class.save_app_settings = save_settings_preserving_subtab

    # The recovered Browse handlers only updated StringVars and delegated to the
    # global save/rebuild. On Windows, the dialog could appear behind Lumo and the
    # rebuild could destroy the control during its callback. Replace those two
    # handlers with parented dialogs and a synchronous, in-place preference write.
    def persist_browse_value(self: Any, attribute: str, key: str, value: str) -> bool:
        variable = getattr(self, attribute, None)
        if variable is None or not callable(getattr(variable, "set", None)):
            return False
        try:
            variable.set(value)
        except Exception:
            return False
        if _persist_live_toggle_value(self, module, attribute):
            pending = getattr(self, "_lumo_autosave_after_id", None)
            if pending is not None:
                try:
                    self.after_cancel(pending)
                except Exception:
                    pass
                self._lumo_autosave_after_id = None
            return True
        try:
            values = module.load_settings() if callable(getattr(module, "load_settings", None)) else {}
        except Exception:
            values = {}
        if not isinstance(values, dict):
            values = {}
        current = getattr(self, "settings", None)
        if isinstance(current, dict):
            values.update(current)
        values[key] = value
        saver = getattr(module, "save_settings", None)
        if not callable(saver):
            return False
        try:
            saver(values)
            if isinstance(current, dict):
                current.update(values)
            else:
                self.settings = values
            return True
        except Exception as error:
            logger = getattr(module, "log_line", None)
            if callable(logger):
                try:
                    logger(f"Could not save {key} selected by Browse: {error}")
                except Exception:
                    pass
            return False

    def browse_download_dir_responsive(self: Any, *args: Any, **kwargs: Any) -> Any:
        attribute, variable = _setting_variable(self, ("download_dir_var", "download_path_var", "download_folder_var"))
        try:
            current = Path(str(variable.get() if variable is not None else "")).expanduser()
        except Exception:
            current = Path.home()
        initial = current if current.is_dir() else Path.home()
        dialog = getattr(module, "filedialog", filedialog)
        try:
            chosen = dialog.askdirectory(parent=self, title="Choose download folder", initialdir=str(initial))
        except TypeError:
            chosen = dialog.askdirectory(initialdir=str(initial))
        except Exception as error:
            logger = getattr(module, "log_line", None)
            if callable(logger):
                try:
                    logger(f"Download-folder picker failed: {error}")
                except Exception:
                    pass
            return None
        if not chosen:
            return None
        chosen = str(Path(chosen).expanduser())
        if not attribute or not persist_browse_value(self, attribute, "download_dir", chosen):
            try:
                messagebox.showerror("Download folder", "Lumo could not save the selected download folder.", parent=self)
            except Exception:
                pass
        _hide_manual_save_ui(self, module)
        return None

    def browse_cookie_file_responsive(self: Any, *args: Any, **kwargs: Any) -> Any:
        attribute, variable = _setting_variable(self, ("cookie_file_var", "cookies_file_var"))
        try:
            current = Path(str(variable.get() if variable is not None else "")).expanduser()
            initial = current.parent if current.parent.is_dir() else Path.home()
        except Exception:
            initial = Path.home()
        dialog = getattr(module, "filedialog", filedialog)
        try:
            chosen = dialog.askopenfilename(
                parent=self, title="Select cookie file", initialdir=str(initial),
                filetypes=(("Cookie/text files", "*.txt"), ("All files", "*.*")),
            )
        except TypeError:
            chosen = dialog.askopenfilename(
                title="Select cookie file", filetypes=(("Cookie/text files", "*.txt"), ("All files", "*.*")),
            )
        except Exception as error:
            logger = getattr(module, "log_line", None)
            if callable(logger):
                try:
                    logger(f"Cookie-file picker failed: {error}")
                except Exception:
                    pass
            return None
        if not chosen:
            return None
        chosen = str(Path(chosen).expanduser())
        if not attribute or not persist_browse_value(self, attribute, "cookie_file", chosen):
            try:
                messagebox.showerror("Cookie file", "Lumo could not save the selected cookie file.", parent=self)
            except Exception:
                pass
        _hide_manual_save_ui(self, module)
        return None

    if callable(getattr(app_class, "browse_download_dir", None)):
        app_class.browse_download_dir = browse_download_dir_responsive
    if callable(getattr(app_class, "browse_cookie_file", None)):
        app_class.browse_cookie_file = browse_cookie_file_responsive


_CUSTOMIZATION_DEFAULTS: dict[str, bool] = {
    "show_history_action_icons": False,
    "animate_history_action_icons": False,
    "show_open_location_action": True,
    "show_share_action": True,
    "show_delete_action": True,
    "show_playlist_thumbnails": True,
    "compact_playlist_rows": False,
    "confirm_file_delete": True,
}


def _pin_customization_defaults(module: ModuleType) -> None:
    """Use fixed defaults for the optional controls that used to live in Customization.

    The Customization section is no longer shown, and values saved by earlier builds
    are ignored, so History and Playlist always read the same settings.
    """
    module._LUMO_CUSTOMIZATION_OPTIONS = dict(_CUSTOMIZATION_DEFAULTS)


def _apply_customization_runtime(app: Any, module: ModuleType) -> None:
    options = dict(getattr(module, "_LUMO_CUSTOMIZATION_OPTIONS", {}))
    app._lumo_customization_options = dict(options)

    # The History file-action row is built by a separate repair wrapper.
    row = getattr(app, "_lumo_history_file_actions_row", None)
    widgets = getattr(app, "_lumo_file_action_widgets", None)
    if row is not None and isinstance(widgets, dict):
        show_keys = ("show_open_location_action", "show_share_action", "show_delete_action")
        any_visible = any(options.get(key, True) for key in show_keys)
        try:
            for key, widget in widgets.items():
                widget.pack_forget()
                if options.get(key, True):
                    widget.pack(side="left", padx=(0, 7))
            if any_visible:
                _pack_history_file_action_row(app, module, row)
            else:
                row.pack_forget()
        except Exception:
            pass

    controller = getattr(app, "_lumo_playlist_controller", None)
    if controller is not None:
        try:
            controller.apply_customization(options)
        except Exception as exc:
            logger = getattr(module, "log_line", None)
            if callable(logger):
                try:
                    logger(f"Could not apply Playlist customization: {exc}")
                except Exception:
                    pass
    try:
        _decorate_history_actions(app)
    except Exception:
        pass


def _read_progress_settings(app: Any) -> dict[str, Any]:
    settings = dict(_PROGRESS_SETTING_DEFAULTS)
    existing = getattr(app, "settings", None)
    if isinstance(existing, dict):
        settings.update({key: existing.get(key, default)
                         for key, default in _PROGRESS_SETTING_DEFAULTS.items()})
    for key, attribute in (
        ("progress_color", "progress_color_var"),
        ("progress_glow_enabled", "progress_glow_var"),
        ("progress_glow_intensity", "progress_glow_intensity_var"),
        ("progress_animation_enabled", "progress_animation_var"),
        ("progress_animation_speed", "progress_animation_speed_var"),
        ("progress_thickness", "progress_thickness_var"),
    ):
        variable = getattr(app, attribute, None)
        if variable is not None:
            try:
                settings[key] = variable.get()
            except Exception:
                pass
    colour = str(settings.get("progress_color", DEFAULT_PROGRESS_COLOR)).strip().upper()
    if not _is_hex_colour(colour):
        existing = getattr(app, "settings", {})
        fallback = existing.get("progress_color", DEFAULT_PROGRESS_COLOR) if isinstance(existing, dict) else DEFAULT_PROGRESS_COLOR
        colour = str(fallback).strip().upper()
    settings["progress_color"] = colour if _is_hex_colour(colour) else DEFAULT_PROGRESS_COLOR
    settings["progress_glow_enabled"] = bool(settings.get("progress_glow_enabled", True))
    settings["progress_animation_enabled"] = bool(settings.get("progress_animation_enabled", True))
    try:
        settings["progress_glow_intensity"] = max(0, min(100, int(settings.get("progress_glow_intensity", 45))))
    except (TypeError, ValueError):
        settings["progress_glow_intensity"] = 45
    try:
        settings["progress_thickness"] = max(9, min(16, int(settings.get("progress_thickness", 14))))
    except (TypeError, ValueError):
        settings["progress_thickness"] = 14
    speed = str(settings.get("progress_animation_speed", "normal")).casefold()
    settings["progress_animation_speed"] = speed if speed in {"slow", "normal", "fast"} else "normal"
    return settings


def _apply_progress_runtime_values(module: ModuleType, values: dict[str, Any]) -> None:
    options = dict(_PROGRESS_SETTING_DEFAULTS)
    options.update(values)
    module._LUMO_PROGRESS_OPTIONS = options
    module.PROGRESS_COLOR = str(options.get("progress_color", DEFAULT_PROGRESS_COLOR)).upper()


def _persist_progress_setting(app: Any, module: ModuleType, key: str, value: Any) -> None:
    """Apply progress options immediately, but coalesce disk writes while controls move."""
    if key == "progress_color":
        candidate = str(value).strip().upper()
        if not _is_hex_colour(candidate):
            return
        value = candidate
    elif key == "progress_glow_intensity":
        try:
            value = max(0, min(100, int(value)))
        except (TypeError, ValueError):
            return
    elif key == "progress_thickness":
        try:
            value = max(9, min(16, int(value)))
        except (TypeError, ValueError):
            return
    elif key == "progress_animation_speed":
        value = str(value).casefold()
        if value not in {"slow", "normal", "fast"}:
            value = "normal"
    elif key in {"progress_glow_enabled", "progress_animation_enabled"}:
        value = bool(value)
    else:
        return

    current_app_settings = getattr(app, "settings", None)
    if isinstance(current_app_settings, dict):
        current_app_settings[key] = value

    try:
        values = _read_progress_settings(app)
        values[key] = value
        _apply_progress_runtime_values(module, values)
        _schedule_progress_visual_update(app, module, key, value)
        _schedule_progress_settings_save(app, module)
    except Exception as error:
        logger = getattr(module, "log_line", None)
        if callable(logger):
            try:
                logger(f"Could not apply progress setting {key}: {error}")
            except Exception:
                pass


def _schedule_progress_settings_save(app: Any, module: ModuleType, *, flush: bool = False) -> None:
    """Save progress settings once after a short quiet period, not per slider tick."""
    def save_now() -> None:
        try:
            app._lumo_progress_save_after_id = None
        except Exception:
            pass
        try:
            merged = dict(module.load_settings())
            current = getattr(app, "settings", None)
            if isinstance(current, dict):
                merged.update(current)
            merged.update(_read_progress_settings(app))
            module.save_settings(merged)
            if isinstance(current, dict):
                current.update(_read_progress_settings(app))
        except Exception as error:
            logger = getattr(module, "log_line", None)
            if callable(logger):
                try:
                    logger(f"Could not save progress settings: {error}")
                except Exception:
                    pass

    pending = getattr(app, "_lumo_progress_save_after_id", None)
    if pending is not None:
        try:
            app.after_cancel(pending)
        except Exception:
            pass
    if flush:
        save_now()
        return
    try:
        app._lumo_progress_save_after_id = app.after(320, save_now)
    except Exception:
        # Test doubles and legacy roots without Tk scheduling still save safely.
        save_now()


def _schedule_progress_visual_update(app: Any, module: ModuleType, key: str, value: Any) -> None:
    """Throttle expensive tree updates while keeping the tab's own preview live."""
    pending_values = getattr(app, "_lumo_progress_visual_values", None)
    if not isinstance(pending_values, dict):
        pending_values = {}
        app._lumo_progress_visual_values = pending_values
    pending_values[key] = value
    if getattr(app, "_lumo_progress_visual_after_id", None) is not None:
        return

    def apply_latest() -> None:
        try:
            app._lumo_progress_visual_after_id = None
        except Exception:
            pass
        latest = dict(getattr(app, "_lumo_progress_visual_values", {}) or {})
        try:
            _redraw_progress_widgets(app, thickness=latest.get("progress_thickness"))
        except Exception:
            pass

    try:
        # Cap updates to about 20 frames/second during rapid slider movement.
        app._lumo_progress_visual_after_id = app.after(50, apply_latest)
    except Exception:
        apply_latest()

def _apply_existing_progress_thickness(root: Any, thickness: int) -> None:
    try:
        if root.__class__.__name__ == "GlowProgress":
            root.configure(height=int(thickness) + 6)
        for child in root.winfo_children():
            _apply_existing_progress_thickness(child, thickness)
    except Exception:
        pass


def _add_progress_customisation(app: Any, module: ModuleType, parent: Any) -> None:
    """Render Progress Bar colour swatches in the same visual language as Accent/Indicator."""
    settings = _read_progress_settings(app)
    page_bg = getattr(module, "BG", "#0E0F14")
    panel_bg = getattr(module, "CARD", getattr(module, "PANEL", "#171A22"))
    border = getattr(module, "BORDER", "#2A2F3A")

    # Reuse the very same recovered Card widget used by Accent and Downloads.
    # It owns Lumo's antialiased rounded corners, border, and inner padding.
    card = None
    panel = None
    card_class = getattr(module, "Card", None)
    if callable(card_class):
        try:
            card = card_class(parent)
            card.pack(fill="x", padx=0, pady=(0, 14), anchor="n")
            panel = getattr(card, "body", None)
            if panel is None:
                raise AttributeError("Recovered Card has no body frame")
            app._lumo_progress_settings_card = card
        except Exception:
            try:
                if card is not None:
                    card.destroy()
            except Exception:
                pass
            card = None
            panel = None

    # Compatibility fallback for test doubles or builds that lack the recovered
    # Card class. The actual app above always uses the shared rounded Card.
    if panel is None:
        card = tk.Canvas(parent, bg=page_bg, bd=0, highlightthickness=0, relief="flat")
        card.pack(fill="x", padx=16, pady=16, anchor="n")
        panel = tk.Frame(card, bg=panel_bg, bd=0, highlightthickness=0)
        card_window = card.create_window(8, 8, window=panel, anchor="nw")
        card_shape = {"item": None}

        def redraw_rounded_card(_event: Any = None) -> None:
            try:
                width = max(100, int(card.winfo_width()))
                inner_width = max(40, width - 16)
                card.itemconfigure(card_window, width=inner_width)
                height = max(76, int(panel.winfo_reqheight()) + 16)
                card.configure(height=height)
                radius = 16
                coords = (radius, 1, width-radius, 1, width-1, radius,
                          width-1, height-radius, width-radius, height-1,
                          radius, height-1, 1, height-radius, 1, radius)
                if card_shape["item"] is not None:
                    card.delete(card_shape["item"])
                card_shape["item"] = card.create_polygon(
                    *coords, smooth=True, splinesteps=24, fill=panel_bg,
                    outline=border, width=1,
                )
                card.tag_lower(card_shape["item"], card_window)
            except Exception:
                pass

        panel.bind("<Configure>", redraw_rounded_card, add="+")
        card.bind("<Configure>", redraw_rounded_card, add="+")
        app._lumo_progress_settings_card = card

    parent = panel
    bg = panel_bg
    foreground = getattr(module, "TEXT", "#F4F6FB")
    muted = getattr(module, "MUTED", "#9AA4B5")
    initial = str(settings.get("progress_color", DEFAULT_PROGRESS_COLOR)).strip().upper()
    if not _is_hex_colour(initial):
        initial = DEFAULT_PROGRESS_COLOR

    # The compiled app provides SwatchRow, the control used for both Accent and
    # Active Indicator. Prefer it so Progress Bar looks and behaves identically
    # (same rounded swatches, check mark, Selected label, custom-colour + button).
    swatch_row_class = getattr(module, "SwatchRow", None)
    accent_presets = getattr(module, "ACCENT_PRESETS", None)
    if callable(swatch_row_class) and isinstance(accent_presets, (tuple, list)):
        try:
            colour_var = tk.StringVar(master=app, value=initial)
        except TypeError:
            colour_var = tk.StringVar(value=initial)
        app.progress_color_var = colour_var
        tk.Label(parent, text="Progress bar colour", bg=bg, fg=foreground,
                 font=("Segoe UI Semibold", 14), anchor="w").pack(
                     fill="x", padx=16, pady=(18, 4))
        tk.Label(parent,
                 text="Colour used for download progress bars only; independent of Accent and Indicator.",
                 bg=bg, fg=muted, font=("Segoe UI", 9), anchor="w").pack(
                     fill="x", padx=16, pady=(0, 14))

        # Reuse the original app's saved custom-colour collection so the plus
        # button and right-click removal work exactly like the other colour tabs.
        pool = getattr(app, "custom_colours", None)
        if not isinstance(pool, list):
            pool = getattr(module, "custom_colours", None)
        if not isinstance(pool, list):
            pool = []
        save_pool = getattr(app, "_save_custom", None)
        if not callable(save_pool):
            save_pool = lambda: None
        notify = getattr(app, "_notify", None)
        if not callable(notify):
            notify = lambda *args, **kwargs: None
        swatches = swatch_row_class(parent, accent_presets, colour_var,
                                   pool, save_pool, notify)
        swatches.pack(fill="x", padx=12, pady=(0, 0), anchor="w")
        app._lumo_progress_swatch_row = swatches

        def persist_progress_swatch(*_args: Any) -> None:
            selected_colour = str(colour_var.get()).strip().upper()
            if _is_hex_colour(selected_colour):
                _persist_progress_setting(app, module, "progress_color", selected_colour)

        colour_var.trace_add("write", persist_progress_swatch)
        return

    # Fallback for tests/compatibility shims that do not expose the recovered
    # SwatchRow class; the real Windows application takes the branch above.
    choices = (
        ("Violet", "#8871FF"),
        ("Blue", "#70A7FF"),
        ("Turquoise", "#5BD4C8"),
        ("Mint", "#65D99A"),
        ("Amber", "#FFB45F"),
        ("Pink", "#FF647F"),
    )
    choice_names = {colour.upper(): name for name, colour in choices}
    try:
        colour_var = tk.StringVar(master=app, value=initial)
    except TypeError:
        colour_var = tk.StringVar(value=initial)
    app.progress_color_var = colour_var

    def persist_fallback_progress_colour(*_args: Any) -> None:
        selected_colour = str(colour_var.get()).strip().upper()
        if _is_hex_colour(selected_colour):
            _persist_progress_setting(app, module, "progress_color", selected_colour)

    colour_var.trace_add("write", persist_fallback_progress_colour)

    tk.Label(parent, text="Progress bar colour", bg=bg, fg=foreground,
             font=("Segoe UI Semibold", 14), anchor="w").pack(
                 fill="x", padx=24, pady=(22, 4))
    tk.Label(parent, text="Choose the colour used for download progress bars.",
             bg=bg, fg=muted, font=("Segoe UI", 9), anchor="w").pack(
                 fill="x", padx=24, pady=(0, 15))

    swatch_row = tk.Frame(parent, bg=bg, bd=0, highlightthickness=0)
    swatch_row.pack(fill="x", padx=20, anchor="w")
    selected_label = tk.Label(parent, text="", bg=bg, fg=muted,
                              font=("Segoe UI", 9), anchor="w")
    selected_label.pack(fill="x", padx=24, pady=(9, 0), anchor="w")

    def luminance(hex_colour: str) -> float:
        try:
            red, green, blue = (int(hex_colour[i:i + 2], 16) / 255 for i in (1, 3, 5))
            return 0.2126 * red + 0.7152 * green + 0.0722 * blue
        except Exception:
            return 0.0

    def rounded(canvas: Any, x1: int, y1: int, x2: int, y2: int,
                radius: int, fill: str) -> None:
        # Build a crisp rounded rectangle with native Canvas primitives. Test
        # doubles may not implement drawing calls, so ignore those gracefully.
        try:
            r = max(2, min(radius, (x2 - x1) // 2, (y2 - y1) // 2))
            canvas.create_rectangle(x1 + r, y1, x2 - r, y2, fill=fill, outline="")
            canvas.create_rectangle(x1, y1 + r, x2, y2 - r, fill=fill, outline="")
            canvas.create_oval(x1, y1, x1 + 2 * r, y1 + 2 * r, fill=fill, outline="")
            canvas.create_oval(x2 - 2 * r, y1, x2, y1 + 2 * r, fill=fill, outline="")
            canvas.create_oval(x1, y2 - 2 * r, x1 + 2 * r, y2, fill=fill, outline="")
            canvas.create_oval(x2 - 2 * r, y2 - 2 * r, x2, y2, fill=fill, outline="")
        except Exception:
            pass

    def apply_colour(value: str, *, flush: bool = False) -> None:
        colour = str(value).strip().upper()
        if not _is_hex_colour(colour):
            return
        colour_var.set(colour)
        if flush:
            _schedule_progress_settings_save(app, module, flush=True)
        render_swatches()

    def choose_custom_colour() -> None:
        try:
            picked = colorchooser.askcolor(color=colour_var.get(), parent=app,
                                           title="Choose progress bar colour")[1]
        except Exception:
            picked = None
        if picked and _is_hex_colour(picked):
            apply_colour(picked, flush=True)

    def render_swatches() -> None:
        try:
            existing_children = list(swatch_row.winfo_children())
        except Exception:
            existing_children = list(getattr(swatch_row, "children", ()))
        for child in existing_children:
            try:
                child.destroy()
            except Exception:
                pass
        current = str(colour_var.get()).strip().upper()
        entries = list(choices)
        if current not in choice_names:
            entries.append(("Custom", current))

        for index, (name, colour) in enumerate(entries):
            selected = current == colour.upper()
            tile = tk.Canvas(swatch_row, width=48, height=48, bg=bg,
                             highlightthickness=0, bd=0, cursor="hand2")
            tile.pack(side="left", padx=(3, 8), pady=1, anchor="w")
            if selected:
                rounded(tile, 2, 2, 46, 46, 12, "#F7F8FC")
                rounded(tile, 4, 4, 44, 44, 10, "#252936")
                rounded(tile, 7, 7, 41, 41, 9, colour.upper())
                # The bright rounded outline marks selection; keep the colour clear.
            else:
                rounded(tile, 4, 4, 44, 44, 11, colour.upper())
                tile.bind("<Enter>", lambda _e, c=tile: c.configure(highlightthickness=1,
                                                                     highlightbackground="#8D93A8"))
                tile.bind("<Leave>", lambda _e, c=tile: c.configure(highlightthickness=0))
            tile.bind("<Button-1>", lambda _e, c=colour: apply_colour(c, flush=True))

        plus_index = len(entries)
        plus = tk.Canvas(swatch_row, width=48, height=48, bg=bg, highlightthickness=0,
                         bd=0, cursor="hand2")
        plus.pack(side="left", padx=(2, 0), pady=1, anchor="w")
        plus.create_text(24, 23, text="+", fill="#F4F6FB",
                         font=("Segoe UI Light", 23), anchor="center")
        plus.bind("<Enter>", lambda _e: plus.itemconfigure(1, fill="#B9ACFF"))
        plus.bind("<Leave>", lambda _e: plus.itemconfigure(1, fill="#F4F6FB"))
        plus.bind("<Button-1>", lambda _e: choose_custom_colour())

        chosen_name = choice_names.get(current, "Custom")
        selected_label.configure(text=f"Selected: {chosen_name}")

    render_swatches()

def _safe_variable_value(variable: Any, converter: Any) -> Any:
    try:
        return converter(variable.get())
    except Exception:
        return None


def _hide_manual_save_ui(app: Any, module: ModuleType) -> None:
    # The old footer status is deliberately removed; autosave remains enabled.
    note = getattr(app, "settings_note", None)
    if note is not None:
        _safe_hide_widget(note)
    roots = []
    pages = getattr(app, "pages", None)
    if isinstance(pages, dict) and pages.get("settings") is not None:
        roots.append(pages["settings"])
    for name in ("settings_scroll",):
        widget = getattr(app, name, None)
        if widget is not None:
            roots.append(widget)
    roots.extend((getattr(app, "settings_tabs", {}) or {}).values()
                 if isinstance(getattr(app, "settings_tabs", None), dict) else [])
    stack, seen = list(roots), set()
    while stack:
        widget = stack.pop()
        if id(widget) in seen:
            continue
        seen.add(id(widget))
        label = str(getattr(widget, "label", getattr(widget, "text", ""))).strip().casefold()
        visible_text = label
        if not visible_text:
            try:
                visible_text = str(widget.cget("text")).strip().casefold()
            except Exception:
                pass
        if any(phrase in visible_text for phrase in (
            "changes save automatically", "saved automatically", "changes apply when you save",
            "preferences saved successfully",
        )):
            _safe_hide_widget(widget)
        if widget.__class__.__name__ == "SoftButton" and label in {
            "save preferences", "save settings", "save preferences now"
        }:
            _safe_hide_widget(widget)
        try:
            stack.extend(widget.winfo_children())
        except Exception:
            pass


def _wire_automatic_settings_save(app: Any, module: ModuleType) -> None:
    """Bind immediate/debounced saves to existing settings variables, not the hidden button."""
    watched = (
        "cookie_var", "use_cookies_var", "youtube_access_var", "youtube_access_toggle_var",
        "cookie_file_var", "cookies_file_var", "download_dir_var", "download_path_var",
        "download_folder_var", "merge_var", "merge_to_mp4_var", "preferred_subtitle_var",
        "accent_var", "indicator_var", "accent_color_var", "indicator_color_var",
        "active_bar_color_var", "active_indicator_var",
    )
    for attribute in watched:
        variable = getattr(app, attribute, None)
        if variable is None or not callable(getattr(variable, "trace_add", None)):
            continue
        # Keep an actual reference per attribute. A set of id(variable) values
        # can match a newly-created Tk variable after rebuild_ui() reuses an id,
        # silently leaving the replacement control without an autosave trace.
        bound_variables = getattr(app, "_lumo_autosave_variables", None)
        if not isinstance(bound_variables, dict):
            bound_variables = {}
        if bound_variables.get(attribute) is variable:
            continue
        try:
            variable.trace_add(
                "write",
                lambda *_args, target=app, name=attribute:
                    _schedule_app_autosave(target, module, changed_attribute=name),
            )
            bound_variables[attribute] = variable
            app._lumo_autosave_variables = bound_variables
            legacy_ids = getattr(app, "_lumo_autosave_variable_ids", set())
            if not isinstance(legacy_ids, set):
                legacy_ids = set()
            legacy_ids.add(id(variable))
            app._lumo_autosave_variable_ids = legacy_ids
        except Exception:
            pass

    # Path fields are saved on focus loss instead of every character, avoiding
    # a validation dialog while someone is still typing a folder path.
    for widget in _walk_widgets(getattr(app, "pages", {}).get("settings")
                                if isinstance(getattr(app, "pages", None), dict) else None):
        if widget.__class__.__name__ == "RoundEntry":
            inner = getattr(widget, "entry", None)
            if inner is not None and not getattr(inner, "_lumo_autosave_focus_bound", False):
                try:
                    inner.bind("<FocusOut>", lambda _event, target=app: _schedule_app_autosave(target, module), add="+")
                    inner._lumo_autosave_focus_bound = True
                except Exception:
                    pass



def _walk_widgets(root: Any) -> list[Any]:
    if root is None:
        return []
    result, stack, seen = [], [root], set()
    while stack:
        widget = stack.pop()
        if id(widget) in seen:
            continue
        seen.add(id(widget))
        result.append(widget)
        try:
            stack.extend(widget.winfo_children())
        except Exception:
            pass
    return result


def _persist_live_toggle_value(app: Any, module: ModuleType, attribute: str) -> bool:
    """Persist a changed Settings variable without rebuilding the Tk interface.

    The recovered save_app_settings() rebuilds the whole UI. Using it for a path
    edit or a toggle can destroy the control during its own callback, making the
    click look ineffective and causing a first-click stall. Keep the edit in the
    current settings dict and save it through the lightweight settings writer.
    """
    setting_for_variable = {
        "cookie_var": "use_cookies",
        "use_cookies_var": "use_cookies",
        "youtube_access_var": "use_cookies",
        "youtube_access_toggle_var": "use_cookies",
        "merge_var": "merge_to_mp4",
        "merge_to_mp4_var": "merge_to_mp4",
        "preferred_subtitle_var": "preferred_subtitle",
        "download_dir_var": "download_dir",
        "download_path_var": "download_dir",
        "download_folder_var": "download_dir",
        "cookie_file_var": "cookie_file",
        "cookies_file_var": "cookie_file",
    }
    key = setting_for_variable.get(attribute)
    variable = getattr(app, attribute, None)
    if key is None or variable is None or not callable(getattr(variable, "get", None)):
        return False

    try:
        loaded = module.load_settings() if callable(getattr(module, "load_settings", None)) else {}
    except Exception:
        loaded = {}
    values = dict(loaded) if isinstance(loaded, dict) else {}
    current = getattr(app, "settings", None)
    if isinstance(current, dict):
        values.update(current)
    try:
        value = variable.get()
    except Exception:
        return False
    if key in {"use_cookies", "merge_to_mp4"}:
        if isinstance(value, str):
            value = value.strip().casefold() in {"1", "true", "yes", "on"}
        else:
            value = bool(value)
    elif key in {"download_dir", "cookie_file"}:
        value = str(value or "").strip()
        if key == "download_dir" and not value:
            # Do not replace a usable folder with an empty path. Treat it as a
            # handled no-op so it cannot fall through to the UI-rebuilding save.
            return True
    values[key] = value

    saver = getattr(module, "save_settings", None)
    if not callable(saver):
        return False
    try:
        saver(values)
        try:
            if isinstance(current, dict):
                current.update(values)
            else:
                app.settings = values
        except Exception:
            pass
        return True
    except Exception as error:
        logger = getattr(module, "log_line", None)
        if callable(logger):
            try:
                logger(f"Could not save {key} without rebuilding the UI: {error}")
            except Exception:
                pass
        return False

def _persist_current_path_and_toggle_settings(app: Any, module: ModuleType) -> bool:
    """Persist all currently exposed path/toggle variables with one disk write."""
    # Canonical recovered names come first. Some app builds expose compatibility
    # aliases too; iterating aliases independently let an old hidden variable
    # overwrite the value of the control the user had actually changed.
    mapping = {
        "use_cookies": ("cookie_var", "use_cookies_var", "youtube_access_var", "youtube_access_toggle_var"),
        "merge_to_mp4": ("merge_var", "merge_to_mp4_var"),
        "preferred_subtitle": ("preferred_subtitle_var",),
        "download_dir": ("download_dir_var", "download_path_var", "download_folder_var"),
        "cookie_file": ("cookie_file_var", "cookies_file_var"),
    }
    values = {}
    try:
        loaded = module.load_settings() if callable(getattr(module, "load_settings", None)) else {}
    except Exception:
        loaded = {}
    if isinstance(loaded, dict):
        values.update(loaded)
    current = getattr(app, "settings", None)
    if isinstance(current, dict):
        values.update(current)
    found = False
    for key, attributes in mapping.items():
        selected_value = None
        selected = False
        for attribute in attributes:
            variable = getattr(app, attribute, None)
            if variable is None or not callable(getattr(variable, "get", None)):
                continue
            try:
                selected_value = variable.get()
                selected = True
                break
            except Exception:
                continue
        if not selected:
            continue
        value = selected_value
        if key in {"use_cookies", "merge_to_mp4"}:
            value = (str(value).strip().casefold() in {"1", "true", "yes", "on"}
                     if isinstance(value, str) else bool(value))
        elif key in {"download_dir", "cookie_file"}:
            value = str(value or "").strip()
            if key == "download_dir" and not value:
                continue
        values[key] = value
        found = True
    saver = getattr(module, "save_settings", None)
    if not found or not callable(saver):
        return False
    try:
        saver(values)
        if isinstance(current, dict):
            current.update(values)
        else:
            app.settings = values
        return True
    except Exception as error:
        logger = getattr(module, "log_line", None)
        if callable(logger):
            try:
                logger(f"Could not save path/toggle settings in place: {error}")
            except Exception:
                pass
        return False


def _schedule_app_autosave(
    app: Any, module: ModuleType, changed_attribute: str | None = None
) -> None:
    def save_now() -> None:
        app._lumo_autosave_after_id = None
        # Saving a toggle by calling save_app_settings() rebuilds the entire UI.
        # That makes it look as though the switch click did nothing and can stall
        # the window. Save these preference values in place instead.
        quiet_save_attributes = {
            "cookie_var", "use_cookies_var", "youtube_access_var", "youtube_access_toggle_var",
            "merge_var", "merge_to_mp4_var", "preferred_subtitle_var",
            "download_dir_var", "download_path_var", "download_folder_var",
            "cookie_file_var", "cookies_file_var",
        }
        if changed_attribute in quiet_save_attributes:
            if _persist_live_toggle_value(app, module, changed_attribute):
                _hide_manual_save_ui(app, module)
                return
        elif changed_attribute is None:
            # RoundEntry focus-out is used by path fields. Persist the currently
            # bound path/toggle variables in place instead of invoking the full
            # save_app_settings() rebuild merely because an entry lost focus.
            if _persist_current_path_and_toggle_settings(app, module):
                _hide_manual_save_ui(app, module)
                return

        tab_var = getattr(app, "settings_tab_var", None)
        try:
            selected_tab = str(tab_var.get()) if tab_var is not None else None
        except Exception:
            selected_tab = None
        try:
            saver = getattr(app, "save_app_settings", None)
            if callable(saver):
                saver()
        except Exception as error:
            logger = getattr(module, "log_line", None)
            if callable(logger):
                try:
                    logger(f"Automatic settings save failed: {error}")
                except Exception:
                    pass
        current_tab_var = getattr(app, "settings_tab_var", None)
        if selected_tab is not None and current_tab_var is not None:
            try:
                if str(current_tab_var.get()) != selected_tab:
                    current_tab_var.set(selected_tab)
                    app.after_idle(lambda target=app: target._show_settings_tab())
            except Exception:
                pass
        _hide_manual_save_ui(app, module)

    try:
        pending = getattr(app, "_lumo_autosave_after_id", None)
        if pending is not None:
            app.after_cancel(pending)
        app._lumo_autosave_after_id = app.after(260, save_now)
    except Exception:
        # Test doubles or older roots without `after` must still preserve a user's change.
        save_now()


_NO_TOGGLE_SNAPSHOT = object()


def _toggle_variable_candidates(widget: Any) -> list[Any]:
    """Find BooleanVar-like values attached to a recovered ToggleSwitch widget."""
    preferred_names = ("variable", "var", "value_var", "state_var", "bool_var", "toggle_var")
    candidates: list[tuple[int, Any]] = []
    try:
        attributes = vars(widget)
    except Exception:
        attributes = {}
    for name, value in attributes.items():
        if not callable(getattr(value, "get", None)) or not callable(getattr(value, "set", None)):
            continue
        class_name = type(value).__name__.casefold()
        if "booleanvar" in class_name or "intvar" in class_name or name.casefold() in preferred_names:
            priority = 0 if name.casefold() in preferred_names else 1
            if "booleanvar" in class_name:
                priority -= 1
            candidates.append((priority, value))
    candidates.sort(key=lambda item: item[0])
    unique: list[Any] = []
    seen: set[int] = set()
    for _priority, variable in candidates:
        if id(variable) not in seen:
            seen.add(id(variable))
            unique.append(variable)
    return unique


def _install_toggle_switch_fallback(module: ModuleType) -> None:
    """Make the recovered ToggleSwitch update its BooleanVar on every click.

    The wrapper leaves normal switch behaviour alone. It only flips the bound
    variable if the recovered click handler returns without changing it, which
    also makes the preference trace/autosave fire normally.
    """
    switch_class = getattr(module, "ToggleSwitch", None)
    original_toggle = getattr(switch_class, "toggle", None) if switch_class else None
    if not callable(original_toggle) or getattr(original_toggle, "_lumo_toggle_fallback", False):
        return

    def toggle_with_variable_fallback(self: Any, *args: Any, **kwargs: Any) -> Any:
        variables = _toggle_variable_candidates(self)
        before: list[tuple[Any, Any]] = []
        for variable in variables:
            try:
                before.append((variable, variable.get()))
            except Exception:
                pass
        result = original_toggle(self, *args, **kwargs)
        changed = False
        for variable, old_value in before:
            try:
                if variable.get() != old_value:
                    changed = True
                    break
            except Exception:
                pass
        if not changed:
            for variable, old_value in before:
                type_name = type(variable).__name__.casefold()
                try:
                    if "booleanvar" in type_name:
                        variable.set(not bool(old_value))
                    elif "intvar" in type_name and old_value in (0, 1):
                        variable.set(0 if int(old_value) else 1)
                    else:
                        continue
                    current = bool(variable.get())
                    animate = getattr(self, "animate_to", None)
                    if callable(animate):
                        try:
                            animate(1.0 if current else 0.0)
                        except Exception:
                            pass
                    draw = getattr(self, "draw", None)
                    if callable(draw):
                        try:
                            draw()
                        except Exception:
                            pass
                    break
                except Exception:
                    continue
        return result

    toggle_with_variable_fallback._lumo_toggle_fallback = True
    switch_class.toggle = toggle_with_variable_fallback


def _install_history_ui_repairs(module: ModuleType) -> None:
    """Use the requested Completed/Active/Failed filters and overlay real circular progress."""
    app_class = module.App

    # Replace only the filter tuple constant; all existing History actions and
    # the Treeview itself remain the recovered implementation.
    try:
        method = app_class.build_history_page
        code = method.__code__
        old_options = (("all", "All"), ("downloading", "Active"), ("failed", "Failed"))
        new_options = (("completed", "Completed"), ("downloading", "Active"), ("failed", "Failed"))
        if old_options in code.co_consts:
            method.__code__ = code.replace(co_consts=tuple(
                new_options if value == old_options else value for value in code.co_consts
            ))
    except Exception:
        pass

    original_refresh = app_class.refresh_history

    def refresh_history_with_completed_filter(self: Any, *args: Any, **kwargs: Any) -> Any:
        variable = getattr(self, "history_filter", None)
        try:
            selected = str(variable.get()).casefold() if variable is not None else "all"
        except Exception:
            selected = "all"
        use_all = selected == "completed"
        if use_all and variable is not None:
            try:
                variable.set("all")
            except Exception:
                pass
        try:
            result = original_refresh(self, *args, **kwargs)
        finally:
            if use_all and variable is not None:
                try:
                    variable.set("completed")
                except Exception:
                    pass
        if use_all:
            _keep_completed_rows_only(self)
        _refresh_progress_circles(self, module)
        return result

    app_class.refresh_history = refresh_history_with_completed_filter

    original_build_history = app_class.build_history_page

    def build_history_page(self: Any, *args: Any, **kwargs: Any) -> Any:
        variable = getattr(self, "history_filter", None)
        if variable is not None:
            try:
                current = str(variable.get()).casefold()
                if current not in {"completed", "downloading", "failed"}:
                    variable.set("completed")
            except Exception:
                pass
        result = original_build_history(self, *args, **kwargs)
        _bind_progress_circle_refresh(self, module)
        _refresh_progress_circles(self, module)
        return result

    app_class.build_history_page = build_history_page

    original_update_active = getattr(app_class, "_refresh_active_row", None)
    if callable(original_update_active):
        def refresh_active_row_with_circle(self: Any, *args: Any, **kwargs: Any) -> Any:
            result = original_update_active(self, *args, **kwargs)
            _schedule_circle_redraw(self, module)
            return result
        app_class._refresh_active_row = refresh_active_row_with_circle


def _keep_completed_rows_only(app: Any) -> None:
    tree = getattr(app, "tree", None)
    if tree is None:
        return
    completed: list[str] = []
    try:
        for iid in list(tree.get_children("")):
            values = tree.item(iid, "values")
            status = str(values[1]).casefold() if len(values) > 1 else ""
            if status == "completed":
                completed.append(iid)
            else:
                tree.delete(iid)
                row_cache = getattr(app, "_row_cache", None)
                if isinstance(row_cache, dict):
                    row_cache.pop(iid, None)
    except Exception:
        return
    count_var = getattr(app, "history_count_var", None)
    if count_var is not None:
        try:
            count_var.set(f"{len(completed)} item" if len(completed) == 1 else f"{len(completed)} items")
        except Exception:
            pass
    empty_var = getattr(app, "empty_var", None)
    empty_state = getattr(app, "empty_state", None)
    if not completed:
        if empty_var is not None:
            try:
                empty_var.set("No completed downloads yet")
            except Exception:
                pass
        if empty_state is not None:
            try:
                empty_state.place(relx=0.5, rely=0.5, anchor="center")
            except Exception:
                pass
    elif empty_state is not None:
        try:
            empty_state.place_forget()
        except Exception:
            pass


def _bind_progress_circle_refresh(app: Any, module: ModuleType) -> None:
    tree = getattr(app, "tree", None)
    if tree is None or getattr(tree, "_lumo_circle_bindings_installed", False):
        return
    schedule = lambda _event=None: _schedule_circle_redraw(app, module)
    for sequence in ("<MouseWheel>", "<Button-4>", "<Button-5>", "<Configure>", "<KeyRelease>"):
        try:
            tree.bind(sequence, schedule, add="+")
        except Exception:
            pass
    history_page = None
    pages = getattr(app, "pages", None)
    if isinstance(pages, dict):
        history_page = pages.get("history")
    for widget in _walk_widgets(history_page):
        if widget.__class__.__name__ == "RoundScrollbar":
            for sequence in ("<B1-Motion>", "<ButtonRelease-1>", "<MouseWheel>"):
                try:
                    widget.bind(sequence, schedule, add="+")
                except Exception:
                    pass
    try:
        tree._lumo_circle_bindings_installed = True
    except Exception:
        pass


def _schedule_circle_redraw(app: Any, module: ModuleType) -> None:
    """Redraw at most once per 65 ms. Leading-edge: a queued redraw is not postponed.

    Cancelling and re-queuing on every event could delay the redraw indefinitely while
    progress events keep arriving.
    """
    if getattr(app, "_lumo_circle_redraw_after_id", None) is not None:
        return
    def redraw() -> None:
        try:
            app._lumo_circle_redraw_after_id = None
        except Exception:
            pass
        _refresh_progress_circles(app, module)
    try:
        app._lumo_circle_redraw_after_id = app.after(65, redraw)
    except Exception:
        redraw()


def _refresh_progress_circles(app: Any, module: ModuleType) -> None:
    """Draw a compact circular indicator over the progress cell for active rows only."""
    tree = getattr(app, "tree", None)
    if tree is None:
        return
    try:
        children = list(tree.get_children(""))
        if not children:
            for canvas in getattr(app, "_lumo_progress_circles", {}).values():
                try:
                    canvas.destroy()
                except Exception:
                    pass
            app._lumo_progress_circles = {}
            return
    except Exception:
        return

    canvases = getattr(app, "_lumo_progress_circles", None)
    if not isinstance(canvases, dict):
        canvases = {}
        app._lumo_progress_circles = canvases
    active_ids: set[str] = set()
    try:
        background = tree.cget("background") or getattr(module, "CARD", "#15171E")
    except Exception:
        background = getattr(module, "CARD", "#15171E")
    foreground = getattr(module, "TEXT", "#F4F6FB")
    track = getattr(module, "BORDER", "#292D38")
    progress_colour = str(getattr(module, "PROGRESS_COLOR", DEFAULT_PROGRESS_COLOR)).upper()

    for iid in children:
        try:
            values = list(tree.item(iid, "values"))
            status = str(values[1]).casefold() if len(values) > 1 else ""
        except Exception:
            continue
        if status not in {"downloading", "queued", "paused", "active"}:
            old_canvas = canvases.pop(iid, None)
            if old_canvas is not None:
                try:
                    old_canvas.destroy()
                except Exception:
                    pass
            continue
        active_ids.add(iid)
        job_id: Any = iid
        try:
            job_id = int(iid)
        except (TypeError, ValueError):
            pass
        pct: int | None = None
        progress_map = getattr(app, "job_progress", None)
        if isinstance(progress_map, dict):
            try:
                if job_id in progress_map:
                    pct = int(progress_map[job_id])
            except (TypeError, ValueError):
                pct = None
        if pct is None:
            try:
                raw = str(values[3]).strip().replace("%", "")
                pct = int(float(raw)) if raw else 0
            except (IndexError, TypeError, ValueError):
                pct = 0
        pct = max(0, min(100, pct))
        # The circular widget replaces the text-only percentage in active rows.
        if len(values) >= 4 and values[3] != "":
            values[3] = ""
            try:
                tree.item(iid, values=tuple(values))
            except Exception:
                pass
        try:
            bbox = tree.bbox(iid, "#4")
        except Exception:
            bbox = ()
        if not bbox or len(bbox) < 4 or int(bbox[2]) <= 0 or int(bbox[3]) <= 0:
            canvas = canvases.get(iid)
            if canvas is not None:
                try:
                    canvas.place_forget()
                    canvas._lumo_last = None
                except Exception:
                    pass
            continue

        canvas = canvases.get(iid)
        if canvas is None:
            try:
                canvas = tk.Canvas(tree, width=32, height=32, bg=background,
                                   highlightthickness=0, bd=0)
                canvases[iid] = canvas
                canvas._lumo_ring = canvas.create_oval(3, 3, 29, 29, outline=track, width=3)
                canvas._lumo_arc = canvas.create_arc(3, 3, 29, 29, start=90, extent=0,
                                                    style="arc", outline=progress_colour, width=3)
                canvas._lumo_text = canvas.create_text(16, 16, text="0", fill=foreground,
                                                      font=("Segoe UI Semibold", 7))
            except Exception:
                continue
        try:
            x, y, width, height = (int(value) for value in bbox)
            place_x = x + max(0, (width - 32) // 2)
            place_y = y + max(0, (height - 32) // 2)
            signature = (background, track, progress_colour, foreground, pct, place_x, place_y)
            if getattr(canvas, "_lumo_last", None) == signature:
                # Nothing changed since the last draw: skip the Tk calls entirely.
                continue
            canvas.configure(bg=background)
            canvas.itemconfigure(getattr(canvas, "_lumo_ring"), outline=track)
            canvas.itemconfigure(getattr(canvas, "_lumo_arc"), extent=-3.6 * pct,
                                 outline=progress_colour)
            canvas.itemconfigure(getattr(canvas, "_lumo_text"), text=str(pct), fill=foreground)
            canvas.place(x=place_x, y=place_y, width=32, height=32)
            canvas._lumo_last = signature
        except Exception:
            pass

    for iid in tuple(canvases):
        if iid not in active_ids:
            try:
                canvases.pop(iid).destroy()
            except Exception:
                canvases.pop(iid, None)


def _pack_history_file_action_row(app: Any, module: ModuleType, row: Any) -> None:
    """Place the optional file-action row immediately after the recovered History actions."""
    try:
        if row.winfo_manager() == "pack":
            return
    except Exception:
        pass
    owner = getattr(row, "master", None)
    action_row = getattr(app, "_lumo_history_action_row", None)
    try:
        siblings = list(owner.winfo_children()) if owner is not None else []
        next_widget = None
        if action_row in siblings:
            index = siblings.index(action_row)
            for candidate in siblings[index + 1:]:
                if candidate is row:
                    continue
                try:
                    if candidate.winfo_manager():
                        next_widget = candidate
                        break
                except Exception:
                    continue
        kwargs = {"fill": "x", "padx": 0, "pady": (0, 7)}
        if next_widget is not None:
            kwargs["before"] = next_widget
        row.pack(**kwargs)
    except Exception:
        try:
            row.pack(fill="x", padx=0, pady=(0, 7))
        except Exception:
            pass


def _install_history_file_actions(module: ModuleType) -> None:
    """Add safe file management actions beneath the original History buttons."""
    app_class = module.App
    original_build = app_class.build_history_page

    def set_status(app: Any, message: str) -> None:
        variable = getattr(app, "status_text", None)
        if variable is None:
            return
        try:
            variable.set(message)
        except Exception:
            return
        # Clear this message after a short pause, but only if nothing newer replaced it.
        previous = getattr(app, "_lumo_file_status_after", None)
        if previous is not None:
            try:
                app.after_cancel(previous)
            except Exception:
                pass
        def clear_if_unchanged() -> None:
            try:
                if variable.get() == message:
                    variable.set("")
            except Exception:
                pass
        try:
            app._lumo_file_status_after = app.after(4500, clear_if_unchanged)
        except Exception:
            app._lumo_file_status_after = None

    def selected_path(app: Any) -> tuple[dict[str, Any] | None, Path | None]:
        try:
            job = app.selected_job()
        except Exception:
            job = None
        if not isinstance(job, dict):
            set_status(app, "Select a download first.")
            return None, None
        raw = job.get("file_path")
        if not raw:
            set_status(app, "The selected History record has no saved file.")
            return job, None
        path = Path(str(raw))
        if not path.is_file():
            set_status(app, "The downloaded file could not be found. It may have been moved or deleted.")
            return job, None
        return job, path

    def reveal_in_file_manager(path: Path) -> None:
        resolved = path.resolve()
        if os.name == "nt":
            subprocess.Popen(["explorer.exe", f"/select,{resolved}"])
        elif sys.platform == "darwin":
            subprocess.Popen(["open", "-R", str(resolved)])
        else:
            subprocess.Popen(["xdg-open", str(resolved.parent)])

    def open_location(app: Any) -> None:
        _job, path = selected_path(app)
        if path is None:
            return
        try:
            reveal_in_file_manager(path)
            set_status(app, "Opened the downloaded file's location.")
        except Exception as exc:
            set_status(app, f"Could not open file location: {exc}")

    def share_path(app: Any) -> None:
        _job, path = selected_path(app)
        if path is None:
            return
        try:
            app.clipboard_clear()
            app.clipboard_append(str(path.resolve()))
            app.update_idletasks()
            reveal_in_file_manager(path)
            set_status(app, "File path copied. Use the file manager's Share option to share the video.")
        except Exception as exc:
            set_status(app, f"Could not prepare file sharing: {exc}")

    def delete_file(app: Any) -> None:
        job, path = selected_path(app)
        if job is None or path is None:
            return
        options = getattr(module, "_LUMO_CUSTOMIZATION_OPTIONS", {})
        if options.get("confirm_file_delete", True):
            try:
                # Prefer the module's messagebox: it carries the focus-restoring proxy.
                dialogs = getattr(module, "messagebox", messagebox)
                accepted = dialogs.askyesno(
                    "Delete downloaded file",
                    f"Permanently delete this file?\n\n{path.name}\n\nThe History record will be retained.",
                    parent=app,
                )
            except Exception:
                accepted = False
        else:
            accepted = True
        if not accepted:
            return
        try:
            path.unlink()
            job_id = job.get("id")
            setter = getattr(module.history, "set_file_path", None)
            if job_id is not None and callable(setter):
                setter(job_id, None)
            set_status(app, "Downloaded file deleted. The History record was retained.")
            try:
                app.refresh_history()
            except Exception:
                pass
        except OSError as exc:
            set_status(app, f"Could not delete the file: {exc}")

    def build_history_with_file_actions(self: Any, *args: Any, **kwargs: Any) -> Any:
        result = original_build(self, *args, **kwargs)
        existing_row = getattr(self, "_lumo_history_file_actions_row", None)
        if getattr(self, "_lumo_history_file_actions", False) and existing_row is not None:
            try:
                if existing_row.winfo_exists():
                    return result
            except Exception:
                pass
        self._lumo_history_file_actions = False
        try:
            tree = getattr(self, "tree", None)
            candidates = [w for w in _walk_widgets(getattr(self, "pages", {}).get("history"))
                          if w.__class__.__name__ == "SoftButton"]
            if tree is None or not candidates:
                return result
            button_parent = getattr(candidates[0], "master", None)
            owner = getattr(button_parent, "master", None)
            if owner is None:
                return result
            # The original History view already has one row of action buttons. Put
            # file management on a second responsive row instead of squeezing the
            # five recovered buttons into a narrow window.
            row = tk.Frame(owner, bg=getattr(module, "CARD", getattr(module, "BG", "#101827")))
            self._lumo_history_file_actions_row = row
            self._lumo_history_action_row = button_parent
            SoftButton = getattr(module, "SoftButton")
            open_button = SoftButton(row, "Open file location", lambda a=self: open_location(a), "secondary", 150, 36)
            share_button = SoftButton(row, "Share / Copy path", lambda a=self: share_path(a), "secondary", 142, 36)
            delete_button = SoftButton(row, "Delete file", lambda a=self: delete_file(a), "danger", 106, 36)
            self._lumo_file_action_widgets = {
                "show_open_location_action": open_button,
                "show_share_action": share_button,
                "show_delete_action": delete_button,
            }
            _apply_customization_runtime(self, module)
            self._lumo_history_file_actions = True
        except Exception as exc:
            logger = getattr(module, "log_line", None)
            if callable(logger):
                try:
                    logger(f"History file actions could not be attached: {exc}")
                except Exception:
                    pass
        return result

    app_class.build_history_page = build_history_with_file_actions


def _install_download_focus_repairs(module: ModuleType) -> None:
    """Restore paste-link focus after Tk finishes mapping the initial window."""
    app_class = module.App
    original_init = app_class.__init__

    def init_with_url_focus(self: Any, *args: Any, **kwargs: Any) -> Any:
        result = original_init(self, *args, **kwargs)
        module._LUMO_APP_INSTANCE = self
        # Tk may discard focus_set() during initial layout/window mapping. Schedule
        # an idle pass and a few short retries; this does not rebuild the UI.
        try:
            self.after_idle(lambda app=self: _schedule_url_focus(app, 0, force=True))
        except Exception:
            pass
        for delay in (180, 420, 800):
            _schedule_url_focus(self, delay, force=True)
        try:
            self.bind("<Map>", lambda _event, app=self: _schedule_url_focus(app, 90, force=True), add="+")
        except Exception:
            pass
        return result

    app_class.__init__ = init_with_url_focus

    original_show_page = app_class.show_page

    def show_page_with_url_focus(self: Any, page: Any, *args: Any, **kwargs: Any) -> Any:
        result = original_show_page(self, page, *args, **kwargs)
        try:
            current = str(getattr(self, "current_display_page", page)).casefold()
            requested = str(page).casefold()
            if requested == "download" or current == "download":
                _schedule_url_focus(self, 90)
        except Exception:
            pass
        return result

    app_class.show_page = show_page_with_url_focus

    original_reset_to_url = getattr(app_class, "reset_to_url", None)
    if callable(original_reset_to_url):
        def reset_to_url_with_focus(self: Any, *args: Any, **kwargs: Any) -> Any:
            result = original_reset_to_url(self, *args, **kwargs)
            _schedule_url_focus(self, 80)
            return result
        app_class.reset_to_url = reset_to_url_with_focus

    # This proxy is local to the recovered module: popup behaviour elsewhere in
    # the Python process is not changed. After a popup closes, only the active
    # Download page requests URL focus.
    original_messagebox = getattr(module, "messagebox", None)
    if original_messagebox is not None and not getattr(original_messagebox, "_lumo_focus_proxy", False):
        dialog_names = {
            "showerror", "showwarning", "showinfo", "askyesno", "askyesnocancel",
            "askokcancel", "askquestion", "askretrycancel",
        }

        class MessageboxFocusProxy:
            _lumo_focus_proxy = True

            def __getattr__(self, name: str) -> Any:
                method = getattr(original_messagebox, name)
                if name not in dialog_names or not callable(method):
                    return method

                def dialog_and_restore_focus(*args: Any, **kwargs: Any) -> Any:
                    result = method(*args, **kwargs)
                    instance = getattr(module, "_LUMO_APP_INSTANCE", None)
                    if instance is not None:
                        _schedule_url_focus(instance, 80)
                    return result
                return dialog_and_restore_focus

        module.messagebox = MessageboxFocusProxy()


def _schedule_url_focus(app: Any, delay_ms: int = 80, *, force: bool = False) -> None:
    """Focus/select URL after Tk maps the entry, with safe startup retries."""
    def focus_url(attempt: int = 0) -> None:
        try:
            raw_page = getattr(app, "current_display_page", getattr(app, "page", "download"))
            page = str(raw_page or "").strip().casefold()
            startup_page_unknown = page in {"", "none", "home", "start", "main"}
            if page != "download" and not (force and startup_page_unknown):
                return  # Do not steal focus after the user navigates away.
            stage = str(getattr(app, "stage", "idle")).casefold()
            active_job_id = getattr(app, "active_job_id", None)
            if stage in {"active", "downloading", "starting", "cancelling", "busy"}:
                return
            if active_job_id is not None and stage not in {"idle", "error", "quality", "extras", "inspect"}:
                return
            entry = getattr(app, "url_entry", None)
            if entry is not None and not callable(getattr(entry, "focus_set", None)):
                entry = getattr(entry, "entry", entry)
            if entry is None or not callable(getattr(entry, "focus_set", None)):
                return
            try:
                if callable(getattr(entry, "winfo_exists", None)) and not entry.winfo_exists():
                    return
                viewable = entry.winfo_viewable() if callable(getattr(entry, "winfo_viewable", None)) else True
            except Exception:
                viewable = False
            if not viewable:
                # The first callback often runs before Windows maps the main window.
                if attempt < 40:
                    app.after(120, lambda n=attempt + 1: focus_url(n))
                return
            entry.focus_set()
            # Ctrl+V replaces the current URL instead of inserting into it.
            select_text = getattr(entry, "selection_range", None)
            if not callable(select_text):
                select_text = getattr(entry, "select_range", None)
            if callable(select_text):
                try:
                    select_text(0, "end")
                except Exception:
                    pass
        except Exception:
            if attempt < 40:
                try:
                    app.after(120, lambda n=attempt + 1: focus_url(n))
                except Exception:
                    pass

    try:
        app.after(max(0, int(delay_ms)), focus_url)
    except Exception:
        focus_url()

def _is_hex_colour(value: Any) -> bool:
    if not isinstance(value, str) or len(value) != 7 or not value.startswith("#"):
        return False
    try:
        int(value[1:], 16)
    except ValueError:
        return False
    return True


def _redraw_progress_widgets(root: Any, thickness: Any = None, widgets: Any = None) -> None:
    """Update progress widgets in one guarded walk; leave unrelated widgets untouched.

    ``widgets`` lets a caller that has already walked the tree pass that list in, so the
    same tree is not walked a second time.
    """
    try:
        thickness_value = None if thickness is None else max(9, min(16, int(thickness)))
    except (TypeError, ValueError):
        thickness_value = None
    for widget in (widgets if widgets is not None else _walk_widgets(root)):
        if widget.__class__.__name__ != "GlowProgress":
            continue
        if thickness_value is not None:
            try:
                widget.configure(height=thickness_value + 6)
            except Exception:
                pass
        try:
            request_redraw = getattr(widget, "request_redraw", None)
            if callable(request_redraw):
                request_redraw()
        except Exception:
            pass


def _install_url_clear_button(module: ModuleType) -> None:
    """Add a plain, bold X beside the URL entry without affecting downloads."""
    app_class = module.App
    original_init = app_class.__init__
    original_show_page = app_class.show_page

    def init_with_clear(self: Any, *args: Any, **kwargs: Any) -> Any:
        result = original_init(self, *args, **kwargs)
        try:
            self._lumo_accent_colour = str(getattr(module, "ACCENT", "#FF647F"))
        except Exception:
            self._lumo_accent_colour = "#FF647F"
        try:
            self.after(260, lambda: _attach_url_clear(self))
        except Exception:
            pass
        return result

    def show_page_with_clear(self: Any, page: Any, *args: Any, **kwargs: Any) -> Any:
        result = original_show_page(self, page, *args, **kwargs)
        if str(page).casefold() == "download":
            try:
                self.after(100, lambda: _attach_url_clear(self))
            except Exception:
                pass
        return result

    app_class.__init__ = init_with_clear
    app_class.show_page = show_page_with_clear


def _attach_url_clear(app: Any) -> None:
    entry = getattr(app, "url_entry", None)
    if entry is None:
        return
    if not callable(getattr(entry, "delete", None)):
        entry = getattr(entry, "entry", getattr(entry, "input", entry))
    if not callable(getattr(entry, "focus_set", None)):
        return
    old = getattr(app, "_lumo_url_clear_canvas", None)
    if old is not None:
        try:
            if old.winfo_exists():
                _position_url_clear(app, entry, old)
                return
        except Exception:
            pass
    try:
        parent = entry.master
        bg = str(entry.cget("background"))
    except Exception:
        parent = getattr(entry, "master", app)
        bg = "#17243A"
    fg = "#C7D5EA"
    try:
        fg = str(entry.cget("foreground"))
    except Exception:
        pass
    try:
        accent = str(getattr(app, "_lumo_accent_colour", "#FF647F"))
        clear_label = tk.Canvas(
            parent, width=28, height=28, bg=bg, highlightthickness=0, bd=0, cursor="hand2",
        )
        clear_label._lumo_state = {"hover": False, "press": False}
        clear_label._lumo_entry = entry
        _draw_url_clear(clear_label, accent)
        clear_label.bind("<Enter>", lambda _e, w=clear_label, a=accent: _set_url_clear_state(w, a, hover=True))
        clear_label.bind("<Leave>", lambda _e, w=clear_label, a=accent: _set_url_clear_state(w, a, hover=False, press=False))
        clear_label.bind("<ButtonPress-1>", lambda _e, w=clear_label, a=accent: _set_url_clear_state(w, a, press=True))
        clear_label.bind(
            "<ButtonRelease-1>",
            lambda _e, a=app, e=entry, w=clear_label, ac=accent: _url_clear_release(a, e, w, ac),
        )
        app._lumo_url_clear_label = clear_label
        # Retain the old attribute as a compatibility alias for existing wrappers.
        app._lumo_url_clear_canvas = clear_label
        app._lumo_url_clear_entry = entry
        _position_url_clear(app, entry, clear_label)
        try:
            # Bind once per widget; rebinding on every rebuild stacks callbacks.
            if not getattr(entry, "_lumo_url_clear_bound", False):
                entry.bind(
                    "<Configure>",
                    lambda _event, a=app, e=entry: _position_url_clear(a, e, app._lumo_url_clear_label),
                    add="+",
                )
                parent.bind(
                    "<Configure>",
                    lambda _event, a=app, e=entry: _position_url_clear(a, e, app._lumo_url_clear_label),
                    add="+",
                )
                entry._lumo_url_clear_bound = True
        except Exception:
            pass
    except Exception:
        return


def _position_url_clear(app: Any, entry: Any, canvas: Any) -> None:
    try:
        if not entry.winfo_exists() or not entry.winfo_viewable():
            canvas.place_forget()
            return
        parent = canvas.master
        # Center the hit target vertically inside the entry and keep its glyph
        # inset from the right edge, rather than letting the font baseline skew it.
        hit_size = 28
        x = entry.winfo_x() + entry.winfo_width() - hit_size - 5
        y = entry.winfo_y() + (entry.winfo_height() - hit_size) // 2
        # Only show while the Download page is active; don't overlay quality forms.
        page = str(getattr(app, "current_display_page", "download")).casefold()
        if page != "download" or entry.winfo_width() < 70:
            canvas.place_forget()
            return
        canvas.place(x=x, y=y, width=hit_size, height=hit_size)
        canvas.lift()
    except Exception:
        pass


def _animate_url_clear_label(label: Any, accent: str, target_size: int) -> None:
    """Pop the plain bold X smoothly without changing its layout or hit area."""
    try:
        old_id = getattr(label, "_lumo_clear_anim_after", None)
        if old_id is not None:
            label.after_cancel(old_id)
    except Exception:
        pass
    try:
        current = int(getattr(label, "_lumo_clear_anim_size", 11))
    except Exception:
        current = 11
    direction = 1 if target_size > current else -1
    sizes = list(range(current + direction, target_size + direction, direction))
    if not sizes:
        sizes = [target_size]
    generation = int(getattr(label, "_lumo_clear_anim_generation", 0)) + 1
    label._lumo_clear_anim_generation = generation
    label.configure(fg=accent)

    def step(index: int = 0) -> None:
        if generation != getattr(label, "_lumo_clear_anim_generation", generation):
            return
        try:
            size = sizes[index]
            label.configure(font=("Segoe UI Symbol", size, "bold"))
            label._lumo_clear_anim_size = size
            if index + 1 < len(sizes):
                label._lumo_clear_anim_after = label.after(14, lambda: step(index + 1))
            else:
                label._lumo_clear_anim_after = None
        except Exception:
            pass

    step()


def _clear_url_clicked(app: Any, entry: Any, label: Any) -> None:
    """Clear the URL and play a small, repeatable pop on every click."""
    _clear_url_with_animation(app, entry, label)
    try:
        old_id = getattr(label, "_lumo_clear_anim_after", None)
        if old_id is not None:
            label.after_cancel(old_id)
    except Exception:
        pass
    generation = int(getattr(label, "_lumo_clear_anim_generation", 0)) + 1
    label._lumo_clear_anim_generation = generation
    # A quick overshoot and settle gives click feedback without moving the field.
    frames = ((17, 0), (20, 12), (22, 24), (20, 36), (18, 48), (17, 60))
    label.configure(fg="#FFFFFF")
    def step(index: int = 0) -> None:
        if generation != getattr(label, "_lumo_clear_anim_generation", generation):
            return
        try:
            size, delay = frames[index]
            label.configure(font=("Segoe UI Symbol", size, "bold"))
            label._lumo_clear_anim_size = size
            if index + 1 < len(frames):
                label._lumo_clear_anim_after = label.after(
                    12, lambda: step(index + 1)
                )
            else:
                label._lumo_clear_anim_after = None
        except Exception:
            pass
    step()


def _mix_hex(a: str, b: str, amount: float) -> str:
    """Blend two #RRGGBB colours; amount 0 keeps a, 1 gives b."""
    try:
        ar, ag, ab = (int(a.lstrip("#")[i:i + 2], 16) for i in (0, 2, 4))
        br, bg_, bb = (int(b.lstrip("#")[i:i + 2], 16) for i in (0, 2, 4))
    except Exception:
        return a
    mix = lambda x, y: round(x + (y - x) * amount)
    return "#{:02X}{:02X}{:02X}".format(mix(ar, br), mix(ag, bg_), mix(ab, bb))


def _draw_url_clear(canvas: Any, accent: str, size_value: Any = None) -> None:
    """Draw a bold X with rounded ends. No disc, no fill: the glyph itself brightens on hover."""
    state = getattr(canvas, "_lumo_state", {"hover": False, "press": False, "d": 5.2})
    lit = bool(state.get("hover") or state.get("press"))
    try:
        bg = str(canvas.cget("bg"))
    except Exception:
        bg = "#17243A"
    d = float(size_value if size_value is not None else state.get("d", 5.2))
    colour = "#FFFFFF" if lit else _mix_hex(bg, "#FFFFFF", 0.72)
    canvas.delete("all")
    c = 14.0
    canvas.create_line(c - d, c - d, c + d, c + d, fill=colour, width=3,
                       capstyle="round", joinstyle="round")
    canvas.create_line(c - d, c + d, c + d, c - d, fill=colour, width=3,
                       capstyle="round", joinstyle="round")


def _url_clear_target(state: dict) -> float:
    if state.get("press"):
        return 4.0
    if state.get("hover"):
        return 6.8
    return 5.2


def _animate_url_clear(canvas: Any, accent: str, target: float, steps: int = 7) -> None:
    """Ease the X toward its target size in a few short frames; a new target cancels the old run."""
    state = canvas._lumo_state
    previous = state.get("after")
    if previous is not None:
        try:
            canvas.after_cancel(previous)
        except Exception:
            pass
        state["after"] = None
    start = float(state.get("d", 5.2))

    def step(index: int = 1) -> None:
        try:
            t = index / steps
            eased = 1 - (1 - t) ** 3  # ease-out cubic: quick start, soft landing
            value = start + (target - start) * eased
            state["d"] = value
            _draw_url_clear(canvas, accent, value)
            if index < steps:
                state["after"] = canvas.after(16, lambda: step(index + 1))
            else:
                state["after"] = None
        except Exception:
            state["after"] = None

    step()


def _set_url_clear_state(canvas: Any, accent: str, hover: Any = None, press: Any = None) -> None:
    state = getattr(canvas, "_lumo_state", None)
    if state is None:
        return
    if hover is not None:
        state["hover"] = bool(hover)
    if press is not None:
        state["press"] = bool(press)
    _animate_url_clear(canvas, accent, _url_clear_target(state))


def _url_clear_release(app: Any, entry: Any, canvas: Any, accent: str) -> None:
    """Clear the URL on release; the X springs back to its hover or rest size."""
    _set_url_clear_state(canvas, accent, press=False)
    _clear_url_with_animation(app, entry, canvas)


def _clear_url_with_animation(app: Any, entry: Any, canvas: Any) -> None:
    """Clear only the URL field and return focus; never touch download state."""
    try:
        entry.delete(0, "end")
    except Exception:
        try:
            variable = getattr(app, "url_var", None)
            if variable is not None:
                variable.set("")
        except Exception:
            pass
    try:
        entry.focus_set()
    except Exception:
        pass


def _install_history_icon_animations(module: ModuleType) -> None:
    """Give History actions crisp vector icons and light, cancellable animations.

    The old implementation changed the whole button label five times per click.
    SoftButton.refresh_look then regenerated the entire Canvas content for each
    frame. This implementation animates only a few Canvas vector items instead.
    """
    app_class = module.App
    original_init = app_class.__init__
    original_refresh = getattr(app_class, "refresh_history", None)
    button_class = getattr(module, "SoftButton", None)
    original_draw_content = getattr(button_class, "draw_content", None) if button_class else None

    if callable(original_draw_content) and not getattr(original_draw_content, "_lumo_vector_icons", False):
        def draw_content_with_history_icon(self: Any, width: Any, height: Any) -> Any:
            result = original_draw_content(self, width, height)
            if getattr(self, "_lumo_action_kind", None) and getattr(self, "_lumo_show_icon", True):
                _draw_history_action_icon(
                    self, module, str(self._lumo_action_kind),
                    float(getattr(self, "_lumo_icon_progress", 0.0) or 0.0),
                    canvas_width=width, canvas_height=height,
                )
            return result
        draw_content_with_history_icon._lumo_vector_icons = True
        button_class.draw_content = draw_content_with_history_icon

    def init_with_history_icons(self: Any, *args: Any, **kwargs: Any) -> Any:
        # Keep the exact recovered runtime module on the instance. Decoration
        # happens later (often from an idle callback), so it cannot rely on a
        # function-local ``module`` variable existing in the launcher globals.
        try:
            self._lumo_runtime_module = module
        except Exception:
            pass
        result = original_init(self, *args, **kwargs)
        # The builders may already have decorated their buttons. This idle pass
        # is deliberately cheap: it only scans if the cached widgets went away.
        try:
            self.after_idle(lambda app=self: _decorate_history_actions(app))
        except Exception:
            pass
        return result

    app_class.__init__ = init_with_history_icons

    if callable(original_refresh):
        def refresh_with_history_icons(self: Any, *args: Any, **kwargs: Any) -> Any:
            result = original_refresh(self, *args, **kwargs)
            if _history_action_widgets_stale(self):
                try:
                    self.after_idle(lambda app=self: _decorate_history_actions(app))
                except Exception:
                    _decorate_history_actions(self)
            return result
        app_class.refresh_history = refresh_with_history_icons


def _widget_label(widget: Any) -> str:
    label = getattr(widget, "label", None)
    if isinstance(label, str):
        return label.strip()
    try:
        return str(widget.cget("text")).strip()
    except Exception:
        return ""


def _set_widget_label(widget: Any, text: str) -> bool:
    # The recovered SoftButton is a custom Canvas; its label is drawn by refresh_look.
    if isinstance(getattr(widget, "label", None), str):
        try:
            widget.label = text
            refresh = getattr(widget, "refresh_look", None)
            if callable(refresh):
                refresh()
            return True
        except Exception:
            return False
    try:
        widget.configure(text=text)
        return True
    except Exception:
        return False


def _history_action_widgets_stale(app: Any) -> bool:
    widgets = getattr(app, "_lumo_history_action_widgets", None)
    if not isinstance(widgets, (list, tuple)) or not widgets:
        return True
    for widget in widgets:
        try:
            if not widget.winfo_exists():
                return True
        except Exception:
            # Simple test doubles may not expose Tk's existence API.
            if widget is None:
                return True
    return False


def _decorate_history_actions(app: Any) -> None:
    options = getattr(app, "_lumo_customization_options", {})
    # History action buttons intentionally use plain text labels. Older settings
    # files may still contain True from an earlier icon experiment; ignore those
    # stale values so icons cannot reappear after a restart.
    show_icons = False
    animate_icons = False
    signature = (show_icons, animate_icons)
    if (not _history_action_widgets_stale(app)
            and getattr(app, "_lumo_history_action_signature", None) == signature):
        return

    # Only inspect History. Traversing the full root also visited Playlist's
    # Treeview, thumbnails, Settings controls and every hidden page on each refresh.
    pages = getattr(app, "pages", None)
    history_root = pages.get("history") if isinstance(pages, dict) else None
    if history_root is None:
        history_root = app  # compatibility with small test doubles

    # Match both the current captions and labels shipped by earlier recovered
    # builds. In particular, the actual caption "Remove from History" must be
    # recognised directly; matching only the old phrase "Remove record" left
    # that real button without an icon.
    patterns = (
        ("delete file", "Delete file", "delete"),
        ("open file location", "Open file location", "folder"),
        ("share / copy path", "Share / Copy path", "share"),
        ("retry / resume", "Retry / Resume", "retry"),
        ("retry", "Retry / Resume", "retry"),
        ("copy url", "Copy URL", "copy"),
        ("show error", "Show Error", "error"),
        ("remove from history", "Remove from History", "delete_record"),
        ("remove record", "Remove from History", "delete_record"),
        ("refresh", "Refresh", "refresh"),
    )
    decorated: list[Any] = []
    runtime_module = getattr(app, "_lumo_runtime_module", None)
    for widget in _walk_widgets(history_root):
        current = _widget_label(widget)
        original = getattr(widget, "_lumo_original_action_label", None)
        if not isinstance(original, str):
            original = current
        lowered = original.casefold()
        match = next((entry for entry in patterns if entry[0] in lowered), None)
        if match is None:
            continue
        _, caption, kind = match
        try:
            widget._lumo_original_action_label = original
            widget._lumo_action_kind = kind
            widget._lumo_show_icon = show_icons
            widget._lumo_icon_progress = 0.0
            widget._lumo_animate_icon = animate_icons
            widget._lumo_icon_app = app
            widget._lumo_icon_module = runtime_module
        except Exception:
            pass
        display = ("\u2003  " + caption) if show_icons else caption
        if current != display:
            _set_widget_label(widget, display)
        decorated.append(widget)

        if show_icons and animate_icons:
            if not getattr(widget, "_lumo_icon_animation_bound", False):
                _bind_history_icon_before_button_command(widget)
        else:
            # Removing the drawing alone was insufficient: the old bindtag still
            # ran an icon animation before each button command, and packed actions
            # with zero horizontal gap looked like Refresh and Remove were joined.
            try:
                tags = tuple(widget.bindtags())
                widget.bindtags(tuple(tag for tag in tags if tag != "LumoHistoryIconAnimation"))
            except Exception:
                pass
            try:
                delattr(widget, "_lumo_icon_animation_bound")
            except Exception:
                pass
            try:
                if kind == "delete_record":
                    widget.pack_configure(padx=(4, 10))
                    widget.grid_configure(padx=(4, 10))
                elif kind == "refresh":
                    widget.pack_configure(padx=(8, 0))
                    widget.grid_configure(padx=(8, 0))
            except Exception:
                pass
    app._lumo_history_action_widgets = decorated
    app._lumo_history_action_signature = signature


def _bind_history_icon_before_button_command(widget: Any) -> None:
    """Bind animation before SoftButton's click command can rebuild the History row.

    Appending an instance binding meant the original button command could refresh
    or destroy the row before the icon callback ever ran. A dedicated bindtag is
    placed first, so the tiny vector animation starts on press, before the command.
    """
    tag = "LumoHistoryIconAnimation"
    try:
        root_getter = getattr(widget, "_root", None)
        root = root_getter() if callable(root_getter) else widget
        if not getattr(root, "_lumo_history_icon_tag_ready", False):
            def start_before_command(event: Any) -> None:
                target = getattr(event, "widget", None)
                app = getattr(target, "_lumo_icon_app", None)
                module = getattr(target, "_lumo_icon_module", None)
                kind = getattr(target, "_lumo_action_kind", None)
                if app is not None and kind:
                    _animate_history_icon(app, target, module, str(kind))
            root.bind_class(tag, "<ButtonPress-1>", start_before_command, add="+")
            root.bind_class(tag, "<KeyPress-Return>", start_before_command, add="+")
            root.bind_class(tag, "<KeyPress-space>", start_before_command, add="+")
            root._lumo_history_icon_tag_ready = True
        current_tags = tuple(widget.bindtags())
        if tag not in current_tags:
            widget.bindtags((tag,) + current_tags)
        widget._lumo_icon_animation_bound = True
        return
    except Exception:
        # Compatibility for the small canvas doubles used by older recovered builds.
        try:
            widget.bind(
                "<Button-1>",
                lambda _event, w=widget:
                    _animate_history_icon(
                        getattr(w, "_lumo_icon_app", None), w,
                        getattr(w, "_lumo_icon_module", None),
                        str(getattr(w, "_lumo_action_kind", "")),
                    ),
                add="+",
            )
            widget._lumo_icon_animation_bound = True
        except Exception:
            pass


def _draw_history_action_icon(
    widget: Any, module: ModuleType, kind: str, progress: float = 0.0,
    canvas_width: Any = None, canvas_height: Any = None,
) -> None:
    """Draw crisp History glyphs using the dimensions supplied by SoftButton.

    SoftButton draws itself before Tk has necessarily mapped it. Reading
    winfo_height() at that point returns 1, which used to pin the icon to the
    clipped top edge. draw_content passes its true canvas dimensions here, so
    the first paint and subsequent animation frames use the same coordinates.
    """
    try:
        widget.delete("lumo_history_action_icon")
        try:
            width = int(float(canvas_width)) if canvas_width is not None else int(widget.winfo_width())
        except (TypeError, ValueError, AttributeError):
            width = 120
        try:
            height = int(float(canvas_height)) if canvas_height is not None else int(widget.winfo_height())
        except (TypeError, ValueError, AttributeError):
            height = 34
        if width < 24:
            width = 120
        if height < 20:
            height = 34

        # Icon slot is intentionally aligned to the label's leading spacer.
        # Keep it proportionate if the user has Windows display scaling enabled.
        scale = max(0.78, min(1.16, (height - 8.0) / 26.0))
        cx, cy = 18.0, height / 2.0
        accent = str(getattr(module, "ACCENT", "#FF647F") or "#FF647F")
        white = str(getattr(module, "TEXT", getattr(module, "WHITE", "#F2F5FA")) or "#F2F5FA")
        muted = str(getattr(module, "MUTED", "#AAB3C2") or "#AAB3C2")
        danger = str(getattr(module, "DANGER", "#FF647F") or "#FF647F")
        amber = str(getattr(module, "AMBER", "#FFB45F") or "#FFB45F")
        p = max(0.0, min(1.0, float(progress)))
        fg = accent if p > 0.015 else white
        if kind == "delete":
            fg = danger if p > 0.015 else white
        elif kind == "delete_record":
            fg = amber if p > 0.015 else white
        tag = ("lumo_history_action_icon",)
        lw = 2.15 * scale
        radius = 7.6 * scale
        import math

        def line(*coords: float, width: float = lw, fill: str = fg, smooth: bool = False) -> None:
            widget.create_line(
                *coords, fill=fill, width=width, capstyle="round", joinstyle="round",
                smooth=smooth, splinesteps=16, tags=tag,
            )

        def arc_arrow(start_deg: float, extent_deg: float, r: float, size: float = 3.1) -> None:
            """Draw a correctly tangent arrowhead at a Tk arc's endpoint."""
            widget.create_arc(
                cx-r, cy-r, cx+r, cy+r, start=start_deg, extent=extent_deg,
                style="arc", outline=fg, width=lw, tags=tag,
            )
            theta = -math.radians(start_deg + extent_deg)
            tip_x = cx + r * math.cos(theta)
            tip_y = cy + r * math.sin(theta)
            heading = theta + math.pi / 2.0
            back_x = tip_x - size * math.cos(heading)
            back_y = tip_y - size * math.sin(heading)
            side = size * 0.62
            left_x = back_x + side * math.cos(heading + math.pi / 2.0)
            left_y = back_y + side * math.sin(heading + math.pi / 2.0)
            right_x = back_x + side * math.cos(heading - math.pi / 2.0)
            right_y = back_y + side * math.sin(heading - math.pi / 2.0)
            widget.create_polygon(
                tip_x, tip_y, left_x, left_y, right_x, right_y,
                fill=fg, outline=fg, tags=tag,
            )

        def smooth_path(points: list[float], width: float = lw, fill: str = fg) -> None:
            line(*points, width=width, fill=fill, smooth=True)

        if kind == "retry":
            # Two opposing arrows; rotating both around the same centre reads as
            # a genuine retry cycle instead of two disconnected curved dashes.
            rotation = 360.0 * p
            for base in (42.0, 222.0):
                arc_arrow(base + rotation, 118.0, radius, 3.0 * scale)

        elif kind == "refresh":
            # One clean, almost-closed circle with a tangent arrowhead.
            arc_arrow(42.0 + 360.0 * p, 292.0, radius, 3.3 * scale)

        elif kind == "copy":
            # URL chain rests as two clear interlocking links. On click, the links
            # give way to a check rather than stacking the two symbols together.
            if p < 0.58:
                travel = 1.2 * math.sin(math.pi * (p / 0.58)) if p > 0 else 0.0
                left_x = cx - 3.7 - travel
                right_x = cx + 3.7 + travel
                widget.create_oval(
                    left_x-4.7*scale, cy-3.0*scale, left_x+2.0*scale, cy+3.0*scale,
                    outline=fg, width=lw, tags=tag,
                )
                widget.create_oval(
                    right_x-2.0*scale, cy-3.0*scale, right_x+4.7*scale, cy+3.0*scale,
                    outline=fg, width=lw, tags=tag,
                )
                line(cx-2.2*scale, cy+1.1*scale, cx+2.2*scale, cy-1.1*scale,
                     width=lw*0.9)
            else:
                q = max(0.0, min(1.0, (p-0.58)/0.30))
                # Draw the tick in two stages for visible feedback at button size.
                line(cx-5.0*scale, cy, cx+(-2.0+3.0*q)*scale, cy+3.4*scale,
                     width=2.5*scale)
                if q > 0.38:
                    q2 = min(1.0, (q-0.38)/0.62)
                    line(cx-2.0*scale+3.0*q*scale, cy+3.4*scale,
                         cx+5.0*q2*scale, cy-4.0*q2*scale, width=2.5*scale)

        elif kind == "error":
            r = 8.0 * scale
            widget.create_oval(cx-r, cy-r, cx+r, cy+r, outline=fg, width=lw, tags=tag)
            bounce = 1.8 * math.sin(math.pi * min(1.0, p / 0.72)) if 0 < p < 0.72 else 0.0
            widget.create_text(
                cx, cy-0.3*scale-bounce, text="?", fill=fg,
                font=("Segoe UI", max(10, round(11*scale)), "bold"), tags=tag,
            )

        elif kind == "delete":
            # A page visibly drops into a bin; the lid lifts on approach and
            # settles back down. This is a visual-only animation: file deletion
            # still happens only in the existing confirmed button command.
            active = p > 0.015
            drop = min(1.0, p / 0.78) if active else 0.0
            lid_lift = 2.1 * scale * (min(1.0, p/0.18) if active else 0.0)
            body_top, body_bottom = cy-2.4*scale, cy+7.0*scale
            smooth_path([
                cx-4.1*scale, body_top, cx-3.1*scale, body_bottom,
                cx+3.1*scale, body_bottom, cx+4.1*scale, body_top,
            ], width=lw)
            line(cx-5.4*scale, cy-4.4*scale-lid_lift,
                 cx+5.4*scale, cy-4.4*scale-lid_lift, width=lw)
            line(cx-2.4*scale, cy-6.0*scale-lid_lift,
                 cx+2.4*scale, cy-6.0*scale-lid_lift, width=lw*0.9)
            if active and drop < 0.95:
                paper_y = cy-9.4*scale + 13.2*scale*drop
                widget.create_rectangle(
                    cx-2.2*scale, paper_y-2.0*scale, cx+2.2*scale, paper_y+2.0*scale,
                    outline=fg, fill="", width=1.45*scale, tags=tag,
                )
                line(cx-1.1*scale, paper_y, cx+1.1*scale, paper_y, width=1.0*scale)
            line(cx-1.4*scale, cy-0.2*scale, cx-1.4*scale, cy+3.7*scale,
                 width=1.2*scale, fill=muted)
            line(cx+1.4*scale, cy-0.2*scale, cx+1.4*scale, cy+3.7*scale,
                 width=1.2*scale, fill=muted)

        elif kind == "delete_record":
            # Remove from History is a document-minus icon, separate from Delete file.
            left, right = cx-5.0*scale, cx+3.0*scale
            top, bottom = cy-7.6*scale, cy+7.2*scale
            widget.create_rectangle(
                left, top, cx+4.5*scale, bottom,
                outline=fg, width=lw, tags=tag,
            )
            # Folded upper-right corner makes the document recognisable without
            # overloading the small icon with too many line segments.
            line(cx+0.9*scale, top, cx+0.9*scale, cy-4.0*scale,
                 cx+4.5*scale, cy-4.0*scale, width=lw*0.85)
            line(cx-2.6*scale, cy-1.7*scale, cx+1.9*scale, cy-1.7*scale,
                 width=1.25*scale, fill=muted)
            slide = 1.2*math.sin(math.pi*p) if p > 0 else 0.0
            line(cx-2.6*scale+slide, cy+1.3*scale,
                 cx+2.8*scale+slide, cy+1.3*scale, width=lw)

        elif kind == "folder":
            # Open-folder outline with a short outgoing location arrow.
            line(cx-7.5*scale, cy-3.8*scale, cx-2.3*scale, cy-3.8*scale,
                 cx-0.2*scale, cy-1.7*scale, cx+7.1*scale, cy-1.7*scale,
                 cx+5.8*scale, cy+5.9*scale, cx-7.5*scale, cy+5.9*scale,
                 cx-7.5*scale, cy-3.8*scale, width=lw)
            shift = 1.7*math.sin(math.pi*p) if p > 0 else 0.0
            line(cx+0.1*scale+shift, cy-0.6*scale,
                 cx+3.9*scale+shift, cy-0.6*scale, width=lw*0.95)
            line(cx+2.5*scale+shift, cy-2.0*scale,
                 cx+3.9*scale+shift, cy-0.6*scale,
                 cx+2.5*scale+shift, cy+0.8*scale, width=lw*0.95)

        elif kind == "share":
            # File outline and rising north-east arrow. The arrow extends on click.
            line(cx-5.6*scale, cy-6.7*scale,
                 cx+0.8*scale, cy-6.7*scale,
                 cx+3.1*scale, cy-4.4*scale,
                 cx+3.1*scale, cy+5.7*scale,
                 cx-5.6*scale, cy+5.7*scale,
                 cx-5.6*scale, cy-6.7*scale, width=lw)
            line(cx-3.3*scale, cy-1.8*scale, cx-0.6*scale, cy-1.8*scale,
                 width=1.15*scale, fill=muted)
            line(cx-3.3*scale, cy+0.8*scale, cx-0.6*scale, cy+0.8*scale,
                 width=1.15*scale, fill=muted)
            lift = 2.6*math.sin(math.pi*p) if p > 0 else 0.0
            line(cx-0.2*scale, cy-1.1*scale-lift,
                 cx+6.6*scale, cy-6.5*scale-lift, width=lw)
            line(cx+3.9*scale, cy-6.5*scale-lift,
                 cx+6.6*scale, cy-6.5*scale-lift,
                 cx+6.6*scale, cy-3.8*scale-lift, width=lw)
    except Exception:
        # Cosmetic painting must never interfere with the History button command.
        return

def _animate_history_icon(app: Any, widget: Any, module: ModuleType, kind: str) -> None:
    options = getattr(app, "_lumo_customization_options", {})
    if not options.get("show_history_action_icons", True):
        return
    if not options.get("animate_history_action_icons", True):
        return
    if not getattr(widget, "enabled", True):
        return
    try:
        if not widget.winfo_exists():
            return
    except Exception:
        pass
    # Cancel the previous callback as well as invalidating its generation. This
    # avoids stale scheduled frames piling up when someone taps quickly.
    old_after = getattr(widget, "_lumo_icon_after_id", None)
    if old_after is not None:
        try:
            app.after_cancel(old_after)
        except Exception:
            pass
    generation = int(getattr(widget, "_lumo_icon_generation", 0)) + 1
    widget._lumo_icon_generation = generation
    start = time.monotonic()
    duration_ms = 390 if kind == "retry" else (350 if kind == "refresh" else 320)

    def frame() -> None:
        if getattr(widget, "_lumo_icon_generation", None) != generation:
            return
        try:
            if not widget.winfo_exists():
                return
        except Exception:
            return
        elapsed = (time.monotonic() - start) * 1000.0
        t = max(0.0, min(1.0, elapsed / duration_ms))
        if kind in {"retry", "refresh"}:
            # A rotating glyph needs a smooth start AND stop; ease-out made it
            # complete most of its revolution immediately, which read as a jerk.
            eased = 0.5 - 0.5 * math.cos(math.pi * t)
        else:
            easing = getattr(module, "ease_out_cubic", None)
            try:
                eased = max(0.0, min(1.0, float(easing(t)))) if callable(easing) else 1.0-(1.0-t)**3
            except Exception:
                eased = 1.0-(1.0-t)**3
        widget._lumo_icon_progress = eased
        _draw_history_action_icon(widget, module, kind, eased)
        if t < 1.0:
            try:
                widget._lumo_icon_after_id = app.after(16, frame)
            except Exception:
                widget._lumo_icon_after_id = None
        else:
            widget._lumo_icon_after_id = None
            widget._lumo_icon_progress = 0.0
            _draw_history_action_icon(widget, module, kind, 0.0)

    frame()

def _downloader_module() -> Any:
    from lumo_windows import downloader as downloader_module
    return downloader_module


def _set_ui_status(app: Any, module: ModuleType, text: str, colour_name: str) -> None:
    try:
        app.set_status(text, getattr(module, colour_name, None))
    except Exception:
        pass


def _matching_button_size(button: Any) -> tuple[int, int]:
    """Use the Cancel button's size so Pause sits beside it at the same height."""
    try:
        width = int(float(button.cget("width")))
        height = int(float(button.cget("height")))
        if width > 20 and height > 20:
            return width, height
    except Exception:
        pass
    return 142, 36


def _sync_pause_label(app: Any, module: ModuleType) -> None:
    """Show Pause or Resume from the running job's real state."""
    button = getattr(app, "pause_download_btn", None)
    if button is None:
        return
    try:
        job = _downloader_module().current_job()
        paused = bool(job is not None and job.is_paused())
        label = "Resume download" if paused else "Pause download"
        # Redraw only when the text changes; this runs on events and must stay cheap.
        if getattr(button, "_lumo_last_label", None) == label:
            return
        button._lumo_last_label = label
        if isinstance(getattr(button, "label", None), str):
            button.label = label
            button.refresh_look()
        else:
            button.configure(text=label)
    except Exception:
        pass


def _report_ui_error(app: Any, module: ModuleType, where: str, exc: BaseException) -> None:
    """Explain a failed button action in plain words and keep the traceback in a log."""
    import traceback
    technical = "".join(traceback.format_exception(type(exc), exc, exc.__traceback__))
    try:
        log_path = _downloader_module()._write_error_log(where, technical)
    except Exception:
        log_path = ""
    message = "That step did not finish. Try again."
    if log_path:
        message += f" (Details: {log_path})"
    _set_ui_status(app, module, message, "WARN")


def _install_global_pause_resume(module: ModuleType) -> None:
    """Expose pause/resume on the ordinary active-download panel, using backend controls."""
    app_class = module.App
    original_build = app_class.build_download_page

    # The recovered worker creates DownloadJob inside its worker function. Wrap
    # that class so the UI gets a safe reference to the real job object; the
    # Thread itself is not a pausable download.
    original_job_class = getattr(module, "DownloadJob", None)
    if isinstance(original_job_class, type) and not getattr(original_job_class, "_lumo_tracking", False):
        class TrackedDownloadJob(original_job_class):
            _lumo_tracking = True
            def __init__(self, *args: Any, **kwargs: Any):
                super().__init__(*args, **kwargs)
                app = getattr(module, "_LUMO_APP_INSTANCE", None)
                if app is not None:
                    app._lumo_active_download_job = self
                    app._lumo_download_paused = False
        module.DownloadJob = TrackedDownloadJob

    def toggle_pause(self: Any) -> None:
        """Pause or resume the job that is actually running; its state is the truth."""
        job = _downloader_module().current_job()
        if job is None:
            _set_ui_status(self, module, "No download is running right now.", "MUTED")
            return
        try:
            if job.is_paused():
                job.resume()
                message = "Download resumed."
            else:
                job.pause()
                message = "Paused. Progress is kept; press Resume to continue."
        except Exception as exc:
            _report_ui_error(self, module, "pause", exc)
            return
        _sync_pause_label(self, module)
        _set_ui_status(self, module, message, "GOOD")

    app_class.toggle_download_pause = toggle_pause
    def build_download_with_pause(self: Any, *args: Any, **kwargs: Any) -> Any:
        # Pause is removed from the download panel. Cancel is the only action there.
        result = original_build(self, *args, **kwargs)
        old_button = getattr(self, "pause_download_btn", None)
        if old_button is not None:
            try:
                old_button.destroy()
            except Exception:
                pass
            self.pause_download_btn = None
        return result
    app_class.build_download_page = build_download_with_pause

    # Keep the button state in sync with a finished or cancelled normal download.
    original_handle = getattr(app_class, "handle_event", None)
    if callable(original_handle):
        def handle_event_with_pause_reset(self: Any, kind: Any, payload: Any) -> Any:
            result = original_handle(self, kind, payload)
            if str(kind).casefold() in {"download_finished", "finished", "download_complete", "completed", "complete", "error", "cancelled", "done", "started"}:
                _sync_pause_label(self, module)
            return result
        app_class.handle_event = handle_event_with_pause_reset


def _schedule_nav_icon_cache_warmup(app: Any, module: ModuleType) -> None:
    """Pre-render navigation icon frames while yielding to normal Tk events.

    One PhotoImage is created per short callback. The older implementation did
    four expensive rasterisations in a single UI-thread callback, which could
    block clicks and the first visible page transition while the cache warmed.
    """
    if getattr(app, "_lumo_nav_icon_warmup_started", False):
        return
    app._lumo_nav_icon_warmup_started = True
    original_photo = getattr(module, "_lumo_original_icon_photo", None)
    params = getattr(module, "_lumo_nav_icon_photo_params", {})
    rows = getattr(app, "nav_rows", {})
    if not callable(original_photo) or not isinstance(params, dict) or not isinstance(rows, dict):
        app._lumo_nav_icon_warmup_complete = True
        return

    tasks: list[tuple[Any, ...]] = []
    warm_rows: list[tuple[str, Any, tuple[Any, ...], Any, Any]] = []
    for row in rows.values():
        kind = str(getattr(row, "icon_name", "") or "").casefold()
        base = params.get(kind)
        pose_func = getattr(row, "_icon_pose", None)
        if isinstance(base, tuple) and len(base) == 4 and callable(pose_func):
            warm_rows.append((kind, row, base, pose_func, getattr(row, "icon_t", 0.0)))

    # Interleave each icon's poses, so every navigation item starts warming early.
    # Nine representative poses are enough to prewarm the animation cache.
    # Forty-one poses created hundreds of UI-thread callbacks and made resize/tab
    # interactions feel sticky while the cache was filling.
    for step in range(9):
        for kind, row, base, pose_func, previous in warm_rows:
            try:
                row.icon_t = step / 8.0
                pose = pose_func()
                if not isinstance(pose, dict):
                    pose = {}
                tasks.append((kind, base[0], base[1], base[2], base[3],
                              pose.get("rot", 0.0), pose.get("sc", 1.0), pose.get("oy", 0.0)))
            except Exception:
                pass
            finally:
                try:
                    row.icon_t = previous
                except Exception:
                    pass

    index = 0
    def render_next() -> None:
        nonlocal index
        # Never spend UI-thread time rasterising animation frames during or just
        # after a user's navigation/resize interaction.
        # Never overlap the icon rasterizer with History/Settings page mapping.
        if not bool(getattr(app, "_lumo_tab_warmup_complete", True)):
            try:
                app._lumo_nav_icon_warmup_after_id = app.after(80, render_next)
            except Exception:
                app._lumo_nav_icon_warmup_complete = True
            return
        try:
            last_input = float(getattr(app, "_lumo_last_ui_interaction", 0.0) or 0.0)
            if time.monotonic() - last_input < 0.90:
                app._lumo_nav_icon_warmup_after_id = app.after(300, render_next)
                return
        except Exception:
            pass
        try:
            exists = getattr(app, "winfo_exists", None)
            if callable(exists) and not exists():
                app._lumo_nav_icon_warmup_complete = True
                return
        except Exception:
            app._lumo_nav_icon_warmup_complete = True
            return
        if index >= len(tasks):
            app._lumo_nav_icon_warmup_complete = True
            return
        args = tasks[index]
        index += 1
        try:
            original_photo(*args)
        except Exception:
            pass
        if index < len(tasks):
            try:
                # Timer callbacks yield to real input and paint events between frames.
                app._lumo_nav_icon_warmup_after_id = app.after(12, render_next)
            except Exception:
                try:
                    app._lumo_nav_icon_warmup_after_id = app.after_idle(render_next)
                except Exception:
                    app._lumo_nav_icon_warmup_complete = True
        else:
            app._lumo_nav_icon_warmup_complete = True

    if tasks:
        try:
            # Primary page layout is warmed first. Leave a short idle gap before
            # drawing animation frames so two CPU-heavy jobs never share startup.
            app._lumo_nav_icon_warmup_after_id = app.after(380, render_next)
        except Exception:
            render_next()
    else:
        app._lumo_nav_icon_warmup_complete = True


def _schedule_primary_tab_warmup(app: Any) -> None:
    """Map each hidden primary page under the visible page once to warm Tk layout.

    Tk defers a number of first-map operations (Canvas/Treeview layout, font
    metrics and redraws) until a frame is first shown. Warming one frame at a
    time behind the current opaque page avoids a visible tab flash and removes
    most of that cold-layout cost from the user's first tab switch.
    """
    if getattr(app, "_lumo_tab_warmup_started", False):
        return
    app._lumo_tab_warmup_started = True
    app._lumo_warmed_pages = set(getattr(app, "_lumo_warmed_pages", set()))
    # Playlist is an intentionally empty placeholder in this recovery build;
    # History and Settings contain the heavier Treeview/chip layouts.
    keys = ("history", "settings")

    def exists(widget: Any) -> bool:
        try:
            return bool(widget is not None and widget.winfo_exists())
        except Exception:
            return False

    def current_key() -> str:
        return str(getattr(app, "current_display_page", "download") or "download").casefold()

    def warm(index: int = 0, retries: int = 0) -> None:
        if not exists(app):
            app._lumo_tab_warmup_complete = True
            return
        try:
            last_input = float(getattr(app, "_lumo_last_ui_interaction", 0.0) or 0.0)
            if time.monotonic() - last_input < 0.90:
                app.after(300, lambda: warm(index, retries))
                return
        except Exception:
            pass
        if index >= len(keys):
            app._lumo_tab_warmup_complete = True
            return
        try:
            if not app.winfo_viewable():
                if retries < 60:
                    app.after(80, lambda: warm(index, retries + 1))
                else:
                    # Do not leave the icon-animation gate permanently closed if
                    # the app is intentionally started unmapped/minimized.
                    app._lumo_tab_warmup_complete = True
                return
        except Exception:
            pass
        key = keys[index]
        pages = getattr(app, "pages", {})
        content = getattr(app, "content", None)
        target = pages.get(key) if isinstance(pages, dict) else None
        visible = pages.get(current_key()) if isinstance(pages, dict) else None
        if target is None or content is None or not exists(target):
            app.after_idle(lambda: warm(index + 1, 0))
            return
        if key in app._lumo_warmed_pages:
            app.after_idle(lambda: warm(index + 1, 0))
            return
        if target is visible or current_key() == key:
            app._lumo_warmed_pages.add(key)
            app.after_idle(lambda: warm(index + 1, 0))
            return
        try:
            target.place(x=0, y=0, relwidth=1, relheight=1)
            if visible is not None and exists(visible):
                target.lower(visible)
            # Return to Tk's event loop so layout, painting, and input can run naturally;
            # avoid synchronously flushing every pending UI geometry operation here.
        except Exception:
            try:
                target.place_forget()
            except Exception:
                pass
            app.after_idle(lambda: warm(index + 1, 0))
            return

        def finish_warm() -> None:
            if not exists(app) or not exists(target):
                return
            try:
                # A user may have selected this page during the warm-up. Never
                # unmap the page if it has become the visible target.
                if current_key() != key:
                    target.place_forget()
            except Exception:
                pass
            app._lumo_warmed_pages.add(key)
            try:
                app.after_idle(lambda: warm(index + 1, 0))
            except Exception:
                pass
        try:
            app.after(45, finish_warm)
        except Exception:
            finish_warm()

    try:
        # Start page layout warming immediately after initial mapping. The old
        # 900 ms delay allowed the first user click to arrive before either heavy
        # page had ever been mapped, so that click paid the cold layout cost.
        app.after(70, lambda: warm(0, 0))
    except Exception:
        pass


# Every click must play the icon, however soon after the previous one. There is no
# time-based "ignore repeat clicks" window any more (that window is what swallowed
# real clicks). A single click is de-duplicated by event instead: the mouse-press
# handler plays the icon and marks the click, and the page switch that belongs to
# the same click consumes that mark instead of starting a second tween.
_NAV_ICON_REPEAT_WINDOW_S = 0.0
_NAV_PRESS_MARK_TTL_S = 1.0


def _schedule_nav_icon_play(app: Any, page_key: str, attempts: int = 0,
                            from_press: bool = False) -> None:
    """Play a sidebar icon animation once per click, on every click.

    - A press always (re)starts the icon animation, including a click on the tab
      that is already open. A newer click replaces a queued one, so rapid clicks
      never stack several animations on the same icon.
    - The page switch caused by that same click does not start a second tween.
    - On the very first click the icon cache may still be warming. The request
      waits and retries instead of being silently dropped.
    """
    key = str(page_key).casefold()
    store = getattr(app, "_lumo_nav_play_state", None)
    if not isinstance(store, dict):
        store = {}
        try:
            app._lumo_nav_play_state = store
        except Exception:
            _play_navigation_icon(app, key)
            return
    state = store.setdefault(key, {"after": None, "last": 0.0, "press": 0.0})
    if attempts == 0:
        if from_press:
            state["press"] = time.monotonic()
        elif time.monotonic() - float(state.get("press", 0.0)) < _NAV_PRESS_MARK_TTL_S:
            # The press of this same click already started the icon; consume the mark.
            state["press"] = 0.0
            return
    if state["after"] is not None:
        try:
            app.after_cancel(state["after"])
        except Exception:
            pass
        state["after"] = None
    if not bool(getattr(app, "_lumo_nav_icon_warmup_complete", True)) and attempts < 60:
        try:
            state["after"] = app.after(60, lambda: _schedule_nav_icon_play(app, key, attempts + 1))
        except Exception:
            pass
        return

    def run() -> None:
        state["after"] = None
        state["last"] = time.monotonic()
        _play_navigation_icon(app, key)

    try:
        state["after"] = app.after(18, run)
    except Exception:
        run()


def _bind_nav_press_animation(app: Any) -> None:
    """Start a sidebar icon animation the moment the mouse button goes down.

    The page switch itself runs on release and can take a moment; binding the press
    means the icon moves immediately under the cursor. The scheduler keeps it to one
    animation per click, so the later page switch does not start a second one.
    """
    rows = getattr(app, "nav_rows", {})
    if not isinstance(rows, dict):
        return
    for key, row in rows.items():
        for widget in [row] + _descendants(row):
            if getattr(widget, "_lumo_press_bound", False):
                continue
            try:
                widget.bind("<ButtonPress-1>",
                            lambda _e, a=app, k=str(key).casefold(): _schedule_nav_icon_play(a, k, from_press=True),
                            add="+")
                widget._lumo_press_bound = True
            except Exception:
                pass


def _icon_ease(t: float) -> float:
    return 4.0 * t * t * t if t < 0.5 else 1.0 - ((-2.0 * t + 2.0) ** 3) / 2.0


def _log_icon_error(text: str) -> None:
    """Append one line to %TEMP%/lumo_icon_debug.log (only ever written on a failure)."""
    try:
        path = Path(tempfile.gettempdir()) / "lumo_icon_debug.log"
        with path.open("a", encoding="utf-8") as handle:
            handle.write(f"{time.strftime('%H:%M:%S')} {text}\n")
    except Exception:
        pass


def _play_navigation_icon(app: Any, page_key: str) -> None:
    """Play a sidebar icon animation from the start, every time it is asked for.

    This drives the row's own _set_icon() directly from a small self-contained
    timer (about 30 frames/s for 0.9 s, then it stops). It does not depend on the
    recovered play_icon()/Tween state, so a finished or cancelled earlier run can
    never stop the next click from animating. A new call restarts the animation.
    """
    rows = getattr(app, "nav_rows", {})
    if not isinstance(rows, dict):
        return
    row = rows.get(str(page_key).casefold())
    if row is None:
        return
    try:
        old = getattr(row, "_icon_tween", None)
        if old is not None:
            old.cancel()
        previous = getattr(row, "_lumo_icon_after", None)
        if previous is not None:
            row.after_cancel(previous)
            row._lumo_icon_after = None
        started = time.perf_counter()
        duration = _NAV_ICON_TWEEN_MS / 1000.0

        def frame() -> None:
            row._lumo_icon_after = None
            try:
                if not row.winfo_exists():
                    return
                progress = min(1.0, (time.perf_counter() - started) / duration)
                row._set_icon(_icon_ease(progress))
                if progress < 1.0:
                    row._lumo_icon_after = row.after(34, frame)
            except Exception as exc:
                _log_icon_error(f"frame failed for {page_key}: {exc!r}")

        frame()
    except Exception as exc:
        _log_icon_error(f"play failed for {page_key}: {exc!r}")


def _install_resize_animation_guard(app: Any, module: ModuleType) -> None:
    """Avoid a page tween fighting Windows maximize/restore geometry changes."""
    if getattr(app, "_lumo_resize_guard_bound", False):
        return
    app._lumo_resize_guard_bound = True
    app._lumo_last_root_size = None

    def on_root_configure(event: Any) -> None:
        try:
            if getattr(event, "widget", None) is not app:
                return
            size = (int(event.width), int(event.height))
        except Exception:
            return
        previous = getattr(app, "_lumo_last_root_size", None)
        app._lumo_last_root_size = size
        if previous is None or previous == size:
            return
        # Size really changed (not just a window move): other loops may hold off briefly.
        app._lumo_resizing_until = time.monotonic() + 0.25
        tween = getattr(app, "_page_tween", None)
        if tween is None:
            return
        cancel_tween = getattr(module, "cancel_tween", None)
        if callable(cancel_tween):
            try:
                cancel_tween(app, "_page_tween")
            except Exception:
                pass
        current = str(getattr(app, "current_display_page", "download") or "download").casefold()
        pages = getattr(app, "pages", {})
        if not isinstance(pages, dict):
            return
        for key, frame in tuple(pages.items()):
            try:
                if str(key).casefold() == current:
                    frame.place(x=0, y=0, relwidth=1, relheight=1)
                else:
                    frame.place_forget()
            except Exception:
                pass

    try:
        app.bind("<Configure>", on_root_configure, add="+")
    except Exception:
        pass


def _install_playlist_navigation(module: ModuleType) -> None:
    """Create an embedded Playlist page and a first-class sidebar navigation row."""
    app_class = module.App
    from lumo_windows.playlist_motion import playlist_icon_rotation
    app_class_original_init = app_class.__init__
    app_class_original_show_page = app_class.show_page

    # Remove only the small "VIDEO STUDIO" tagline from the sidebar brand.
    # Apply this after each shell build so it stays removed after UI rebuilds.
    try:
        module.APP_TITLE = "Lumo"
        original_build_shell = app_class.build_shell

        def build_shell_without_tagline(self: Any, *args: Any, **kwargs: Any) -> Any:
            result = original_build_shell(self, *args, **kwargs)

            def remove_tagline(parent: Any) -> None:
                try:
                    children = tuple(parent.winfo_children())
                except Exception:
                    return
                for child in children:
                    try:
                        label_text = str(child.cget("text")).strip().casefold()
                    except Exception:
                        label_text = ""
                    if label_text == "video studio":
                        try:
                            child.destroy()
                        except Exception:
                            pass
                    else:
                        remove_tagline(child)

            remove_tagline(self)
            return result

        app_class.build_shell = build_shell_without_tagline
    except Exception:
        pass

    old_nav_items = tuple(getattr(module, "NAV_ITEMS", ()))
    if not any(isinstance(item, (tuple, list)) and item and item[0] == "playlist" for item in old_nav_items):
        replacement = []
        inserted = False
        for item in old_nav_items:
            replacement.append(item)
            if not inserted and isinstance(item, (tuple, list)) and item and item[0] == "download":
                replacement.append(("playlist", "Playlist", "playlist"))
                inserted = True
        if not inserted:
            replacement.append(("playlist", "Playlist", "playlist"))
        module.NAV_ITEMS = tuple(replacement)

    # Playlist is a new icon kind, so the recovered NavRow pose function does not
    # animate it. Give it its own white, crisp glyph and staggered one-shot motion.
    original_icon_rgba = getattr(module, "icon_rgba", None)
    if callable(original_icon_rgba) and not getattr(original_icon_rgba, "_lumo_playlist_icon", False):
        def icon_rgba_with_playlist(kind: str, colour: Any, bg: Any, size: int,
                                    ss: int, rot: float, sc: float, oy: float) -> Any:
            if str(kind).casefold() != "playlist":
                return original_icon_rgba(kind, colour, bg, size, ss, rot, sc, oy)
            try:
                import math
                from PIL import Image, ImageDraw
                logical_size = max(16, int(size))
                scale = max(1, int(ss))
                canvas_size = logical_size * scale
                image = Image.new("RGBA", (canvas_size, canvas_size), (0, 0, 0, 0))
                draw = ImageDraw.Draw(image)
                color = module._rgb("#FFFFFF")
                if not isinstance(color, tuple):
                    color = (255, 255, 255)
                phase = max(0.0, min(1.0, float(rot) / 360.0))
                center = logical_size / 2
                factor = max(0.55, min(1.25, float(sc)))
                y_offset = float(oy)

                def rounded_progress(value: float, start: float, end: float) -> float:
                    q = max(0.0, min(1.0, (value - start) / max(0.001, end - start)))
                    return math.sin(math.pi * q) if 0.0 < q < 1.0 else 0.0

                def point(x: float, y: float) -> tuple[int, int]:
                    px = center + (x - center) * factor
                    py = center + (y - center) * factor + y_offset
                    return int(round(px * scale)), int(round(py * scale))

                width = max(1, int(round(1.75 * scale)))
                # Three list strokes move independently in a staggered sequence.
                top_y = 6.6 - 2.1 * rounded_progress(phase, 0.00, 0.42)
                middle_stretch = 1.8 * rounded_progress(phase, 0.13, 0.58)
                bottom_y = 17.0 + 2.1 * rounded_progress(phase, 0.28, 0.72)
                for y, end_x in ((top_y, 12.0), (11.8, 12.0 + middle_stretch), (bottom_y, 12.0)):
                    draw.line([point(4.4, y), point(end_x, y)], fill=color, width=width)

                # Rotate the arrow around its own hub, clockwise for a complete turn.
                arrow_angle = math.radians(float(rot))
                hub_x, hub_y = 16.0, 12.0
                def arrow_point(x: float, y: float) -> tuple[int, int]:
                    dx, dy = x - hub_x, y - hub_y
                    rx = dx * math.cos(arrow_angle) - dy * math.sin(arrow_angle)
                    ry = dx * math.sin(arrow_angle) + dy * math.cos(arrow_angle)
                    return point(hub_x + rx, hub_y + ry)

                draw.line([arrow_point(11.2, 12.0), arrow_point(16.0, 12.0)],
                          fill=color, width=width)
                arrowhead = [arrow_point(13.2, 7.0), arrow_point(20.0, 12.0),
                             arrow_point(13.2, 17.0)]
                draw.polygon(arrowhead, fill=color)
                return module._premul_down(image, logical_size, logical_size)
            except Exception:
                return original_icon_rgba("history", "#FFFFFF", bg, size, ss, rot, sc, oy)
        icon_rgba_with_playlist._lumo_playlist_icon = True
        module.icon_rgba = icon_rgba_with_playlist

    # Register Playlist with NavRow's tween system; without this, the recovered
    # _icon_pose() returns no motion for the new icon kind.
    nav_row_class = getattr(module, "NavRow", None)
    original_icon_pose = getattr(nav_row_class, "_icon_pose", None) if nav_row_class is not None else None
    if callable(original_icon_pose) and not getattr(original_icon_pose, "_lumo_playlist_pose", False):
        def icon_pose_with_playlist(self: Any) -> Any:
            if str(getattr(self, "icon_name", "")).casefold() == "playlist":
                try:
                    progress = max(0.0, min(1.0, float(getattr(self, "icon_t", 0.0))))
                except (TypeError, ValueError):
                    progress = 0.0
                # rot carries the tween phase to the renderer: three list lines
                # bounce/stagger, the arrow spins clockwise, and the glyph settles.
                ease = getattr(module, "ease_out_cubic", None)
                return {"rot": playlist_icon_rotation(progress, ease), "sc": 1.0, "oy": 0.0}
            return original_icon_pose(self)
        icon_pose_with_playlist._lumo_playlist_pose = True
        nav_row_class._icon_pose = icon_pose_with_playlist

    # Class-level hook: kept only for the window constant. With the window at 0 no
    # call is ever dropped, so every click can replay the icon animation.
    original_play_icon = getattr(nav_row_class, "play_icon", None) if nav_row_class is not None else None
    if callable(original_play_icon) and not getattr(original_play_icon, "_lumo_once_per_click", False):
        def play_icon_once_per_click(self: Any, *args: Any, **kwargs: Any) -> Any:
            now = time.monotonic()
            if now - float(getattr(self, "_lumo_icon_played_at", 0.0) or 0.0) < _NAV_ICON_REPEAT_WINDOW_S:
                return None
            self._lumo_icon_played_at = now
            return original_play_icon(self, *args, **kwargs)
        play_icon_once_per_click._lumo_once_per_click = True
        nav_row_class.play_icon = play_icon_once_per_click

    # Keep the four primary sidebar glyphs genuinely white in every state.
    # The original renderer was passed tinted colours, which made the edges
    # appear soft/coloured. Preserve its geometry, scaling, and rotation so the
    # Playlist icon animation continues to work; only replace the glyph colour.
    current_icon_rgba = getattr(module, "icon_rgba", None)
    if callable(current_icon_rgba) and not getattr(current_icon_rgba, "_lumo_white_nav_icons", False):
        _white_nav_kinds = {"download", "playlist", "history", "settings"}

        def icon_rgba_with_white_nav(kind: str, colour: Any, bg: Any, size: int,
                                     ss: int, rot: float, sc: float, oy: float) -> Any:
            if str(kind).casefold() in _white_nav_kinds:
                colour = "#FFFFFF"
            return current_icon_rgba(kind, colour, bg, size, ss, rot, sc, oy)

        icon_rgba_with_white_nav._lumo_white_nav_icons = True
        module.icon_rgba = icon_rgba_with_white_nav

    # Capture the real renderer parameters during normal NavRow drawing. We use
    # those exact settings for warm-up so cached frames match the actual UI sizes,
    # colours and supersampling configuration.
    original_icon_photo = getattr(module, "icon_photo", None)
    if callable(original_icon_photo) and not getattr(original_icon_photo, "_lumo_nav_photo_probe", False):
        module._lumo_original_icon_photo = original_icon_photo
        module._lumo_nav_icon_photo_params = {}

        def icon_photo_with_nav_probe(kind: str, colour: Any, bg: Any, size: int,
                                      ss: int, rot: float = 0.0, sc: float = 1.0,
                                      oy: float = 0.0) -> Any:
            key = str(kind).casefold()
            if key in {"download", "playlist", "history", "settings"}:
                try:
                    module._lumo_nav_icon_photo_params.setdefault(
                        key, (colour, bg, size, ss,)
                    )
                except Exception:
                    pass
            return original_icon_photo(kind, colour, bg, size, ss, rot, sc, oy)

        icon_photo_with_nav_probe._lumo_nav_photo_probe = True
        module.icon_photo = icon_photo_with_nav_probe

    def set_title_icon(self: Any) -> None:
        try:
            self.title("Lumo")
        except Exception:
            pass
        try:
            roots = []
            if getattr(sys, "_MEIPASS", None):
                roots.append(Path(sys._MEIPASS))
            roots.append(Path(__file__).resolve().parent)
            roots.append(Path.cwd())
            icon = next((root / "Lumo_icon.ico" for root in roots if (root / "Lumo_icon.ico").is_file()), None)
            if icon is not None:
                self.iconbitmap(default=str(icon))
        except Exception:
            pass

    def ensure_embedded_playlist(self: Any, force: bool = False) -> None:
        pages = getattr(self, "pages", None)
        content = getattr(self, "content", None)
        if not isinstance(pages, dict) or content is None:
            return
        old_controller = getattr(self, "_lumo_playlist_controller", None)
        if not force and "playlist" in pages and old_controller is not None:
            try:
                if old_controller.container.winfo_exists():
                    return
            except Exception:
                pass
        if old_controller is not None:
            # A UI rebuild recreates the lazy Playlist controller against the new
            # page frame. Stop the old event pump before replacing its widgets.
            try:
                old_controller.shutdown_inspection()
            except Exception:
                pass
            try:
                pending = getattr(old_controller, "_poll_after_id", None)
                if pending is not None:
                    self.after_cancel(pending)
            except Exception:
                pass
            try:
                old_container = getattr(old_controller, "container", None)
                if old_container is not None:
                    old_container.destroy()
            except Exception:
                pass
        previous_frame = pages.get("playlist")
        if previous_frame is not None:
            try:
                previous_frame.destroy()
            except Exception:
                pass
        frame = tk.Frame(content, bg=getattr(module, "BG", "#101827"), bd=0, highlightthickness=0)
        pages["playlist"] = frame
        self._lumo_customization_options = dict(_CUSTOMIZATION_DEFAULTS)
        # Leave the frame empty until Playlist is first selected. Constructing
        # its scroll canvas, styles and controls during startup competes with the
        # Download page's first paint and is a real source of initial UI stutter.
        self._lumo_playlist_controller = None
        self._lumo_playlist_controller_pending = False

    def init_with_embedded_playlist(self: Any, *args: Any, **kwargs: Any) -> Any:
        result = app_class_original_init(self, *args, **kwargs)
        set_title_icon(self)
        _install_resize_animation_guard(self, module)
        try:
            ensure_embedded_playlist(self)
        except Exception as exc:
            logger = getattr(module, "log_line", None)
            if callable(logger):
                try:
                    logger(f"Playlist page initialisation failed: {exc}")
                except Exception:
                    pass
        # Stagger lightweight first-paint preparation: map History/Settings
        # behind the visible Download page first, then rasterise nav icon poses
        # in single-frame callbacks. Without this, the very first click paid the
        # full Treeview/chip layout cost and a cold icon render at once.
        self._lumo_nav_icon_warmup_complete = False
        self._lumo_tab_warmup_complete = False
        try:
            self.after_idle(lambda: _schedule_primary_tab_warmup(self))
            self.after_idle(lambda: _schedule_nav_icon_cache_warmup(self, module))
            self.after_idle(lambda: _bind_nav_press_animation(self))
        except Exception:
            try:
                self.after(70, lambda app=self: _schedule_primary_tab_warmup(app))
                self.after(80, lambda app=self: _schedule_nav_icon_cache_warmup(app, module))
            except Exception:
                self._lumo_nav_icon_warmup_complete = True
                self._lumo_tab_warmup_complete = True
        return result

    def rebuild_with_playlist(self: Any, *args: Any, **kwargs: Any) -> Any:
        old_page = str(getattr(self, "current_display_page", "download"))
        controller = getattr(self, "_lumo_playlist_controller", None)
        worker = getattr(controller, "worker", None) if controller is not None else None
        if worker is not None and worker.is_alive():
            # Avoid destroying the queue's event pump/widgets while it downloads.
            try:
                controller.status_var.set("Finish the Playlist queue before applying a layout rebuild. Your settings have been saved.")
            except Exception:
                pass
            return None
        result = app_class_original_rebuild(self, *args, **kwargs)
        set_title_icon(self)
        try:
            # Rebuilt sidebar rows are new widgets; bind the press animation again.
            self.after_idle(lambda app=self: _bind_nav_press_animation(app))
        except Exception:
            pass
        try:
            ensure_embedded_playlist(self, force=True)
            if old_page == "playlist":
                self.show_page("playlist")
        except Exception as exc:
            logger = getattr(module, "log_line", None)
            if callable(logger):
                try:
                    logger(f"Playlist page could not be restored after a UI rebuild: {exc}")
                except Exception:
                    pass
        return result

    def show_page_with_embedded_playlist(self: Any, page: Any, *args: Any, **kwargs: Any) -> Any:
        # Warm-up jobs yield after interaction instead of competing with first-click
        # page layout, icon animation, or maximize/restore painting.
        try:
            self._lumo_last_ui_interaction = time.monotonic()
        except Exception:
            pass
        requested_page = str(page).casefold()
        if requested_page != "playlist":
            previous_page = str(getattr(self, "current_display_page", "download") or "download").casefold()
            nav_row = getattr(self, "nav_rows", {}).get(requested_page) if isinstance(getattr(self, "nav_rows", {}), dict) else None
            original_row_play = getattr(nav_row, "play_icon", None) if nav_row is not None else None
            row_had_own_play = False
            try:
                row_had_own_play = "play_icon" in getattr(nav_row, "__dict__", {})
            except Exception:
                pass

            # Let the incremental icon cache finish while yielding between frames.
            # Cancelling it on the first click made that click synchronously render
            # uncached icons, which was the main source of the startup hitch.

            # The recovered page handler starts the icon tween before the newly
            # selected page has painted. Defer that one trigger, then start it at
            # the same post-layout point for every primary-tab switch/click.
            if callable(original_row_play):
                try:
                    nav_row.play_icon = lambda: None
                except Exception:
                    original_row_play = None
            current_before = str(getattr(self, "current_display_page", "download") or "download").casefold()
            first_navigation_switch = (
                requested_page in {"download", "history", "settings"}
                and current_before != requested_page
                and not bool(getattr(self, "_lumo_first_primary_switch_done", False))
            )
            try:
                cold_page = (
                    requested_page in {"download", "history", "settings"}
                    and current_before != requested_page
                    and (first_navigation_switch
                         or not bool(getattr(self, "_lumo_tab_warmup_complete", True)))
                )
                if cold_page:
                    # Do not call the recovered show_page() and then cancel its tween:
                    # doing so still pays the cold setup cost and queues animation work
                    # during the click. Perform the same page state switch directly.
                    page_copy = {
                        "download": ("Download", "One link. The options you need."),
                        "history": ("History", "Your downloads, with unfinished items easy to find."),
                        "settings": ("Settings", "A calmer look, tuned to the way you work."),
                    }
                    title_text, hint_text = page_copy[requested_page]
                    _restore_primary_page_without_animation(
                        self, requested_page, module, title_text=title_text, hint_text=hint_text
                    )
                    try:
                        live_settings = getattr(self, "settings", {})
                        set_badge = getattr(self, "set_cookie_badge", None)
                        if callable(set_badge):
                            set_badge(bool(live_settings.get("use_cookies", False))
                                      if isinstance(live_settings, dict) else False)
                    except Exception:
                        pass
                    if requested_page == "history":
                        refresh = getattr(self, "refresh_history", None)
                        if callable(refresh):
                            try:
                                self.after(120, refresh)
                            except Exception:
                                pass
                    elif requested_page == "download":
                        render_stage = getattr(self, "render_download_stage", None)
                        if callable(render_stage):
                            try:
                                self.after_idle(render_stage)
                            except Exception:
                                pass
                    result = None
                else:
                    result = app_class_original_show_page(self, page, *args, **kwargs)
                if requested_page in {"download", "history", "settings"} and current_before != requested_page:
                    self._lumo_first_primary_switch_done = True
            finally:
                if callable(original_row_play) and nav_row is not None:
                    try:
                        if row_had_own_play:
                            nav_row.play_icon = original_row_play
                        else:
                            delattr(nav_row, "play_icon")
                    except Exception:
                        pass

            if requested_page in {"download", "history", "settings"}:
                def animate_after_paint(a: Any = self, k: str = requested_page) -> None:
                    # One animation per click; waits for the icon cache on the first click.
                    _schedule_nav_icon_play(a, k)
                try:
                    self.after_idle(animate_after_paint)
                except Exception:
                    try:
                        self.after(18, lambda a=self, k=requested_page: _play_navigation_icon(a, k))
                    except Exception:
                        # Test doubles and rare Tk wrappers may not expose an
                        # event queue. The icon is cosmetic, so a direct fallback
                        # is safer than silently dropping the animation entirely.
                        _play_navigation_icon(self, requested_page)
                # Only the layout warm-up job marks pages prewarmed. Marking a page
                # here merely because it was clicked hid the cold-layout problem.
            return result
        # Do not cancel the incremental icon cache on a Playlist click; allowing
        # it to finish avoids a cold-render spike on the first animation.
        pages = getattr(self, "pages", {})
        content = getattr(self, "content", None)
        frame = pages.get("playlist") if isinstance(pages, dict) else None
        if content is None or frame is None:
            return app_class_original_show_page(self, "download", *args, **kwargs)
        try:
            # Hide only the page we are leaving; the old implementation iterated
            # every direct child of the content area on each Playlist tap.
            previous_key = str(getattr(self, "current_display_page", "download")).casefold()
            previous_frame = pages.get(previous_key) if isinstance(pages, dict) else None
            if previous_frame is not None and previous_frame is not frame:
                previous_frame.place_forget()
            frame.place(x=0, y=0, relwidth=1, relheight=1)
            self.current_display_page = "playlist"
            getattr(self, "_lumo_warmed_pages", set()).add("playlist")
            self.page_title.configure(text="Playlist")
            self.top_hint.configure(text="")
            cancel_tween = getattr(module, "cancel_tween", None)
            if callable(cancel_tween):
                cancel_tween(self, "_page_tween")
            for key, row in getattr(self, "nav_rows", {}).items():
                row.set_active(key == "playlist")
            # Use the same post-layout timing as the other primary tabs so the
            # first Playlist animation cannot be consumed by the initial paint.
            def animate_playlist_after_paint(a: Any = self) -> None:
                _schedule_nav_icon_play(a, "playlist")
            try:
                self.after_idle(animate_playlist_after_paint)
            except Exception:
                try:
                    self.after(18, lambda a=self: _play_navigation_icon(a, "playlist"))
                except Exception:
                    _play_navigation_icon(self, "playlist")
            dot = getattr(self, "page_status_dot", None)
            if dot is not None:
                downloading = getattr(self, "active_job_id", None) is not None
                dot.configure(text="●  DOWNLOADING" if downloading else "●  READY",
                              fg=getattr(module, "CYAN" if downloading else "GOOD", "#55D8F2"))
            controller = getattr(self, "_lumo_playlist_controller", None)
            if controller is None:
                # Construct the Playlist controls after Tk has painted the newly
                # selected page. Building its scroll canvas and row controls inside
                # the click callback made Playlist the one tab that could still
                # visibly hitch even after the other pages were warmed.
                if not bool(getattr(self, "_lumo_playlist_controller_pending", False)):
                    self._lumo_playlist_controller_pending = True
                    placeholder = None
                    try:
                        placeholder = tk.Label(
                            frame, text="Preparing Playlist…",
                            bg=getattr(module, "BG", "#101827"),
                            fg=getattr(module, "MUTED", "#A9B8CC"),
                            font=("Segoe UI", 10),
                        )
                        placeholder.place(relx=0.5, rely=0.5, anchor="center")
                    except Exception:
                        placeholder = None

                    def create_playlist_controller(a: Any = self, f: Any = frame,
                                                   loading: Any = placeholder) -> None:
                        a._lumo_playlist_controller_pending = False
                        try:
                            current_pages = getattr(a, "pages", {})
                            exists = bool(f.winfo_exists())
                            if not exists or not isinstance(current_pages, dict) or current_pages.get("playlist") is not f:
                                return
                            if getattr(a, "_lumo_playlist_controller", None) is not None:
                                return
                            from lumo_windows.playlist_ui import PlaylistWindow
                            built = PlaylistWindow(a, parent=f, embedded=True)
                            a._lumo_playlist_controller = built
                            if str(getattr(a, "current_display_page", "")).casefold() == "playlist":
                                try:
                                    built.url_entry.focus_set()
                                except Exception:
                                    pass
                        except Exception as exc:
                            logger = getattr(module, "log_line", None)
                            if callable(logger):
                                try:
                                    logger(f"Could not create Playlist controller: {exc}")
                                except Exception:
                                    pass
                            try:
                                if str(getattr(a, "current_display_page", "")).casefold() == "playlist":
                                    a.top_hint.configure(text="Playlist could not be loaded. Check the application files and logs.")
                            except Exception:
                                pass
                        finally:
                            try:
                                if loading is not None and loading.winfo_exists():
                                    loading.destroy()
                            except Exception:
                                pass
                    try:
                        self.after(60, create_playlist_controller)
                    except Exception:
                        create_playlist_controller()
                return None
            try:
                controller.url_entry.focus_set()
            except Exception:
                pass
            return None
        except Exception as exc:
            logger = getattr(module, "log_line", None)
            if callable(logger):
                try:
                    logger(f"Could not open Playlist page: {exc}")
                except Exception:
                    pass
            return app_class_original_show_page(self, "download", *args, **kwargs)

    app_class.__init__ = init_with_embedded_playlist
    app_class.show_page = show_page_with_embedded_playlist
    app_class_original_rebuild = app_class.rebuild_ui
    app_class.rebuild_ui = rebuild_with_playlist

    original_app_close = getattr(app_class, "on_close", None)
    if callable(original_app_close) and not getattr(original_app_close, "_lumo_inspection_shutdown", False):
        def close_with_playlist_inspection_shutdown(self: Any, *args: Any, **kwargs: Any) -> Any:
            # Let the recovered close handler ask for confirmation first. If the
            # user cancels the close, the app and its Playlist inspection workers
            # must remain usable; shut workers down only after the root is gone.
            result = original_app_close(self, *args, **kwargs)
            try:
                still_open = bool(self.winfo_exists())
            except Exception:
                still_open = False
            if not still_open:
                controller = getattr(self, "_lumo_playlist_controller", None)
                if controller is not None:
                    try:
                        controller.shutdown_inspection()
                    except Exception:
                        pass
            return result
        close_with_playlist_inspection_shutdown._lumo_inspection_shutdown = True
        app_class.on_close = close_with_playlist_inspection_shutdown


def _install_cookie_prompt(module: ModuleType) -> None:
    """Offer a one-time, non-blocking import prompt if the configured cookie file is missing."""
    app_class = module.App
    original_init = app_class.__init__

    def init_with_cookie_prompt(self: Any, *args: Any, **kwargs: Any) -> Any:
        result = original_init(self, *args, **kwargs)
        try:
            self.after(900, lambda app=self: _maybe_show_cookie_prompt(app, module))
        except Exception:
            pass
        return result

    app_class.__init__ = init_with_cookie_prompt


def _maybe_show_cookie_prompt(app: Any, module: ModuleType) -> None:
    try:
        prefs = module.load_settings()
        path = Path(str(prefs.get("cookie_file", "") or "")).expanduser()
        if path.is_file() or bool(prefs.get("cookie_prompt_seen", False)):
            return
    except Exception as exc:
        logger = getattr(module, "log_line", None)
        if callable(logger):
            try:
                logger(f"Could not check cookie setup: {exc}")
            except Exception:
                pass
        return

    try:
        dialog = tk.Toplevel(app)
        dialog.title("YouTube cookies — optional")
        dialog.transient(app)
        dialog.resizable(False, False)
        dialog.configure(bg="#101827")
        dialog.geometry("470x225")
        try:
            icon_roots = []
            if getattr(sys, "_MEIPASS", None):
                icon_roots.append(Path(sys._MEIPASS))
            icon_roots.append(Path(__file__).resolve().parent)
            icon_file = next((root / "Lumo_icon.ico" for root in icon_roots
                              if (root / "Lumo_icon.ico").is_file()), None)
            if icon_file is not None:
                dialog.iconbitmap(default=str(icon_file))
        except Exception:
            pass
        tk.Label(dialog, text="Some videos may need sign-in", bg="#101827", fg="#F2F6FF",
                 font=("Segoe UI Semibold", 13)).pack(anchor="w", padx=20, pady=(18, 7))
        tk.Label(dialog,
                 text=("You can import your own exported cookies.txt if YouTube asks you to sign in. "
                       "Only import your own file: cookies can give access to your account. "
                       "Lumo uses a private temporary copy during download."),
                 bg="#101827", fg="#A9B8CC", font=("Segoe UI", 9),
                 justify="left", wraplength=425).pack(fill="x", padx=20, pady=(0, 14))
        buttons = tk.Frame(dialog, bg="#101827")
        buttons.pack(fill="x", padx=20, pady=(0, 16))

        def close_prompt() -> None:
            # Persist the one-time choice only after the prompt was actually
            # created and the user dismissed it. If Tk fails to create the
            # dialog, the next launch can offer it again instead of silently
            # treating an unseen prompt as seen.
            try:
                current = module.load_settings()
                current["cookie_prompt_seen"] = True
                module.save_settings(current)
            except Exception as exc:
                logger = getattr(module, "log_line", None)
                if callable(logger):
                    try:
                        logger(f"Could not save cookie-prompt choice: {exc}")
                    except Exception:
                        pass
            try:
                dialog.grab_release()
            except Exception:
                pass
            try:
                dialog.destroy()
            except Exception:
                pass
            _schedule_url_focus(app, 120)

        def import_cookie_file() -> None:
            filename = filedialog.askopenfilename(
                parent=dialog, title="Select your exported cookies.txt",
                filetypes=(("Cookie text files", "*.txt"), ("All files", "*.*")),
            )
            if not filename:
                return
            try:
                from lumo_windows.downloader import prepare_cookies, cleanup_cookies
                temp_copy, _message = prepare_cookies(True, filename)
                cleanup_cookies(temp_copy)
                updated = module.load_settings()
                updated.update(cookie_file=filename, use_cookies=True, cookie_prompt_seen=True)
                module.save_settings(updated)
                for attr, value in (("cookie_file_var", filename), ("cookie_var", True)):
                    variable = getattr(app, attr, None)
                    if variable is not None and callable(getattr(variable, "set", None)):
                        variable.set(value)
                if isinstance(getattr(app, "settings", None), dict):
                    app.settings.update({"cookie_file": filename, "use_cookies": True,
                                          "cookie_prompt_seen": True})
                try:
                    app.save_app_settings()
                except Exception:
                    pass
                close_prompt()
                try:
                    app.set_status("Cookie file selected. Lumo will use a private copy when needed.",
                                   getattr(module, "GOOD", "#55D8F2"))
                except Exception:
                    pass
            except Exception as exc:
                messagebox.showerror(
                    "Could not use this cookie file",
                    f"Choose an exported Netscape-format cookies.txt file.\n\n{exc}",
                    parent=dialog,
                )

        tk.Button(buttons, text="Import cookies", command=import_cookie_file,
                  bg="#55D8F2", fg="#0B1423", activebackground="#72E2F4",
                  relief="flat", bd=0, padx=14, pady=8,
                  font=("Segoe UI Semibold", 9), cursor="hand2").pack(side="left")
        tk.Button(buttons, text="Skip", command=close_prompt,
                  bg="#1C2B43", fg="#F2F6FF", activebackground="#27435C",
                  relief="flat", bd=0, padx=18, pady=8,
                  font=("Segoe UI Semibold", 9), cursor="hand2").pack(side="right")
        dialog.protocol("WM_DELETE_WINDOW", close_prompt)
        try:
            dialog.after(100, dialog.grab_set)
            dialog.after(150, lambda: dialog.focus_force() if dialog.winfo_exists() else None)
        except Exception:
            pass
    except Exception as exc:
        logger = getattr(module, "log_line", None)
        if callable(logger):
            try:
                logger(f"Could not show the optional cookie prompt: {exc}")
            except Exception:
                pass



_QUALITY_FALLBACKS = {
    "ACCENT": "#8871FF",
    "CARD_ALT": "#15171E",
    "CARD": "#0E0F14",
    "TEXT": "#F4F6FB",
    "MUTED": "#9AA4B5",
}
_QUALITY_ARROW_ANGLES = (0, 28, 58, 90, 122, 152, 180)  # 0 = down, last = up


def _quality_colour(module: ModuleType, name: str) -> str:
    """Return the live palette colour for ``name``, or its Dark-palette fallback."""
    value = getattr(module, name, None)
    return value if _is_hex_colour(value) else _QUALITY_FALLBACKS[name]


def _with_quality_arrow(layout: Any, arrow_element: str) -> Any:
    """Return a copy of a ttk layout with every downarrow replaced by ``arrow_element``."""
    rewritten = []
    for element, options in layout:
        opts = dict(options)
        children = opts.get("children")
        if children:
            opts["children"] = _with_quality_arrow(children, arrow_element)
        if str(element).lower().endswith(".downarrow") or str(element).lower() == "downarrow":
            element = arrow_element
        rewritten.append((element, opts))
    return rewritten


def _after_or_none(widget: Any, delay_ms: int, callback: Any) -> Any:
    try:
        return widget.after(delay_ms, callback)
    except Exception:
        return None


def _install_quality_dropdown_visuals(module: ModuleType) -> None:
    """Polish only the recovered Download page quality combobox.

    The combobox, its value list, its bound variable, the <<ComboboxSelected>>
    handler and all download/quality logic are left exactly as the recovered UI
    creates them. This hook only:

    * styles the combobox and its popup listbox from the live palette
      (CARD_ALT, CARD, TEXT, MUTED and ACCENT),
    * replaces the chevron with an animated image when the active ttk theme
      allows it, and
    * adds additive bindings that move the chevron to match whether the popup
      is actually open.

    It is attached to build_download_page(), so a Download page rebuilt by
    rebuild_ui() receives the same look as the first build.
    """
    app_class = getattr(module, "App", None)
    if app_class is None or not callable(getattr(app_class, "build_download_page", None)):
        return
    original_build = app_class.build_download_page
    if getattr(original_build, "_lumo_quality_visuals_installed", False):
        return

    def build_download_with_quality_visuals(self: Any, *args: Any, **kwargs: Any) -> Any:
        result = original_build(self, *args, **kwargs)
        _schedule_quality_visuals(self, module)
        return result

    build_download_with_quality_visuals._lumo_quality_visuals_installed = True  # type: ignore[attr-defined]
    app_class.build_download_page = build_download_with_quality_visuals


def _schedule_quality_visuals(app: Any, module: ModuleType, attempt: int = 0) -> None:
    def apply_when_ready() -> None:
        combo = getattr(app, "quality_combo", None)
        if combo is None or not callable(getattr(combo, "configure", None)):
            # Retry briefly in case the page creates its controls later. Never block startup.
            if attempt < 20:
                _schedule_quality_visuals(app, module, attempt + 1)
            return
        _apply_quality_visuals(combo, module)

    try:
        app.after(100, apply_when_ready)
    except Exception:
        pass


def _install_modern_quality_picker(combo: Any, module: ModuleType) -> None:
    """Replace the quality combobox's look with a modern dark picker.

    The ttk combobox stays underneath and keeps its variable, values and state, so the
    recovered quality logic is unchanged. The picker draws a rounded field that mirrors
    the chosen value, with an animated chevron, and opens a fading dark list. Choosing an
    item sets the same variable and calls the same _quality_changed handler as before.
    """
    if getattr(combo, "_lumo_modern_picker", False):
        return
    app = getattr(module, "_LUMO_APP_INSTANCE", None)
    if app is None:
        return
    try:
        parent = combo.master
        root = combo.winfo_toplevel()
    except Exception:
        return

    field_bg = _quality_colour(module, "CARD_ALT")
    panel_bg = _quality_colour(module, "CARD")
    text_fg = _quality_colour(module, "TEXT")
    muted = _quality_colour(module, "MUTED")
    accent = _quality_colour(module, "ACCENT")
    page_bg = getattr(module, "BG", "#0B0C10")
    if not _is_hex_colour(page_bg):
        page_bg = "#0B0C10"
    border = _mix_hex(field_bg, muted, 0.22)
    border_hot = _mix_hex(field_bg, accent, 0.70)
    row_hover = _mix_hex(panel_bg, accent, 0.16)
    font = ("Segoe UI", 11)

    field = tk.Canvas(parent, bg=page_bg, highlightthickness=0, bd=0, cursor="hand2")
    state: dict[str, Any] = {
        "win": None, "hover": False, "t": 0.0, "anim": None,
        "index": 0, "rows": [], "values": [], "selected": "",
    }

    def current_value() -> str:
        variable = getattr(app, "quality_var", None)
        try:
            return str(variable.get()) if variable is not None else str(combo.get())
        except Exception:
            return ""

    def rounded(x1: float, y1: float, x2: float, y2: float, r: float, **options: Any) -> None:
        points = [x1 + r, y1, x2 - r, y1, x2, y1, x2, y1 + r, x2, y2 - r,
                  x2, y2, x2 - r, y2, x1 + r, y2, x1, y2, x1, y2 - r, x1, y1 + r, x1, y1]
        field.create_polygon(points, smooth=True, **options)

    def draw_chevron(cx: float, cy: float, t: float, colour: str) -> None:
        # t = 0 points down (closed), t = 1 points up (open); the chevron glides between them.
        down = [(cx - 6, cy - 3), (cx, cy + 3), (cx + 6, cy - 3)]
        up = [(cx - 6, cy + 3), (cx, cy - 3), (cx + 6, cy + 3)]
        flat = []
        for (x0, y0), (_x1, y1) in zip(down, up):
            flat += [x0, y0 + (y1 - y0) * t]
        field.create_line(*flat, fill=colour, width=2, capstyle="round", joinstyle="round")

    def draw_field(*_args: Any) -> None:
        try:
            w = max(field.winfo_width(), 4)
            h = max(field.winfo_height(), 4)
            field.delete("all")
            active = state["hover"] or state["win"] is not None
            rounded(1, 1, w - 1, h - 1, 12, fill=field_bg,
                    outline=border_hot if active else border, width=1)
            field.create_text(16, h / 2, text=current_value() or "Choose quality",
                              anchor="w", fill=text_fg, font=font)
            draw_chevron(w - 22, h / 2, state["t"], accent if active else muted)
        except Exception:
            pass

    def animate_chevron() -> None:
        target = 1.0 if state["win"] is not None else 0.0
        if abs(target - state["t"]) <= 0.25:
            state["t"] = target
        else:
            state["t"] += 0.25 if target > state["t"] else -0.25
        draw_field()
        if state["t"] != target:
            try:
                state["anim"] = field.after(16, animate_chevron)
            except Exception:
                state["anim"] = None
        else:
            state["anim"] = None

    def start_animation() -> None:
        if state["anim"] is None:
            animate_chevron()

    def close_popup(*_args: Any) -> None:
        window = state.get("win")
        state["win"] = None
        if window is not None:
            try:
                window.destroy()
            except Exception:
                pass
        start_animation()

    def choose(value: str) -> None:
        close_popup()
        variable = getattr(app, "quality_var", None)
        if variable is not None:
            try:
                variable.set(value)
            except Exception:
                pass
        handler = getattr(app, "_quality_changed", None)
        if callable(handler):
            try:
                handler(None)
            except TypeError:
                try:
                    handler()
                except Exception:
                    pass
            except Exception:
                pass
        draw_field()

    # Quality list, drawn in the app's own style: a soft rounded panel, flat rows
    # with rounded hover/selected pills, a small accent dot on the chosen quality,
    # and a slim rounded scrollbar. Every movement is eased.
    VISIBLE_ROWS = 6
    ROW_H = 34
    PAD = 8
    list_font = ("Segoe UI", 10)

    def pill_points(x1: float, y1: float, x2: float, y2: float, r: float) -> list[float]:
        return [x1 + r, y1, x2 - r, y1, x2, y1, x2, y1 + r, x2, y2 - r,
                x2, y2, x2 - r, y2, x1 + r, y2, x1, y2, x1, y2 - r, x1, y1 + r, x1, y1]

    def clamp_offset(value: float) -> float:
        total = len(state["values"]) * ROW_H
        return max(0.0, min(float(value), max(0.0, total - state["view_h"])))

    def draw_list() -> None:
        canvas = state.get("inner")
        if canvas is None:
            return
        try:
            canvas.delete("all")
            w = state["inner_w"]
            offset = state["offset"]
            for i, value in enumerate(state["values"]):
                y = i * ROW_H - offset
                if y + ROW_H < 0 or y > state["view_h"]:
                    continue
                chosen = value == state["selected"]
                hovered = i == state["index"]
                fill = None
                if chosen:
                    fill = _mix_hex(panel_bg, accent, 0.16)
                elif hovered:
                    fill = _mix_hex(panel_bg, text_fg, 0.07)
                if fill:
                    canvas.create_polygon(pill_points(2, y + 3, w - 2, y + ROW_H - 3, 9),
                                          smooth=True, fill=fill, outline="")
                canvas.create_text(14, y + ROW_H / 2, text=value, anchor="w",
                                   fill=accent if chosen else text_fg, font=list_font)
                if chosen:
                    cx, cy = w - 14, y + ROW_H / 2
                    canvas.create_oval(cx - 3, cy - 3, cx + 3, cy + 3, fill=accent, outline="")
        except Exception:
            pass

    def draw_scrollbar() -> None:
        shell = state.get("shell")
        total = len(state["values"]) * ROW_H
        view = state["view_h"]
        if shell is None or total <= view:
            return
        try:
            shell.delete("scroll")
            track_x = state["width"] - 12
            thumb_h = max(26.0, view * view / total)
            max_off = total - view
            top = PAD + (state["offset"] / max_off) * (view - thumb_h)
            shell.create_polygon(pill_points(track_x, top, track_x + 4, top + thumb_h, 2),
                                 smooth=True, fill=_mix_hex(panel_bg, muted, 0.6),
                                 outline="", tags="scroll")
        except Exception:
            pass

    def scroll_step() -> None:
        state["scroll_after"] = None
        delta = state["target"] - state["offset"]
        if abs(delta) < 0.5:
            state["offset"] = state["target"]
        else:
            state["offset"] += delta * 0.28
        draw_list()
        draw_scrollbar()
        if state["offset"] != state["target"]:
            try:
                state["scroll_after"] = state["shell"].after(16, scroll_step)
            except Exception:
                pass

    def scroll_to(value: float) -> None:
        state["target"] = clamp_offset(value)
        if state.get("scroll_after") is None:
            scroll_step()

    def ensure_visible(index: int) -> None:
        top = index * ROW_H
        bottom = top + ROW_H
        if top < state["target"]:
            scroll_to(top)
        elif bottom > state["target"] + state["view_h"]:
            scroll_to(bottom - state["view_h"])

    def highlight(index: int) -> None:
        if not state["values"]:
            return
        state["index"] = index % len(state["values"])
        draw_list()
        ensure_visible(state["index"])

    def move(step: int) -> None:
        highlight(state["index"] + step)

    def wheel(event: Any) -> str:
        scroll_to(state["target"] - (event.delta / 120.0) * ROW_H)
        return "break"

    def on_motion(event: Any) -> None:
        i = int((event.y + state["offset"]) // ROW_H)
        if 0 <= i < len(state["values"]) and i != state["index"]:
            state["index"] = i
            draw_list()

    def on_release(event: Any) -> None:
        i = int((event.y + state["offset"]) // ROW_H)
        if 0 <= i < len(state["values"]):
            choose(state["values"][i])

    def enter_step(window: Any, step: int, x: int, base_y: int, width: int, height: int) -> None:
        if state.get("win") is not window:
            return
        t = min(1.0, (step + 1) / 7.0)
        eased = 1.0 - (1.0 - t) ** 3          # ease-out: fast start, soft landing
        try:
            window.attributes("-alpha", eased)
            window.geometry(f"{width}x{height}+{x}+{int(base_y + 8 * (1.0 - eased))}")
        except Exception:
            return
        if step + 1 < 7:
            try:
                window.after(16, lambda: enter_step(window, step + 1, x, base_y, width, height))
            except Exception:
                pass

    def open_popup(*_args: Any) -> None:
        if str(combo.cget("state")) == "disabled":
            return
        if state.get("win") is not None:
            close_popup()
            return
        try:
            values = [str(v) for v in root.tk.splitlist(combo.cget("values"))]
        except Exception:
            values = []
        if not values:
            return
        selected = current_value()
        needs_scroll = len(values) > VISIBLE_ROWS
        width = max(field.winfo_width(), 220)
        view_h = min(VISIBLE_ROWS, len(values)) * ROW_H
        height = view_h + PAD * 2
        inner_w = width - PAD * 2 - (14 if needs_scroll else 0)

        window = tk.Toplevel(root)
        window.withdraw()
        window.overrideredirect(True)
        window.configure(bg=page_bg)
        try:
            window.attributes("-alpha", 0.0)
            window.attributes("-transparentcolor", page_bg)
        except Exception:
            pass

        shell = tk.Canvas(window, bg=page_bg, highlightthickness=0, bd=0,
                          width=width, height=height)
        shell.pack(fill="both", expand=True)
        shell.create_polygon(pill_points(1, 1, width - 1, height - 1, 16), smooth=True,
                             fill=panel_bg, outline=border, width=1)
        inner = tk.Canvas(shell, bg=panel_bg, highlightthickness=0, bd=0,
                          width=inner_w, height=view_h)
        shell.create_window(PAD, PAD, window=inner, anchor="nw")

        state.update({
            "win": window, "shell": shell, "inner": inner,
            "values": values, "selected": selected,
            "width": width, "inner_w": inner_w, "view_h": view_h,
            "offset": 0.0, "target": 0.0, "scroll_after": None,
            "index": values.index(selected) if selected in values else 0,
        })

        for widget in (inner, shell):
            widget.bind("<MouseWheel>", wheel)
        inner.bind("<Motion>", on_motion)
        inner.bind("<ButtonRelease-1>", on_release)
        window.bind("<Escape>", close_popup)
        window.bind("<Up>", lambda _e: move(-1))
        window.bind("<Down>", lambda _e: move(1))
        window.bind("<Return>", lambda _e: choose(state["values"][state["index"]]))
        window.bind("<FocusOut>", close_popup)

        highlight(state["index"])
        draw_scrollbar()
        try:
            window.update_idletasks()
            x = field.winfo_rootx()
            base_y = field.winfo_rooty() + field.winfo_height() + 6
            window.geometry(f"{width}x{height}+{x}+{base_y + 8}")
        except Exception:
            x, base_y = 0, 0
        window.deiconify()
        enter_step(window, 0, x, base_y, width, height)
        start_animation()
        try:
            window.focus_force()
        except Exception:
            pass

    def on_enter(_e: Any = None) -> None:
        state["hover"] = True
        draw_field()

    def on_leave(_e: Any = None) -> None:
        state["hover"] = False
        draw_field()

    def reposition(*_args: Any) -> None:
        try:
            if not combo.winfo_ismapped():
                field.place_forget()
                return
            field.place(x=combo.winfo_x(), y=combo.winfo_y(),
                        width=combo.winfo_width(), height=combo.winfo_height())
            field.lift()
            draw_field()
        except Exception:
            pass

    field.bind("<Configure>", draw_field)
    field.bind("<ButtonRelease-1>", open_popup)
    field.bind("<Enter>", on_enter)
    field.bind("<Leave>", on_leave)

    variable = getattr(app, "quality_var", None)
    if variable is not None:
        try:
            variable.trace_add("write", draw_field)
        except Exception:
            pass
    # Reposition whenever the combobox is shown or resized, not only at build time.
    for event in ("<Map>", "<Configure>", "<Visibility>"):
        combo.bind(event, reposition, add="+")
    def reposition_on_resize(_e: Any = None) -> None:
        try:
            combo.after_idle(reposition)
        except Exception:
            pass  # the combobox belongs to a page that was rebuilt; nothing to do

    try:
        root.bind("<Configure>", reposition_on_resize, add="+")
    except Exception:
        pass
    combo.after_idle(reposition)
    combo._lumo_modern_picker = True  # type: ignore[attr-defined]
    combo._lumo_modern_button = field  # type: ignore[attr-defined]


def _apply_quality_visuals(combo: Any, module: ModuleType) -> None:
    try:
        if not combo.winfo_exists():
            return
        _install_modern_quality_picker(combo, module)
    except Exception:
        pass
    if getattr(combo, "_lumo_quality_applied", False):
        return
    try:
        root = combo.winfo_toplevel()
        style = ttk.Style(root)
        store = _quality_arrow_store(root, style, module)
        _style_quality_combo(combo, style, store, module)
    except Exception:
        # A visual-only enhancement must never stop the recovered app from working.
        return


def _quality_arrow_store(root: Any, style: Any, module: ModuleType) -> dict[str, Any]:
    """Create the shared chevron elements once per Tk root.

    ttk element names are global to a Style, so creating them again for a rebuilt
    Download page would fail. The store keeps the names, the PhotoImage objects
    (which must stay alive) and whether the custom layout is active.
    """
    store = getattr(root, "_lumo_quality_arrow_store", None)
    if store is not None:
        return store
    style_names = [f"LumoQualityArrow{i}.TCombobox" for i in range(len(_QUALITY_ARROW_ANGLES))]
    store = {"style_names": style_names, "custom": False, "images": []}
    root._lumo_quality_arrow_store = store  # type: ignore[attr-defined]
    try:
        from PIL import Image, ImageDraw, ImageTk
    except Exception:
        # Without Pillow the native chevron and the colour styling still work.
        return store
    try:
        text_fg = _quality_colour(module, "TEXT")
        accent = _quality_colour(module, "ACCENT")

        def make_arrow(angle: float, colour: str) -> Any:
            scale = 3
            canvas = Image.new("RGBA", (22 * scale, 22 * scale), (0, 0, 0, 0))
            draw = ImageDraw.Draw(canvas)
            points = [(6 * scale, 8 * scale), (11 * scale, 14 * scale), (16 * scale, 8 * scale)]
            draw.line(points, fill=colour, width=3 * scale, joint="curve")
            canvas = canvas.rotate(angle, resample=Image.Resampling.BICUBIC, expand=False)
            canvas = canvas.resize((22, 22), Image.Resampling.LANCZOS)
            return ImageTk.PhotoImage(canvas, master=root)

        normal = [make_arrow(angle, text_fg) for angle in _QUALITY_ARROW_ANGLES]
        hover = [make_arrow(angle, accent) for angle in _QUALITY_ARROW_ANGLES]
        store["images"] = normal + hover
        base_layout = style.layout("TCombobox")
        for index, (normal_image, hover_image) in enumerate(zip(normal, hover)):
            element_name = f"LumoQuality.downarrow.{index}"
            style.element_create(
                element_name, "image", normal_image,
                ("active", hover_image), ("pressed", hover_image),
                border=0, sticky="",
            )
            style.layout(style_names[index], _with_quality_arrow(base_layout, element_name))
        store["custom"] = any(
            str(element).startswith("LumoQuality.downarrow.")
            for element, _options in _walk_ttk_layout(style.layout(style_names[0]))
        )
    except Exception:
        # Native themes differ across Windows and Tk versions. Colour styling remains.
        store["custom"] = False
    return store


def _style_quality_combo(combo: Any, style: Any, store: dict[str, Any], module: ModuleType) -> None:
    style_names: list[str] = store["style_names"]
    arrow_ready = bool(store["custom"])
    last_frame = len(style_names) - 1
    root = combo.winfo_toplevel()
    accent = _quality_colour(module, "ACCENT")
    field_bg = _quality_colour(module, "CARD_ALT")
    panel_bg = _quality_colour(module, "CARD")
    text_fg = _quality_colour(module, "TEXT")
    muted_fg = _quality_colour(module, "MUTED")

    for name in style_names:
        try:
            style.configure(
                name, fieldbackground=field_bg, background=panel_bg,
                foreground=text_fg, selectbackground=accent,
                selectforeground="#FFFFFF", arrowcolor=muted_fg,
                arrowsize=12, bordercolor=accent, lightcolor=accent,
                darkcolor=field_bg, padding=(14, 9), relief="flat",
                font=("Segoe UI", 10),
            )
            style.map(
                name,
                fieldbackground=[("readonly", field_bg), ("disabled", panel_bg)],
                foreground=[("readonly", text_fg), ("disabled", muted_fg)],
                bordercolor=[("focus", accent), ("active", accent)],
                arrowcolor=[("pressed", "#FFFFFF"), ("active", accent)],
            )
        except Exception:
            pass
    combo.configure(style=style_names[0])
    combo._lumo_quality_applied = True  # type: ignore[attr-defined]

    state: dict[str, Any] = {"frame": 0, "serial": 0, "watch": None, "popdown_styled": False}

    def style_popdown() -> None:
        # ttk draws its popup with a Tk listbox; style that exact widget.
        try:
            popdown = str(root.tk.call("ttk::combobox::PopdownWindow", combo._w))
            listbox = popdown + ".f.l"
            if int(root.tk.call("winfo", "exists", listbox)):
                root.tk.call(
                    listbox, "configure",
                    "-background", field_bg,
                    "-foreground", text_fg,
                    "-selectbackground", accent,
                    "-selectforeground", "#FFFFFF",
                    "-highlightthickness", 0,
                    "-highlightbackground", panel_bg,
                    "-highlightcolor", panel_bg,
                    "-borderwidth", 0,
                    "-relief", "flat",
                    "-font", ("Segoe UI", 10),
                    "-activestyle", "none",
                )
        except Exception:
            pass

    def popdown_open() -> bool:
        try:
            popdown = str(root.tk.call("ttk::combobox::PopdownWindow", combo._w))
            return bool(int(root.tk.call("winfo", "ismapped", popdown)))
        except Exception:
            return False

    def widget_disabled() -> bool:
        try:
            return bool(combo.instate(["disabled"]))
        except Exception:
            return False

    def move_arrow(target: int) -> None:
        # Presentation only: changes the chevron style, never the value or state.
        if not arrow_ready:
            return
        try:
            if not combo.winfo_exists():
                return
        except Exception:
            return
        state["serial"] += 1
        serial = state["serial"]
        goal = max(0, min(last_frame, target))

        def step() -> None:
            if serial != state["serial"]:
                return
            current = int(state["frame"])
            if current == goal:
                return
            current += 1 if goal > current else -1
            state["frame"] = current
            try:
                combo.configure(style=style_names[current])
                combo.after(16, step)
            except Exception:
                return

        try:
            combo.after_idle(step)
        except Exception:
            pass

    def check(retries_left: int) -> None:
        # The chevron follows the popup's real mapped state rather than a toggle,
        # so outside clicks, Escape, disabled clicks and selection all stay in sync.
        state["watch"] = None
        try:
            if not combo.winfo_exists():
                return
        except Exception:
            return
        is_open = popdown_open() and not widget_disabled()
        if is_open:
            if not state["popdown_styled"]:
                style_popdown()
                state["popdown_styled"] = True
            move_arrow(last_frame)
            state["watch"] = _after_or_none(combo, 80, lambda: check(0))
            return
        state["popdown_styled"] = False
        move_arrow(0)
        if retries_left > 0:
            # The popup may map a moment after the click; look a few more times.
            state["watch"] = _after_or_none(combo, 40, lambda: check(retries_left - 1))

    def follow_popdown(retries: int, delay_ms: int) -> None:
        pending = state["watch"]
        if pending is not None:
            try:
                combo.after_cancel(pending)
            except Exception:
                pass
        state["watch"] = _after_or_none(combo, delay_ms, lambda: check(retries))

    def on_press(_event: Any = None) -> None:
        # Runs before ttk posts the popup, so check after it has had time to map.
        follow_popdown(6, 30)

    def on_settle(_event: Any = None) -> None:
        follow_popdown(0, 30)

    def on_focus_out(_event: Any = None) -> None:
        follow_popdown(0, 120)

    # Additive bindings only. None of them returns "break", so the ttk class
    # bindings that open, select and dismiss the popup continue to run.
    try:
        combo.bind("<ButtonPress-1>", on_press, add="+")
        combo.bind("<<ComboboxSelected>>", on_settle, add="+")
        combo.bind("<Escape>", on_settle, add="+")
        combo.bind("<FocusOut>", on_focus_out, add="+")
    except Exception:
        pass


def _walk_ttk_layout(layout: Any) -> Any:
    """Yield nested ttk layout items for compatibility checks."""
    for element, options in layout:
        yield element, options
        children = options.get("children", ()) if isinstance(options, dict) else ()
        yield from _walk_ttk_layout(children)




def _setting_variable(app: Any, names: tuple[str, ...]) -> tuple[str | None, Any]:
    """Return the first live settings variable from a compatibility-name list."""
    for name in names:
        variable = getattr(app, name, None)
        if variable is not None and callable(getattr(variable, "get", None)) and callable(getattr(variable, "set", None)):
            return name, variable
    return None, None


def _set_runtime_button_command(widget: Any, callback: Any) -> bool:
    """Set a button command and repair the recovered Canvas button's mouse release.

    The recovered SoftButton is a Canvas widget with its own <ButtonRelease-1>
    callback, rather than a native Tk Button. Updating ``command`` alone can leave
    the old release binding in place. Replacing that binding on this custom widget
    makes a mouse release invoke the current command exactly once while retaining
    its press animation and enabled-state check.
    """
    changed = False
    try:
        widget.configure(command=callback)
        changed = True
    except Exception:
        pass
    try:
        setattr(widget, "command", callback)
        changed = True
    except Exception:
        pass

    # Only custom buttons expose _animate_press. Native ttk/Tk buttons keep their
    # native command semantics and are not given an extra event handler.
    animate_press = getattr(widget, "_animate_press", None)
    bind = getattr(widget, "bind", None)
    if callable(animate_press) and callable(bind) and not getattr(widget, "_lumo_release_command_bound", False):
        def press_shows_pressed_look(event: Any, button: Any = widget) -> str:
            """Pressed look only; the action runs on release, as a normal button does."""
            if not bool(getattr(button, "enabled", True)):
                return "break"
            try:
                animate = getattr(button, "_animate_press", None)
                if callable(animate):
                    animate(1.0)
            except Exception:
                pass
            return "break"

        def release_runs_action(event: Any, button: Any = widget, action: Any = callback) -> str:
            """Release the pressed look and run the command if the pointer is still on the button."""
            try:
                animate = getattr(button, "_animate_press", None)
                if callable(animate):
                    animate(0.0)
            except Exception:
                pass
            if not bool(getattr(button, "enabled", True)):
                return "break"
            try:
                inside = (0 <= int(event.x) <= int(button.winfo_width())
                          and 0 <= int(event.y) <= int(button.winfo_height()))
            except Exception:
                inside = True
            if inside:
                try:
                    current_action = getattr(button, "command", None)
                    if callable(current_action):
                        current_action()
                    elif callable(action):
                        action()
                except Exception:
                    pass
            return "break"

        try:
            bind("<ButtonPress-1>", press_shows_pressed_look)
            bind("<ButtonRelease-1>", release_runs_action)
            widget._lumo_release_command_bound = True
            changed = True
        except Exception:
            pass
    return changed


_ACTIVE_DOWNLOAD_STAGES = {"active", "downloading", "starting", "cancelling", "busy"}


def _auto_inspect(app: Any, force: bool = False) -> None:
    """Start inspecting a pasted link right away, so quality is ready when the user continues.

    A link pasted while another video's quality/subtitle page is showing starts over
    from the URL stage, keeping the pasted text. Nothing changes while a download runs.
    """
    stage = str(getattr(app, "stage", "idle")).casefold()
    if stage in _ACTIVE_DOWNLOAD_STAGES:
        return
    try:
        text = str(app.url_entry.get()).strip()
    except Exception:
        return
    if not text.startswith(("http://", "https://")):
        return
    if stage not in {"idle", "error"}:
        reset = getattr(app, "reset_to_url", None)
        if not callable(reset):
            return
        try:
            reset()
            if str(app.url_entry.get()).strip() != text:
                app.url_entry.delete(0, "end")
                app.url_entry.insert(0, text)
        except Exception:
            return
        stage = str(getattr(app, "stage", "idle")).casefold()
        if stage not in {"idle", "error"}:
            return
        force = True
    if not force and getattr(app, "_lumo_last_auto_url", None) == text:
        return
    app._lumo_last_auto_url = text
    inspect = getattr(app, "inspect", None)
    if callable(inspect):
        try:
            inspect()
        except Exception:
            pass


def _bind_enter_to_continue(app: Any, continue_action: Any) -> None:
    """Enter in the URL field starts inspection; Enter on the quality choice continues.

    Clicking the buttons still works. Pasting with Ctrl+V also starts inspection.
    """
    def enter_in_url(_event: Any = None) -> str:
        _auto_inspect(app, force=True)
        return "break"

    def enter_in_quality(_event: Any = None) -> str:
        try:
            continue_action()
        except Exception:
            pass
        return "break"

    def paste_in_url(_event: Any = None) -> None:
        try:
            app.url_entry.after(60, lambda: _auto_inspect(app))
        except Exception:
            pass

    entry = getattr(app, "url_entry", None)
    if entry is not None and not getattr(entry, "_lumo_enter_bound", False):
        try:
            entry.bind("<Return>", enter_in_url, add="+")
            entry.bind("<<Paste>>", paste_in_url, add="+")
            entry._lumo_enter_bound = True
        except Exception:
            pass
    combo = getattr(app, "quality_combo", None)
    if combo is not None and not getattr(combo, "_lumo_enter_bound", False):
        try:
            combo.bind("<Return>", enter_in_quality, add="+")
            combo._lumo_enter_bound = True
        except Exception:
            pass


def _schedule_download_controls_repair(app: Any, module: ModuleType) -> None:
    """Run the download-controls repair once, shortly after a burst of renders.

    Each render used to start its own full widget-tree walk. Renders that happened
    close together repeated the same slow walk, which froze the window. Requests
    arriving within the delay now share one walk.
    """
    if getattr(app, "_lumo_controls_repair_pending", False):
        return
    app._lumo_controls_repair_pending = True

    def run_once() -> None:
        app._lumo_controls_repair_pending = False
        _repair_download_controls(app, module)

    try:
        app.after(120, run_once)
    except Exception:
        app._lumo_controls_repair_pending = False
        _repair_download_controls(app, module)


def _repair_download_controls(app: Any, module: ModuleType) -> None:
    """Rebind dynamic Download-stage controls after recovered UI rebuilds."""
    pages = getattr(app, "pages", {})
    roots = []
    if isinstance(pages, dict) and pages.get("download") is not None:
        roots.append(pages.get("download"))
    for candidate in (getattr(app, "stage_area", None), getattr(app, "content", None)):
        if candidate is not None and all(candidate is not existing for existing in roots):
            roots.append(candidate)
    if not roots:
        roots.append(app)
    # Walk each widget once. `content` is the shell that holds every page, so walking it
    # (as before) also scanned all of History and Settings on every render. Paste, Continue
    # and the progress bars exist only on the Download page, so the other primary pages are
    # skipped; anything else directly inside `content` is still covered.
    skip_ids = set()
    if isinstance(pages, dict):
        download_frame = pages.get("download")
        for page_frame in pages.values():
            if page_frame is not None and page_frame is not download_frame:
                skip_ids.add(id(page_frame))
    widgets = []
    seen_widgets = set(skip_ids)
    for root in roots:
        stack = [root]
        while stack:
            widget = stack.pop()
            if id(widget) in seen_widgets:
                continue
            seen_widgets.add(id(widget))
            widgets.append(widget)
            try:
                stack.extend(widget.winfo_children())
            except Exception:
                pass
    paste = getattr(app, "paste_url", None)
    continue_action = getattr(app, "continue_to_extras", None)
    if callable(continue_action):
        _bind_enter_to_continue(app, continue_action)
    for widget in widgets:
        label = _widget_text(widget).strip().casefold()
        if label in {"paste", "paste url", "paste link"} and callable(paste):
            _set_runtime_button_command(widget, paste)
            try:
                widget._lumo_paste_command_bound = True
            except Exception:
                pass
        if label == "continue" or label.startswith("continue ") or label.endswith(" continue"):
            if callable(continue_action):
                _set_runtime_button_command(widget, continue_action)
                try:
                    widget._lumo_continue_command_bound = True
                except Exception:
                    pass
    # Keep the native data/selection behavior intact; only the arrow/palette styling is applied.
    combo = getattr(app, "quality_combo", None)
    if combo is not None:
        _apply_quality_visuals(combo, module)
    # Progress widgets are often created lazily as the download stage changes.
    settings = getattr(module, "_LUMO_PROGRESS_OPTIONS", {})
    thickness = settings.get("progress_thickness", 12) if isinstance(settings, dict) else 12
    _redraw_progress_widgets(app, thickness=thickness, widgets=widgets)


def _install_download_interaction_repairs(module: ModuleType) -> None:
    """Repair clipboard, dynamic Continue command, and post-stage control bindings."""
    app_class = getattr(module, "App", None)
    if app_class is None or getattr(app_class, "_lumo_download_interaction_repairs", False):
        return

    original_paste = getattr(app_class, "paste_url", None)
    if callable(original_paste):
        def paste_url_immediately(self: Any, *args: Any, **kwargs: Any) -> Any:
            """Read the Windows clipboard, replace the URL field, and restore focus."""
            text = ""
            for getter in (
                lambda: self.clipboard_get(),
                lambda: self.tk.call("clipboard", "get"),
                lambda: self.winfo_toplevel().clipboard_get(),
            ):
                try:
                    text = str(getter() or "").strip()
                    if text:
                        break
                except Exception:
                    continue
            if not text:
                try:
                    messagebox.showinfo("Clipboard empty", "Copy a video URL first, then select Paste.", parent=self)
                except Exception:
                    pass
                try:
                    self.url_entry.focus_set()
                except Exception:
                    pass
                return None
            entry = getattr(self, "url_entry", None)
            if entry is None:
                return original_paste(self, *args, **kwargs)
            try:
                entry.configure(state="normal")
            except Exception:
                pass
            try:
                entry.delete(0, "end")
                entry.insert(0, text)
                entry.icursor("end")
                entry.focus_set()
                try:
                    entry.selection_range(0, "end")
                except Exception:
                    pass
                return None
            except Exception:
                return original_paste(self, *args, **kwargs)
        paste_url_immediately._lumo_paste_repaired = True  # type: ignore[attr-defined]
        app_class.paste_url = paste_url_immediately

    # Rebind only at structural render points. The previous generic handle_event
    # wrapper walked the whole Download widget tree after *every* UI event; that
    # repeated scan competed with the first tab click and worsened navigation jitter.
    original_build = getattr(app_class, "build_download_page", None)
    if callable(original_build) and not getattr(original_build, "_lumo_controls_repaired", False):
        def build_download_with_controls(self: Any, *args: Any, **kwargs: Any) -> Any:
            result = original_build(self, *args, **kwargs)
            _schedule_download_controls_repair(self, module)
            return result
        build_download_with_controls._lumo_controls_repaired = True  # type: ignore[attr-defined]
        app_class.build_download_page = build_download_with_controls

    original_render_stage = getattr(app_class, "render_download_stage", None)
    if callable(original_render_stage) and not getattr(original_render_stage, "_lumo_controls_repaired", False):
        def render_download_stage_with_controls(self: Any, *args: Any, **kwargs: Any) -> Any:
            result = original_render_stage(self, *args, **kwargs)
            _schedule_download_controls_repair(self, module)
            return result
        render_download_stage_with_controls._lumo_controls_repaired = True  # type: ignore[attr-defined]
        app_class.render_download_stage = render_download_stage_with_controls

    # Rebind path buttons against the actual live variable aliases after a settings rebuild.
    original_build_settings = getattr(app_class, "build_settings_page", None)
    if callable(original_build_settings) and not getattr(original_build_settings, "_lumo_path_controls_repaired", False):
        def build_settings_with_working_paths(self: Any, *args: Any, **kwargs: Any) -> Any:
            result = original_build_settings(self, *args, **kwargs)
            try:
                self.after_idle(lambda target=self: _repair_settings_path_controls(target, module))
            except Exception:
                _repair_settings_path_controls(self, module)
            return result
        build_settings_with_working_paths._lumo_path_controls_repaired = True  # type: ignore[attr-defined]
        app_class.build_settings_page = build_settings_with_working_paths

    app_class._lumo_download_interaction_repairs = True


def _repair_settings_path_controls(app: Any, module: ModuleType) -> None:
    """Ensure Browse buttons point at the live, persisted folder and cookie callbacks."""
    pages = getattr(app, "pages", {})
    root = pages.get("settings") if isinstance(pages, dict) else None
    if root is None:
        tabs = getattr(app, "settings_tabs", {})
        root = tabs.get("downloads") if isinstance(tabs, dict) else None
    if root is None:
        return
    download_command = getattr(app, "browse_download_dir", None)
    cookie_command = getattr(app, "browse_cookie_file", None)
    for widget in _walk_widgets(root):
        label = _widget_text(widget).strip().casefold()
        # Only interactive controls are candidates. Generic ancestor containers and
        # labels must never acquire a synthetic .command attribute.
        has_button_api = (
            callable(getattr(widget, "invoke", None))
            or callable(getattr(widget, "bind", None))
            or callable(getattr(widget, "_animate_press", None))
            or callable(getattr(widget, "command", None))
        )
        if not has_button_api:
            continue
        current_command = getattr(widget, "command", None)
        command_func = getattr(current_command, "__func__", current_command)
        command_name = str(getattr(command_func, "__name__", "")).casefold()
        if callable(cookie_command) and "browse_cookie_file" in command_name:
            _set_runtime_button_command(widget, cookie_command)
            continue
        if callable(download_command) and "browse_download_dir" in command_name:
            _set_runtime_button_command(widget, download_command)
            continue

        is_browse = label in {"browse", "browse…", "browse...", "choose", "select file", "select folder"}
        if not is_browse:
            continue
        # Inspect the nearest row first. Do not combine text from several parent
        # levels: the old scan did that, so both Browse buttons could see both
        # "Downloads" and "Cookies" labels and get rebound to the same callback.
        context = ""
        ancestor = getattr(widget, "master", None)
        for _depth in range(3):
            if ancestor is None:
                break
            try:
                sibling_text = " ".join(_widget_text(child).casefold()
                                        for child in ancestor.winfo_children())
            except Exception:
                sibling_text = ""
            has_cookie = "cookie" in sibling_text or "cookies" in sibling_text
            has_download = any(word in sibling_text for word in (
                "download folder", "download location", "save downloads",
                "download directory", "download path", "download location",
            ))
            if has_cookie != has_download:
                context = sibling_text
                break
            if has_cookie and has_download:
                # Ambiguous parent (typically the whole Settings tab); stop rather
                # than binding a generic Browse button to the wrong picker.
                break
            ancestor = getattr(ancestor, "master", None)
        is_cookie_row = "cookie" in context or "cookies" in context
        is_download_row = any(word in context for word in (
            "download folder", "download location", "save downloads", "download directory", "download path"
        ))
        if callable(cookie_command) and is_cookie_row:
            _set_runtime_button_command(widget, cookie_command)
        elif callable(download_command) and is_download_row:
            _set_runtime_button_command(widget, download_command)
    _wire_automatic_settings_save(app, module)



def _sync_settings_chip_underlines(app: Any, module: ModuleType) -> None:
    """Make each Settings chip's underline match the selected tab.

    The recovered ChoiceChip animates its underline (indicator_progress) toward 1.0
    when selected and 0.0 when not. A rebuild can leave a non-selected chip with a
    running or stale tween, so its underline stays visible. This cancels any pending
    underline tween and sets the selected chip to on and every other chip to off.
    """
    variable = getattr(app, "settings_tab_var", None)
    if variable is None:
        return
    try:
        selected = _canonical_settings_tab_key(variable.get())
    except Exception:
        return
    for widget in _walk_widgets(app):
        if widget.__class__.__name__ != "ChoiceChip":
            continue
        text = _widget_text(widget) or str(getattr(widget, "text", "") or "")
        key = _canonical_settings_tab_key(text)
        if key not in {"accent", "indicator", "downloads", "subtitles", "progress"}:
            continue
        wanted = key == selected
        try:
            current = bool(getattr(widget, "indicator", False))
            progress = float(getattr(widget, "indicator_progress", 0.0))
        except Exception:
            continue
        setter = getattr(widget, "set_indicator", None)
        if not callable(setter):
            continue
        # Use the recovered set_indicator so the underline still animates. Never snap the
        # progress value or cancel the running tween: that is what made the line jump.
        if current != wanted:
            try:
                setter(wanted)
            except Exception:
                pass
        elif not wanted and progress > 0.001:
            # A stale, visible underline on a non-selected tab: animate it back to zero.
            try:
                setter(False)
            except Exception:
                pass


def _thumbnail_ssl_context():
    """Trust store used for thumbnails: the certifi bundle, the same one yt-dlp uses.

    Python's default store can miss a certificate that antivirus or a web filter
    inserts for HTTPS, which made every thumbnail download fail with a certificate error.
    """
    try:
        import ssl
        import certifi
        return ssl.create_default_context(cafile=certifi.where())
    except Exception:
        return None


def _download_thumbnail_bytes(url: str) -> bytes:
    request = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(request, timeout=15, context=_thumbnail_ssl_context()) as response:
        data = response.read(6 * 1024 * 1024)
    if not data:
        raise ValueError("empty thumbnail")
    return data


def _thumbnail_candidates(info: dict) -> list[str]:
    """Best thumbnail first: the largest listed image, then the default thumbnail URL."""
    urls: list[str] = []
    thumbs = info.get("thumbnails") or []
    ranked = sorted(
        (t for t in thumbs if isinstance(t, dict) and t.get("url")),
        key=lambda t: (t.get("width") or 0) * (t.get("height") or 0),
        reverse=True,
    )
    for entry in ranked:
        urls.append(str(entry["url"]))
    if info.get("thumbnail_url"):
        urls.insert(0, str(info["thumbnail_url"]))
    seen: set[str] = set()
    unique = []
    for url in urls:
        if url not in seen:
            seen.add(url)
            unique.append(url)
    return unique


def _thumb_trace(message: str) -> None:
    """Append one line to %TEMP%\\lumo_thumb_trace.log so a missing thumbnail is explained."""
    try:
        line = f"{time.strftime('%H:%M:%S')} [thumb] {message}\n"
        with (Path(tempfile.gettempdir()) / "lumo_thumb_trace.log").open("a", encoding="utf-8") as handle:
            handle.write(line)
    except OSError:
        pass


def _poll_thumbnail_ready(app: Any) -> None:
    """Runs on the Tk main thread. Applies a finished thumbnail with App.set_thumbnail."""
    ready = getattr(app, "_lumo_thumb_ready", None)
    if ready is not None:
        app._lumo_thumb_ready = None
        url, path = ready
        # The original app checks this too: an image for an older video is ignored.
        if url != getattr(app, "inspected_url", None):
            _thumb_trace("ignored: the thumbnail is for a different video than the one shown")
        else:
            try:
                # App.set_thumbnail takes (path, url). The arguments were swapped before,
                # so the image was never loaded; the failure was hidden inside the method.
                app.set_thumbnail(path, url)
                _thumb_trace(f"applied {Path(path).name}")
            except Exception as exc:
                _thumb_trace(f"set_thumbnail failed: {exc!r}")
    try:
        app.after(120, lambda: _poll_thumbnail_ready(app))
    except Exception:
        pass


def _start_thumbnail_fetch(app: Any, payload: Any) -> None:
    """After a successful inspection, download the preview image and show it on the main thread."""
    try:
        url, info, error = payload
    except Exception:
        _thumb_trace("skipped: unexpected inspection payload")
        return
    if error or not isinstance(info, dict):
        _thumb_trace(f"no thumbnail: inspection error or no info ({error})")
        return
    candidates = _thumbnail_candidates(info)[:4]
    if not candidates:
        _thumb_trace("no thumbnail URL in the video info")
        return
    if not getattr(app, "_lumo_thumb_poller", False):
        app._lumo_thumb_poller = True
        try:
            app.after(120, lambda: _poll_thumbnail_ready(app))
        except Exception:
            _thumb_trace("could not start the main-thread poller")
            return

    def worker() -> None:
        for candidate in candidates:
            try:
                data = _download_thumbnail_bytes(candidate)
                folder = Path(tempfile.gettempdir()) / "lumo_thumbnails"
                folder.mkdir(parents=True, exist_ok=True)
                name = hashlib.sha1(str(url).encode("utf-8")).hexdigest()[:20] + ".jpg"
                path = folder / name
                path.write_bytes(data)
                # Shrink here, on the worker thread, so the window thread only has to show
                # a small image. Large resize/convert work on the window thread froze Lumo.
                try:
                    import io
                    from PIL import Image, ImageOps
                    with Image.open(io.BytesIO(data)) as source:
                        small = ImageOps.fit(source.convert("RGB"), (300, 169), Image.Resampling.LANCZOS)
                        small.save(path, "JPEG", quality=90)
                except Exception as exc:
                    _thumb_trace(f"pre-shrink skipped, using the original image: {exc!r}")
                app._lumo_thumb_ready = (url, str(path))
                _thumb_trace(f"downloaded {len(data)} bytes from {candidate[:60]}")
                return
            except Exception as exc:
                _thumb_trace(f"candidate failed: {candidate[:60]} -> {exc!r}")
                continue
        _thumb_trace("all thumbnail candidates failed")

    threading.Thread(target=worker, daemon=True).start()


def _install_reduced_navigation_and_download_controls(module: ModuleType) -> None:
    """Keep Download and Settings navigation, and remove the two obsolete toggles."""
    nav_items = getattr(module, "NAV_ITEMS", None)
    if isinstance(nav_items, (tuple, list)):
        kept = []
        for item in nav_items:
            key = str(item[0]).strip().casefold() if isinstance(item, (tuple, list)) and item else ""
            label = str(item[1]).strip().casefold() if isinstance(item, (tuple, list)) and len(item) > 1 else ""
            if key in {"history", "playlist"} or label in {"history", "playlist"}:
                continue
            kept.append(item)
        module.NAV_ITEMS = tuple(kept) if isinstance(nav_items, tuple) else kept

    app_class = getattr(module, "App", None)
    if app_class is None:
        return

    toggle_phrases = (
        "use cookies from my cookie file",
        "use a private cookie file",
        "prefer mp4 while merging is possible",
        "prefer mp4 when merging is possible",
    )
    cookie_description_phrases = ("use cookies from my cookie file", "use a private cookie file")
    mp4_phrases = ("prefer mp4 while merging is possible", "prefer mp4 when merging is possible")

    def _normal_text(value: Any) -> str:
        return " ".join(str(value or "").casefold().replace("\\n", " ").split())

    def _has_legacy_toggle_text(root: Any) -> bool:
        for child in _walk_widgets(root):
            text = _normal_text(_widget_text(child))
            if text and (any(p in text for p in cookie_description_phrases)
                         or any(p in text for p in mp4_phrases)):
                return True
        return False

    def _destroy_quietly(widget: Any) -> None:
        try:
            widget.destroy()
        except Exception:
            try:
                widget.pack_forget()
                widget.grid_remove()
                widget.place_forget()
            except Exception:
                pass

    def _row_holds_cookie_box(row: Any) -> bool:
        """True when a row also contains the cookie path box or its Browse button."""
        for child in _walk_widgets(row):
            if isinstance(child, tk.Entry) or "browse" in _normal_text(_widget_text(child)):
                return True
        return False

    def _switch_belongs_to_youtube_access(switch: Any, app: Any) -> bool:
        """True when the switch sits in the YouTube access card (within 3 levels)."""
        ancestor = getattr(switch, "master", None)
        for _ in range(3):
            if ancestor is None or ancestor is app:
                break
            for child in _walk_widgets(ancestor):
                if _normal_text(_widget_text(child)) == "youtube access":
                    return True
            ancestor = getattr(ancestor, "master", None)
        return False

    def remove_legacy_download_toggles(app: Any) -> None:
        """Keep cookies and MP4 merging on, and remove their description text and the MP4 toggle row."""
        settings = getattr(app, "settings", None)
        if isinstance(settings, dict):
            settings["use_cookies"] = True
            settings["merge_to_mp4"] = True
        for variable_name in ("cookie_var", "use_cookies_var", "youtube_access_var",
                              "youtube_access_toggle_var", "merge_var", "merge_to_mp4_var"):
            variable = getattr(app, variable_name, None)
            if variable is None:
                continue
            try:
                # Writing an unchanged value still fires autosave traces; only write when needed.
                if variable.get() is not True and str(variable.get()).casefold() != "true":
                    variable.set(True)
            except Exception:
                pass

        pages = getattr(app, "pages", None)
        scope = pages.get("settings") if isinstance(pages, dict) and pages.get("settings") is not None else app
        # Already cleaned for this built Settings page: skip the widget walk entirely.
        # The flag is cleared each time build_settings_page() creates new widgets.
        if getattr(scope, "_lumo_toggles_cleaned", False):
            return
        for widget in list(_walk_widgets(scope)):
            text = _normal_text(_widget_text(widget))
            if not text:
                continue
            if any(phrase in text for phrase in cookie_description_phrases):
                # Remove only the description line; the cookie path box stays so cookies keep working.
                _destroy_quietly(widget)
                continue
            if any(phrase in text for phrase in mp4_phrases):
                target = widget
                row = getattr(widget, "master", None)
                if row is not None and row is not app and not _row_holds_cookie_box(row):
                    target = row
                _destroy_quietly(target)

        # The YouTube access card's header switch is removed too: cookies are forced on above,
        # so the cookie path box keeps working without a visible toggle.
        for widget in list(_walk_widgets(scope)):
            if type(widget).__name__ == "ToggleSwitch" and _switch_belongs_to_youtube_access(widget, app):
                _destroy_quietly(widget)
        try:
            scope._lumo_toggles_cleaned = True  # type: ignore[attr-defined]
        except Exception:
            pass

    def schedule_toggle_removal(app: Any) -> None:
        remove_legacy_download_toggles(app)

    original_build_settings_page = getattr(app_class, "build_settings_page", None)
    if callable(original_build_settings_page) and not getattr(original_build_settings_page, "_lumo_toggle_reset", False):
        def build_settings_page_resetting_toggles(self: Any, *args: Any, **kwargs: Any) -> Any:
            result = original_build_settings_page(self, *args, **kwargs)
            pages = getattr(self, "pages", None)
            scope = pages.get("settings") if isinstance(pages, dict) else None
            if scope is not None:
                try:
                    scope._lumo_toggles_cleaned = False  # new widgets: run the cleanup once
                except Exception:
                    pass
            return result
        build_settings_page_resetting_toggles._lumo_toggle_reset = True  # type: ignore[attr-defined]
        app_class.build_settings_page = build_settings_page_resetting_toggles

    original_show_settings = getattr(app_class, "_show_settings_tab", None)
    if callable(original_show_settings) and not getattr(original_show_settings, "_lumo_toggle_cleanup", False):
        def show_settings_with_toggle_cleanup(self: Any, *args: Any, **kwargs: Any) -> Any:
            result = original_show_settings(self, *args, **kwargs)
            schedule_toggle_removal(self)
            return result
        show_settings_with_toggle_cleanup._lumo_toggle_cleanup = True  # type: ignore[attr-defined]
        app_class._show_settings_tab = show_settings_with_toggle_cleanup

    original_handle = getattr(app_class, "handle_event", None)
    if callable(original_handle) and not getattr(original_handle, "_lumo_thumbnail_fetch", False):
        def handle_event_with_thumbnail(self: Any, kind: Any, payload: Any = None, *args: Any, **kwargs: Any) -> Any:
            result = original_handle(self, kind, payload, *args, **kwargs)
            if kind == "inspected":
                try:
                    _start_thumbnail_fetch(self, payload)
                except Exception:
                    pass
            return result
        handle_event_with_thumbnail._lumo_thumbnail_fetch = True  # type: ignore[attr-defined]
        app_class.handle_event = handle_event_with_thumbnail

    original_show_page = getattr(app_class, "show_page", None)
    if callable(original_show_page) and not getattr(original_show_page, "_lumo_settings_default_tab", False):
        def show_page_with_accent_default(self: Any, page: Any, *args: Any, **kwargs: Any) -> Any:
            # Opening Settings from the sidebar always starts on Accent & Indicator.
            # Switching tabs inside Settings, or a colour rebuild, does not reach this branch.
            target = str(page or "").strip().casefold()
            previous = str(getattr(self, "current_display_page", "") or "").strip().casefold()
            if target == "settings" and previous != "settings":
                variable = getattr(self, "settings_tab_var", None)
                if variable is not None:
                    try:
                        variable.set("accent")
                    except Exception:
                        pass
            return original_show_page(self, page, *args, **kwargs)
        show_page_with_accent_default._lumo_settings_default_tab = True  # type: ignore[attr-defined]
        app_class.show_page = show_page_with_accent_default

    original_paste = getattr(app_class, "paste_url", None)
    if callable(original_paste) and not getattr(original_paste, "_lumo_auto_inspect", False):
        def paste_then_inspect(self: Any, *args: Any, **kwargs: Any) -> Any:
            result = original_paste(self, *args, **kwargs)
            try:
                self.after(60, lambda target=self: _auto_inspect(target))
            except Exception:
                pass
            return result
        paste_then_inspect._lumo_auto_inspect = True  # type: ignore[attr-defined]
        app_class.paste_url = paste_then_inspect

    original_init = getattr(app_class, "__init__", None)
    if callable(original_init) and not getattr(original_init, "_lumo_reduced_ui", False):
        def init_reduced_ui(self: Any, *args: Any, **kwargs: Any) -> Any:
            result = original_init(self, *args, **kwargs)
            schedule_toggle_removal(self)
            return result
        init_reduced_ui._lumo_reduced_ui = True  # type: ignore[attr-defined]
        app_class.__init__ = init_reduced_ui

    for method_name in ("build_download_page", "_build_download_page", "rebuild_ui"):
        original_method = getattr(app_class, method_name, None)
        marker = f"_lumo_reduced_ui_{method_name}"
        if not callable(original_method) or getattr(original_method, marker, False):
            continue

        def make_wrapper(method: Any, marker_name: str) -> Any:
            def wrapped(self: Any, *args: Any, **kwargs: Any) -> Any:
                result = method(self, *args, **kwargs)
                schedule_toggle_removal(self)
                return result
            setattr(wrapped, marker_name, True)
            return wrapped

        setattr(app_class, method_name, make_wrapper(original_method, marker))



def _enable_crisp_rendering() -> None:
    """Render Tk at the real screen resolution on Windows.

    Without per-monitor DPI awareness, Windows scales the window bitmap when display
    scaling is above 100 percent (125 or 150 percent is common on laptops). That softens
    text, icons and edges, which is the "dirty pixels" look. Call this before Tk starts.
    """
    if os.name != "nt":
        return
    try:
        import ctypes
        try:
            ctypes.windll.shcore.SetProcessDpiAwareness(2)  # per-monitor DPI aware
        except Exception:
            ctypes.windll.user32.SetProcessDPIAware()
    except Exception:
        pass


def _raise_animation_frame_rate(module: ModuleType) -> None:
    """Redraw the progress glow every 16 ms (about 60 fps) instead of 33 ms (about 30 fps)."""
    cls = getattr(module, "GlowProgress", None)
    animate = getattr(cls, "animate", None)
    code = getattr(animate, "__code__", None)
    if code is None or getattr(animate, "_lumo_fps", False):
        return
    try:
        consts = tuple(16 if (type(value) is int and value == 33) else value for value in code.co_consts)
        if consts != code.co_consts:
            animate.__code__ = code.replace(co_consts=consts)
            animate._lumo_fps = True  # type: ignore[attr-defined]
    except Exception:
        pass


def _install_no_chip_animation_on_rebuild(module: ModuleType) -> None:
    """Changing a colour rebuilds Settings. Snap the tab underline during that rebuild.

    The recovered ChoiceChip animates its underline from zero each time a chip is created
    and selected. A colour change rebuilds every chip, so the underline under Downloads
    grew from nothing. During a colour rebuild the underline is placed at its final state
    instead. Normal tab switching still animates as before.
    """
    chip_class = getattr(module, "ChoiceChip", None)
    app_class = getattr(module, "App", None)
    if chip_class is None or app_class is None:
        return
    original_animate = getattr(chip_class, "_animate_indicator", None)
    if callable(original_animate) and not getattr(original_animate, "_lumo_snap", False):
        def animate_or_snap(self: Any, *args: Any, **kwargs: Any) -> Any:
            if getattr(module, "_LUMO_SNAP_CHIP_INDICATORS", False):
                try:
                    self.indicator_progress = 1.0 if bool(getattr(self, "indicator", False)) else 0.0
                    refresh = getattr(self, "refresh_look", None)
                    if callable(refresh):
                        refresh()
                except Exception:
                    pass
                return None
            return original_animate(self, *args, **kwargs)
        animate_or_snap._lumo_snap = True  # type: ignore[attr-defined]
        chip_class._animate_indicator = animate_or_snap

    original_rebuild = getattr(app_class, "rebuild_ui", None)
    if callable(original_rebuild) and not getattr(original_rebuild, "_lumo_snap_rebuild", False):
        def rebuild_without_chip_tween(self: Any, *args: Any, **kwargs: Any) -> Any:
            module._LUMO_SNAP_CHIP_INDICATORS = True  # type: ignore[attr-defined]
            try:
                return original_rebuild(self, *args, **kwargs)
            finally:
                module._LUMO_SNAP_CHIP_INDICATORS = False  # type: ignore[attr-defined]
        rebuild_without_chip_tween._lumo_snap_rebuild = True  # type: ignore[attr-defined]
        app_class.rebuild_ui = rebuild_without_chip_tween


_LUMO_L_MASK_B64 = (
    "iVBORw0KGgoAAAANSUhEUgAAAPgAAAEYCAAAAABUiWThAAAUBElEQVR42u1dfYxU13U/595ZYGGHnaxFWjU2jSqoCY6cRg0Elopl"
    "dyENwqhR2KZVK1kBKsUqRW0dgRenWKSR7NStIkWp1JLWBhy5bMBr2sKatsTGVKramrQUVbWXj2oXhURR7YWFBcMy757TP958vI/7"
    "3sy8fXfee7tz/0BiNPvm/e7vnnPP1z0XoDVaozVaozVaozVaI2MDZ/YnPHdmSgrn/4ScA4wjACIxiLY2QABgKBYJUDA3i3vNy7Jx"
    "4JIJAAB6tq/Mt4EEAAXFqXcPnStzj2oGkASCqvcNPH9JRoELZhDz27s+8eQ291/w8Cujk0X1oMI9R3gFwdTQWpOAipBJKVZGGZfE"
    "sH77Y4vbuzoAlEu5SYC7k5ZV5b5R5m0eH197/Q1GrnOtIQADE1nWg5vHX7bQkJgJBOg+qpiZmSxi16h+QMe3LutaKABQIjbybPGx"
    "jX91m61toFGUiBIBxMKuZVuPe365PL4AkRRsrvYiJ+h/+nM5UAiA6P0RlMDAAMByYODOjelb/3PonKqXd0kE63d88pGPAhTbVui5"
    "VtCz/bHO+b61BgCgpAAQhugGWDfEzFbAfPu5V0NbluYAUApEDOIeEYWsriTrAd/8pBeCQIDc0i1DurVGpJTFzNfOPpVDNIJ77Umr"
    "Htj26yj7dSYuHOkN2+nLtkD/SJHZUmQxT/y6B7dAgPWHL0wws6WUIt0Uv7rpo4b2TQm77jJb3Mgovdbw1uVLCvn5osp9aQhbah9a"
    "vnW4tJIU3z/+aS9ugHVDSq9VmPnOjy6df3l96YsmcO9hLhI3OkhZzHzn+vjV99453ON/cM/h85d/NFWCTYqHV3sAYHmlKd+PW/ak"
    "PtTeoBptDPcgK8WRhkvbL19SKOTz+Xw+XygsWV7Wz/ZXSPFzAMKFW6K90sj/VObiSL9Zcxkl7GVFHHkQqZLM37k+Pj42NjY2NjY+"
    "fv2OLbVUQq940ANBIMAB7UqzmHmouyw8YAz34Ixw+7nXfECK94JEr3Sf0v6yYnWyHwCNOkYz5tvPvT3IpZ8VD/pwrzmpWOkUB59a"
    "B4ACDOMejA13iBL08h28j5DiA6bZjpnvMNyDPtwB+4hGFxiJNiTGd8A+otEFWcbt5ztgnTUJt4Dd9RqpcfIdMt+K9zeF7+57KmW4"
    "TzQBNyCMNGieRxh+DkPWGd1fheajmhJWT5N53Cd8fAeuM4tPgXm+AWHIPOE07eUweJ2RKm6AZhDeVzQu4RaPePzJkHVm8dHmEH7a"
    "OOGk7nWDrHed0fRqyKiEe1YQKd7tIzxwnVn8RiIS7nQwPC5GRO/M1uj1rjMiq68phPcWHeBIFwugBsWZ+b9P32JyaXSB9Uv4kBHC"
    "PeFlgqdyqjy/TFLChzetSnYEIVdYJEuB5joezsxS0rlX/vlzG5zsTj+PSJ6f/cN5SgaYkS+BUKaBI+dWVOZXSQmvv/LeDauS1pLQ"
    "Vljx5DZpz4oIx84kEAFe/87bAJ0LSFSD4T8474m6S9U3QHo/m/HGKFATJPzhD8qLUrFVjm75Q4XXpjRhX1eYucjME//5vV4AkSv8"
    "VzWyoNuVQ3YSxWOdTdBtEjYyueId7tBwJThcTekERpbomJ1YyEn4C0dERbMrh+0kiq92QDPM9KP21IfFO8rpABfzlWEx89S1y+eP"
    "9NiRUJTwdWckSbMri/KvaoFflIBN0+k14h065qvIXMlDlLDfiVuzK0voKQZukxYPgTBOuCht4vX5/VXm33nv6tWxsbGxq44EQmna"
    "JDzr9LmIir1+wv8mkHDd900s9NxFVg3EOyrMz+/oyOfz+Y6OasqozOY+l6+pkXAEeZEVJ2mnIyy9wdRwvCOkHMjnYxNv9Kv0jqtB"
    "wIl4U1PMtl+1cTca73Cq/VAfm/iDh/2Md44FAuebH28C4wK+yxazuveZmOIdwrs/K76Y8wN/ZIIpCPh4lyHgjmWK1L6WESxx5ocY"
    "i40oeVUfu6aQYdRXsSJgRRcHgGNogtUGCPP/nR8UeWp1PGkaFHDCvYa1OhpDd/HxzqYs9c//H/P7vxnTxunZwQN0tMcf9Bms+eY4"
    "44/tf3ZlTL8kYLcvAuHX6RXbIVHg9m/ExbcvaqrX6eJC4C5uErjbLWWBwPGoE4avLVDC42L++Kf+L7YvhiSGLxARl01Aqzay9M7F"
    "qKYKUYhEgBv6VWR+dp4HIws6CMmgbN7wa/SA6BlC5zhT4sotvnXk0+gBdjfCz9+YPcC1eTC93S1hE1MIcGMGjBGZI/jaAo0Veuu2"
    "7qs7gbDWDpsR4JJX+zR6gN0tuXcbizDUIkPACZ6eRwE+h++Tr+RCCe9cnB3gkvu2aaPkftMISTwaupi5sNwQ58IE4XtyXK9oLlgU"
    "ag4Q7DDkmAoTEt7HdQcyathtggd6WWYDeKCER9HaSLmvmDnSJuInPFRPa6IVNeblUUGYBeAET+VifdNFCzIh4658azxvmBWt/rMf"
    "ixe4IdNNxP68FQ9xvIxnw1Yn2NmMiHDqgEvuHWAxB4HHrtMzAjx+nZ4VxmPX6RkBHr9Ozwhwgu3Z0OkxA5e84Uss5iDwmvGUWQoc"
    "SazITDA43oWZUB4sBVpdzFHgGRoxM45zVMYLc1PGBfziRxoNDNYuQ8D0R2Bq5sH0e39N5GkH3mB8tTRZVBN16hmPZLfdv1vrG4ay"
    "Z/EBr5kH082VoEs1Frup7FmczwzPgwWs5IOW4NDpNJQ9i1WrN/4whWdfw1BcprJnsa4ijPL7L0MNys1kz2L1ziI8jODKZI28oZns"
    "WfK2+u1btb5hJHuWPHCqacQIMSuBJ2S6pYDxmsgFzkrgrUBEC/isA45irjKOcxI4pkuumvkunYtnKfAa8TNzdamJM86QhGedPPAa"
    "8TNzdalJA68RPzNXl5os8NrxM2N1qQkzjnBQCW6+Z504cIVnh5Ea9qyZsgbc3RkHAAT8dY3nYTSHPFXApXAfERMSGcZuh99gofOs"
    "KRnGc9GkWZCq3FpSviMHciAjPK52LiUtwO27LNZvf6x0awmAguKd0cNvFmHLQmpwCbGgS7+Uiauk3HdZOMeZr377VmiHP+1J0dBW"
    "Cek5X+q5y8LT3KpmM1YdhLDmGKkBHnyXBTNZVo2uhnoI4cdqjQFvSMYFrX12swSFqOmQE7VpDsGVyUKolBMnq9xQqF0vLgQVe3v3"
    "27cK0Z0+8/s4CrXnzxdaHH/b61q5FEo2TSzU4ItEOQNqphajd+8nCVyqZ14gM3HScBlmuESCEwMu1O99U2ECuwoL66CJ3axO4JK6"
    "/5REErsp4WtnUSUGnODAgkTOXLCAlxMs/pG8JqlwGU5eMRKirG8fZ9gmLG9D9CYtAF0vkSYCX+IPnnAzhJ7RUEi6Xsvt2+3LFzlu"
    "D6z03W6CoudEGb/wG3K+dHoWbYUVX/6ibALvnCzjCOpD9yfvXznZ++XHl3ZJUCJLfagaBM4+XYZIZ8/mfu7x7V+UoAxqfEphfMbu"
    "wduvv5it/kBEfiyseaGhNuMzsg0UIUp8c+v6EWGOF0plAxxmxRL/5Ymvl24hNzCM+GaxZFIUS3FgnyHkhnyz2OzKuq4CjCDjzemv"
    "bhp5BOCmbkmJLWnIJF98Lv4lyQJeSvlhHCb5jb8VsStgvHk57W3NGPD56fhX5e1JQ8IZ3zpScP4HcYdK2Fz2XMT5qD+zRCbyfzED"
    "V/h2jRNF6bHb4j5UG78Kvn0vA8AJRicwwloP9moZRk3ZbfEy9NMfR4mXBOM2FFOPGzijNRoFuAjCTnjsbRMx9dgZF3Awyspc3Bn4"
    "vEPZaEGs8K3jDet1AcsD0uOME+Zut4u7ydVL0CjlBDsC+gww6O5cSCVwgqu3GlRGIT3/9HcupBI4wGSjtnVwnwEW1l+aq+yP+8Hc"
    "YAIgpM+AqTxpTMBnnEoJ7DNgzhePAbgUzK5ioFzDDww6K2xUp0esZS0bXIIUIBBgOdIoubPx+8mCrvxCgzp9BsDLFa2PwqXD58qS"
    "aMGmRWHVrLrou5TQfJ0eXUKcFa10fOvyJYVCobBk5a73Q4oUdVkRhMK4NtRoOr4aiXHBBOt3fGppF4BCYDkwcHfSAoBcV3vj3nWA"
    "pU7SpE6PrBC7jzoqWh2FrSq8DvmC8DP+8Zvam3F0d6MlzLigz/6Rq6IVJTCwre7C9/hL5A3ECqW31A3r9Gh8//ZtZivC1fON3Gio"
    "u+8yadyfmuJi47D1WZHAMn2Lv28Wd8P2BsJAx4MoGUJtViTIUjdrp0eScYYxmAdRal80WREk+YkAnT5sWKdHAP5q1xe6FnV1NF7z"
    "pMuKtOstdfHgWyBStpkBAMz/yLKtr7H+iEYjudKge4ktPp3Cdp/l2u3eI/ahHJoJcO29xKSKfanMipfvHc8tfWKYma06gf/vIv9l"
    "85t01ou5rHgso+GaJ53dpr2mlqZXp7oMAhAlAqw7VbsKpESj8BLepzS7uMUjGWjoKxHgAHMxit2G8H0N4aTudaeb8Cr0XXdDz8wF"
    "3ESNkLvoFxNSvDsjnZhQwNrTNRn331qK8PAHft2meH8m+C4bvtt+Eso58cQjfp2+UYf7BGSoKFhIGAhV7orHOv1LXeOZ0fQqzAzh"
    "tk/+ZtiGrgk7aT0zi0cy1mpNey2vy7+WHuAIb/imKjMa3SXnu0P2c4uPepiUsHqasqvRXUieC6tJ3QCypoRnSqM7d7UTQcgtftUn"
    "4X1F7wLJmEZ3WDL9QVeJ+2OmCKf9Ep4xjV7DyWRm4g8edjOuk/DsafQaYQVdzFQj4VnU6GUwHVf1wH0xU42Ek5VFjV4CLi/WmQfz"
    "SzgpHswm3wAg9HEFv2fml/BM4w5MD/h0uk/CSfFekJhV4AEJIZ9Ol7DBLeE239nFHdDFx6fTEU655ifrfAclfb06XeKq+7OKbwCE"
    "rnEfcK9O95q22ec7oLDDGyWXsN+DO+t8AyB0+oF7ouQe93U28K0/NejJg3kCFrOCby1wbx5MwIhDo88OvrVL3WO1SVw1Pev41io3"
    "t4S7Nfps4Vu3nbklHF0afdbwrTFgPBIu4ZmqRp89fGtMVreEe3HPFr41+W6XhLt28Hr49vR2TjPhnny3S8JdO3gdfEtXOEakumGC"
    "J9/tlnDnDh7Ed4VgIRFAzO/oyOfz+Y6O+QIApYiR+1ycuDnnvn+c5LG3KtVqkj7TX+4JRyD2vSh91euyelqcAXq2ryx1d1ZQnHr3"
    "ULkqXqStqNmf73ZKOMrqDl5kN99ejguFJcu3Hvd4eXZVfL7K/UxfNkYRVxvPOPsbKvkPm8tnDFCo/X9sH15QEu7v/U6V7yrPZY4R"
    "coVFAMr5ciwB7k5aVnHq3UPnUsa8J/DklHBHuxTFfPpX7Dhylee8j2Nf6WD1Azq+dVlXu0jNrVLeUKPDD3fhPtNr1w6XtXbP4Xfe"
    "uzp+/Y6zg7e+uoKo3Nd76troO4fWR2/4bFanVyQcJQyWcBM/LwFliemFXcuqPNddHlr+ojranQbWvTVM1T3cwTfxAcCczXXP4fOX"
    "r02VeaaGSuDJZr440p886x6dXs2EOfhWPARtbQAw7xeeOEaN8axjnpmHEmfdXcNUrW1wtoEi/i0AgM8PXbxVYjoy6gr0xFl36/RK"
    "bYODb2bitzZ/dmBkhkx7Ah0Jsy5hg0OnV2ob/G2/iJktFQ/qNLDuzo6UaxukcPBdgk0WxzySZN2dHbH4n0DYBzEPeEuhiOMfVda1"
    "0IWUpqbEG0ub7gEBou6S7rhYX6c9ViUq/5iQcHcs7Q9AgIDuN+os4o+LdevkWn/ZlICV+/atNIPcnR1R/A0QKGH3h/Ue24iP9bu7"
    "vEpOws4J5onfMYHcnR1RPIJCSBjkaCcSZ8J6kfmAS7+jhKeZi0XmvQaQe7Ij1Ac5CfubJd3ekpJT66pKzt5VFLNS/GTsyN3ZEYv+"
    "o10IeC4R3MysWJ3sB0CJKEV1V7HoQnvMJ12csRVmUrwDAF5gKxncJf2+yn63NX9fnv/4gbuzI0z8vXZY9N3kcNv6/cHrm7u6Nr8+"
    "XX4zin2pe2xSxf/6M/DQseZqcz3rV65UDwOS4kGjuJn4W/lP/2PSuEs+UMURIsXPxFtF5/K97DF+5ifNs1pCtZzBrGxAy+VU4DZZ"
    "ZaPhOz5HO07czeGb5yTfacTd4jshvu10QPAgmo1816XyYteLIXxHnAwUavAFqidjaTdDKqX8QtoaOhOFcd2sxSye0WSjZwAchdr7"
    "J3XgrjaL4eFXRieLoEJ8+rbCiie3ofcPZ4Z73zcDcEcDXg/fzLrUbq3Rs31lvi1X4n6GKfAwvk3Jd1lYfcn80OFMGQ/PWOZVk/U5"
    "VRK5l88f7qkGeOuMaVQ8qHKXmYgbJhWZ9zRPnzuYXta1MFLBTpX73NItxygi73bYsUl8k4/pmZRolVLJjXUXcoaf1pj1vz1cv+Zi"
    "eoY/hQ13F3IFHOPGreHb5nriwpHemTOt473/pNUA66T4QNx5NB3fNtd0bMvSXDxM63jvHqqbdTvKFG/mVMM3lbjuiZdpb/waoH+k"
    "WBfrJmqiNblui5mHn7C5NlloK+pl3URNtJdvqpTfNKPEVmI9ncTM821Ltl1wJZtTVC1qdxIzUgPvqmWxJftwk0vsyp3EqIl8g4A9"
    "FdwOyW5y8YXdSSxA0o3wjfC75Ro9i9k62STJ1pVerAmQdCN8S1h7zw4NVQptZELHJYIKTMyccSkdNklFQZ3QSrqZM00I4oekUlJC"
    "qZV0Q2eaEPDf6AHz9Mn+VJRK+yTd2Bk2AV9l/vDI6tQUx7sl3dwZNoTcl37/l1NSGO+Q9NJGY/rMIqaqMY+zsMfgmUU0VxY5AyO6"
    "VMr19Kw5q1m3ebFzgnliZ4Rqh4xPlKCVvwZ/964gmGsjcoFu5kVDoLlrfFujNVqjNVqjNVqjNVojDeP/AWnL0N0MNvGkAAAAAElF"
    "TkSuQmCC"
)


def _hex_to_rgb(value: Any) -> tuple[int, int, int]:
    text = str(value).strip().lstrip("#")
    return (int(text[0:2], 16), int(text[2:4], 16), int(text[4:6], 16))


_LUMO_L_MASK_CACHE: Any = None
_LUMO_L_MASK_LOCK = threading.Lock()


def _lumo_l_mask() -> Any:
    """Return the blackletter L as an 8-bit alpha mask (decoded once from the embedded PNG).

    The lock matters: the icon frames are rendered on a background thread and a colour
    change starts another render, so two threads could otherwise both decode the picture.
    """
    global _LUMO_L_MASK_CACHE
    if _LUMO_L_MASK_CACHE is None:
        with _LUMO_L_MASK_LOCK:
            if _LUMO_L_MASK_CACHE is None:
                import base64
                import io
                from PIL import Image

                _LUMO_L_MASK_CACHE = Image.open(io.BytesIO(base64.b64decode(_LUMO_L_MASK_B64))).convert("L")
    return _LUMO_L_MASK_CACHE


def _lumo_icon_frame(size: int, phase: float = 0.0, accent: Any = None):
    """Render one frame of the Lumo app icon at ``size`` px, supersampled for crisp edges.

    Design: a full black squircle with a white blackletter L, and a faint light sweep.
    ``phase`` runs 0..1 over one loop. ``accent`` (a #RRGGBB colour) fills the L; white when omitted.
    """
    from PIL import Image, ImageChops, ImageDraw, ImageFilter

    ss = 4 if size <= 64 else 2
    s = size * ss

    tile = Image.new("RGBA", (s, s), (4, 4, 5, 255))

    mask = Image.new("L", (s, s), 0)
    ImageDraw.Draw(mask).rounded_rectangle((0, 0, s - 1, s - 1), radius=int(s * 0.22), fill=255)

    # Faint light band sweeping across the black tile.
    band = Image.new("L", (s, s), 0)
    center = (-0.6 + 1.9 * phase) * s
    width = 0.22 * s
    ImageDraw.Draw(band).polygon(
        [(center - width, 0), (center + width * 0.2, 0), (center - width * 0.2 + s * 0.9, s),
         (center - width * 1.2 + s * 0.9, s)],
        fill=18,
    )
    band = band.filter(ImageFilter.GaussianBlur(s * 0.06))
    light = Image.new("RGBA", (s, s), (235, 235, 240, 255))
    light.putalpha(ImageChops.multiply(band, mask))
    tile = Image.alpha_composite(tile, light)

    # White blackletter L, centred, scaled to about 62 percent of the tile height.
    source = _lumo_l_mask()
    target_h = int(s * 0.62)
    target_w = int(source.width * target_h / source.height)
    letter = source.resize((target_w, target_h), Image.LANCZOS)
    glyph = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    ink_rgb = _hex_to_rgb(accent) if _is_hex_colour(accent) else (250, 250, 252)
    ink = Image.new("RGBA", (target_w, target_h), ink_rgb + (255,))
    glyph.paste(ink, (int((s - target_w) / 2), int((s - target_h) / 2)), letter)
    tile = Image.alpha_composite(tile, glyph)

    # Thin edge so the black tile reads on a dark taskbar.
    border = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    ImageDraw.Draw(border).rounded_rectangle(
        (s * 0.006, s * 0.006, s * 0.994, s * 0.994), radius=int(s * 0.22),
        outline=(255, 255, 255, 40), width=max(1, int(s * 0.012)),
    )
    tile = Image.alpha_composite(tile, border)

    out = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    out.paste(tile, (0, 0), mask)
    return out.resize((size, size), Image.LANCZOS)


def _start_taskbar_icon_animation(app: Any, module: ModuleType) -> None:
    """Animate the window icon (taskbar and title bar): an accent-coloured L with a light sweep.

    Frames are rendered in a background thread at each Windows icon size, then swapped in
    on the Tk thread about nine times a second. When the accent colour changes, the frames
    are rendered again in the new colour. The .exe icon stays the static Lumo_icon.ico.
    """
    frame_count = 12
    sizes = [16, 24, 32, 48, 256]
    token = object()
    app._lumo_icon_token = token

    def current_accent() -> str:
        return str(getattr(module, "ACCENT", "#8871FF"))

    def start_for(accent: str) -> None:
        result: dict[str, Any] = {"frames": None, "error": None}

        def render() -> None:
            try:
                frames = []
                for index in range(frame_count):
                    frames.append([_lumo_icon_frame(size, index / frame_count, accent) for size in sizes])
                    # Hand the interpreter back to the window thread between frames so the
                    # render never makes the interface stutter.
                    time.sleep(0.006)
                result["frames"] = frames
            except Exception as exc:
                result["error"] = exc

        threading.Thread(target=render, daemon=True).start()

        def wait_then_start(attempt: int = 0) -> None:
            if app._lumo_icon_token is not token or result["error"] is not None:
                return
            if result["frames"] is None:
                if attempt < 400:
                    app.after(50, lambda: wait_then_start(attempt + 1))
                return
            try:
                from PIL import ImageTk
            except Exception:
                return
            photos: list = []
            app._lumo_icon_photos = photos  # keep references alive
            state = {"index": 0, "accent": accent, "pending": None, "pending_at": 0.0}

            def build_photos(position: int = 0) -> None:
                # One frame (five sizes) per timer tick instead of all sixty pictures at
                # once, which used to freeze the window for about 80 ms.
                if app._lumo_icon_token is not token:
                    return
                if position < len(result["frames"]):
                    try:
                        photos.append([ImageTk.PhotoImage(img, master=app) for img in result["frames"][position]])
                        app.after(12, lambda: build_photos(position + 1))
                    except Exception:
                        pass
                    return
                tick()

            def tick() -> None:
                if app._lumo_icon_token is not token:
                    return
                wanted = current_accent()
                if wanted != state["accent"]:
                    # Re-render only once the colour has stopped changing for a moment,
                    # not on every step while a colour is being dragged.
                    now = time.monotonic()
                    if state["pending"] != wanted:
                        state["pending"], state["pending_at"] = wanted, now
                    elif now - state["pending_at"] >= 0.8:
                        start_for(wanted)
                        return
                else:
                    state["pending"] = None
                # Keep the icon animating, but do not swap it while the window is being
                # resized (the swap is a window-manager call that competes with the resize).
                if time.monotonic() >= float(getattr(app, "_lumo_resizing_until", 0.0) or 0.0):
                    try:
                        app.iconphoto(True, *photos[state["index"]])
                    except Exception:
                        return
                    state["index"] = (state["index"] + 1) % frame_count
                try:
                    app.after(200, tick)
                except Exception:
                    pass

            build_photos()

        wait_then_start()

    start_for(current_accent())


_TASKBAR_ICON_ANIMATION = True


def _install_taskbar_icon(module: ModuleType) -> None:
    app_class = getattr(module, "App", None)
    if app_class is None:
        return
    original_init = app_class.__init__
    if getattr(original_init, "_lumo_taskbar_icon", False):
        return

    def init_with_taskbar_icon(self: Any, *args: Any, **kwargs: Any) -> Any:
        result = original_init(self, *args, **kwargs)
        # The animated window icon is kept (flag defaults to True). It only skips an icon
        # swap while the window is being resized. Set _TASKBAR_ICON_ANIMATION = False to
        # turn the animation off completely.
        if _TASKBAR_ICON_ANIMATION:
            try:
                self.after(1400, lambda target=self: _start_taskbar_icon_animation(target, module))
            except Exception:
                pass
        return result

    init_with_taskbar_icon._lumo_taskbar_icon = True  # type: ignore[attr-defined]
    app_class.__init__ = init_with_taskbar_icon


class _TaskbarProgress:
    """Windows taskbar button progress (the green bar browsers draw over their icon).

    Uses the ITaskbarList3 COM interface through ctypes: no extra packages, no threads,
    and a call is made only when the state or the whole-number percentage changes.
    """
    NONE, INDETERMINATE, NORMAL, ERROR, PAUSED = 0, 1, 2, 4, 8

    def __init__(self, window: Any) -> None:
        self.window = window
        self.ok = False
        self.ptr = None
        self.last: tuple[int, int] | None = None
        if sys.platform != "win32":
            return
        try:
            import ctypes
            from ctypes import wintypes
            self.ctypes = ctypes
            ole32 = ctypes.windll.ole32
            ole32.CoInitialize(None)

            class GUID(ctypes.Structure):
                _fields_ = [("a", ctypes.c_uint32), ("b", ctypes.c_uint16),
                            ("c", ctypes.c_uint16), ("d", ctypes.c_ubyte * 8)]

            def guid(text: str) -> Any:
                import uuid
                u = uuid.UUID(text)
                g = GUID()
                g.a, g.b, g.c = u.time_low, u.time_mid, u.time_hi_version
                for i, byte in enumerate(u.bytes[8:]):
                    g.d[i] = byte
                return g

            clsid = guid("56FDF344-FD6D-11d0-958A-006097C9A090")
            iid = guid("EA1AFB91-9E28-4B86-90E9-9E9F8A5EEFAF")
            ole32.CoCreateInstance.argtypes = [ctypes.c_void_p, ctypes.c_void_p, wintypes.DWORD,
                                               ctypes.c_void_p, ctypes.POINTER(ctypes.c_void_p)]
            ole32.CoCreateInstance.restype = ctypes.c_long
            ptr = ctypes.c_void_p()
            hr = ole32.CoCreateInstance(ctypes.byref(clsid), None, 1, ctypes.byref(iid), ctypes.byref(ptr))
            if hr != 0 or not ptr.value:
                return
            self.ptr = ptr
            vtable = ctypes.cast(ctypes.cast(ptr, ctypes.POINTER(ctypes.c_void_p))[0],
                                 ctypes.POINTER(ctypes.c_void_p))
            proto = ctypes.WINFUNCTYPE
            hr_init = proto(ctypes.c_long, ctypes.c_void_p)(vtable[3])
            self._set_value = proto(ctypes.c_long, ctypes.c_void_p, wintypes.HWND,
                                    ctypes.c_ulonglong, ctypes.c_ulonglong)(vtable[9])
            self._set_state = proto(ctypes.c_long, ctypes.c_void_p, wintypes.HWND, ctypes.c_int)(vtable[10])
            self.ok = hr_init(ptr) == 0
        except Exception:
            self.ok = False

    def _hwnd(self) -> Any:
        ctypes = self.ctypes
        user32 = ctypes.windll.user32
        user32.GetAncestor.restype = ctypes.c_void_p
        user32.GetAncestor.argtypes = [ctypes.c_void_p, ctypes.c_uint]
        return user32.GetAncestor(self.window.winfo_id(), 2)  # GA_ROOT

    def update(self, state: int, percent: float = 0.0) -> None:
        if not self.ok:
            return
        key = (state, int(percent))
        if key == self.last:
            return
        self.last = key
        try:
            hwnd = self._hwnd()
            if not hwnd:
                return
            self._set_state(self.ptr, hwnd, state)
            if state in (self.NORMAL, self.ERROR, self.PAUSED):
                self._set_value(self.ptr, hwnd, int(max(0.0, min(100.0, percent)) * 10), 1000)
        except Exception:
            pass


def _install_taskbar_progress(module: ModuleType) -> None:
    """Show download progress on the taskbar icon: green bar, yellow when paused, red on error."""
    app_class = getattr(module, "App", None)
    original = getattr(app_class, "handle_event", None) if app_class is not None else None
    if not callable(original) or getattr(original, "_lumo_taskbar_progress", False):
        return

    def sync(app: Any) -> None:
        bar = getattr(app, "_lumo_taskbar_bar", None)
        if bar is None:
            return
        app._lumo_taskbar_polling = False
        try:
            if getattr(app, "active_job_id", None) is None:
                if time.monotonic() >= float(getattr(app, "_lumo_taskbar_error_until", 0.0)):
                    bar.update(_TaskbarProgress.NONE)
                else:
                    app._lumo_taskbar_polling = True
                    app.after(500, lambda a=app: sync(a))
                return
            try:
                percent = float(getattr(app, "progress_value", 0.0) or 0.0)
            except (TypeError, ValueError):
                percent = 0.0
            job = getattr(app, "_lumo_active_download_job", None)
            paused = False
            try:
                paused = bool(job is not None and job.is_paused())
            except Exception:
                pass
            if paused:
                bar.update(_TaskbarProgress.PAUSED, percent)
            elif percent <= 0.0:
                bar.update(_TaskbarProgress.INDETERMINATE)
            else:
                bar.update(_TaskbarProgress.NORMAL, percent)
            # Keeps running only while a download is active, so an idle app does no work.
            app._lumo_taskbar_polling = True
            app.after(500, lambda a=app: sync(a))
        except Exception:
            pass

    def handle_event_with_taskbar(self: Any, kind: Any, payload: Any = None, *args: Any, **kwargs: Any) -> Any:
        result = original(self, kind, payload, *args, **kwargs)
        try:
            if getattr(self, "_lumo_taskbar_bar", None) is None:
                self._lumo_taskbar_bar = _TaskbarProgress(self)
            if str(kind).casefold() == "error" and getattr(self, "_lumo_taskbar_bar", None) is not None:
                self._lumo_taskbar_error_until = time.monotonic() + 3.0
                self._lumo_taskbar_bar.update(_TaskbarProgress.ERROR, 100.0)
            if not getattr(self, "_lumo_taskbar_polling", False):
                sync(self)
            elif getattr(self, "active_job_id", None) is None:
                sync(self)
        except Exception:
            pass
        return result

    handle_event_with_taskbar._lumo_taskbar_progress = True  # type: ignore[attr-defined]
    app_class.handle_event = handle_event_with_taskbar


def _install_brand_logo(module: ModuleType) -> None:
    """Replace the sidebar 'Y' tile with the Lumo mark: a black tile and an accent-coloured L.

    Painted.redraw draws the accent squircle first and then calls draw_content, so this
    paints a sidebar-coloured backing (hiding the squircle's corners), then the mark.
    After every palette change the logo is redrawn so the L follows the new accent.
    """
    logo_class = getattr(module, "Logo", None)
    if logo_class is None or getattr(logo_class.draw_content, "_lumo_brand_logo", False):
        return

    def draw_brand_logo(self: Any, *args: Any, **kwargs: Any) -> None:
        try:
            self.delete("content")
        except Exception:
            pass
        try:
            width = int(float(self.cget("width")))
            height = int(float(self.cget("height")))
        except Exception:
            width, height = 26, 28
        sidebar = str(getattr(module, "SIDEBAR", "#0E0F14"))
        try:
            self.create_rectangle(0, 0, width, height, fill=sidebar, outline=sidebar, tags=("content",))
        except Exception:
            pass
        size = max(8, min(width, height))
        accent = str(getattr(module, "ACCENT", "#8871FF"))
        try:
            root = self.winfo_toplevel()
            cache = getattr(root, "_lumo_brand_cache", None)
            if cache is None:
                cache = {}
                root._lumo_brand_cache = cache  # type: ignore[attr-defined]
            key = (size, accent)
            photo = cache.get(key)
            if photo is None:
                from PIL import ImageTk
                photo = ImageTk.PhotoImage(_lumo_icon_frame(size, 0.35, accent), master=root)
                cache.clear()  # keep only the current accent in memory
                cache[key] = photo
            self._lumo_brand_photo = photo
            self.create_image(width / 2, height / 2, image=photo, anchor="center", tags=("content",))
        except Exception:
            pass

    draw_brand_logo._lumo_brand_logo = True  # type: ignore[attr-defined]
    logo_class.draw_content = draw_brand_logo

    original_palette = getattr(module, "apply_palette", None)
    if callable(original_palette) and not getattr(original_palette, "_lumo_logo_refresh", False):
        def palette_then_redraw_logo(*args: Any, **kwargs: Any) -> Any:
            result = original_palette(*args, **kwargs)
            app = getattr(module, "_LUMO_APP_INSTANCE", None)
            if app is not None:
                for widget in _walk_widgets(app):
                    if isinstance(widget, logo_class):
                        try:
                            widget.redraw()
                        except Exception:
                            pass
            return result
        palette_then_redraw_logo._lumo_logo_refresh = True  # type: ignore[attr-defined]
        module.apply_palette = palette_then_redraw_logo


def _apply_lumo_names(app: Any) -> None:
    """Show the name Lumo in the window title and the sidebar brand.

    The recovered UI draws its brand text and title itself, and the earlier constant
    patch did not take effect. This sets the visible text directly, and is repeated after
    startup and page changes so the recovered code cannot put the old name back.
    """
    try:
        app.title("Lumo")
    except Exception:
        pass
    for widget in _walk_widgets(app):
        try:
            text = str(widget.cget("text"))
        except Exception:
            continue
        if text.strip().upper() == "VIDEO STUDIO":
            try:
                widget.destroy()
            except Exception:
                pass


def _install_lumo_names(module: ModuleType) -> None:
    app_class = getattr(module, "App", None)
    if app_class is None:
        return
    original_init = app_class.__init__
    if getattr(original_init, "_lumo_lumo_names", False):
        return

    def init_with_lumo_names(self: Any, *args: Any, **kwargs: Any) -> Any:
        result = original_init(self, *args, **kwargs)
        for delay in (0, 400):
            try:
                self.after(delay, lambda target=self: _apply_lumo_names(target))
            except Exception:
                pass
        return result

    init_with_lumo_names._lumo_lumo_names = True  # type: ignore[attr-defined]
    app_class.__init__ = init_with_lumo_names


def _install_perf_logging(module: ModuleType) -> None:
    """Optional timing log for diagnosing stutter. Off unless the environment sets LUMO_PERF=1.

    Writes one line per page switch and Settings open to lumo_perf.log in the user's temp
    folder, with the time each call took in milliseconds.
    """
    if os.environ.get("LUMO_PERF") != "1":
        return
    log_path = Path(tempfile.gettempdir()) / "lumo_perf.log"
    app_class = getattr(module, "App", None)
    if app_class is None:
        return

    def record(label: str, started: float) -> None:
        try:
            elapsed = (time.perf_counter() - started) * 1000.0
            with log_path.open("a", encoding="utf-8") as handle:
                handle.write(f"{time.strftime('%H:%M:%S')}  {label:<28} {elapsed:8.1f} ms\n")
        except Exception:
            pass

    def timed(name: str, function: Any) -> Any:
        def wrapper(self: Any, *args: Any, **kwargs: Any) -> Any:
            started = time.perf_counter()
            try:
                return function(self, *args, **kwargs)
            finally:
                label = name
                if args and isinstance(args[0], str):
                    label = f"{name}({args[0]})"
                record(label, started)
        wrapper._lumo_perf = True  # type: ignore[attr-defined]
        return wrapper

    for name in ("show_page", "_show_settings_tab", "refresh_history", "render_download_stage"):
        method = getattr(app_class, name, None)
        if callable(method) and not getattr(method, "_lumo_perf", False):
            setattr(app_class, name, timed(name, method))
    try:
        log_path.write_text(f"Lumo performance log started {time.strftime('%Y-%m-%d %H:%M:%S')}\n",
                            encoding="utf-8")
    except Exception:
        pass


def _cap_redraw_rate(module: ModuleType) -> None:
    """Redraw animated Painted widgets at about 60 Hz instead of 125 Hz.

    Painted.request_redraw schedules a full canvas rebuild after 8 ms. During a page
    switch several sidebar rows and buttons animate at once, so the UI thread was asked
    to rebuild every canvas about 125 times per second. A 16 ms interval matches the
    display refresh, so the visible motion is the same while the UI thread does half
    the work. The compiled function is patched only where its constant is exactly 8.
    """
    painted = getattr(module, "Painted", None)
    method = getattr(painted, "request_redraw", None)
    code = getattr(method, "__code__", None)
    if code is None or getattr(method, "_lumo_rate", False):
        return
    if 8 not in code.co_consts:
        return
    try:
        consts = tuple(16 if (type(value) is int and value == 8) else value for value in code.co_consts)
        method.__code__ = code.replace(co_consts=consts)
        method._lumo_rate = True  # type: ignore[attr-defined]
    except Exception:
        pass


def _base_language(code: Any) -> str:
    return re.split(r"[-_]", str(code).strip().casefold(), maxsplit=1)[0]


def _apply_subtitle_availability(app: Any) -> None:
    """Disable and deselect subtitle chips not present in the inspected video."""
    info = getattr(app, "video_info", None)
    if not isinstance(info, dict):
        return
    offered_value = info.get("subtitles_available")
    if offered_value is None:
        offered_value = info.get("subtitle_languages")
    tracks_known = bool(info.get("_subtitle_tracks_known", offered_value is not None))
    # Do not guess when inspection did not return subtitle metadata. An explicitly
    # known empty list, however, means no language chip is available.
    if not tracks_known:
        return
    if not isinstance(offered_value, (list, tuple, set)):
        offered_value = []
    offered = [str(code).strip() for code in offered_value if str(code).strip()]
    applied_key = (id(info), tuple(sorted(offered)))
    if getattr(app, "_lumo_applied_subtitles", None) == applied_key:
        return
    app._lumo_applied_subtitles = applied_key
    offered_bases = {_base_language(code) for code in offered}
    chips = getattr(app, "subtitle_chips", None)
    if isinstance(chips, dict):
        items = list(chips.items())
    elif isinstance(chips, (list, tuple)):
        items = [(getattr(chip, "code", None), chip) for chip in chips]
    else:
        return
    selected = getattr(app, "subtitle_selection", None)
    for code, chip in items:
        key = str(code or "").strip()
        if not key or key.casefold() in {"none", "off"}:
            continue
        available = key in offered or _base_language(key) in offered_bases
        setter = getattr(chip, "set_enabled", None)
        if callable(setter):
            try:
                setter(available)
            except Exception:
                pass
        if not available:
            try:
                chip.set_selected(False)
            except Exception:
                pass
            if isinstance(selected, set):
                selected.discard(key)
            elif isinstance(selected, list):
                try:
                    selected.remove(key)
                except ValueError:
                    pass


def _install_subtitle_availability(module: ModuleType) -> None:
    app_class = getattr(module, "App", None)
    original = getattr(app_class, "build_subtitle_chips", None)
    if not callable(original) or getattr(original, "_lumo_subtitle_availability", False):
        return

    def build_subtitle_chips_checked(self: Any, *args: Any, **kwargs: Any) -> Any:
        result = original(self, *args, **kwargs)
        _apply_subtitle_availability(self)
        return result

    build_subtitle_chips_checked._lumo_subtitle_availability = True  # type: ignore[attr-defined]
    app_class.build_subtitle_chips = build_subtitle_chips_checked


def _invalidate_subtitle_availability(app: Any, url: str | None = None) -> None:
    """Discard availability tied to an older URL without guessing about the new video."""
    if url is None:
        try:
            url = str(app.url_entry.get()).strip()
        except Exception:
            url = ""
    url = str(url or "").strip()
    previous = getattr(app, "_lumo_subtitle_availability_url", None)
    if previous == url:
        return

    app._lumo_subtitle_availability_url = url
    app._lumo_subtitle_request_url = None
    # The old metadata must not be used for a new link while its inspection is pending.
    try:
        app.video_info = None
    except Exception:
        pass

    chips = getattr(app, "subtitle_chips", None)
    values = chips.values() if isinstance(chips, dict) else (
        chips if isinstance(chips, (list, tuple)) else ()
    )
    # Until the new video's metadata arrives, availability is unknown. Re-enable
    # controls instead of falsely showing stale unavailable states; preserve selection.
    for chip in values:
        setter = getattr(chip, "set_enabled", None)
        if callable(setter):
            try:
                setter(True)
            except Exception:
                pass


def _install_subtitle_availability_refresh(module: ModuleType) -> None:
    """Refresh subtitle chips after inspection events and invalidate them on URL changes."""
    app_class = getattr(module, "App", None)
    if app_class is None:
        return

    original_init = getattr(app_class, "__init__", None)
    if callable(original_init) and not getattr(original_init, "_lumo_subtitle_url_binding", False):
        def init_with_subtitle_url_binding(self: Any, *args: Any, **kwargs: Any) -> Any:
            result = original_init(self, *args, **kwargs)
            entry = getattr(self, "url_entry", None)
            if entry is not None and not getattr(entry, "_lumo_subtitle_url_binding", False):
                def invalidate_on_edit(_event: Any = None) -> None:
                    _invalidate_subtitle_availability(self)
                try:
                    entry.bind("<KeyRelease>", invalidate_on_edit, add="+")
                    entry.bind("<<Paste>>", invalidate_on_edit, add="+")
                    entry._lumo_subtitle_url_binding = True
                except Exception:
                    pass
            return result
        init_with_subtitle_url_binding._lumo_subtitle_url_binding = True  # type: ignore[attr-defined]
        app_class.__init__ = init_with_subtitle_url_binding

    original_inspect = getattr(app_class, "inspect", None)
    if callable(original_inspect) and not getattr(original_inspect, "_lumo_invalidate_subtitles", False):
        def inspect_with_fresh_subtitles(self: Any, *args: Any, **kwargs: Any) -> Any:
            _invalidate_subtitle_availability(self)
            try:
                self._lumo_subtitle_request_url = str(self.url_entry.get()).strip()
            except Exception:
                self._lumo_subtitle_request_url = None
            return original_inspect(self, *args, **kwargs)
        inspect_with_fresh_subtitles._lumo_invalidate_subtitles = True  # type: ignore[attr-defined]
        app_class.inspect = inspect_with_fresh_subtitles

    original_event = getattr(app_class, "handle_event", None)
    if callable(original_event) and not getattr(original_event, "_lumo_refresh_subtitles", False):
        def handle_event_refreshing_subtitles(self: Any, *args: Any, **kwargs: Any) -> Any:
            result = original_event(self, *args, **kwargs)
            try:
                current_url = str(self.url_entry.get()).strip()
            except Exception:
                current_url = ""
            request_url = str(getattr(self, "_lumo_subtitle_request_url", "") or "").strip()
            # Ignore results while no inspection for the current URL is pending/active.
            if current_url and request_url and current_url == request_url:
                info = getattr(self, "video_info", None)
                if isinstance(info, dict):
                    self._lumo_subtitle_availability_url = current_url
                    _apply_subtitle_availability(self)
            else:
                event_kind = str(args[0] if args else kwargs.get("kind", "")).casefold()
                if "inspect" in event_kind:
                    # An inspection result without a matching current request is stale.
                    try:
                        self.video_info = None
                    except Exception:
                        pass
            return result
        handle_event_refreshing_subtitles._lumo_refresh_subtitles = True  # type: ignore[attr-defined]
        app_class.handle_event = handle_event_refreshing_subtitles


def _strip_extra_status_text(module: ModuleType) -> None:
    _strip_compiled_text(module, "App.handle_event", "Downloading video…  Progress details are below.")
    _strip_compiled_text(module, "App.begin_worker", "Preparing video and audio streams…")


def _strip_compiled_text(module: ModuleType, qualified: str, text: str) -> None:
    """Remove one redundant caption from a compiled method, including nested callbacks.

    Recovered Tkinter methods sometimes create a nested callback that owns the visible
    string constant. Walk nested code objects too, so the repair does not depend on which
    level of the recovered method contains the label.
    """
    class_name, method_name = qualified.split(".", 1)
    owner = getattr(module, class_name, None)
    method = getattr(owner, method_name, None)
    code = getattr(method, "__code__", None)
    if code is None:
        return

    code_type = type(code)

    def replace_in_code(current: Any) -> tuple[Any, bool]:
        changed = False
        constants = []
        for value in current.co_consts:
            if value == text:
                constants.append("")
                changed = True
            elif isinstance(value, code_type):
                nested, nested_changed = replace_in_code(value)
                constants.append(nested)
                changed = changed or nested_changed
            else:
                constants.append(value)
        return (current.replace(co_consts=tuple(constants)), True) if changed else (current, False)

    try:
        patched, changed = replace_in_code(code)
        if changed:
            method.__code__ = patched
    except Exception:
        # Caption removal must never prevent the recovered application from launching.
        pass


_UNWANTED_DOWNLOAD_CAPTIONS = (
    "progress details are below",
    "see progress below",
    "video is downloading",
    "preparing video and audio streams",
    "resolving video formats",
    "contacting the video site",
    "calculating speed",
    "eta unknown",
)


def _is_unwanted_download_caption(value: Any) -> bool:
    """Match only the three redundant progress/status captions reported by the user."""
    text = re.sub(r"\s+", " ", str(value or "")).strip().casefold()
    if not text:
        return False
    return any(phrase in text for phrase in _UNWANTED_DOWNLOAD_CAPTIONS)


def _install_status_caption_filter(module: ModuleType) -> None:
    """Prevent redundant stage captions from reappearing through App.set_status."""
    app_class = getattr(module, "App", None)
    original = getattr(app_class, "set_status", None)
    if not callable(original) or getattr(original, "_lumo_status_caption_filter", False):
        return

    def set_status_without_extra_caption(self: Any, *args: Any, **kwargs: Any) -> Any:
        if args and _is_unwanted_download_caption(args[0]):
            args = ("", *args[1:])
        elif "text" in kwargs and _is_unwanted_download_caption(kwargs.get("text")):
            kwargs = dict(kwargs)
            kwargs["text"] = ""
        return original(self, *args, **kwargs)

    set_status_without_extra_caption._lumo_status_caption_filter = True  # type: ignore[attr-defined]
    app_class.set_status = set_status_without_extra_caption


def _clear_unwanted_meta_text(app: Any) -> None:
    """The compiled UI writes the caption into active_meta_var. Clear it directly."""
    var = getattr(app, "active_meta_var", None)
    if var is None:
        return
    try:
        if _is_unwanted_download_caption(var.get()):
            var.set("")
    except Exception:
        pass


def _blank_extra_caption(app: Any) -> None:
    """Clear redundant Download-page captions, whether drawn from text or a variable."""
    pages = getattr(app, "pages", None)
    page = pages.get("download") if isinstance(pages, dict) else None
    if page is None:
        return
    for widget in _walk_widgets(page):
        text = _widget_text(widget)
        if _is_unwanted_download_caption(text):
            try:
                widget.configure(text="")
            except Exception:
                pass
        try:
            variable_name = str(widget.cget("textvariable") or "")
        except Exception:
            variable_name = ""
        if variable_name:
            try:
                if _is_unwanted_download_caption(widget.getvar(variable_name)):
                    widget.setvar(variable_name, "")
            except Exception:
                pass


def _install_caption_cleanup(module: ModuleType) -> None:
    app_class = getattr(module, "App", None)
    if app_class is None:
        return

    for method_name in ("handle_event", "begin_worker", "render_download_stage",
                        "continue_to_extras", "start_download"):
        original = getattr(app_class, method_name, None)
        marker = f"_lumo_caption_cleanup_{method_name}"
        if not callable(original) or getattr(original, marker, False):
            continue

        def clean_after_call(self: Any, *args: Any, _original=original, _method=method_name, **kwargs: Any) -> Any:
            try:
                return _original(self, *args, **kwargs)
            finally:
                # handle_event runs for every progress tick; walking the widget tree on each
                # one is what made the app stutter. Clean at most every 0.75 s for those events.
                try:
                    _clear_unwanted_meta_text(self)
                    now = time.monotonic()
                    if _method != "handle_event" or now - getattr(self, "_lumo_caption_last_clean", 0.0) >= 0.75:
                        self._lumo_caption_last_clean = now
                        _blank_extra_caption(self)
                except Exception:
                    pass

        setattr(clean_after_call, marker, True)
        setattr(app_class, method_name, clean_after_call)


def _install_subtitle_warning_notice(module: ModuleType) -> None:
    """Show a subtitle-only completion warning in the existing inline status area."""
    app_class = getattr(module, "App", None)
    original = getattr(app_class, "handle_event", None)
    if not callable(original) or getattr(original, "_lumo_subtitle_warning_notice", False):
        return

    def handle_event_with_subtitle_warning(self: Any, kind: Any, payload: Any,
                                           *args: Any, **kwargs: Any) -> Any:
        result = original(self, kind, payload, *args, **kwargs)
        try:
            if (str(kind).casefold() == "done" and isinstance(payload, dict)
                    and str(payload.get("status", "")).casefold() == "completed"):
                warning = str(payload.get("warning") or "").strip()
                setter = getattr(self, "set_status", None)
                if warning and callable(setter):
                    setter(warning[:700], getattr(module, "WARN", None))
        except Exception:
            # An informational subtitle warning must never break completion handling.
            pass
        return result

    handle_event_with_subtitle_warning._lumo_subtitle_warning_notice = True  # type: ignore[attr-defined]
    app_class.handle_event = handle_event_with_subtitle_warning


def _install_subtitle_selection_fix(module: ModuleType) -> None:
    """Let a language chip be selected whenever inspection explicitly offers it.

    The recovered toggle ignores clicks on chips whose ``enabled`` flag is off. A
    chip can be left disabled after a stale availability pass, so an offered
    language appeared but could not be picked. Only chips that the current
    video's metadata lists are re-enabled; unavailable ones stay dimmed.
    """
    app_class = getattr(module, "App", None)
    original = getattr(app_class, "toggle_subtitle", None)
    if not callable(original) or getattr(original, "_lumo_subtitle_select_fix", False):
        return

    def toggle_subtitle_fixed(self: Any, code: Any, *args: Any, **kwargs: Any) -> Any:
        try:
            chips = getattr(self, "subtitle_chips", None)
            chip = chips.get(code) if isinstance(chips, dict) else None
            info = getattr(self, "video_info", None)
            if (chip is not None and not getattr(chip, "enabled", True)
                    and isinstance(info, dict) and info.get("_subtitle_tracks_known")):
                offered = info.get("subtitles_available")
                if offered is None:
                    offered = info.get("subtitle_languages")
                offered = [str(c).strip() for c in (offered or []) if str(c).strip()]
                key = str(code).strip()
                if key in offered or _base_language(key) in {_base_language(c) for c in offered}:
                    setter = getattr(chip, "set_enabled", None)
                    if callable(setter):
                        setter(True)
        except Exception:
            # Selection must never break because of this helper; fall back to the original.
            pass
        return original(self, code, *args, **kwargs)

    toggle_subtitle_fixed._lumo_subtitle_select_fix = True  # type: ignore[attr-defined]
    app_class.toggle_subtitle = toggle_subtitle_fixed


def _link_text(app: Any) -> str:
    try:
        return str(app.url_entry.get()).strip()
    except Exception:
        return ""


def _install_pending_download_actions(module: ModuleType) -> None:
    """Continue and Download wait for inspection instead of silently doing nothing.

    The recovered code ignores these actions when no inspection result is loaded.
    Here the action is queued, the link is inspected, and the action runs as soon as
    the result arrives. If inspection fails, the normal error panel explains why.
    """
    app_class = getattr(module, "App", None)
    if app_class is None:
        return
    original_handle = getattr(app_class, "handle_event", None)
    if callable(original_handle) and not getattr(original_handle, "_lumo_pending_actions", False):
        def handle_event_with_pending(self: Any, *args: Any, **kwargs: Any) -> Any:
            result = original_handle(self, *args, **kwargs)
            name = getattr(self, "_lumo_pending_action", None)
            if name:
                stage = str(getattr(self, "stage", "")).casefold()
                info = getattr(self, "video_info", None)
                if stage != "loading" and isinstance(info, dict):
                    self._lumo_pending_action = None
                    action = getattr(self, name, None)
                    if callable(action):
                        try:
                            action()
                        except Exception as exc:
                            _report_ui_error(self, module, name, exc)
                elif stage in {"error", "idle"}:
                    self._lumo_pending_action = None
            return result
        handle_event_with_pending._lumo_pending_actions = True  # type: ignore[attr-defined]
        app_class.handle_event = handle_event_with_pending

    def wrap_action(method_name: str) -> None:
        original = getattr(app_class, method_name, None)
        if not callable(original) or getattr(original, "_lumo_pending_wrapper", False):
            return

        def action_waiting_for_inspection(self: Any, *args: Any, **kwargs: Any) -> Any:
            text = _link_text(self)
            info = getattr(self, "video_info", None)
            if text.startswith(("http://", "https://")) and not isinstance(info, dict):
                if getattr(self, "active_job_id", None) is None:
                    self._lumo_pending_action = method_name
                    _set_ui_status(self, module,
                                   "Checking the link first. The download starts when the check finishes.",
                                   "CYAN")
                    # The recovered inspect() ignores a request while a check for the same
                    # link is still marked "loading". If that check never finishes, every
                    # later click would wait forever. Treat a check older than 20 s as stuck.
                    started = getattr(self, "_lumo_inspect_started", None)
                    if getattr(self, "stage", "") == "loading" and (
                            started is None or time.monotonic() - started > 20.0):
                        self.stage = "idle"
                        self.pending_inspect_url = None
                    self._lumo_inspect_started = time.monotonic()
                    inspect = getattr(self, "inspect", None)
                    if callable(inspect):
                        inspect()
                return None
            try:
                return original(self, *args, **kwargs)
            except Exception as exc:
                _report_ui_error(self, module, method_name, exc)
                return None

        action_waiting_for_inspection._lumo_pending_wrapper = True  # type: ignore[attr-defined]
        setattr(app_class, method_name, action_waiting_for_inspection)

    wrap_action("continue_to_extras")
    wrap_action("start_download")


def _install_quiet_completion(module: ModuleType) -> None:
    """Replace the completion pop-up with a status line. The Open folder button still works."""
    app_class = getattr(module, "App", None)
    if app_class is None:
        return

    def show_completion_quietly(self: Any, *args: Any, **kwargs: Any) -> None:
        _set_ui_status(self, module, "Download complete. Use Open folder to find the file.", "GOOD")

    app_class.show_completion_popup = show_completion_quietly


def _install_quality_list_style(module: ModuleType) -> None:
    """Restyle the quality drop-down list: larger text, rounded-feel padding, accent highlight."""
    app_class = getattr(module, "App", None)
    if app_class is None:
        return
    original_build = getattr(app_class, "build_download_page", None)
    if not callable(original_build) or getattr(original_build, "_lumo_quality_style", False):
        return

    def build_with_quality_style(self: Any, *args: Any, **kwargs: Any) -> Any:
        result = original_build(self, *args, **kwargs)
        try:
            card = getattr(module, "CARD", "#141b2d")
            text = getattr(module, "TEXT", "#eef3ff")
            accent = getattr(module, "ACCENT", "#4f8cff")
            self.option_add("*TCombobox*Listbox.background", card)
            self.option_add("*TCombobox*Listbox.foreground", text)
            self.option_add("*TCombobox*Listbox.selectBackground", accent)
            self.option_add("*TCombobox*Listbox.selectForeground", "#ffffff")
            self.option_add("*TCombobox*Listbox.font", ("Segoe UI", 12))
            self.option_add("*TCombobox*Listbox.borderWidth", 0)
            self.option_add("*TCombobox*Listbox.highlightThickness", 0)
            self.option_add("*TCombobox*Listbox.relief", "flat")
        except Exception:
            pass
        return result

    build_with_quality_style._lumo_quality_style = True  # type: ignore[attr-defined]
    app_class.build_download_page = build_with_quality_style


def _install_animation_frame_rate(module: ModuleType) -> None:
    """Set how often the recovered tween loop redraws (default 16 ms, about 60 fps).

    The tween engine is time-based: every animation lasts exactly its set duration and
    only the number of steps changes. A 33 ms step (30 fps) looked steppy, and because
    Windows timers used to fire in 15.6 ms ticks it also arrived unevenly (33 ms became
    31 or 47 ms). With the finer timer from _install_smooth_timing and the cheaper card
    drawing from _install_image_speedups, 60 fps is affordable and moves the same
    animation more smoothly. Set LUMO_FRAME_MS (16 to 50) to try a different rate.
    """
    default = 16
    try:
        requested = int(os.environ.get("LUMO_FRAME_MS", str(default)))
    except ValueError:
        requested = default
    module.FRAME_MS = max(16, min(50, requested))


def _install_smooth_timing() -> None:
    """Even frame timing and no garbage-collection pauses during animations.

    * Windows runs timers in 15.6 ms ticks, so after(16) arrives after 16 or 31 ms
      alternately, which is visible as jitter. timeBeginPeriod(1) makes timers accurate
      to about 1 ms for this process only (undone at exit).
    * Python's garbage collector can pause for 10 to 30 ms in a big Tk app. A higher
      threshold makes it run far less often, and freezing the objects created during
      start-up keeps those out of every later collection.
    Neither changes what the app draws or does.
    """
    try:
        import atexit
        import ctypes
        winmm = ctypes.windll.winmm
        if winmm.timeBeginPeriod(1) == 0:
            atexit.register(lambda: winmm.timeEndPeriod(1))
    except Exception:
        pass
    try:
        import gc
        gc.set_threshold(50000, 20, 50)
        timer = threading.Timer(5.0, gc.freeze)
        timer.daemon = True
        timer.start()
    except Exception:
        pass


def _style_quality_popdown(app: Any, combo: Any, module: ModuleType) -> None:
    """Style the open quality list: accent highlight, larger text, no border."""
    try:
        popdown = app.tk.call("ttk::combobox::PopdownWindow", str(combo))
        listbox = f"{popdown}.f.l"
        app.tk.call(listbox, "configure",
                    "-background", getattr(module, "CARD", "#141b2d"),
                    "-foreground", getattr(module, "TEXT", "#eef3ff"),
                    "-selectbackground", getattr(module, "ACCENT", "#4f8cff"),
                    "-selectforeground", "#ffffff",
                    "-font", "{Segoe UI} 12",
                    "-relief", "flat", "-borderwidth", "0",
                    "-highlightthickness", "0", "-activestyle", "none")
    except Exception:
        pass


_NAV_ICON_TWEEN_MS = 900  # normal pace; shorter tweens looked fast and steppy


def _install_v3_polish(module: ModuleType) -> None:
    """Progress colours, one-time tab logo play, styled quality popup."""
    app_class = getattr(module, "App", None)
    nav_class = getattr(module, "NavRow", None)
    if app_class is None:
        return

    # 2) quality popup styled every time it opens
    original_build = getattr(app_class, "build_download_page", None)
    if callable(original_build) and not getattr(original_build, "_lumo_v3", False):
        def build_v3(self: Any, *args: Any, **kwargs: Any) -> Any:
            result = original_build(self, *args, **kwargs)
            combo = getattr(self, "quality_combo", None)
            if combo is not None:
                try:
                    combo.bind("<Button-1>",
                               lambda event: self.after_idle(lambda: _style_quality_popdown(self, combo, module)),
                               add="+")
                except Exception:
                    pass
            return result
        build_v3._lumo_v3 = True  # type: ignore[attr-defined]
        app_class.build_download_page = build_v3

    # 3) tab logo plays once on click (420 ms, no repeat, no wobble added by this code)
    if nav_class is not None and not getattr(nav_class.play_icon, "_lumo_v3", False):
        def play_icon_once(self: Any) -> None:
            # Every click plays the icon. A click can reach here twice (our tab handler and
            # the page switch); cancelling the running tween first means the second call
            # restarts the same animation instead of stacking two tweens on one icon.
            tween = getattr(module, "start_tween", None)
            cancel = getattr(module, "cancel_tween", None)
            ease = (getattr(module, "ease_in_out_cubic", None)
                    or getattr(module, "ease_out_cubic", None) or (lambda t: t))
            if callable(cancel):
                try:
                    cancel(self, "_icon_tween")
                except Exception:
                    pass
            try:
                pending = getattr(self, "_lumo_icon_after", None)
                if pending is not None:
                    self.after_cancel(pending)
                    self._lumo_icon_after = None
            except Exception:
                pass
            if callable(tween):
                tween(self, "_icon_tween", _NAV_ICON_TWEEN_MS, self._set_icon, ease)
        play_icon_once._lumo_v3 = True  # type: ignore[attr-defined]
        nav_class.play_icon = play_icon_once

    # Frame pacing for the sidebar icon tween. Each tween frame re-renders the icon
    # image, which is the costly part. Redrawing at most about 30 times a second keeps
    # the motion smooth, and the first and last frames are always drawn so the icon
    # starts and ends exactly where it should.
    if nav_class is not None:
        original_set_icon = getattr(nav_class, "_set_icon", None)
        if callable(original_set_icon) and not getattr(original_set_icon, "_lumo_paced", False):
            min_frame_s = 1.0 / 30.0

            def set_icon_paced(self: Any, value: Any, *args: Any, **kwargs: Any) -> Any:
                try:
                    progress = float(value)
                except (TypeError, ValueError):
                    return original_set_icon(self, value, *args, **kwargs)
                now = time.monotonic()
                edge = progress <= 0.0 or progress >= 1.0
                last = float(getattr(self, "_lumo_icon_drawn_at", 0.0) or 0.0)
                if not edge and now - last < min_frame_s:
                    return None
                self._lumo_icon_drawn_at = now
                return original_set_icon(self, value, *args, **kwargs)

            set_icon_paced._lumo_paced = True  # type: ignore[attr-defined]
            nav_class._set_icon = set_icon_paced


def _start_backend_warmup() -> None:
    """Load yt-dlp and find the JavaScript runtime in the background at startup."""
    def worker() -> None:
        try:
            from lumo_windows.downloader import warm_up
            warm_up()
        except Exception:
            pass
    threading.Thread(target=worker, name="lumo-warmup", daemon=True).start()


_SUBTITLE_LANGUAGE_NAMES = {
    "en": "English", "hi": "Hindi", "mr": "Marathi", "ur": "Urdu", "bn": "Bengali", "ta": "Tamil",
    "te": "Telugu", "gu": "Gujarati", "kn": "Kannada", "ml": "Malayalam", "pa": "Punjabi",
    "or": "Odia", "as": "Assamese", "ne": "Nepali", "si": "Sinhala", "es": "Spanish",
    "fr": "French", "de": "German", "it": "Italian", "pt": "Portuguese", "ru": "Russian",
    "uk": "Ukrainian", "pl": "Polish", "nl": "Dutch", "sv": "Swedish", "da": "Danish",
    "no": "Norwegian", "fi": "Finnish", "cs": "Czech", "ro": "Romanian", "hu": "Hungarian",
    "el": "Greek", "tr": "Turkish", "ar": "Arabic", "fa": "Persian", "he": "Hebrew",
    "ja": "Japanese", "ko": "Korean", "zh": "Chinese", "id": "Indonesian", "ms": "Malay",
    "vi": "Vietnamese", "th": "Thai", "fil": "Filipino", "sw": "Swahili",
}
_SUBTITLE_COMMON_AUTO = (
    "en", "hi", "mr", "ur", "bn", "ta", "te", "gu", "kn", "ml", "pa", "es", "fr", "de",
    "pt", "ru", "ja", "ko", "ar", "zh", "it", "tr", "id", "vi", "th",
)
_SUBTITLE_MAX_CHIPS = 24


def _subtitle_base(code: str) -> str:
    return re.split(r"[-_]", str(code), maxsplit=1)[0].casefold()


def _subtitle_label(code: str, kind: str) -> str:
    parts = re.split(r"[-_]", str(code), maxsplit=1)
    base = parts[0].casefold()
    region = parts[1] if len(parts) > 1 else ""
    name = _SUBTITLE_LANGUAGE_NAMES.get(base, base.upper())
    if region and region.casefold() not in {"orig"}:
        name += f" ({region})"
    return f"{name} · auto" if kind == "auto" else name


def _subtitle_tracks_to_show(info: dict) -> tuple[list[dict], int]:
    """Return (tracks to show, total tracks the video reports).

    Manual tracks are always shown. Automatic captions are shown for the original
    language and for common languages that have no manual track, one per language.
    """
    tracks = info.get("subtitle_tracks")
    if not isinstance(tracks, list):
        tracks = [{"code": c, "kind": "manual"} for c in (info.get("subtitles_available") or [])]
    clean = [t for t in tracks if isinstance(t, dict) and str(t.get("code") or "").strip()]
    manual = [t for t in clean if t.get("kind") == "manual"]
    auto = [t for t in clean if t.get("kind") != "manual"]
    covered = {_subtitle_base(t["code"]) for t in manual}
    chosen_auto: dict[str, dict] = {}
    for track in sorted(auto, key=lambda t: (not str(t["code"]).endswith("-orig"), str(t["code"]))):
        base = _subtitle_base(track["code"])
        if base in covered or base in chosen_auto:
            continue
        if str(track["code"]).endswith("-orig") or base in _SUBTITLE_COMMON_AUTO:
            chosen_auto[base] = track
    order = {code: i for i, code in enumerate(_SUBTITLE_COMMON_AUTO)}
    auto_shown = sorted(chosen_auto.values(), key=lambda t: (order.get(_subtitle_base(t["code"]), 99), t["code"]))
    shown = sorted(manual, key=lambda t: _subtitle_label(t["code"], "manual")) + auto_shown
    return shown[:_SUBTITLE_MAX_CHIPS], len(clean)


_VISIBLE_SUBTITLE_CHOICES = (("en", "English"), ("hi", "Hindi"), ("mr", "Marathi"))


def _default_subtitle_code(app: Any, available: set) -> str | None:
    """The subtitle selected for a new video: the Settings choice, else English.

    The Settings value ("preferred_subtitle": en, hi, mr or none) was saved but never
    used on the Download page. "none" selects nothing. If the preferred language is not
    available for this video, English is used when the video has it.
    """
    settings = getattr(app, "settings", None)
    preferred = ""
    if isinstance(settings, dict):
        preferred = str(settings.get("preferred_subtitle", "en") or "").strip().casefold()
    if preferred in {"none", "off"}:
        return None
    if preferred in _VISIBLE_SUBTITLE_CHOICES_CODES and preferred in available:
        return preferred
    return "en" if "en" in available else None


_VISIBLE_SUBTITLE_CHOICES_CODES = ("en", "hi", "mr")


def _rebuild_subtitle_chips(app: Any, module: ModuleType) -> None:
    """Show English, Hindi and Marathi only. Languages the video lacks are greyed out."""
    holder = getattr(app, "subtitle_chip_holder", None)
    chip_class = getattr(module, "ChoiceChip", None)
    if holder is None or chip_class is None:
        return
    info = getattr(app, "video_info", None)
    info = info if isinstance(info, dict) else {}
    tracks = info.get("subtitle_tracks")
    if not isinstance(tracks, list):
        tracks = [{"code": c, "kind": "auto"} for c in (info.get("subtitles_available") or [])]
    available = {_subtitle_base(t["code"]) for t in tracks
                 if isinstance(t, dict) and str(t.get("code") or "").strip()}
    video_key = str(getattr(app, "_lumo_subtitle_request_url", "") or "").strip()
    selection = getattr(app, "subtitle_selection", None)
    if not isinstance(selection, set):
        selection = set()
        app.subtitle_selection = selection

    # Check BEFORE destroying anything. Nothing changes for the same video and the same
    # available languages, so the chips stay as they are. (The destroy used to run first,
    # which emptied the holder and forced a rebuild on every event.)
    signature = (video_key, tuple(sorted(available)))
    holder_has_chips = bool(getattr(app, "subtitle_chips", None)) and bool(holder.winfo_children())
    if getattr(app, "_lumo_chip_signature", None) == signature and holder_has_chips:
        return
    app._lumo_chip_signature = signature
    for child in list(holder.winfo_children()):
        child.destroy()

    # A new video starts with English selected if the video has English. This is silent:
    # no prompt, and the user's own choices for the same video are kept.
    if getattr(app, "_lumo_subtitle_default_for", None) != video_key:
        app._lumo_subtitle_default_for = video_key
        selection.clear()
        default = _default_subtitle_code(app, available)
        if default:
            selection.add(default)
    for code, _ in _VISIBLE_SUBTITLE_CHOICES:
        if code not in available:
            selection.discard(code)
    app.subtitle_codes = [code for code, _ in _VISIBLE_SUBTITLE_CHOICES]
    app.subtitle_chips = {}
    app._lumo_applied_subtitles = None
    for index, (code, name) in enumerate(_VISIBLE_SUBTITLE_CHOICES):
        is_available = code in available
        selected = is_available and code in selection
        chip = chip_class(holder, name, (lambda c=code: app.toggle_subtitle(c)),
                          width=max(118, 9 * len(name) + 52), height=38,
                          color_index=index % 5, selected=selected,
                          enabled=is_available, indicator=selected, multicolor=True)
        chip.pack(side="left", padx=(0, 8), pady=(0, 7))
        app.subtitle_chips[code] = chip
    none_chip = chip_class(holder, "None", (lambda: app.clear_subtitles()),
                           width=86, height=38, color_index=4, selected=not selection,
                           indicator=not selection, multicolor=True)
    none_chip.pack(side="left", padx=(0, 8), pady=(0, 7))
    app.none_subtitle_chip = none_chip
    note = getattr(app, "subtitle_note", None)
    if note is not None:
        missing = [name for code, name in _VISIBLE_SUBTITLE_CHOICES if code not in available]
        text = ("Pick one or more. The selected ones are embedded as tracks."
                if not missing else
                "Pick one or more. Greyed out: " + ", ".join(missing) + " (not available for this video).")
        try:
            note.configure(text=text)
        except Exception:
            pass


def _install_detected_subtitles(module: ModuleType) -> None:
    """Replace the fixed English/Hindi/Marathi row with the video's real tracks."""
    app_class = getattr(module, "App", None)
    if app_class is None:
        return

    def build_subtitle_chips_detected(self: Any, *args: Any, **kwargs: Any) -> None:
        _rebuild_subtitle_chips(self, module)

    def toggle_subtitle_detected(self: Any, code: Any, *args: Any, **kwargs: Any) -> None:
        key = str(code)
        chip = (getattr(self, "subtitle_chips", None) or {}).get(key)
        selection = getattr(self, "subtitle_selection", None)
        if chip is None or not isinstance(selection, set) or not getattr(chip, "enabled", True):
            return
        on = key not in selection
        if on:
            selection.add(key)
        else:
            selection.discard(key)
        for setter, value in ((getattr(chip, "set_selected", None), on),
                              (getattr(chip, "set_indicator", None), on)):
            if callable(setter):
                try:
                    setter(value)
                except Exception:
                    pass
        none_chip = getattr(self, "none_subtitle_chip", None)
        if none_chip is not None:
            for setter, value in ((getattr(none_chip, "set_selected", None), not selection),
                                  (getattr(none_chip, "set_indicator", None), not selection)):
                if callable(setter):
                    try:
                        setter(value)
                    except Exception:
                        pass

    def clear_subtitles_detected(self: Any, *args: Any, **kwargs: Any) -> None:
        selection = getattr(self, "subtitle_selection", None)
        if isinstance(selection, set):
            selection.clear()
        for chip in (getattr(self, "subtitle_chips", None) or {}).values():
            chip.set_selected(False)
        none_chip = getattr(self, "none_subtitle_chip", None)
        if none_chip is not None:
            none_chip.set_selected(True)

    app_class.build_subtitle_chips = build_subtitle_chips_detected
    app_class.toggle_subtitle = toggle_subtitle_detected
    app_class.clear_subtitles = clear_subtitles_detected


_BLACK_BACKGROUNDS = {"black", "#000", "#000000"}


def _recolour_black_page_frames(app: Any, background: str) -> None:
    """Set the window and page containers to the app background when they are pure black."""
    frames: list[Any] = [app]
    pages = getattr(app, "pages", None)
    if isinstance(pages, dict):
        frames.extend(frame for frame in pages.values() if frame is not None)
    for frame in frames:
        try:
            if str(frame.cget("bg")).casefold() in _BLACK_BACKGROUNDS:
                frame.configure(bg=background)
        except Exception:
            pass


def _page_hide_noop(*_args: Any, **_kwargs: Any) -> None:
    """Replaces place_forget() on a primary page frame so the page is never unmapped."""
    return None


def _pin_page_frames(app: Any, raise_key: Any = None, only: Any = None) -> None:
    """Keep every primary page placed at full size, stacked on top of each other.

    Switching pages then only changes which frame is on top (one tkraise). Nothing is
    unmapped and re-mapped, so Tk does not re-layout or repaint the page from scratch.
    That unmap/map cycle was the black rectangle and the stutter on every page switch.
    """
    pages = getattr(app, "pages", None)
    if not isinstance(pages, dict):
        return
    for name, frame in tuple(pages.items()):
        if frame is None:
            continue
        if only is not None and str(name).strip().casefold() not in only:
            continue
        try:
            if not getattr(frame, "_lumo_pinned", False):
                # Any later place_forget() on a page (the recovered show_page, the
                # tab warm-up, the resize guard) becomes a no-op for this frame.
                frame.place_forget = _page_hide_noop
                frame._lumo_pinned = True
            if frame.winfo_manager() != "place":
                frame.place(x=0, y=0, relwidth=1, relheight=1)
        except Exception:
            pass
    target = pages.get(str(raise_key).strip().casefold()) if raise_key else None
    if target is not None:
        try:
            target.tkraise()
        except Exception:
            pass


def _deferred_method(app: Any, name: str, delay_ms: int, only_page: str) -> Any:
    """Return a stand-in for app.<name>() that runs the real method after the next paint.

    The page switch shows the new page first; heavy refresh work (History rows, Download
    stage) runs a few milliseconds later instead of blocking the first paint. Repeated
    requests are merged into one run, and the run is skipped if the user already left.
    """
    flag = f"_lumo_deferred_{name}"

    def schedule(*_args: Any, **_kwargs: Any) -> None:
        if getattr(app, flag, False):
            return None
        try:
            setattr(app, flag, True)
        except Exception:
            return None

        def run() -> None:
            try:
                setattr(app, flag, False)
            except Exception:
                pass
            try:
                if not app.winfo_exists():
                    return
                current = str(getattr(app, "current_display_page", "") or "").casefold()
                if current != only_page:
                    return
                getattr(type(app), name)(app)
            except Exception:
                pass

        try:
            app.after(delay_ms, run)
        except Exception:
            run()
        return None

    return schedule


# ---------------------------------------------------------------------------
# Smooth start-up: map the other pages and pre-draw the Settings sub-tabs one at a time.
#
# The first time a page or a Settings sub-tab is shown, its rounded cards are drawn and
# cached at their real size. That first draw costs 50-250 ms, and it used to happen all at
# once in the first seconds after launch (every page was mapped together) and again when
# a sub-tab was opened for the first time. Now only the visible page is mapped during
# start-up; History and Settings are mapped one per timer tick afterwards, and each Settings
# sub-tab is drawn once behind the visible one, so a later click finds everything ready.
# Nothing here changes what any page looks like. Work pauses while the user is clicking or
# typing and never runs on a page the user is already looking at.
# ---------------------------------------------------------------------------
_STARTUP_STAGING = {"active": False}
_STARTUP_INPUT_QUIET_S = 0.7
_STARTUP_FIRST_DELAY_MS = 900
_STARTUP_STEP_GAP_MS = 170
_STARTUP_TAB_DRAW_MS = 150


def _track_user_input(app: Any) -> None:
    """Remember when the user last pressed a key or mouse button (bound once)."""
    if getattr(app, "_lumo_input_tracking", False):
        return

    def mark(_event: Any = None) -> None:
        try:
            app._lumo_input_at = time.monotonic()
        except Exception:
            pass

    try:
        for sequence in ("<ButtonPress>", "<Key>", "<MouseWheel>"):
            app.bind_all(sequence, mark, add="+")
        app._lumo_input_tracking = True
    except Exception:
        pass


def _widget_exists(widget: Any) -> bool:
    try:
        return widget is not None and bool(widget.winfo_exists())
    except Exception:
        return False


def _idle_chain(app: Any, steps: list, generation: int) -> None:
    """Run start-up steps one per timer tick, waiting while the user is interacting.

    A step returns (delay_ms, again). `again` puts the same step back at the front of the
    queue (used while there is more of the same work left).
    """
    queue = list(steps)

    def tick() -> None:
        if not _widget_exists(app) or getattr(app, "_lumo_idle_generation", 0) != generation:
            return
        if not queue:
            return
        try:
            quiet_for = time.monotonic() - float(getattr(app, "_lumo_input_at", 0.0) or 0.0)
        except Exception:
            quiet_for = _STARTUP_INPUT_QUIET_S
        if quiet_for < _STARTUP_INPUT_QUIET_S:
            try:
                app.after(250, tick)
            except Exception:
                pass
            return
        step = queue.pop(0)
        delay, again = _STARTUP_STEP_GAP_MS, False
        try:
            outcome = step()
            if isinstance(outcome, tuple) and len(outcome) == 2:
                delay, again = int(outcome[0]), bool(outcome[1])
        except Exception:
            pass
        if again:
            queue.insert(0, step)
        try:
            app.after(max(20, delay), tick)
        except Exception:
            pass

    try:
        app.after(_STARTUP_FIRST_DELAY_MS, tick)
    except Exception:
        pass


def _map_page_behind(app: Any, name: str) -> tuple:
    """Map one hidden page under the visible one so its cards are drawn once."""
    pages = getattr(app, "pages", None)
    if not isinstance(pages, dict):
        return (_STARTUP_STEP_GAP_MS, False)
    frame = pages.get(name)
    current = str(getattr(app, "current_display_page", "") or "").strip().casefold()
    if frame is None or not _widget_exists(frame) or getattr(frame, "_lumo_pinned", False) or current == name:
        return (20, False)
    _pin_page_frames(app, None, only={name})
    try:
        frame.lower()  # never above the page the user is looking at
        visible = pages.get(current)
        if visible is not None and _widget_exists(visible):
            visible.tkraise()
    except Exception:
        pass
    return (_STARTUP_STEP_GAP_MS + 120, False)


def _draw_next_settings_tab(app: Any) -> tuple:
    """Draw one not-yet-shown Settings sub-tab behind the visible one, then release it."""
    tabs = getattr(app, "settings_tabs", None)
    variable = getattr(app, "settings_tab_var", None)
    if not isinstance(tabs, dict) or not tabs:
        return (20, False)
    drawn = getattr(app, "_lumo_drawn_tabs", None)
    if not isinstance(drawn, set):
        drawn = set()
        app._lumo_drawn_tabs = drawn
    try:
        selected = str(variable.get()) if variable is not None else ""
    except Exception:
        selected = ""
    pending = [(key, frame) for key, frame in tuple(tabs.items())
               if id(frame) not in drawn and key != selected and _widget_exists(frame)]
    if not pending:
        return (20, False)
    key, frame = pending[0]
    drawn.add(id(frame))
    try:
        # Only a tab that is not packed (not showing) is drawn this way.
        if frame.winfo_manager() == "pack":
            return (20, bool(len(pending) > 1))
        frame.place(x=0, y=0, relwidth=1, relheight=1)
        frame.lower()
    except Exception:
        return (20, bool(len(pending) > 1))

    deadline = time.monotonic() + 2.0

    def release() -> None:
        # Keep the tab placed until its cards have actually been redrawn (they are drawn
        # a few at a time), but never for more than two seconds.
        if _SLICED_REDRAW["queue"] and time.monotonic() < deadline:
            try:
                app.after(60, release)
                return
            except Exception:
                pass
        # If the user opened this tab meanwhile, pack() already took it over: leave it.
        try:
            if _widget_exists(frame) and frame.winfo_manager() == "place":
                frame.place_forget()
        except Exception:
            pass

    try:
        app.after(_STARTUP_TAB_DRAW_MS, release)
    except Exception:
        release()
    return (_STARTUP_TAB_DRAW_MS + _STARTUP_STEP_GAP_MS, bool(len(pending) > 1))


def _start_staged_startup(app: Any, pages: bool = True) -> None:
    """Queue the idle-time work: map History and Settings, then draw each Settings sub-tab."""
    _track_user_input(app)
    generation = int(getattr(app, "_lumo_idle_generation", 0) or 0) + 1
    app._lumo_idle_generation = generation
    app._lumo_drawn_tabs = set()
    steps: list = []
    if pages:
        for name in ("history", "settings"):
            steps.append(lambda n=name: _map_page_behind(app, n))
    steps.append(lambda: _draw_next_settings_tab(app))
    _idle_chain(app, steps, generation)


def _install_idle_progress_skip(module: ModuleType) -> None:
    """GlowProgress.set_value(x) when the bar already shows x does nothing.

    The recovered code starts a tween even when start and end are the same (it ran twice
    at launch, while the window was busy, and each time forced a redraw). The bar looks and
    moves exactly the same; only the do-nothing tween and its redraw are skipped.
    """
    progress_class = getattr(module, "GlowProgress", None)
    original = getattr(progress_class, "set_value", None)
    if not callable(original) or getattr(original, "_lumo_skip_same", False):
        return

    def set_value_skipping_same(self: Any, value: Any, *args: Any, **kwargs: Any) -> Any:
        try:
            target = max(0.0, min(100.0, float(value)))
            if abs(target - float(self.value)) < 0.05:
                cancel = getattr(module, "cancel_tween", None)
                if callable(cancel):
                    cancel(self, "_value_tween")
                self.target_value = target
                return None
        except Exception:
            pass
        return original(self, value, *args, **kwargs)

    set_value_skipping_same._lumo_skip_same = True  # type: ignore[attr-defined]
    progress_class.set_value = set_value_skipping_same


def _install_page_switch_repaint(module: ModuleType) -> None:
    """Instant page switching: no animation, no unmap/map, no black rectangle.

    Every other layer of show_page (titles, sidebar bar and icon animation, URL focus,
    Playlist page, Settings default tab) still runs unchanged. This outermost layer only
    changes how the pages are shown:

    * all pages stay mapped in a stack; the requested page is raised first,
    * the recovered show_page can no longer unmap pages (place_forget is a no-op on them),
    * no update_idletasks() inside the click handler,
    * refresh_history / render_download_stage run just after the new page has painted.
    """
    app_class = getattr(module, "App", None)
    if app_class is None:
        return
    original_show_page = getattr(app_class, "show_page", None)
    if not callable(original_show_page) or getattr(original_show_page, "_lumo_page_repaint", False):
        return
    background = getattr(module, "BG", "#0E0F14")

    def show_page_instant(self: Any, page: Any, *args: Any, **kwargs: Any) -> Any:
        key = str(page).strip().casefold()
        _recolour_black_page_frames(self, background)
        # Put the requested page on top before anything else happens. While the window is
        # still being built only the requested page is mapped; the other pages are mapped
        # one at a time shortly afterwards (see _start_staged_startup).
        if _STARTUP_STAGING["active"]:
            _pin_page_frames(self, key, only={key})
        else:
            _pin_page_frames(self, key)
        shadowed: list[str] = []
        for name, delay, only_page in (("refresh_history", 20, "history"),
                                       ("render_download_stage", 25, "download")):
            try:
                setattr(self, name, _deferred_method(self, name, delay, only_page))
                shadowed.append(name)
            except Exception:
                pass
        try:
            result = original_show_page(self, page, *args, **kwargs)
        finally:
            for name in shadowed:
                try:
                    self.__dict__.pop(name, None)
                except Exception:
                    pass
        # A fallback page may have been shown instead of the requested one.
        pages = getattr(self, "pages", None)
        if isinstance(pages, dict):
            shown_key = str(getattr(self, "current_display_page", "") or key).strip().casefold()
            if shown_key != key:
                shown = pages.get(shown_key)
                if shown is not None:
                    try:
                        shown.tkraise()
                    except Exception:
                        pass
        return result

    show_page_instant._lumo_page_repaint = True  # type: ignore[attr-defined]
    app_class.show_page = show_page_instant

    original_init = app_class.__init__

    def init_with_page_stack(self: Any, *args: Any, **kwargs: Any) -> Any:
        _STARTUP_STAGING["active"] = True
        try:
            result = original_init(self, *args, **kwargs)
        finally:
            _STARTUP_STAGING["active"] = False
        current = str(getattr(self, "current_display_page", "download") or "download").strip().casefold()
        try:
            _pin_page_frames(self, current, only={current})
        except Exception:
            pass
        try:
            _start_staged_startup(self)
        except Exception:
            # Never leave a page unmapped if the staging could not be set up.
            try:
                _pin_page_frames(self, current)
            except Exception:
                pass
        return result

    app_class.__init__ = init_with_page_stack

    original_rebuild = getattr(app_class, "rebuild_ui", None)
    if callable(original_rebuild) and not getattr(original_rebuild, "_lumo_page_stack", False):
        def rebuild_with_page_stack(self: Any, *args: Any, **kwargs: Any) -> Any:
            result = original_rebuild(self, *args, **kwargs)
            # A colour change creates brand-new page frames. Stack them again once the
            # rebuilt window has painted, so the first visit to every page is instant too.
            try:
                self.after(150, lambda a=self: _pin_page_frames(
                    a, getattr(a, "current_display_page", "download")))
                self.after(400, lambda a=self: _start_staged_startup(a, pages=False))
            except Exception:
                pass
            return result
        rebuild_with_page_stack._lumo_page_stack = True  # type: ignore[attr-defined]
        app_class.rebuild_ui = rebuild_with_page_stack


def _install_same_tab_icon_replay(module: ModuleType) -> None:
    """Replay the sidebar icon when the tab that is already open is clicked again.

    The recovered show_page() starts the icon animation only when the page changes, so a
    second click on the same tab did nothing until another tab had been opened. This wraps
    show_page: if the requested page is the one already showing, the icon animation is
    started from the beginning (once per click, nothing runs in the background).
    """
    app_class = getattr(module, "App", None)
    original = getattr(app_class, "show_page", None) if app_class is not None else None
    if not callable(original) or getattr(original, "_lumo_same_tab_replay", False):
        return

    def show_page_with_replay(self: Any, page: Any, *args: Any, **kwargs: Any) -> Any:
        key = str(page).strip().casefold()
        previous = str(getattr(self, "current_display_page", "") or "").strip().casefold()
        result = original(self, page, *args, **kwargs)
        try:
            rows = getattr(self, "nav_rows", {})
            if key == previous and isinstance(rows, dict) and key in rows:
                self.after_idle(lambda app=self, name=key: _play_navigation_icon(app, name))
        except Exception:
            pass
        return result

    show_page_with_replay._lumo_same_tab_replay = True  # type: ignore[attr-defined]
    app_class.show_page = show_page_with_replay


# While the window is being resized the glow bar holds still for a moment (at most ~250 ms
# after the last size change) instead of redrawing 60 times a second into a resize. Set to
# False to keep it moving during resize.
_PAUSE_GLOW_WHILE_RESIZING = True


def _install_hidden_animation_pause(module: ModuleType) -> None:
    """Stop redrawing the glowing progress bar while nobody can see it.

    GlowProgress.animate() redraws about 30 times a second for as long as a bar is active.
    That kept running for a bar on a page that is covered by another page, and while the
    window was minimised. Now such a bar only checks again every 400 ms, and it resumes
    drawing as soon as its page is shown. What the bar looks like and how it moves while
    visible is unchanged; progress values are still applied as before.
    """
    progress_class = getattr(module, "GlowProgress", None)
    original_animate = getattr(progress_class, "animate", None)
    if not callable(original_animate) or getattr(original_animate, "_lumo_pause_hidden", False):
        return

    def is_hidden(widget: Any) -> bool:
        try:
            if not widget.winfo_viewable():
                return True  # window minimised or withdrawn
            app = widget.winfo_toplevel()
            pages = getattr(app, "pages", None)
            if not isinstance(pages, dict):
                return False
            visible = pages.get(str(getattr(app, "current_display_page", "") or "").casefold())
            if visible is None:
                return False
            parent = widget
            while parent is not None:
                if parent is visible:
                    return False
                if any(parent is frame for frame in pages.values()):
                    return True  # inside a page that is not the visible one
                parent = getattr(parent, "master", None)
        except Exception:
            return False
        return False

    def animate_when_visible(self: Any, *args: Any, **kwargs: Any) -> Any:
        try:
            if getattr(self, "active", False) and is_hidden(self):
                self._after_id = self.after(400, self.animate)
                return None
            # While the window is being resized, hold the glow still and check again soon.
            app = self.winfo_toplevel()
            if _PAUSE_GLOW_WHILE_RESIZING and time.monotonic() < float(
                    getattr(app, "_lumo_resizing_until", 0.0) or 0.0):
                if getattr(self, "active", False):
                    self._after_id = self.after(60, self.animate)
                return None
        except Exception:
            pass
        return original_animate(self, *args, **kwargs)

    animate_when_visible._lumo_pause_hidden = True  # type: ignore[attr-defined]
    progress_class.animate = animate_when_visible


# ---------------------------------------------------------------------------
# Cancel that stays on the download page, and the completion tick animation.
# ---------------------------------------------------------------------------
_CANCEL_FALLBACK_MS = 2500
_TICK_TOTAL_MS = 1750.0
_TICK_CANVAS_HEIGHT = 36


def _widget_alive(widget: Any) -> bool:
    try:
        return widget is not None and bool(widget.winfo_exists())
    except Exception:
        return False


def _hex_or(value: Any, fallback: str) -> str:
    return value if _is_hex_colour(value) else fallback


def _history_store(module: ModuleType) -> Any:
    return getattr(module, "history", None)


def _clear_history_rows(module: ModuleType) -> None:
    """No History is kept: remove every row (at launch and before a new download)."""
    store = _history_store(module)
    if store is None:
        return
    try:
        store.clear_all_jobs()
    except Exception:
        pass


def _forget_history_row(module: ModuleType, job_id: Any) -> None:
    store = _history_store(module)
    if store is None or job_id is None:
        return
    try:
        store.delete_job(int(job_id))
    except Exception:
        pass


def _discard_cancelled_partials(job: Any) -> None:
    """Delete the partial files of a cancelled download. Only called after its worker has stopped."""
    if job is None:
        return
    try:
        _downloader_module().discard_partial_folder(job.out_dir, job.url)
    except Exception:
        pass


def _finish_cancelled_download(app: Any, module: ModuleType) -> None:
    """Return to the link page after a cancel. No History page, no error panel."""
    app._lumo_cancel_pending = False
    _forget_history_row(module, getattr(app, "active_job_id", None))
    app.active_job_id = None
    app.active_job = None
    app.cancel_requested = False
    try:
        app.new_download()
    except Exception as exc:
        _report_ui_error(app, module, "cancel", exc)
        return
    _set_ui_status(app, module, "Download cancelled.", "MUTED")


def _cancel_fallback(app: Any, module: ModuleType, generation: int) -> None:
    """If the worker has not stopped quickly, show the link page anyway and ignore its late events."""
    if getattr(app, "_lumo_cancel_gen", 0) != generation or not getattr(app, "_lumo_cancel_pending", False):
        return
    app._lumo_stale_worker = True
    _finish_cancelled_download(app, module)


def _install_fast_cancel(app_class: Any, module: ModuleType) -> Any:
    """Replace cancel_download and guard start_download while a cancelled worker is still stopping."""
    original_start = getattr(app_class, "start_download", None)

    def cancel_download_fast(self: Any, *args: Any, **kwargs: Any) -> None:
        if getattr(self, "_lumo_cancel_pending", False):
            return None
        job = getattr(self, "active_job", None)
        if job is None:
            try:
                job = _downloader_module().current_job()
            except Exception:
                job = None
        self.cancel_requested = True
        self._lumo_cancelled_job = job
        if job is not None:
            try:
                job.cancel()
            except Exception as exc:
                _report_ui_error(self, module, "cancel", exc)
                return None
        self._lumo_cancel_pending = True
        try:
            self.cancel_btn.set_enabled(False)
        except Exception:
            pass
        _set_ui_status(self, module, "Cancelling download…", "WARN")
        generation = getattr(self, "_lumo_cancel_gen", 0) + 1
        self._lumo_cancel_gen = generation
        try:
            self.after(_CANCEL_FALLBACK_MS, lambda: _cancel_fallback(self, module, generation))
        except Exception:
            pass
        return None

    app_class.cancel_download = cancel_download_fast

    original_show_page = getattr(app_class, "show_page", None)
    if callable(original_show_page):
        def show_page_without_history(self: Any, page: Any, *args: Any, **kwargs: Any) -> Any:
            if str(page).strip().casefold() == "history":
                page = "download"
            return original_show_page(self, page, *args, **kwargs)
        app_class.show_page = show_page_without_history

    if callable(original_start):
        def start_download_guarded(self: Any, *args: Any, **kwargs: Any) -> Any:
            if getattr(self, "_lumo_cancel_pending", False) or getattr(self, "_lumo_stale_worker", False):
                _set_ui_status(self, module, "The last download is still stopping. Try again in a moment.", "WARN")
                return None
            _drop_completion_tick(self)
            if not getattr(self, "active_job_id", None):
                _clear_history_rows(module)
            return original_start(self, *args, **kwargs)
        app_class.start_download = start_download_guarded


def _lerp_point(p: tuple[float, float], q: tuple[float, float], t: float) -> tuple[float, float]:
    return (p[0] + (q[0] - p[0]) * t, p[1] + (q[1] - p[1]) * t)


def _tick_ease(x: float) -> float:
    x = min(1.0, max(0.0, x))
    return x * x * (3.0 - 2.0 * x)


def _drop_completion_tick(app: Any) -> None:
    canvas = getattr(app, "_lumo_tick_canvas", None)
    app._lumo_tick_canvas = None
    if canvas is not None:
        try:
            canvas.destroy()
        except Exception:
            pass


def _draw_completion_tick(canvas: Any, elapsed: float, colours: dict[str, str], font: Any) -> None:
    """One frame of the completion animation (timeline in ms).

    0-250     the progress bar fills from left to right
    300-950   both ends of the bar shrink inward until they meet at the centre
    900-1200  the collapsed bar becomes a green point at the centre
    1000-1300 the point draws into a tick
    1300-1550 the tick slides left to make room for the text
    1350-1750 "Completed" fades in beside the tick; the pair stays centred
    """
    accent, good, bg = colours["accent"], colours["good"], colours["bg"]
    width = float(canvas.winfo_width() or 360)
    height = float(_TICK_CANVAS_HEIGHT)
    cy = height / 2.0
    x0, x2 = 10.0, width - 10.0
    xm = width / 2.0
    radius = 11.5
    gap = 8.0
    text_w = float(font.measure("Completed"))
    comp = 2.0 * radius + gap + text_w
    start_x = (width - comp) / 2.0
    final_cx = start_x + radius
    text_x = start_x + 2.0 * radius + gap
    canvas.delete("all")

    grow = _tick_ease(elapsed / 250.0)
    conv = _tick_ease((elapsed - 300.0) / 650.0)
    if elapsed < 950.0:
        left = x0 + (xm - x0) * conv
        right = min(x0 + (x2 - x0) * grow, x2 - (x2 - xm) * conv)
        if right - left > 0.5:
            canvas.create_line(left, cy, right, cy, fill=accent, width=6, capstyle="round")

    dot_r = 3.5 * _tick_ease((elapsed - 900.0) / 150.0) * (1.0 - _tick_ease((elapsed - 1000.0) / 200.0))
    if dot_r > 0.2:
        canvas.create_oval(xm - dot_r, cy - dot_r, xm + dot_r, cy + dot_r, fill=good, outline="")

    tk_t = _tick_ease((elapsed - 1000.0) / 300.0)
    slide = _tick_ease((elapsed - 1300.0) / 250.0)
    cx = xm + (final_cx - xm) * slide
    if tk_t > 0.0:
        a = (cx - 0.5 * radius, cy + 0.05 * radius)
        b = (cx - 0.12 * radius, cy + 0.5 * radius)
        c = (cx + 0.55 * radius, cy - 0.5 * radius)
        if tk_t <= 0.5:
            points = [a, _lerp_point(a, b, tk_t * 2.0)]
        else:
            points = [a, b, _lerp_point(b, c, (tk_t - 0.5) * 2.0)]
        flat = [v for point in points for v in point]
        canvas.create_line(*flat, fill=good, width=4.5, capstyle="round", joinstyle="round")

    text_t = _tick_ease((elapsed - 1350.0) / 400.0)
    if text_t > 0.0:
        canvas.create_text(text_x - 6.0 * (1.0 - text_t), cy, text="Completed", anchor="w",
                           fill=_mix_hex(bg, good, text_t), font=font)


def _tick_trace(message: str) -> None:
    """Append one line to %TEMP%\\lumo_tick_trace.log so a missing completion animation is explained."""
    try:
        line = f"{time.strftime('%H:%M:%S')} [tick] {message}\n"
        with (Path(tempfile.gettempdir()) / "lumo_tick_trace.log").open("a", encoding="utf-8") as handle:
            handle.write(line)
    except OSError:
        pass


def _start_completion_tick(app: Any, module: ModuleType) -> None:
    progress = getattr(app, "progress", None)
    parent = getattr(progress, "master", None)
    if not _widget_alive(progress) or parent is None:
        _tick_trace("skipped: progress bar or its parent is not alive")
        return
    _drop_completion_tick(app)
    try:
        parent_bg = str(parent.cget("bg"))
    except Exception:
        parent_bg = ""
    colours = {
        "accent": _hex_or(getattr(module, "ACCENT", None), DEFAULT_PROGRESS_COLOR),
        "good": _hex_or(getattr(module, "GOOD", None), "#3DDC84"),
        "white": _hex_or(getattr(module, "WHITE", None), "#FFFFFF"),
        "bg": _hex_or(parent_bg, _hex_or(getattr(module, "CARD", None), "#16181F")),
    }
    try:
        canvas = tk.Canvas(parent, height=_TICK_CANVAS_HEIGHT, bg=colours["bg"],
                           highlightthickness=0, bd=0)
        canvas.place(in_=progress, relx=0.0, rely=0.5, anchor="w",
                     relwidth=1.0, height=_TICK_CANVAS_HEIGHT)
    except Exception as exc:
        _tick_trace(f"skipped: could not place the canvas: {exc!r}")
        return
    _tick_trace("started")
    try:
        font = tkfont.Font(root=canvas, family="Segoe UI", size=10, weight="bold")
    except Exception:
        font = tkfont.Font(root=canvas, size=10, weight="bold")
    # The animation draws its own "Completed"; clear the old percentage label now so no
    # half-drawn copy of the word is visible while the animation runs.
    label = getattr(app, "percent_label", None)
    try:
        if _widget_alive(label):
            label.configure(text="")
    except Exception:
        pass
    generation = getattr(app, "_lumo_tick_gen", 0) + 1
    app._lumo_tick_gen = generation
    app._lumo_tick_canvas = canvas
    started = time.perf_counter()

    def step() -> None:
        if getattr(app, "_lumo_tick_gen", 0) != generation or not _widget_alive(canvas):
            return
        elapsed = min(_TICK_TOTAL_MS, (time.perf_counter() - started) * 1000.0)
        try:
            _draw_completion_tick(canvas, elapsed, colours, font)
        except tk.TclError:
            return
        if elapsed >= _TICK_TOTAL_MS:
            # The percentage label stays blank: the animation itself shows the result.
            label = getattr(app, "percent_label", None)
            try:
                if _widget_alive(label):
                    label.configure(text="")
            except Exception:
                pass
            return
        canvas.after(20, step)

    step()


def _install_cancel_and_completion(module: ModuleType) -> None:
    app_class = getattr(module, "App", None)
    if app_class is None:
        return
    _install_fast_cancel(app_class, module)

    original_handle = getattr(app_class, "handle_event", None)
    if not callable(original_handle) or getattr(original_handle, "_lumo_cancel_completion", False):
        return

    def handle_event_cancel_and_completion(self: Any, kind: Any, payload: Any = None, *args: Any, **kwargs: Any) -> Any:
        name = str(kind).casefold()
        status = ""
        if name == "done" and isinstance(payload, dict):
            status = str(payload.get("status", "") or "").casefold()

        if getattr(self, "_lumo_cancel_pending", False) or getattr(self, "_lumo_stale_worker", False):
            # A cancelled worker may still send a few last events. Never show them on the link page.
            if name in {"progress", "status"}:
                return None
            if name == "done":
                was_pending = bool(getattr(self, "_lumo_cancel_pending", False))
                self._lumo_cancel_pending = False
                self._lumo_stale_worker = False
                if status == "completed":
                    return original_handle(self, kind, payload, *args, **kwargs)
                _discard_cancelled_partials(getattr(self, "_lumo_cancelled_job", None))
                self._lumo_cancelled_job = None
                if was_pending:
                    _finish_cancelled_download(self, module)
                return None

        if name == "done" and status == "cancelled":
            # A cancelled download never goes to the History page.
            _discard_cancelled_partials(getattr(self, "_lumo_cancelled_job", None))
            self._lumo_cancelled_job = None
            _finish_cancelled_download(self, module)
            return None

        if name == "done" and status == "completed":
            # Start the animation while the progress bar is still on screen, then let the
            # original completion handler run once the animation has finished. Otherwise
            # its stage switch hides the bar and the tick is drawn where nobody can see it.
            _start_completion_tick(self, module)
            token = getattr(self, "_lumo_done_token", 0)

            def finish_completion_later() -> None:
                if getattr(self, "_lumo_done_token", 0) != token:
                    return  # a new download started meanwhile; drop this stale completion
                original_handle(self, kind, payload, *args, **kwargs)
                label = getattr(self, "percent_label", None)
                try:
                    if _widget_alive(label):
                        label.configure(text="")
                except Exception:
                    pass

            try:
                self.after(int(_TICK_TOTAL_MS) + 150, finish_completion_later)
            except Exception:
                return original_handle(self, kind, payload, *args, **kwargs)
            return None
        if name == "started":
            self._lumo_done_token = getattr(self, "_lumo_done_token", 0) + 1
            _drop_completion_tick(self)
        return original_handle(self, kind, payload, *args, **kwargs)

    handle_event_cancel_and_completion._lumo_cancel_completion = True  # type: ignore[attr-defined]
    app_class.handle_event = handle_event_cancel_and_completion



# ---------------------------------------------------------------------------
# Faster rounded cards, gradients and down-scaling (same pictures, far less work).
#
# The speed report showed the window thread spending most of its image time in the
# original UI's picture helpers: every rounded card or bar was drawn four times larger
# than needed as a full colour picture, converted to a premultiplied copy, shrunk and
# converted back (up to 110 ms for a big card). Those helpers only ever draw flat colours
# or a left-to-right gradient inside a rounded shape, so only the shape's coverage (one
# grey channel) really needs the large drawing. The functions below build the same
# pictures from that coverage mask. Output differs from the original by at most 1 to 2
# levels out of 255 on edge pixels, and they run 5 to 20 times faster. Any call they do
# not understand is passed to the original function unchanged.
# ---------------------------------------------------------------------------
def _install_image_speedups(module: ModuleType) -> None:
    import inspect
    try:
        from PIL import Image, ImageChops, ImageDraw
    except Exception:
        return

    def to_rgb(value: Any) -> tuple:
        return tuple(module._rgb(value))[:3]

    def coverage(width: int, height: int, box: Any, radius: int, ss: int) -> Any:
        mask = Image.new("L", (width, height), 0)
        ImageDraw.Draw(mask).rounded_rectangle(box, radius=radius, fill=255)
        return mask.reduce(ss) if ss > 1 else mask

    def gradient_strip(width: int, ss: int, c1: Any, c2: Any) -> Any:
        a, b = to_rgb(c1), to_rgb(c2)
        strip = Image.new("RGBA", (width, 1))
        px = strip.load()
        span = max(1, width * ss - 1)
        for x in range(width):
            t = (x * ss + (ss - 1) / 2) / span
            px[x, 0] = (round(a[0] + (b[0] - a[0]) * t), round(a[1] + (b[1] - a[1]) * t),
                        round(a[2] + (b[2] - a[2]) * t), 255)
        return strip

    # -- _premul_down(img, w, h): premultiplied box down-scale ----------------------
    original_premul = getattr(module, "_premul_down", None)
    if callable(original_premul) and not getattr(original_premul, "_lumo_fast", False):
        def fast_premul_down(img: Any, w: Any, h: Any) -> Any:
            try:
                sw, sh = img.size
                if (isinstance(w, int) and isinstance(h, int) and w > 0 and h > 0
                        and sw % w == 0 and sh % h == 0 and sw // w == sh // h and sw // w > 1):
                    return img.convert("RGBa").reduce(sw // w).convert("RGBA")
            except Exception:
                pass
            return original_premul(img, w, h)

        fast_premul_down._lumo_fast = True  # type: ignore[attr-defined]
        module._premul_down = fast_premul_down

    # -- rounded_rgba(w, h, radius, fill, outline, line, ss) ------------------------
    original_rounded = getattr(module, "rounded_rgba", None)
    if callable(original_rounded) and not getattr(original_rounded, "_lumo_fast", False):
        try:
            rounded_sig = inspect.signature(original_rounded)
        except (TypeError, ValueError):
            rounded_sig = None

        def fast_rounded_rgba(*args: Any, **kwargs: Any) -> Any:
            try:
                bound = rounded_sig.bind(*args, **kwargs)
                bound.apply_defaults()
                v = bound.arguments
                ss = v["ss"]
                if not (isinstance(ss, int) and ss >= 1):
                    return original_rounded(*args, **kwargs)
                w = max(1, int(round(v["w"])))
                h = max(1, int(round(v["h"])))
                fill, outline, line = v["fill"], v["outline"], v["line"]
                big_w, big_h = w * ss, h * ss
                r = int(round(max(0.0, min(v["radius"] * ss, big_w / 2, big_h / 2))))
                if outline and line > 0:
                    lw = max(1, int(round(line * ss)))
                    outer = coverage(big_w, big_h, (0, 0, big_w - 1, big_h - 1), r, ss)
                    ring = Image.new("RGBA", (w, h), to_rgb(outline) + (255,))
                    inner_box = (lw, lw, big_w - 1 - lw, big_h - 1 - lw)
                    if inner_box[2] > inner_box[0] and inner_box[3] > inner_box[1]:
                        inner = coverage(big_w, big_h, inner_box, max(0, r - lw), ss)
                        ring.putalpha(ImageChops.subtract(outer, inner))
                        if not fill:
                            return ring
                        body = Image.new("RGBA", (w, h), to_rgb(fill) + (255,))
                        body.putalpha(inner)
                        return ImageChops.add(ring.convert("RGBa"), body.convert("RGBa")).convert("RGBA")
                    ring.putalpha(outer)
                    return ring
                if not fill:
                    return Image.new("RGBA", (w, h), (0, 0, 0, 0))
                out = Image.new("RGBA", (w, h), to_rgb(fill) + (255,))
                out.putalpha(coverage(big_w, big_h, (0, 0, big_w - 1, big_h - 1), r, ss))
                return out
            except Exception:
                return original_rounded(*args, **kwargs)

        if rounded_sig is not None:
            fast_rounded_rgba._lumo_fast = True  # type: ignore[attr-defined]
            module.rounded_rgba = fast_rounded_rgba

    # -- gradient_rgba(w, h, c1, c2, ss): a full pill filled with a gradient --------
    original_gradient = getattr(module, "gradient_rgba", None)
    if callable(original_gradient) and not getattr(original_gradient, "_lumo_fast", False):
        try:
            gradient_sig = inspect.signature(original_gradient)
        except (TypeError, ValueError):
            gradient_sig = None

        def fast_gradient_rgba(*args: Any, **kwargs: Any) -> Any:
            try:
                bound = gradient_sig.bind(*args, **kwargs)
                bound.apply_defaults()
                v = bound.arguments
                ss = v["ss"]
                if not (isinstance(ss, int) and ss >= 1):
                    return original_gradient(*args, **kwargs)
                w = max(1, int(round(v["w"])))
                h = max(1, int(round(v["h"])))
                big_w, big_h = w * ss, h * ss
                out = gradient_strip(w, ss, v["c1"], v["c2"]).resize((w, h), Image.NEAREST)
                r = int(round(min(big_h / 2, big_w / 2)))
                out.putalpha(coverage(big_w, big_h, (0, 0, big_w - 1, big_h - 1), r, ss))
                return out
            except Exception:
                return original_gradient(*args, **kwargs)

        if gradient_sig is not None:
            fast_gradient_rgba._lumo_fast = True  # type: ignore[attr-defined]
            module.gradient_rgba = fast_gradient_rgba

    # -- _rounded_gradient_rgba(w, h, radius, c1, c2, ss) ---------------------------
    original_round_grad = getattr(module, "_rounded_gradient_rgba", None)
    if callable(original_round_grad) and not getattr(original_round_grad, "_lumo_fast", False):
        try:
            round_grad_sig = inspect.signature(original_round_grad)
        except (TypeError, ValueError):
            round_grad_sig = None

        def fast_rounded_gradient_rgba(*args: Any, **kwargs: Any) -> Any:
            try:
                bound = round_grad_sig.bind(*args, **kwargs)
                bound.apply_defaults()
                v = bound.arguments
                ss, w, h = v["ss"], v["w"], v["h"]
                if not (isinstance(ss, int) and ss >= 1 and isinstance(w, int) and isinstance(h, int)
                        and w > 0 and h > 0):
                    return original_round_grad(*args, **kwargs)
                big_w, big_h = w * ss, h * ss
                out = gradient_strip(w, ss, v["c1"], v["c2"]).resize((w, h), Image.NEAREST)
                r = int(round(max(0.0, min(v["radius"] * ss, big_w / 2, big_h / 2))))
                out.putalpha(coverage(big_w, big_h, (0, 0, big_w - 1, big_h - 1), r, ss))
                return out
            except Exception:
                return original_round_grad(*args, **kwargs)

        if round_grad_sig is not None:
            fast_rounded_gradient_rgba._lumo_fast = True  # type: ignore[attr-defined]
            module._rounded_gradient_rgba = fast_rounded_gradient_rgba


# ---------------------------------------------------------------------------
# Time-sliced redraw of the rounded cards (no frozen window, no black box on maximise).
#
# Every Painted card, button and bar redraws itself from its own timer. When the window
# is maximised, or a page is shown for the first time, dozens of them all become due at
# once and each rebuilds its picture at the new size. Windows can only repaint the newly
# exposed area when the window thread returns to its event loop, so a long run of
# back-to-back redraws left a black rectangle on screen until the whole backlog was done.
# Redraws now go through one queue: at most about 10 ms of them run at a time, the page
# the user is looking at is drawn first, and the event loop gets control back in between
# so the window keeps repainting. Each card is still drawn exactly as before.
# ---------------------------------------------------------------------------
_SLICED_REDRAW: dict = {"queue": [], "scheduled": False}
_REDRAW_SLICE_S = 0.004


def _redraw_page_rank(widget: Any) -> int:
    """0 for a widget on the page being shown, 1 for a page stacked underneath it."""
    try:
        app = widget.winfo_toplevel()
        pages = getattr(app, "pages", None)
        if not isinstance(pages, dict):
            return 0
        current = pages.get(str(getattr(app, "current_display_page", "") or "").strip().casefold())
        frames = {id(frame) for frame in pages.values() if frame is not None}
        node = widget
        while node is not None:
            if id(node) in frames:
                return 0 if node is current else 1
            node = getattr(node, "master", None)
    except Exception:
        pass
    return 0


def _install_sliced_redraw(module: ModuleType) -> None:
    painted = getattr(module, "Painted", None)
    original = getattr(painted, "request_redraw", None)
    if painted is None or not callable(original) or getattr(original, "_lumo_sliced", False):
        return
    state = _SLICED_REDRAW

    def schedule(widget: Any, delay_ms: int) -> None:
        if state["scheduled"]:
            return
        try:
            # The root window outlives every card, so the timer can never be lost
            # together with a card that gets destroyed.
            widget._root().after(delay_ms, pump)
            state["scheduled"] = True
        except Exception:
            pass

    def pump() -> None:
        state["scheduled"] = False
        queue = state["queue"]
        if not queue:
            return
        if len(queue) > 1:
            try:
                queue.sort(key=_redraw_page_rank)  # stable: the visible page first
            except Exception:
                pass
        started = time.perf_counter()
        while queue:
            widget = queue.pop(0)
            try:
                widget._flush()
            except Exception:
                pass
            if time.perf_counter() - started >= _REDRAW_SLICE_S:
                break
        if queue:
            schedule(queue[0], 1)

    def request_redraw(self: Any) -> None:
        if getattr(self, "_redraw_id", None) is not None:
            return
        try:
            self._redraw_id = "lumo-queued"
        except Exception:
            return
        state["queue"].append(self)
        schedule(self, 12)

    request_redraw._lumo_sliced = True  # type: ignore[attr-defined]
    painted.request_redraw = request_redraw


def _paint_window_background(window: Any, colour: str) -> None:
    """Make Windows fill any not-yet-painted part of the main window with the app colour."""
    try:
        import ctypes
        from ctypes import wintypes
        text = str(colour).lstrip("#")
        red, green, blue = int(text[0:2], 16), int(text[2:4], 16), int(text[4:6], 16)
        user32, gdi32 = ctypes.windll.user32, ctypes.windll.gdi32
        gdi32.CreateSolidBrush.restype = ctypes.c_void_p
        gdi32.CreateSolidBrush.argtypes = [wintypes.DWORD]
        brush = gdi32.CreateSolidBrush(red | (green << 8) | (blue << 16))
        setter = user32.SetClassLongPtrW
        setter.restype = ctypes.c_void_p
        setter.argtypes = [wintypes.HWND, ctypes.c_int, ctypes.c_void_p]
        handle = window.winfo_id()
        outer = user32.GetParent(handle) or handle
        setter(outer, -10, brush)  # GCLP_HBRUSHBACKGROUND
        window._lumo_background_brush = brush
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Clean, fast start-up: no half-drawn window, no background work while the UI is built.
#
# * The main window stays hidden while the interface is being built, then appears once,
#   fully laid out and in the app colour. Before, a Windows window that is shown while
#   its pages are still being created flashes a black or white rectangle.
# * The yt-dlp import (about a second of work that competes with the interface for the
#   interpreter) now starts a moment after the window is visible instead of during
#   the build. The first link inspection still finds it ready.
# Set LUMO_NO_HIDE=1 to switch the hidden-until-ready behaviour off.
# ---------------------------------------------------------------------------
def _install_clean_startup(module: ModuleType) -> bool:
    app_class = getattr(module, "App", None)
    if app_class is None:
        return False
    original_init = app_class.__init__
    if getattr(original_init, "_lumo_clean_start", False):
        return True
    background = getattr(module, "BG", "#0E0F14")
    hide = os.environ.get("LUMO_NO_HIDE", "") != "1"

    def init_clean(self: Any, *args: Any, **kwargs: Any) -> Any:
        real_tk_init = tk.Tk.__init__

        def tk_init(window: Any, *a: Any, **k: Any) -> None:
            real_tk_init(window, *a, **k)
            if window is self:
                try:
                    window.configure(bg=background)
                    if hide:
                        window.withdraw()
                except Exception:
                    pass

        tk.Tk.__init__ = tk_init  # type: ignore[method-assign]
        try:
            result = original_init(self, *args, **kwargs)
        finally:
            tk.Tk.__init__ = real_tk_init  # type: ignore[method-assign]

        def reveal() -> None:
            try:
                if hide and str(self.state()) == "withdrawn":
                    self.update_idletasks()
                    self.deiconify()
            except Exception:
                pass
            _paint_window_background(self, background)

        try:
            reveal()
            # Safety net: never leave the window hidden.
            self.after(1500, reveal)
            self.after(1200, _start_backend_warmup)
        except Exception:
            _start_backend_warmup()
        return result

    init_clean._lumo_clean_start = True  # type: ignore[attr-defined]
    app_class.__init__ = init_clean
    return True


def run() -> None:
    _enable_crisp_rendering()
    _install_smooth_timing()
    module = _load_original()
    _install_image_speedups(module)
    _clear_history_rows(module)
    _strip_extra_status_text(module)
    _pin_customization_defaults(module)
    _install_repairs(module)
    _install_selected_swatch_tick_removal(module)
    _install_progress_rendering_repairs(module)
    _install_settings_ui_repairs(module)
    _install_no_chip_animation_on_rebuild(module)
    _install_taskbar_icon(module)
    _install_brand_logo(module)
    _install_lumo_names(module)
    _install_subtitle_availability(module)
    _install_status_caption_filter(module)
    _install_caption_cleanup(module)
    _install_perf_logging(module)
    _cap_redraw_rate(module)
    _install_sliced_redraw(module)
    _install_toggle_switch_fallback(module)
    _install_download_focus_repairs(module)
    _install_url_clear_button(module)
    _install_global_pause_resume(module)
    _install_cookie_prompt(module)
    _install_quality_dropdown_visuals(module)
    _install_download_interaction_repairs(module)
    _install_reduced_navigation_and_download_controls(module)
    _install_subtitle_warning_notice(module)
    _install_subtitle_availability_refresh(module)
    _install_subtitle_selection_fix(module)
    _install_pending_download_actions(module)
    _install_detected_subtitles(module)
    _install_quiet_completion(module)
    _install_quality_list_style(module)
    _install_v3_polish(module)
    _install_animation_frame_rate(module)
    _install_page_switch_repaint(module)
    _install_cancel_and_completion(module)
    _install_taskbar_progress(module)
    _install_hidden_animation_pause(module)
    _install_idle_progress_skip(module)
    _install_same_tab_icon_replay(module)
    if not _install_clean_startup(module):
        _start_backend_warmup()
    try:
        # Own taskbar identity: the button shows Lumo's icon and progress instead of
        # being grouped under python.exe. Must be set before the window is created.
        import ctypes
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("Lumo.Downloader")
    except Exception:
        pass
    original_entry = getattr(module, "main", None)
    if not callable(original_entry):
        raise RuntimeError("The recovered original module has no callable main() entry point.")
    original_entry()


if __name__ == "__main__":
    run()
