package com.lumo.android

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.BroadcastReceiver
import android.content.IntentFilter
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.text.TextWatcher
import android.text.Editable
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.ffmpeg.FFmpeg
import java.io.File
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val worker = Executors.newSingleThreadExecutor()
    private lateinit var urlInput: EditText
    private lateinit var detailsText: TextView
    private lateinit var statusText: TextView
    private lateinit var inspectButton: Button
    private lateinit var downloadButton: Button
    private lateinit var qualitySpinner: Spinner
    private lateinit var formatSpinner: Spinner
    private lateinit var subtitlesSpinner: Spinner
    private lateinit var progressPanel: LinearLayout
    private lateinit var downloadProgress: ProgressBar
    private lateinit var progressLabel: TextView
    private lateinit var cancelDownloadButton: Button
    private var progressReceiverRegistered = false

    private val progressReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (currentScreen != SCREEN_DOWNLOAD || intent == null) return
            renderProgressUi(
                intent.getStringExtra(DownloadService.EXTRA_PROGRESS_MESSAGE).orEmpty(),
                intent.getIntExtra(DownloadService.EXTRA_PROGRESS_VALUE, 0),
                intent.getBooleanExtra(DownloadService.EXTRA_PROGRESS_ONGOING, false)
            )
        }
    }

    private var engineReady = false
    private var selectedTab = TAB_VIDEO
    private var currentScreen = SCREEN_DOWNLOAD
    private var inspectedUrl = ""
    private var inspectedTitle = ""

    private val bg = Color.rgb(5, 5, 6)
    private val panel = Color.rgb(23, 25, 32)
    private val border = Color.rgb(42, 45, 55)
    private val muted = Color.rgb(154, 164, 181)
    private val accent = Color.rgb(255, 100, 127)
    private val white = Color.rgb(244, 246, 251)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = Color.BLACK
        window.decorView.systemUiVisibility = 0
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 41)
        }
        showDownloadScreen()
        initialiseEngine()
    }

    private fun initialiseEngine() {
        statusText.text = "Preparing download engine…"
        worker.execute {
            try {
                YoutubeDL.getInstance().init(applicationContext)
                FFmpeg.getInstance().init(applicationContext)
                runOnUiThread {
                    engineReady = true
                    if (currentScreen == SCREEN_DOWNLOAD) statusText.text = "Ready · Native download engine initialized"
                    updateDownloadButtonState()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    if (currentScreen == SCREEN_DOWNLOAD) {
                        statusText.text = "Engine initialization failed: ${e.message ?: "unknown error"}"
                    }
                }
            }
        }
    }

    private fun showDownloadScreen() {
        currentScreen = SCREEN_DOWNLOAD
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }
        val scroll = ScrollView(this).apply { setFillViewport(true) }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(22))
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val header = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            orientation = LinearLayout.HORIZONTAL
        }
        val logo = ImageView(this).apply {
            setImageResource(R.mipmap.ic_launcher)
            scaleType = ImageView.ScaleType.FIT_CENTER
        }
        header.addView(logo, LinearLayout.LayoutParams(dp(50), dp(50)))
        val heading = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        heading.setPadding(dp(12), 0, 0, 0)
        heading.addView(text("Lumo", 27f, white, true))
        heading.addView(text("Download videos and playlists", 12f, muted, false))
        header.addView(heading)
        content.addView(header)
        content.addView(space(20))

        val tabs = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(4), dp(4), dp(4), dp(4))
            background = rounded(panel, 16)
        }
        val videoTab = button("Video") { selectedTab = TAB_VIDEO; inspectedUrl = ""; showDownloadScreen() }
        val playlistTab = button("Playlist") { selectedTab = TAB_PLAYLIST; inspectedUrl = ""; showDownloadScreen() }
        videoTab.background = rounded(if (selectedTab == TAB_VIDEO) accent else panel, 12)
        playlistTab.background = rounded(if (selectedTab == TAB_PLAYLIST) accent else panel, 12)
        tabs.addView(videoTab, LinearLayout.LayoutParams(0, dp(48), 1f))
        tabs.addView(playlistTab, LinearLayout.LayoutParams(0, dp(48), 1f).apply { leftMargin = dp(6) })
        content.addView(tabs)
        content.addView(space(18))

        val urlCard = card()
        urlCard.addView(text(if (selectedTab == TAB_VIDEO) "VIDEO LINK" else "PLAYLIST LINK", 11f, muted, true))
        urlInput = EditText(this).apply {
            hint = if (selectedTab == TAB_VIDEO) "Paste a video link…" else "Paste a playlist link…"
            setHintTextColor(muted)
            setTextColor(white)
            textSize = 16f
            setSingleLine(false)
            minLines = 1
            maxLines = 3
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = rounded(Color.rgb(14, 15, 20), 12)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI
        }
        urlCard.addView(urlInput, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(9) })
        urlInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                updateDownloadButtonState()
            }
            override fun afterTextChanged(s: Editable?) = Unit
        })
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val pasteButton = button("Paste") {
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = clipboard.primaryClip
            val value = clip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(this@MainActivity)?.toString().orEmpty()
            if (value.isNotBlank()) {
                urlInput.setText(value)
                inspectedUrl = ""
                updateDownloadButtonState()
            }
        }
        inspectButton = button(if (selectedTab == TAB_VIDEO) "Inspect link" else "Validate link") {
            if (selectedTab == TAB_VIDEO) inspectVideo() else validatePlaylistLink()
        }
        actions.addView(pasteButton, LinearLayout.LayoutParams(0, dp(48), 1f))
        actions.addView(spaceView(9))
        actions.addView(inspectButton, LinearLayout.LayoutParams(0, dp(48), 1.55f))
        urlCard.addView(space(10))
        urlCard.addView(actions)
        content.addView(urlCard)
        content.addView(space(16))

        content.addView(text(if (selectedTab == TAB_VIDEO) "Video details" else "Playlist details", 18f, white, true))
        content.addView(space(8))
        detailsText = text(
            if (selectedTab == TAB_VIDEO) "Paste a supported link and inspect it to load real video information."
            else "Paste a playlist link. Lumo will download the available entries in playlist order.",
            14f, muted, false
        )
        detailsText.setPadding(dp(15), dp(15), dp(15), dp(15))
        detailsText.background = rounded(panel, 14, border)
        content.addView(detailsText, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))
        content.addView(space(18))

        content.addView(text("Choose quality", 18f, white, true))
        content.addView(space(7))
        qualitySpinner = spinner(listOf("Best available", "1080p", "720p", "480p", "360p"))
        content.addView(qualitySpinner, LinearLayout.LayoutParams(-1, dp(52)))
        content.addView(space(14))

        val preferenceRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        left.addView(text("Subtitles", 16f, white, true))
        left.addView(text("When available", 11f, muted, false))
        preferenceRow.addView(left, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        subtitlesSpinner = spinner(listOf("Off", "English", "Hindi", "English + Hindi", "All available"))
        val savedPrefs = getSharedPreferences("lumo_settings", Context.MODE_PRIVATE)
        subtitlesSpinner.setSelection(savedPrefs.getInt("subtitle_choice", 0).coerceIn(0, 4))
        preferenceRow.addView(subtitlesSpinner, LinearLayout.LayoutParams(dp(164), dp(48)))
        content.addView(preferenceRow)
        content.addView(space(12))

        val formatRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        formatRow.addView(text("File format", 16f, white, true), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        formatSpinner = spinner(listOf("MP4 · Compatible", "MKV · Flexible"))
        formatSpinner.setSelection(savedPrefs.getInt("format_choice", 0).coerceIn(0, 1))
        formatRow.addView(formatSpinner, LinearLayout.LayoutParams(dp(190), dp(48)))
        content.addView(formatRow)
        content.addView(space(18))

        downloadButton = button(if (selectedTab == TAB_VIDEO) "Download video ↓" else "Download Playlist ↓") { startDownload() }
        downloadButton.isEnabled = selectedTab == TAB_PLAYLIST && validUrl(urlInput.text.toString().trim()) && engineReady
        content.addView(downloadButton, LinearLayout.LayoutParams(-1, dp(54)))
        content.addView(space(12))

        progressPanel = card()
        progressPanel.addView(text("DOWNLOAD PROGRESS", 11f, muted, true))
        progressLabel = text("Preparing your download…", 13f, white, false)
        progressPanel.addView(space(7))
        progressPanel.addView(progressLabel)
        downloadProgress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = 0
        }
        progressPanel.addView(
            downloadProgress,
            LinearLayout.LayoutParams(-1, dp(8)).apply { topMargin = dp(12) }
        )
        cancelDownloadButton = button("Cancel download") {
            try {
                startService(Intent(this, DownloadService::class.java).setAction(DownloadService.ACTION_CANCEL))
                progressLabel.text = "Cancelling download…"
                cancelDownloadButton.isEnabled = false
            } catch (e: Exception) {
                Toast.makeText(this, "Could not cancel: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
        progressPanel.addView(space(10))
        progressPanel.addView(cancelDownloadButton)
        progressPanel.visibility = View.GONE
        content.addView(progressPanel)
        content.addView(space(10))

        statusText = text(if (engineReady) "Ready" else "Preparing download engine…", 12f, muted, false)
        statusText.gravity = Gravity.CENTER
        content.addView(statusText)
        content.addView(space(12))

        root.addView(bottomNavigation("download"))
        setContentView(root)
        restoreProgressUi()
    }

    private fun inspectVideo() {
        val url = urlInput.text.toString().trim()
        if (!validUrl(url)) {
            statusText.text = "Enter a valid HTTP or HTTPS video URL."
            return
        }
        if (!engineReady) {
            statusText.text = "Download engine is still starting. Try again shortly."
            return
        }
        hideKeyboard()
        inspectButton.isEnabled = false
        downloadButton.isEnabled = false
        statusText.text = "Inspecting link with yt-dlp…"
        worker.execute {
            try {
                val info = YoutubeDL.getInstance().getInfo(url)
                val title = info.title?.takeIf { it.isNotBlank() } ?: "Video"
                val duration = if (info.duration > 0) " · ${formatDuration(info.duration.toLong())}" else ""
                runOnUiThread {
                    if (currentScreen != SCREEN_DOWNLOAD || selectedTab != TAB_VIDEO) return@runOnUiThread
                    inspectedUrl = url
                    inspectedTitle = title
                    detailsText.text = "$title$duration\nSource: ${info.extractor ?: "Supported extractor"}"
                    statusText.text = "Video information loaded."
                    inspectButton.isEnabled = true
                    updateDownloadButtonState()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    if (currentScreen != SCREEN_DOWNLOAD) return@runOnUiThread
                    statusText.text = "Could not inspect link: ${e.message ?: "unsupported or unavailable link"}"
                    detailsText.text = "No video details were returned. Check the link and try again."
                    inspectButton.isEnabled = true
                    updateDownloadButtonState()
                }
            }
        }
    }

    private fun validatePlaylistLink() {
        val url = urlInput.text.toString().trim()
        if (!validUrl(url)) {
            statusText.text = "Enter a valid HTTP or HTTPS playlist URL."
            return
        }
        inspectedUrl = url
        inspectedTitle = "Playlist download"
        detailsText.text = "Playlist link accepted. yt-dlp will process the playlist entries in their source order."
        statusText.text = "Ready to download playlist."
        updateDownloadButtonState()
    }

    private fun updateDownloadButtonState() {
        if (!::downloadButton.isInitialized || !::urlInput.isInitialized) return
        val url = urlInput.text.toString().trim()
        downloadButton.isEnabled = engineReady && validUrl(url) &&
            (selectedTab == TAB_PLAYLIST || inspectedUrl == url)
    }

    private fun startDownload() {
        val url = urlInput.text.toString().trim()
        if (!validUrl(url)) {
            statusText.text = "Enter a valid video or playlist URL."
            return
        }
        if (!engineReady) {
            statusText.text = "Download engine is not ready yet."
            return
        }
        if (selectedTab == TAB_VIDEO && inspectedUrl != url) {
            statusText.text = "Inspect the video link before downloading."
            return
        }
        if (selectedTab == TAB_PLAYLIST && inspectedUrl != url) {
            validatePlaylistLink()
        }
        val heights = listOf(0, 1080, 720, 480, 360)
        val cap = heights[qualitySpinner.selectedItemPosition]
        val extFilter = if (formatSpinner.selectedItemPosition == 0) "[ext=mp4]" else ""
        val format = if (cap == 0) {
            "bestvideo$extFilter+bestaudio/best$extFilter/best"
        } else {
            "bestvideo$extFilter[height<=$cap]+bestaudio/best$extFilter[height<=$cap]/best[height<=$cap]"
        }
        val subtitle = when (subtitlesSpinner.selectedItemPosition) {
            1 -> "en"
            2 -> "hi"
            3 -> "en,hi"
            4 -> "all"
            else -> ""
        }
        val container = if (formatSpinner.selectedItemPosition == 0) "mp4" else "mkv"
        val title = if (selectedTab == TAB_PLAYLIST) "Playlist download" else inspectedTitle
        val intent = Intent(this, DownloadService::class.java).apply {
            action = DownloadService.ACTION_START
            putExtra(DownloadService.EXTRA_URL, url)
            putExtra(DownloadService.EXTRA_TITLE, title)
            putExtra(DownloadService.EXTRA_FORMAT, format)
            putExtra(DownloadService.EXTRA_CONTAINER, container)
            putExtra(DownloadService.EXTRA_SUBTITLE_LANGS, subtitle)
            putExtra(DownloadService.EXTRA_PLAYLIST, selectedTab == TAB_PLAYLIST)
        }
        renderProgressUi("Starting download…", 0, true)
        try {
            ContextCompat.startForegroundService(this, intent)
            downloadButton.isEnabled = false
            statusText.text = "Download started. Progress and Cancel are available here and in the notification."
        } catch (e: Exception) {
            renderProgressUi("Could not start download: ${e.message ?: "unknown error"}", 0, false)
            statusText.text = "Could not start the download service. Try again while Lumo is open."
            updateDownloadButtonState()
        }
    }

    private fun restoreProgressUi() {
        if (currentScreen != SCREEN_DOWNLOAD || !::progressPanel.isInitialized) return
        val prefs = getSharedPreferences("lumo_download_state", Context.MODE_PRIVATE)
        val message = prefs.getString("message", "").orEmpty()
        if (message.isNotBlank()) {
            renderProgressUi(
                message,
                prefs.getInt("progress", 0),
                prefs.getBoolean("ongoing", false)
            )
        }
    }

    private fun renderProgressUi(message: String, progress: Int, ongoing: Boolean) {
        if (currentScreen != SCREEN_DOWNLOAD || !::progressPanel.isInitialized) return
        progressPanel.visibility = View.VISIBLE
        progressLabel.text = message.ifBlank { "Download status unavailable" }
        downloadProgress.progress = progress.coerceIn(0, 100)
        cancelDownloadButton.visibility = if (ongoing) View.VISIBLE else View.GONE
        cancelDownloadButton.isEnabled = true
        if (!ongoing) updateDownloadButtonState()
    }

    private fun showHistory() {
        currentScreen = SCREEN_HISTORY
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(20), dp(22), dp(20), dp(16))
        }
        root.addView(text("History", 27f, white, true))
        root.addView(text("Your recent Lumo downloads", 13f, muted, false))
        root.addView(space(12))
        root.addView(button("Clear history") {
            HistoryStore.clear(this)
            showHistory()
        })
        root.addView(space(12))
        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val items = HistoryStore.items(this)
        if (items.length() == 0) {
            list.addView(text("No downloads yet.", 15f, muted, false))
        } else {
            for (i in 0 until items.length()) {
                val item = items.optJSONObject(i) ?: continue
                val card = card()
                card.addView(text(item.optString("title", "Lumo download"), 15f, white, true))
                card.addView(space(5))
                card.addView(text(item.optString("status", ""), 12f, muted, false))
                val location = item.optString("location", "")
                if (location.isNotBlank()) {
                    card.addView(space(5))
                    card.addView(text(location, 10f, muted, false))
                }
                val uriText = item.optString("uri", "")
                val path = item.optString("path", "")
                if (uriText.isNotBlank() || path.isNotBlank()) {
                    val share = button("Share / Open") {
                        shareDownload(uriText, path, item.optString("title", "Lumo download"))
                    }
                    card.addView(space(9))
                    card.addView(share)
                }
                list.addView(card, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(10) })
            }
        }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(bottomNavigation("history"))
        setContentView(root)
    }

    private fun showSettings() {
        currentScreen = SCREEN_SETTINGS
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(20), dp(22), dp(20), dp(16))
        }
        root.addView(text("Settings", 27f, white, true))
        root.addView(text("Adjust Lumo download preferences", 13f, muted, false))
        root.addView(space(20))

        val prefs = getSharedPreferences("lumo_settings", Context.MODE_PRIVATE)
        val folder = if (Build.VERSION.SDK_INT >= 29) "Downloads/Lumo" else "App storage / Download / LumoWork"
        val folderCard = card()
        folderCard.addView(text("DOWNLOAD FOLDER", 11f, muted, true))
        folderCard.addView(space(8))
        folderCard.addView(text(folder, 15f, white, false))
        root.addView(folderCard)
        root.addView(space(14))

        val subtitlesCard = card()
        subtitlesCard.addView(text("Preferred subtitles", 16f, white, true))
        subtitlesCard.addView(text("Used as the initial subtitle choice on the download screen.", 12f, muted, false))
        val prefSubs = spinner(listOf("Off", "English", "Hindi", "English + Hindi", "All available"))
        prefSubs.setSelection(prefs.getInt("subtitle_choice", 0).coerceIn(0, 4))
        subtitlesCard.addView(space(8))
        subtitlesCard.addView(prefSubs, LinearLayout.LayoutParams(-1, dp(48)))
        root.addView(subtitlesCard)
        root.addView(space(14))

        val qualityCard = card()
        qualityCard.addView(text("Preferred file format", 16f, white, true))
        qualityCard.addView(text("Choose the default container for merged downloads.", 12f, muted, false))
        val format = spinner(listOf("MP4 · Compatible", "MKV · Flexible"))
        format.setSelection(prefs.getInt("format_choice", 0).coerceIn(0, 1))
        qualityCard.addView(space(8))
        qualityCard.addView(format, LinearLayout.LayoutParams(-1, dp(48)))
        root.addView(qualityCard)
        root.addView(space(18))

        root.addView(button("Save preferences") {
            prefs.edit()
                .putInt("subtitle_choice", prefSubs.selectedItemPosition)
                .putInt("format_choice", format.selectedItemPosition)
                .apply()
            Toast.makeText(this, "Preferences saved", Toast.LENGTH_SHORT).show()
        })
        root.addView(space(10))
        root.addView(text("About this Android build", 15f, white, true))
        root.addView(space(4))
        root.addView(text("Native Kotlin interface · yt-dlp Android engine · FFmpeg merging\nVersion 1.0.0-native-alpha", 12f, muted, false))
        root.addView(View(this), LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(bottomNavigation("settings"))
        setContentView(root)
    }

    private fun bottomNavigation(active: String): LinearLayout {
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(12), dp(7), dp(12), dp(7))
            setBackgroundColor(Color.rgb(14, 15, 20))
            gravity = Gravity.CENTER
        }
        nav.addView(navButton("Download", active == "download") { showDownloadScreen() }, LinearLayout.LayoutParams(0, dp(48), 1f))
        nav.addView(navButton("History", active == "history") { showHistory() }, LinearLayout.LayoutParams(0, dp(48), 1f))
        nav.addView(navButton("Settings", active == "settings") { showSettings() }, LinearLayout.LayoutParams(0, dp(48), 1f))
        return nav
    }

    private fun navButton(label: String, active: Boolean, action: () -> Unit): Button = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 12f
        setTextColor(if (active) accent else muted)
        background = rounded(Color.TRANSPARENT, 10)
        setOnClickListener { action() }
    }

    private fun shareDownload(uriText: String, path: String, title: String) {
        try {
            val uri = if (uriText.isNotBlank()) Uri.parse(uriText) else {
                FileProvider.getUriForFile(this, "$packageName.fileprovider", File(path))
            }
            val viewIntent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, contentResolver.getType(uri) ?: "video/*")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            val sendIntent = Intent(Intent.ACTION_SEND).apply {
                type = contentResolver.getType(uri) ?: "video/*"
                putExtra(Intent.EXTRA_STREAM, uri)
                clipData = ClipData.newUri(contentResolver, title, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            val chooser = Intent.createChooser(sendIntent, "Share $title")
            if (viewIntent.resolveActivity(packageManager) != null) chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, arrayOf(viewIntent))
            startActivity(chooser)
        } catch (e: Exception) {
            Toast.makeText(this, "Could not open or share this file: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun spinner(values: List<String>): Spinner = Spinner(this).apply {
        adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, values).also {
            it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
        background = rounded(panel, 10, border)
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(15), dp(14), dp(15), dp(14))
        background = rounded(panel, 15, border)
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean): TextView = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun button(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 14f
        setTextColor(white)
        background = rounded(accent, 12)
        setPadding(dp(12), 0, dp(12), 0)
        setOnClickListener { action() }
    }

    private fun rounded(color: Int, radius: Int, stroke: Int? = null): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
        if (stroke != null) setStroke(dp(1), stroke)
    }

    private fun space(height: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(height)) }
    private fun spaceView(width: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(dp(width), 1) }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    private fun validUrl(value: String): Boolean {
        return try {
            val uri = Uri.parse(value)
            (uri.scheme.equals("https", true) || uri.scheme.equals("http", true)) && !uri.host.isNullOrBlank()
        } catch (_: Exception) { false }
    }

    private fun hideKeyboard() {
        try {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
                .hideSoftInputFromWindow(urlInput.windowToken, 0)
        } catch (_: Exception) { }
    }

    private fun formatDuration(seconds: Long): String {
        val h = seconds / 3600
        val m = (seconds % 3600) / 60
        val s = seconds % 60
        return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
    }

    override fun onBackPressed() {
        if (currentScreen != SCREEN_DOWNLOAD) {
            showDownloadScreen()
        } else {
            super.onBackPressed()
        }
    }

    override fun onStart() {
        super.onStart()
        if (!progressReceiverRegistered) {
            ContextCompat.registerReceiver(
                this,
                progressReceiver,
                IntentFilter(DownloadService.ACTION_PROGRESS),
                ContextCompat.RECEIVER_NOT_EXPORTED
            )
            progressReceiverRegistered = true
        }
        restoreProgressUi()
    }

    override fun onStop() {
        if (progressReceiverRegistered) {
            unregisterReceiver(progressReceiver)
            progressReceiverRegistered = false
        }
        super.onStop()
    }

    override fun onDestroy() {
        worker.shutdown()
        super.onDestroy()
    }

    companion object {
        private const val TAB_VIDEO = "Video"
        private const val TAB_PLAYLIST = "Playlist"
        private const val SCREEN_DOWNLOAD = "download"
        private const val SCREEN_HISTORY = "history"
        private const val SCREEN_SETTINGS = "settings"
    }
}
