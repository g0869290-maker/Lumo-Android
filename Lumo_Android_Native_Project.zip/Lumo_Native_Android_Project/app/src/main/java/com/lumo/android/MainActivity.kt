package com.lumo.android

import android.Manifest
import android.app.Activity
import android.content.*
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.webkit.*
import android.widget.Toast
import androidx.core.content.ContextCompat
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.ffmpeg.FFmpeg
import org.json.JSONObject
import java.util.concurrent.Executors

/** Lumo's supplied HTML is the actual app UI. Native code is limited to privileged media work. */
class MainActivity : Activity() {
    private lateinit var web: WebView
    private val worker = Executors.newSingleThreadExecutor()
    @Volatile private var engineReady = false
    @Volatile private var inspectedUrl = ""
    @Volatile private var inspectedTitle = "Lumo download"
    private val progressReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent == null || !::web.isInitialized) return
            val message = JSONObject.quote(intent.getStringExtra(DownloadService.EXTRA_PROGRESS_MESSAGE).orEmpty())
            val progress = intent.getIntExtra(DownloadService.EXTRA_PROGRESS_VALUE, 0)
            val ongoing = intent.getBooleanExtra(DownloadService.EXTRA_PROGRESS_ONGOING, false)
            web.evaluateJavascript("window.LumoNativeProgress && window.LumoNativeProgress($message,$progress,${if (ongoing) "true" else "false"})", null)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(5,5,6)
        window.navigationBarColor = android.graphics.Color.BLACK
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 41)
        web = WebView(this).apply {
            setBackgroundColor(android.graphics.Color.rgb(5,5,6))
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            settings.mediaPlaybackRequiresUserGesture = true
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean = true
                override fun onPageFinished(view: WebView?, url: String?) { installNativeHooks() }
            }
            addJavascriptInterface(NativeBridge(), "Lumo")
            loadUrl("file:///android_asset/index.html")
        }
        setContentView(web)
        val filter = IntentFilter(DownloadService.ACTION_PROGRESS)
        if (Build.VERSION.SDK_INT >= 33) { registerReceiver(progressReceiver, filter, RECEIVER_NOT_EXPORTED) } else { @Suppress("DEPRECATION") registerReceiver(progressReceiver, filter) }
        worker.execute {
            try { YoutubeDL.getInstance().init(applicationContext); FFmpeg.getInstance().init(applicationContext); engineReady = true }
            catch (_: Exception) { engineReady = false }
        }
    }

    private fun installNativeHooks() {
        val js = """
        (function(){
          const $=s=>document.querySelector(s), show=(e,v)=>e&&e.classList.toggle('hide',!v);
          let currentUrl='',currentTitle='Lumo download',quality='best',container='mp4',subs='';
          const toast=m=>{const t=$('#toast');if(t){t.textContent=m;t.classList.add('on');setTimeout(()=>t.classList.remove('on'),2400)}};
          function pasteInto(id){Lumo.getClipboard(id);}
          $('#paste').onclick=()=>pasteInto('video'); $('#ppaste').onclick=()=>pasteInto('playlist');
          window.LumoSetClipboard=(kind,value)=>{if(!value){toast('Clipboard is empty');return}currentUrl=value; if(kind==='video'){$('#url').textContent=value;$('#url').classList.add('f');show($('#vx'),true);show($('#vinsp'),true);show($('#vq'),false);Lumo.inspect(value)}else{$('#purl').textContent=value;$('#purl').classList.add('f');show($('#px'),true);show($('#pinsp'),true);Lumo.inspectPlaylist(value)}};
          window.LumoInspectResult=(ok,data)=>{show($('#vinsp'),false);if(!ok){toast(data.error||'Could not inspect link');return}currentTitle=data.title||'Video';
            const q=$('#vq');show(q,true);const card=q.querySelector('.card');if(card){const t=card.querySelector('.t'),s=card.querySelector('.s'),thumb=card.querySelector('.thumb');if(t)t.textContent=currentTitle;if(s)s.textContent=(data.extractor||'Video source')+(data.duration?' · '+data.duration:'');if(thumb&&data.thumbnail){thumb.innerHTML='';const im=document.createElement('img');im.src=data.thumbnail;im.alt='Video thumbnail';im.style.cssText='width:100%;height:100%;object-fit:cover;border-radius:12px';thumb.append(im)}}
            const est=$('#est');if(est)est.textContent=data.formats||'Exact size unavailable for this source';const dd=$('#vdd');if(dd){const b=dd.querySelector('button span');if(b)b.textContent='Best available'} };
          $('#dl').onclick=()=>{const chosen=$('#vdd button span')?.textContent||'Best available';quality=chosen;container=$('#fmt .on')?.textContent.includes('MKV')?'mkv':'mp4';subs=[...($('#vsubs')?.children||[])].filter(x=>x.classList.contains('on')).map(x=>x.dataset.k).join(',');Lumo.startDownload(currentUrl,currentTitle,quality,container,subs,false);show($('#vd'),true);$('#dt').textContent=currentTitle;$('#ds').textContent='Starting download…'};
          $('#cancel').onclick=()=>{Lumo.cancelDownload();toast('Cancellation requested')};
          $('#pgo').onclick=()=>{const u=currentUrl;Lumo.startDownload(u,'Playlist download','best','mp4','',true);show($('#prun'),true);toast('Playlist download started')};
          window.LumoNativeProgress=(message,p,ongoing)=>{const fill=$('#fill'),pc=$('#pc'),ds=$('#ds'),spd=$('#spd');if(fill)fill.style.width=p+'%';if(pc)pc.textContent=ongoing?p+'%':'Completed';if(ds)ds.textContent=message;if(spd)spd.textContent=ongoing?'Download running in background':'Download finished';if(!ongoing){show($('#cancel'),false);show($('#open'),true);show($('#nv'),true);const w=$('#pbw');if(w)w.classList.add('c3')}};
          $('#vx').onclick=()=>{currentUrl='';$('#url').textContent='Paste a video link…';show($('#vq'),false);show($('#vo'),false);show($('#vd'),false)};
          const oldBack=$('#back');if(oldBack)oldBack.onclick=()=>{show($('#vo'),false);show($('#vq'),true)};
          window.LumoPlaylistResult=(ok,data)=>{show($('#pinsp'),false);if(!ok){toast(data.error||'Playlist inspection failed');return}const list=$('#plist');if(list){list.innerHTML='';(data.entries||[]).forEach(e=>{const row=document.createElement('div');row.className='li';const m=document.createElement('div');m.className='m';const title=document.createElement('div');title.className='t';title.textContent=e.title||'Video';const sub=document.createElement('div');sub.className='s';sub.textContent=e.duration||'';m.append(title,sub);row.append(m);list.append(row)});$('#ptitle').textContent=(data.title||'Playlist')+' · '+(data.entries||[]).length+' videos';show($('#pready'),true);show($('#pcfg'),true)}};
        })();
        """.trimIndent()
        web.evaluateJavascript(js, null)
        web.evaluateJavascript("window.LumoNativeReady=${if (engineReady) "true" else "false"}", null)
    }

    inner class NativeBridge {
        @JavascriptInterface fun getClipboard(kind: String) { runOnUiThread { val cm=getSystemService(CLIPBOARD_SERVICE) as ClipboardManager; val value=cm.primaryClip?.takeIf{it.itemCount>0}?.getItemAt(0)?.coerceToText(this@MainActivity)?.toString().orEmpty(); web.evaluateJavascript("window.LumoSetClipboard(${JSONObject.quote(kind)},${JSONObject.quote(value)})",null) } }
        @JavascriptInterface fun inspect(url: String) {
            if (!validUrl(url)) { callbackInspect(false, JSONObject().put("error","Enter a valid HTTP or HTTPS link")); return }
            worker.execute { try {
                if (!engineReady) throw IllegalStateException("Download engine is still starting")
                val info=YoutubeDL.getInstance().getInfo(url); inspectedUrl=url; inspectedTitle=info.title?.takeIf{it.isNotBlank()}?:"Video"
                val obj=JSONObject().put("title",inspectedTitle).put("extractor",info.extractor?:"Source").put("duration",if(info.duration>0) formatDuration(info.duration.toLong()) else "").put("thumbnail",reflectedString(info,"getThumbnail","getThumbnailUrl","thumbnail","thumbnailUrl")?:"").put("formats",formatSummary(info))
                callbackInspect(true,obj)
            } catch(e:Exception){callbackInspect(false,JSONObject().put("error",e.message?:"Inspection failed"))} }
        }
        @JavascriptInterface fun inspectPlaylist(url:String) { if(!validUrl(url)){callbackPlaylist(false,JSONObject().put("error","Invalid playlist URL"));return}; worker.execute { try { val info=YoutubeDL.getInstance().getInfo(url); val entries=JSONObject(); val arr=org.json.JSONArray(); val raw=try{info.javaClass.methods.firstOrNull{it.name=="getEntries"&&it.parameterCount==0}?.invoke(info) as? Iterable<*>}catch(_:Exception){null}; raw?.take(500)?.forEach{entry->if(entry!=null)arr.put(JSONObject().put("title",reflectedText(entry,"getTitle")?:"Video").put("duration",reflectedText(entry,"getDuration")?:""))};entries.put("title",info.title?:"Playlist").put("entries",arr);callbackPlaylist(true,entries) }catch(e:Exception){callbackPlaylist(false,JSONObject().put("error",e.message?:"Playlist inspection failed"))} } }
        @JavascriptInterface fun startDownload(url:String,title:String,quality:String,container:String,subs:String,playlist:Boolean) { if(!validUrl(url)){toastUi("Invalid link");return}; if(!engineReady){toastUi("Download engine is not ready");return}; val cap=when{quality.contains("1080")->1080;quality.contains("720")->720;quality.contains("480")->480;quality.contains("360")->360;else->0}; val ext=if(container=="mp4")"[ext=mp4]" else ""; val fmt=if(cap==0)"bestvideo$ext+bestaudio/best$ext/best" else "bestvideo$ext[height<=$cap]+bestaudio/best$ext[height<=$cap]/best[height<=$cap]"; val i=Intent(this@MainActivity,DownloadService::class.java).apply{action=DownloadService.ACTION_START;putExtra(DownloadService.EXTRA_URL,url);putExtra(DownloadService.EXTRA_TITLE,title);putExtra(DownloadService.EXTRA_FORMAT,fmt);putExtra(DownloadService.EXTRA_CONTAINER,container);putExtra(DownloadService.EXTRA_SUBTITLE_LANGS,subs);putExtra(DownloadService.EXTRA_PLAYLIST,playlist)};try{ContextCompat.startForegroundService(this@MainActivity,i)}catch(e:Exception){toastUi(e.message?:"Could not start download")}}
        @JavascriptInterface fun cancelDownload(){startService(Intent(this@MainActivity,DownloadService::class.java).setAction(DownloadService.ACTION_CANCEL))}
    }

    private fun callbackInspect(ok:Boolean,obj:JSONObject){runOnUiThread{web.evaluateJavascript("window.LumoInspectResult(${if(ok)"true" else "false"},JSON.parse(${JSONObject.quote(obj.toString())}))",null)}}
    private fun callbackPlaylist(ok:Boolean,obj:JSONObject){runOnUiThread{web.evaluateJavascript("window.LumoPlaylistResult(${if(ok)"true" else "false"},JSON.parse(${JSONObject.quote(obj.toString())}))",null)}}
    private fun toastUi(s:String){runOnUiThread{Toast.makeText(this,s,Toast.LENGTH_LONG).show()}}
    private fun validUrl(s:String)=try{val u=android.net.Uri.parse(s);(u.scheme=="http"||u.scheme=="https")&&!u.host.isNullOrBlank()}catch(_:Exception){false}
    private fun reflectedString(o:Any,vararg names:String):String?{for(n in names)try{o.javaClass.methods.firstOrNull{it.name==n&&it.parameterCount==0}?.invoke(o)?.toString()?.let{if(it.startsWith("http"))return it}}catch(_:Exception){};return null}
    private fun reflectedText(o:Any,n:String):String?=try{o.javaClass.methods.firstOrNull{it.name==n&&it.parameterCount==0}?.invoke(o)?.toString()}catch(_:Exception){null}
    private fun formatSummary(info:Any):String{val fs=try{info.javaClass.methods.firstOrNull{(it.name=="getFormats"||it.name=="getFormatList")&&it.parameterCount==0}?.invoke(info) as? Iterable<*>}catch(_:Exception){null}?:return "Exact size unavailable";val map=linkedMapOf<Int,Long>();fs.forEach{f->if(f!=null)try{val h=(f.javaClass.methods.firstOrNull{it.name=="getHeight"&&it.parameterCount==0}?.invoke(f) as? Number)?.toInt()?:0;val b=(f.javaClass.methods.firstOrNull{it.name in listOf("getFilesize","getFileSize","getFilesizeApprox","getFileSizeApprox")&&it.parameterCount==0}?.invoke(f) as? Number)?.toLong()?:0;if(h>0&&b>0&&b>(map[h]?:0))map[h]=b}catch(_:Exception){}};return if(map.isEmpty())"Exact size unavailable" else map.entries.sortedByDescending{it.key}.joinToString(" · "){it.key.toString()+"p ~ "+"%.1f".format(java.util.Locale.US,it.value/1048576.0)+" MB"}}
    private fun formatDuration(s:Long):String="%d:%02d".format(s/60,s%60)
    override fun onBackPressed(){if(web.canGoBack())web.goBack() else web.evaluateJavascript("(function(){const p=document.querySelector('.page.on');if(p&&p.id!=='p0'){document.querySelectorAll('.page').forEach(x=>x.classList.remove('on'));document.querySelector('#p0')?.classList.add('on')}else{const q=document.querySelector('#vo');if(q&&!q.classList.contains('hide'))q.classList.add('hide');else if(!document.querySelector('#vq')?.classList.contains('hide'))document.querySelector('#vq')?.classList.add('hide');else return 'exit'}})()",null)}
    override fun onDestroy(){try{unregisterReceiver(progressReceiver)}catch(_:Exception){};worker.shutdown();if(::web.isInitialized)web.destroy();super.onDestroy()}
}
