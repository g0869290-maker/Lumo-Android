# Lumo Android — HTML UI + native downloader bridge (alpha)

This iteration changes the Android app architecture: the supplied `Lumo_Android_Preview_Original.html` is copied unchanged into `app/src/main/assets/index.html` and loaded as the actual WebView interface. The prior hand-built Kotlin screen is no longer the app's main screen.

## Native integrations in this iteration
- Local HTML/CSS/JS UI with JavaScript enabled only for the bundled local asset.
- Native clipboard read for the Video and Playlist paste actions.
- Native yt-dlp `getInfo()` inspection for video links; title, extractor, duration, thumbnail URL, and source-reported format sizes are passed back to the HTML.
- Playlist metadata inspection attempts to enumerate source entries returned by the installed yt-dlp Android wrapper.
- Native foreground `DownloadService` start/cancel actions, with progress broadcasts reflected into the HTML progress panel.
- Uses the supplied Lumo launcher artwork and original Windows source archive retained under `reference/`.

## Known incomplete items — do not mistake this alpha for a finished clone
- The supplied HTML itself contains simulated preview behavior in parts of Playlist, History, Settings, and some quality/size display. This bridge replaces core video inspection and download start/cancel, but does not yet replace every simulated interaction.
- Playlist entry parsing depends on what `youtubedl-android` exposes from `getInfo()`; some extractors may not return a complete playlist entry list.
- The currently pinned `youtubedl-android` dependency is still `0.18.1`. This ZIP does **not** claim that the embedded yt-dlp runtime is automatically updated to the latest upstream release. A supported updateable runtime strategy remains a separate engineering task.
- The progress UI receives the service's progress message and percentage; detailed instantaneous speed/ETA parsing is not yet wired into dedicated fields.
- This environment has not run a complete Android SDK build or device test. GitHub Actions is the build check; install and test on the OPPO Reno6 5G before relying on it.

## Build with GitHub Actions
Use `.github/workflows/build-android.yml` as before. It builds `assembleDebug` with JDK 17 / Gradle 8.9 and uploads the debug APK artifact.

Only download media you own or are authorized to save, and follow the source platform's terms.
