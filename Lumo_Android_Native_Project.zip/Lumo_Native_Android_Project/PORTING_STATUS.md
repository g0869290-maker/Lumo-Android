# Lumo Windows → Android port status

The Windows source archive and Android preview are kept in `reference/`. The Windows application is a Python desktop application (Tkinter-oriented UI plus a Python `yt-dlp` downloader). That desktop UI cannot simply be copied into Android: the native UI and Android background/storage lifecycle need Android implementations.

## Implemented in this native alpha

| Area | Android implementation |
|---|---|
| App identity | Lumo app label and launcher icon rendered from the supplied `Lumo_icon.ico` |
| Interface | Native Kotlin/Android Views with the dark layout, pink accent, Video/Playlist selector and bottom navigation |
| Video inspection | Android yt-dlp `getInfo` call for individual video links |
| Video download | yt-dlp request, format/quality selector and FFmpeg merge |
| Playlist download | yt-dlp playlist mode, ignoring unavailable entries so the rest can continue |
| Subtitles | Language selection, subtitle/automatic-subtitle retrieval and embedding attempt |
| Background operation | Android foreground service, in-app progress panel, notification progress and Cancel action |
| Storage | Temporary app-private work area; MediaStore export to `Downloads/Lumo` on Android 10+ |
| History | Local history with share/open handoff for saved files |
| Preferences | Saved preferred subtitle language and file container |

## Not yet a full parity port

These parts exist in or are referenced by the Windows code, but are **not implemented to Windows parity** in this alpha:

- Cookie file import / browser-cookie support and related sign-in guidance.
- True pause and resume of an active job (the Android library integration used here currently exposes process destruction for Cancel; pause/resume needs a different job-control design).
- The Windows multi-URL/multi-job queue and detailed per-item playlist selection / retry controls.
- Full Windows format enumeration, accurate per-format size estimates and all of the original quality-selection rules.
- User-selected output folder / folder browser equivalent on Android.
- Every Windows setting, diagnostics panel, animation and interaction detail.
- Full source parity for the Windows subtitle ranking/fetch/mux logic; Android uses yt-dlp's built-in subtitle handling and FFmpeg embedding options.

## Next technical milestones

1. Build with GitHub Actions and resolve any compile errors reported by the runner.
2. Install and test on the OPPO Reno6 5G: first-run engine setup, individual video inspect, video download, playlist download, notification cancellation, app backgrounding, history, file export and sharing.
3. Port missing Windows features in priority order after device tests, keeping the native UI aligned with the supplied Android preview.

No APK is bundled here because it has not been built and device-tested in this environment.
