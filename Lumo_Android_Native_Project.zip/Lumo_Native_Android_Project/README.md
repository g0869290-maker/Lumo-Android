# Lumo for Android — Native project

This is the native Android implementation package for Lumo. The app code is Kotlin and Android Views. The supplied HTML file is kept only as a design/reference preview; it is **not** loaded in the app and is not the download engine.

## What is in this ZIP

- `app/` — native Android application source, manifest, icon resources and downloader service.
- `.github/workflows/build-android.yml` — GitHub Actions workflow that builds a debug APK on pushes to `main`/`master` or by manual run.
- `reference/Lumo_Windows_Source_Original.zip` — the original Windows app source archive you supplied, kept intact for porting and comparison.
- `reference/Lumo_Android_Preview_Original.html` — the Android HTML preview you supplied, kept intact as the UI reference.
- `reference/Lumo_icon.ico` — the original Windows icon asset. Android launcher PNGs are rendered from this ICO.
- `PORTING_STATUS.md` — implemented functionality and remaining Windows-to-Android parity work.

## Native functionality in this build

- Native Kotlin interface with Video / Playlist modes and Download / History / Settings navigation.
- Real individual-video inspection through the Android yt-dlp runtime.
- Video downloads and playlist downloads through yt-dlp; playlist entries are processed by yt-dlp in playlist order.
- Best available, 1080p, 720p, 480p and 360p quality caps.
- MP4 or MKV merge container using the bundled FFmpeg integration.
- Optional subtitle retrieval for English, Hindi, both, or all available languages, then embedding where supported by the source and FFmpeg.
- Foreground download service with an in-app progress panel, progress notifications and a Cancel action. Downloads continue when the activity is not visible, subject to Android's background-service and battery policies.
- Download history with a Share / Open action.
- Android 10+ completed files are exported to the user's public `Downloads/Lumo` folder through MediaStore. On older Android versions the fallback is app-specific storage and files are shareable from History.
- The launcher icon is based on the exact `Lumo_icon.ico` from the supplied Windows ZIP.

## Build APK with GitHub Actions (phone-friendly workflow)

1. Extract this ZIP so that `settings.gradle.kts`, `build.gradle.kts`, `app/`, and `.github/` are at the **root of the GitHub repository**. Do not commit only this ZIP as a single file.
2. Commit and push the files to the repository's `main` or `master` branch. The included workflow starts automatically. You can also open **Actions → Build Lumo Android → Run workflow**.
3. Open the finished workflow run, find **Artifacts**, and download `Lumo-Android-debug-APK`.
4. Extract the artifact and install `app-debug.apk` on the phone. Android may ask permission to install apps from the browser or file manager used to open it.

The workflow accepts the Android SDK licences, installs JDK 17 and Android SDK 35, and installs Gradle 8.9. It uses the Gradle executable installed by the GitHub Actions setup step, so a Gradle wrapper JAR is not required for this GitHub build.

## Important build and feature status

This is a **native Android alpha port**, not a claim that every Windows feature is already identical. The current environment did not contain an Android SDK or Gradle installation, so an APK could not be compiled or run here. The included GitHub Actions workflow is the build/verification step; check its result before installing.

Windows-only behaviour still needs dedicated Android implementation and device testing. See `PORTING_STATUS.md`. In particular, this package does not yet claim full parity for browser-cookie import, pausing/resuming an in-flight download, the Windows multi-job queue, every advanced format/size estimate, custom folder picking, or all Windows settings and motion details.

## Toolchain and dependency notes

- Android Gradle Plugin: 8.7.3
- Kotlin Gradle Plugin: 2.0.21
- Gradle: 8.9
- Java: 17
- Android compile / target SDK: 35
- yt-dlp Android wrapper: `io.github.junkfood02.youtubedl-android` 0.18.1
- FFmpeg module: same library release 0.18.1

The yt-dlp Android wrapper documentation describes yt-dlp and Python as bundled in the library, its `YoutubeDL.execute` progress callback, and the optional FFmpeg module. Its current documentation also notes Android scoped-storage restrictions for direct writes; this project avoids asking for broad storage access and publishes completed media through MediaStore on Android 10+.

## Licensing / distribution

The Android yt-dlp wrapper and its FFmpeg module are published with GPL-3.0 licensing metadata. Before public distribution, review the dependencies' license terms and ensure the final app/source distribution complies. The user's original Lumo source files are retained in `reference/` and have not been relicensed by this package.
