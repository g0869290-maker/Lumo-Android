# Lumo Android — complete starter source project

This is the Android Studio source project for Lumo, based on the supplied Android HTML preview. It contains the app module, Kotlin Android host, bundled HTML/CSS/JavaScript interface, Android resources, Gradle Kotlin build files, and the original Windows source ZIP for reference.

## Open the project

1. Extract this ZIP on your computer.
2. In Android Studio, choose **Open** and select the `Lumo_Android_Project` folder (the folder containing `settings.gradle.kts`).
3. Allow Android Studio to download the required Gradle and Android SDK components.
4. Select the `app` run configuration and run on an Android device or emulator.

The project targets Android SDK 35, uses Android Gradle Plugin 8.7.3 and Kotlin 2.0.21, and is configured for Gradle 8.9. `gradle/wrapper/gradle-wrapper.properties` is included. If you use Android Studio, it can sync the project using its Gradle integration.

## What's included

- `app/src/main/assets/index.html` — supplied Lumo Android HTML preview bundled as the app UI.
- `app/src/main/java/com/lumo/android/MainActivity.kt` — Android WebView host and JavaScript bridge.
- `app/src/main/AndroidManifest.xml` — app declaration and permissions.
- `app/src/main/res/values/styles.xml` — app theme.
- `app/build.gradle.kts`, `build.gradle.kts`, `settings.gradle.kts`, and `gradle.properties` — Gradle project configuration.
- `reference/Lumo_Windows_Source_Original.zip` — original Windows app source archive for reference; it is not compiled into the Android app.

## Current implementation status — read before testing

This is a **buildable starter project**, not a finished feature-equivalent port of the Windows downloader.

- The supplied HTML preview is bundled in the Android app.
- The native bridge supports direct HTTPS file downloads using Android `DownloadManager`, status lookup, cancellation, clipboard reading, and opening the system Downloads screen.
- The preview's sample/demo download behavior is not the same as a real platform media extractor.
- YouTube/platform extraction, playlist parsing, quality/format selection, subtitle extraction, and conversion have **not** been ported from the Windows Python application.
- No APK has been built or device-tested as part of this source archive.

Only download content you have permission to save and comply with the source site's terms and applicable law.

## Package identity

- App label: Lumo
- Application ID: `com.lumo.android`
- Namespace: `com.lumo.android`
- Version: `0.2.0-native-direct-download`
