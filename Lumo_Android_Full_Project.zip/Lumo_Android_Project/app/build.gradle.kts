plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.lumo.android"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.lumo.android"
        minSdk = 23
        targetSdk = 35
        versionCode = 2
        versionName = "0.2.0-native-direct-download"
    }
}
