package com.lumo.android

import android.Manifest
import android.app.Activity
import android.app.DownloadManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import org.json.JSONObject
import java.net.URLConnection

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private lateinit var downloadManager: DownloadManager
    private var backArmed = false

    @Suppress("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        downloadManager = getSystemService(DOWNLOAD_SERVICE) as DownloadManager
        window.statusBarColor = android.graphics.Color.BLACK
        window.navigationBarColor = android.graphics.Color.BLACK
        window.decorView.systemUiVisibility = 0
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)

        webView = WebView(this).apply {
            setBackgroundColor(android.graphics.Color.BLACK)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            settings.setSupportZoom(false)
            settings.javaScriptCanOpenWindowsAutomatically = false
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
                    // Keep the privileged JavaScript bridge confined to the bundled local UI.
                    return !url.startsWith("file:///android_asset/")
                }
            }
            webChromeClient = WebChromeClient()
            addJavascriptInterface(LumoBridge(this@MainActivity), "LumoAndroid")
            overScrollMode = View.OVER_SCROLL_NEVER
            loadUrl("file:///android_asset/index.html")
        }
        setContentView(webView)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 41)
        }
    }

    private inner class LumoBridge(private val activity: Activity) {
        @JavascriptInterface
        fun clipboardText(): String {
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val item: ClipData.Item = clipboard.primaryClip?.getItemAt(0) ?: return ""
            return item.coerceToText(activity)?.toString()?.trim().orEmpty()
        }

        @JavascriptInterface
        fun enqueueDownload(rawUrl: String): String {
            return try {
                val uri = Uri.parse(rawUrl.trim())
                val scheme = uri.scheme?.lowercase()
                if (scheme != "https") {
                    return JSONObject().put("ok", false).put("error", "Use a direct HTTPS file URL.").toString()
                }
                val host = uri.host ?: return JSONObject().put("ok", false).put("error", "That URL is not valid.").toString()
                if (host.isBlank() || rawUrl.length > 4096) {
                    return JSONObject().put("ok", false).put("error", "That URL is not valid.").toString()
                }
                val pathName = uri.lastPathSegment.orEmpty().substringAfterLast('/')
                val safeName = pathName.replace(Regex("[^A-Za-z0-9._-]"), "_")
                    .take(100).ifBlank { "lumo_${System.currentTimeMillis()}.download" }
                val mime = URLConnection.guessContentTypeFromName(safeName) ?: "application/octet-stream"
                val request = DownloadManager.Request(uri)
                    .setTitle(safeName)
                    .setDescription("Downloading with Lumo")
                    .setMimeType(mime)
                    .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    .setAllowedOverMetered(true)
                    .setAllowedOverRoaming(false)
                    .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "Lumo/$safeName")
                val id = downloadManager.enqueue(request)
                JSONObject().put("ok", true).put("id", id).put("name", safeName).toString()
            } catch (e: Exception) {
                JSONObject().put("ok", false)
                    .put("error", e.message ?: "Could not start this download.").toString()
            }
        }

        @JavascriptInterface
        fun downloadStatus(id: Long): String {
            val query = DownloadManager.Query().setFilterById(id)
            downloadManager.query(query)?.use { cursor ->
                if (!cursor.moveToFirst()) return JSONObject().put("found", false).toString()
                val status = cursor.getInt(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
                val downloaded = cursor.getLong(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR))
                val total = cursor.getLong(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES))
                val reason = cursor.getInt(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_REASON))
                val state = when (status) {
                    DownloadManager.STATUS_PENDING -> "pending"
                    DownloadManager.STATUS_RUNNING -> "running"
                    DownloadManager.STATUS_PAUSED -> "paused"
                    DownloadManager.STATUS_SUCCESSFUL -> "complete"
                    DownloadManager.STATUS_FAILED -> "failed"
                    else -> "unknown"
                }
                return JSONObject().put("found", true).put("state", state)
                    .put("downloaded", downloaded).put("total", total).put("reason", reason).toString()
            }
            return JSONObject().put("found", false).toString()
        }

        @JavascriptInterface
        fun cancelDownload(id: Long): Boolean = downloadManager.remove(id) > 0

        @JavascriptInterface
        fun openDownloads(): Boolean {
            return try {
                startActivity(android.content.Intent(DownloadManager.ACTION_VIEW_DOWNLOADS))
                true
            } catch (_: Exception) { false }
        }
    }

    @Deprecated("Deprecated in Android API; retained for broad device compatibility")
    override fun onBackPressed() {
        webView.evaluateJavascript(
            "(function(){var b=document.querySelectorAll('#nav button');" +
                "if(b.length && !b[0].classList.contains('on')){b[0].click();return 'handled';}" +
                "return 'home';})()"
        ) { result ->
            if (result == "\"home\"") {
                if (backArmed) finish() else {
                    backArmed = true
                    Toast.makeText(this, "Press Back again to exit Lumo", Toast.LENGTH_SHORT).show()
                    webView.postDelayed({ backArmed = false }, 2000)
                }
            }
        }
    }

    override fun onDestroy() {
        if (::webView.isInitialized) {
            webView.stopLoading()
            webView.destroy()
        }
        super.onDestroy()
    }
}
