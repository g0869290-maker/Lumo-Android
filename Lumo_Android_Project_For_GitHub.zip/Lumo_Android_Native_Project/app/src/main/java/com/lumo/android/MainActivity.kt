package com.lumo.android

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color as AndroidColor
import android.os.Build
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.launch
import org.json.JSONObject

class MainActivity : ComponentActivity() {
    private lateinit var webView: WebView
    private var pageReady = false
    private var pendingShareText: String? = null
    private val pendingEvents = ArrayList<Pair<String, JSONObject>>()

    private val cookiePicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) Lumo.importCookies(uri)
    }

    fun pickCookieFile() {
        cookiePicker.launch(arrayOf("text/plain", "text/*", "application/octet-stream", "*/*"))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = AndroidColor.BLACK
        window.navigationBarColor = AndroidColor.BLACK
        WindowInsetsControllerCompat(window, window.decorView).apply {
            isAppearanceLightStatusBars = false
            isAppearanceLightNavigationBars = false
        }

        Lumo.init(this)
        requestRuntimePermissions()
        pendingShareText = sharedText(intent)

        webView = WebView(this).apply {
            setBackgroundColor(AndroidColor.BLACK)
            ViewCompat.setOnApplyWindowInsetsListener(this) { view, insets ->
                val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
                view.setPadding(0, bars.top, 0, bars.bottom)
                insets
            }
            isVerticalScrollBarEnabled = false
            isHorizontalScrollBarEnabled = false
            overScrollMode = WebView.OVER_SCROLL_NEVER
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                allowFileAccess = true
                allowContentAccess = false
                allowFileAccessFromFileURLs = false
                allowUniversalAccessFromFileURLs = false
                javaScriptCanOpenWindowsAutomatically = false
                setSupportMultipleWindows(false)
                mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW
            }
            addJavascriptInterface(LumoWebBridge(this@MainActivity), "LumoNative")
            webChromeClient = WebChromeClient()
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    if (!pageReady) {
                        pageReady = true
                        dispatch("boot", WebPayload.bootstrap())
                        syncActiveUi()
                        pendingEvents.toList().forEach { dispatch(it.first, it.second) }
                        pendingEvents.clear()
                        pendingShareText?.let { shared ->
                            pendingShareText = null
                            Lumo.handleShare(shared)
                        }
                    }
                }

                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    val uri = request?.url ?: return false
                    // The only app document is the bundled asset. External pages are opened outside Lumo.
                    if (uri.scheme == "file" && uri.path?.contains("/android_asset/") == true) return false
                    if (uri.scheme == "https" || uri.scheme == "http") {
                        return try {
                            startActivity(Intent(Intent.ACTION_VIEW, uri))
                            true
                        } catch (_: Exception) {
                            true
                        }
                    }
                    return true
                }
            }
        }
        setContentView(webView)
        ViewCompat.requestApplyInsets(webView)
        webView.loadUrl("file:///android_asset/index.html")

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    LumoWebEvents.events.collect { event -> dispatch(event.name, event.payload) }
                }
                launch {
                    DownloadBus.state.collect { state -> dispatch("onDownloadState", WebPayload.job(state)) }
                }
                launch {
                    HistoryStore.items.collect { items ->
                        dispatch("onHistory", JSONObject().put("items", WebPayload.history(items)))
                    }
                }
            }
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (!::webView.isInitialized) {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                    return
                }
                // The page answers "true" when it consumed Back; otherwise leave the app as usual.
                webView.evaluateJavascript("window.LumoApp ? window.LumoApp.onSystemBack() : false") { result ->
                    if (result != "true") {
                        isEnabled = false
                        onBackPressedDispatcher.onBackPressed()
                    }
                }
            }
        })
    }

    override fun onResume() {
        super.onResume()
        if (::webView.isInitialized) webView.onResume()
        if (pageReady) {
            dispatch("onEngine", JSONObject().put("ready", Lumo.engineReady).put("status", Lumo.engineStatus))
            dispatch("onSettings", WebPayload.settings())
            dispatch("onHistory", JSONObject().put("items", WebPayload.history(HistoryStore.items.value)))
            syncActiveUi()
            dispatch("onDownloadState", WebPayload.job(DownloadBus.state.value))
        }
    }

    override fun onPause() {
        if (::webView.isInitialized) webView.onPause()
        super.onPause()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        sharedText(intent)?.let { Lumo.handleShare(it) }
    }

    private fun sharedText(incoming: Intent?): String? =
        if (incoming?.action == Intent.ACTION_SEND) incoming.getStringExtra(Intent.EXTRA_TEXT) else null


    /** Re-send non-Flow inspection state after the WebView has been paused or recreated. */
    private fun syncActiveUi() {
        if (Lumo.playlistMode) {
            when {
                Lumo.pStep == PStep.Inspecting -> dispatch("onPlaylistInspecting", JSONObject().put("url", Lumo.pUrl))
                Lumo.pInfo != null -> dispatch("onPlaylistInfo", WebPayload.playlist(Lumo.pInfo!!))
                Lumo.pError.isNotBlank() -> dispatch("onPlaylistError", JSONObject().put("message", Lumo.pError))
            }
        } else {
            when {
                Lumo.vStep == VStep.Inspecting -> dispatch("onVideoInspecting", JSONObject().put("url", Lumo.vUrl))
                Lumo.vInfo != null -> dispatch("onVideoInfo", WebPayload.video(Lumo.vInfo!!, Lumo.vSubs))
                Lumo.vError.isNotBlank() -> dispatch("onVideoError", JSONObject().put("message", Lumo.vError))
            }
        }
    }

    private fun dispatch(name: String, payload: JSONObject) {
        if (!pageReady) {
            pendingEvents.add(name to payload)
            if (pendingEvents.size > 100) pendingEvents.removeAt(0)
            return
        }
        val raw = JSONObject.quote(payload.toString())
        val script = "window.LumoApp && window.LumoApp.$name($raw);"
        runOnUiThread { if (::webView.isInitialized) webView.evaluateJavascript(script, null) }
    }

    private fun requestRuntimePermissions() {
        val requested = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) requested.add(Manifest.permission.POST_NOTIFICATIONS)
        if (Build.VERSION.SDK_INT < 29 &&
            checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) requested.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        if (requested.isNotEmpty()) requestPermissions(requested.toTypedArray(), 1101)
    }

    override fun onDestroy() {
        if (::webView.isInitialized) {
            webView.removeJavascriptInterface("LumoNative")
            webView.stopLoading()
            webView.loadUrl("about:blank")
            webView.destroy()
        }
        super.onDestroy()
    }
}
