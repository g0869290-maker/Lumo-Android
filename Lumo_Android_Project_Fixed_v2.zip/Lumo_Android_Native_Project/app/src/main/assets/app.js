(() => {
  'use strict';
  const $ = (s, root = document) => root.querySelector(s);
  const $$ = (s, root = document) => [...root.querySelectorAll(s)];
  const Native = window.LumoNative;
  const show = (el, yes) => { if (el) el.classList.toggle('hide', !yes); };
  const text = (el, value) => { if (el) el.textContent = value == null ? '' : String(value); };
  const esc = value => String(value ?? '');
  const safeImage = url => /^https:\/\//i.test(String(url || '')) ? String(url) : '';
  const parse = raw => { try { return JSON.parse(raw || '{}'); } catch (_) { return {}; } };

  let videoInfo = null;
  let videoQualities = [];
  let videoQualityIndex = 0;
  let videoSubs = new Set();
  let videoFormat = 'mp4';
  let playlistInfo = null;
  let playlistQualities = [];
  let playlistQualityIndex = 0;
  let playlistSubs = new Set();
  let historyItems = [];
  let currentJob = null;
  let engineReady = false;
  let engineStatusText = '';
  let activeNav = 0;
  let settingsTab = 0;
  let settingsState = {
    folder: 'Download/Lumo', preferMp4: true, prefSub: 'en', autoUpdate: false,
    indHex: '#FFB45F', progHex: '#8871FF', savedColors: []
  };
  let toastTimer = 0;

  function toast(message) {
    const el = $('#toast');
    text(el, message);
    el.classList.add('on');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => el.classList.remove('on'), 2400);
  }

  function navTo(index) {
    activeNav = index;
    $$('.page').forEach((p, i) => p.classList.toggle('on', i === index));
    $$('#nav button').forEach((b, i) => b.classList.toggle('on', i === index));
    $('#npill').style.transform = `translateX(${index * 100}%)`;
    const frames = [
      [{ transform: 'translateY(0)' }, { transform: 'translateY(-6px)' }, { transform: 'translateY(0)' }],
      [{ transform: 'rotate(0)' }, { transform: 'rotate(-360deg)' }],
      [{ transform: 'rotate(0)' }, { transform: 'rotate(180deg)' }]
    ];
    const icon = $('svg', $('#nav').children[index + 1]);
    if (icon && icon.animate) icon.animate(frames[index], { duration: 560, easing: 'cubic-bezier(.22,.8,.3,1)' });
  }
  $$('#nav button').forEach((b, i) => b.addEventListener('click', () => navTo(i)));

  function mode(playlist) {
    $$('#seg button').forEach(b => b.classList.toggle('on', b.dataset.m === (playlist ? 'p' : 'v')));
    Native.setMode(!!playlist);
    show($('#vmode'), !playlist);
    show($('#pmode'), playlist);
  }
  $$('#seg button').forEach(b => b.addEventListener('click', () => mode(b.dataset.m === 'p')));

  function setInput(input, value) {
    input.value = value || '';
    const clearId = input.id === 'url' ? '#vx' : '#px';
    show($(clearId), !!input.value);
  }
  function setThumb(el, url) {
    const image = safeImage(url);
    if (!el) return;
    el.replaceChildren();
    if (image) {
      el.classList.add('has-image');
      const img = document.createElement('img');
      img.className = 'thumb-img';
      img.alt = '';
      img.loading = 'lazy';
      img.referrerPolicy = 'no-referrer';
      img.src = image;
      el.append(img);
    } else {
      el.classList.remove('has-image');
      el.textContent = el.closest('#vq') ? '▶  VIDEO PREVIEW' : 'VIDEO';
    }
  }
  function createChip(label, code, selected, tint, onClick, disabled = false) {
    const b = document.createElement('button');
    b.className = 'chip' + (selected ? ' on' : '') + (disabled ? ' off' : '');
    b.textContent = label;
    if (tint) b.style.setProperty('--t', tint);
    b.disabled = !!disabled;
    b.dataset.code = code || '';
    b.addEventListener('click', onClick);
    return b;
  }

  function buildDropdown(host, options, selected, onChange) {
    host.innerHTML = '';
    const button = document.createElement('button');
    const left = document.createElement('span');
    const right = document.createElement('span');
    right.textContent = '▾';
    button.append(left, right);
    const list = document.createElement('div');
    list.className = 'dl hide';
    options.forEach((option, index) => {
      const item = document.createElement('button');
      const label = document.createElement('span');
      const hint = document.createElement('small');
      label.textContent = option.label;
      hint.textContent = option.sizeText || '';
      item.append(label, hint);
      item.addEventListener('click', e => {
        e.stopPropagation();
        list.classList.add('hide');
        selected = index;
        refresh();
        onChange(index, option);
      });
      list.append(item);
    });
    function refresh() {
      const current = options[selected] || options[0] || { label: 'Best available', sizeText: '' };
      left.textContent = current.label;
      [...list.children].forEach((el, i) => el.classList.toggle('on', i === selected));
    }
    button.addEventListener('click', e => {
      e.stopPropagation();
      $$('.dl').forEach(el => { if (el !== list) el.classList.add('hide'); });
      list.classList.toggle('hide');
    });
    host.append(button, list);
    refresh();
  }
  document.addEventListener('click', () => $$('.dl').forEach(el => el.classList.add('hide')));

  function goVideo(step) {
    ['vinsp', 'vq', 'vo', 'vd'].forEach(id => show($('#' + id), false));
    if (step === 'inspect') show($('#vinsp'), true);
    if (step === 'quality') show($('#vq'), true);
    if (step === 'options') show($('#vo'), true);
    if (step === 'download') show($('#vd'), true);
  }

  function renderVideoInfo(info) {
    videoInfo = info;
    videoQualities = Array.isArray(info.qualities) && info.qualities.length ? info.qualities : [{ label: 'Best available', height: 0, sizeText: 'Size unavailable' }];
    videoQualityIndex = Math.max(0, Math.min(videoQualities.length - 1, Number(info.selectedQuality || 0)));
    videoSubs = new Set(Array.isArray(info.selectedSubs) ? info.selectedSubs : []);
    videoFormat = info.container === 'mkv' ? 'mkv' : info.container === 'mp4' ? 'mp4' : (settingsState.preferMp4 ? 'mp4' : 'mkv');

    const preview = $('#vq .thumb');
    setThumb(preview, info.thumb);
    setThumb($('#vd .thumb'), info.thumb);
    text($('#vq .t'), info.title || 'Video');
    text($('#vq .s'), [info.extractor, info.duration].filter(Boolean).join(' · '));
    buildDropdown($('#vdd'), videoQualities, videoQualityIndex, index => {
      videoQualityIndex = index;
      const q = videoQualities[index] || videoQualities[0];
      text($('#est'), `Estimated size  ·  ${q.sizeText || 'Not reported by source'}`);
      Native.setVideoSelection(videoQualityIndex, [...videoSubs].join(','), videoFormat);
    });
    const q = videoQualities[videoQualityIndex] || videoQualities[0];
    text($('#est'), `Estimated size  ·  ${q.sizeText || 'Not reported by source'}`);
    renderVideoSubtitleChips(info.subtitles || []);
    renderFormatChips();
    setInput($('#url'), info.url || '');
    goVideo('quality');
  }

  function renderVideoSubtitleChips(subtitles) {
    const host = $('#vsubs');
    host.innerHTML = '';
    if (!subtitles.length) {
      const note = document.createElement('span');
      note.className = 's';
      note.textContent = 'No subtitle tracks were reported for this video.';
      host.append(note);
      return;
    }
    subtitles.forEach((item, i) => {
      const code = item.code;
      const tint = ['#8871FF', '#FFB45F', '#2DD4BF', '#FF647F', '#60A5FA'][i % 5];
      host.append(createChip(item.label || code, code, videoSubs.has(code), tint, () => {
        if (videoSubs.has(code)) videoSubs.delete(code); else videoSubs.add(code);
        Native.setVideoSelection(videoQualityIndex, [...videoSubs].join(','), videoFormat);
        renderVideoSubtitleChips(subtitles);
        renderFormatChips();
      }));
    });
    const note = document.createElement('span');
    note.className = 's';
    note.style.width = '100%';
    note.textContent = 'Choose one or more detected subtitle languages.';
    host.append(note);
  }

  function renderFormatChips() {
    $$('#fmt .format-note').forEach(node => node.remove());
    $$('#fmt .chip').forEach((chip, i) => {
      chip.disabled = false;
      chip.classList.toggle('on', (i === 0) === (videoFormat === 'mp4'));
    });
    if (videoSubs.size) {
      const note = document.createElement('div');
      note.className = 's format-note';
      note.style.width = '100%';
      note.textContent = videoFormat === 'mp4'
        ? 'Subtitles are saved as separate .srt files next to the video.'
        : 'Subtitles are embedded inside the MKV file.';
      $('#fmt').append(note);
    }
  }
  $$('#fmt .chip').forEach((chip, i) => chip.addEventListener('click', () => {
    videoFormat = i === 0 ? 'mp4' : 'mkv';
    Native.setVideoSelection(videoQualityIndex, [...videoSubs].join(','), videoFormat);
    renderFormatChips();
  }));

  $('#paste').addEventListener('click', () => {
    const url = $('#url').value.trim();
    if (url) Native.inspectVideo(url); else Native.pasteVideo();
  });
  $('#url').addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); $('#url').blur(); $('#paste').click(); } });
  $('#purl').addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); $('#purl').blur(); $('#ppaste').click(); } });
  $('#url').addEventListener('input', () => show($('#vx'), !!$('#url').value));
  $('#vx').addEventListener('click', () => {
    if (currentJob?.kind === 'video' && ['running', 'prompt'].includes(currentJob.phase)) return toast('Cancel the active video download before clearing it.');
    setInput($('#url'), ''); Native.clearVideo(); goVideo('idle');
  });
  $('#cont').addEventListener('click', () => { Native.showOptions(); goVideo('options'); });
  $('#back').addEventListener('click', () => { Native.backToQuality(); goVideo('quality'); });
  $('#dl').addEventListener('click', () => {
    if (!videoInfo) return toast('Inspect a video first.');
    goVideo('download');
    resetVideoProgress();
    Native.startVideo(videoQualityIndex, [...videoSubs].join(','), videoFormat);
  });
  $('#cancel').addEventListener('click', () => Native.cancelVideo());
  $('#open').addEventListener('click', () => Native.openFolder());
  $('#nv').addEventListener('click', () => {
    videoInfo = null; videoQualities = []; videoSubs.clear();
    setInput($('#url'), ''); Native.newVideo(); goVideo('idle');
  });

  function resetVideoProgress() {
    const pbw = $('#pbw');
    pbw.className = 'pbw';
    $('#fill').style.width = '0%';
    text($('#pc'), '0%');
    text($('#dt'), videoInfo?.title || 'Preparing your video');
    text($('#ds'), 'Starting download…');
    text($('#spd'), 'Connecting to source');
    show($('#cancel'), true); show($('#open'), false); show($('#nv'), false);
  }

  function renderDownloadState(state) {
    if (!state || !state.jobId) { currentJob = null; return; }
    currentJob = state;
    if (state.kind === 'video') {
      if (state.phase !== 'idle') goVideo('download');
      const pct = Math.max(0, Math.min(100, Number(state.percent || 0)));
      const phase = state.phase;
      const finished = ['done', 'failed', 'cancelled'].includes(phase);
      $('#fill').style.width = (phase === 'done' ? 100 : pct) + '%';
      text($('#pc'), phase === 'done' ? 'Completed' : phase === 'failed' ? 'FAILED' : phase === 'cancelled' ? 'STOPPED' : Math.round(pct) + '%');
      text($('#dt'), videoInfo?.title || state.items?.[0]?.title || 'Video download');
      text($('#ds'), phase === 'done' ? 'Your video is ready.' : phase === 'failed' ? (state.items?.[0]?.error || state.message || 'Download failed') : phase === 'cancelled' ? 'Download cancelled' : phase === 'prompt' ? state.prompt : 'Downloading video…');
      const speedLine = [state.speed, state.eta > 0 ? `ETA ${formatEta(state.eta)}` : ''].filter(Boolean).join('  ·  ');
      text($('#spd'), phase === 'done' ? `Saved to ${state.folder || settingsState.folder}` : speedLine || state.message || 'Calculating speed');
      show($('#cancel'), !finished); show($('#open'), phase === 'done'); show($('#nv'), finished);
      if (phase === 'done') {
        setTimeout(() => { $('#pbw').classList.add('c1'); }, 100);
        setTimeout(() => { $('#pbw').classList.add('c2'); }, 350);
        setTimeout(() => { $('#pbw').classList.add('c3'); }, 650);
      }
    } else if (state.kind === 'playlist') {
      renderPlaylistJob(state);
    }
    // Subtitle fallback prompts apply to both single-video and playlist jobs.
    if (state.phase === 'prompt') askSubtitleFallback(state.prompt || 'Subtitles could not be downloaded.');
  }

  function formatEta(seconds) {
    const value = Math.max(0, Number(seconds) || 0);
    return `${String(Math.floor(value / 60)).padStart(2, '0')}:${String(Math.floor(value % 60)).padStart(2, '0')}`;
  }

  // ================== PLAYLIST ==================
  function goPlaylist(step) {
    show($('#pinsp'), step === 'inspect');
    show($('#pready'), step === 'ready' || step === 'run' || step === 'done');
    show($('#pcfg'), step === 'ready');
    show($('#prun'), step === 'run');
    show($('#pdone'), step === 'done');
  }
  function playlistFormatOptions() {
    return [
      { label: 'Best available', height: 0, sizeText: 'Per video' },
      { label: 'Up to 1080p', height: 1080, sizeText: 'Per video' },
      { label: 'Up to 720p', height: 720, sizeText: 'Per video' },
      { label: 'Up to 480p', height: 480, sizeText: 'Per video' },
      { label: 'Up to 360p', height: 360, sizeText: 'Per video' }
    ];
  }
  function renderPlaylistSubtitleChips() {
    const choices = [ ['en','English'], ['hi','Hindi'], ['mr','Marathi'], ['all','All languages'], ['none','None'] ];
    const host = $('#psubs'); host.innerHTML = '';
    choices.forEach(([code, label], i) => {
      const selected = code === 'none' ? playlistSubs.size === 0 : playlistSubs.has(code);
      host.append(createChip(label, code, selected, i % 2 ? 'var(--ind)' : 'var(--prog)', () => {
        if (code === 'none') playlistSubs.clear();
        else if (code === 'all') {
          if (playlistSubs.has('all')) playlistSubs.delete('all');
          else { playlistSubs.clear(); playlistSubs.add('all'); }
        } else {
          playlistSubs.delete('none');
          playlistSubs.delete('all');
          if (playlistSubs.has(code)) playlistSubs.delete(code); else playlistSubs.add(code);
        }
        Native.setPlaylistSelection(playlistQualityIndex, [...playlistSubs].filter(x => x !== 'none').join(','));
        renderPlaylistSubtitleChips();
      }));
    });
    const note = document.createElement('span'); note.className = 's'; note.style.width = '100%';
    note.textContent = 'Playlist tracks are requested per video; a language may not exist on every item.';
    host.append(note);
  }
  function renderPlaylistInfo(info) {
    playlistInfo = info;
    playlistSubs = new Set(Array.isArray(info.selectedSubs)
      ? info.selectedSubs
      : (settingsState.prefSub === 'none' ? [] : [settingsState.prefSub]));
    playlistQualities = playlistFormatOptions();
    playlistQualityIndex = Math.max(0, Math.min(playlistQualities.length - 1, Number(info.selectedQuality || 0)));
    text($('#ptitle'), `${info.title || 'Playlist'} · ${info.entries.length} videos`);
    buildDropdown($('#pdd'), playlistQualities, playlistQualityIndex, i => {
      playlistQualityIndex = i;
      Native.setPlaylistSelection(playlistQualityIndex, [...playlistSubs].filter(x => x !== 'none').join(','));
    });
    renderPlaylistSubtitleChips();
    renderPlaylistEntries(info.entries, false);
    goPlaylist('ready');
  }
  function ring(cls, pct, label) {
    const w = document.createElement('div');
    w.className = 'rw' + (cls ? ' ' + cls : '');
    w.innerHTML = '<svg viewBox="0 0 36 36"><circle class="bg" cx="18" cy="18" r="14"/><circle class="fg" cx="18" cy="18" r="14" style="stroke-dashoffset:' + (88 * (1 - Math.max(0, Math.min(100, pct)) / 100)) + '"/></svg><span></span>';
    w.querySelector('span').textContent = label;
    return w;
  }
  function renderPlaylistEntries(entries, live) {
    const host = $('#plist'); host.innerHTML = '';
    (entries || []).forEach((entry, index) => {
      const row = document.createElement('div'); row.className = 'li';
      const thumb = document.createElement('div'); thumb.className = 'thumb'; setThumb(thumb, entry.thumb);
      const meta = document.createElement('div'); meta.className = 'm';
      const titleEl = document.createElement('div'); titleEl.className = 't'; titleEl.textContent = entry.title || `Video ${index + 1}`;
      const subEl = document.createElement('div'); subEl.className = 's';
      const st = live ? (entry.status || 'queued') : 'queued';
      subEl.textContent = [entry.duration || 'Video', statusName(st)].filter(Boolean).join(' · ');
      meta.append(titleEl, subEl);
      row.append(thumb, meta);
      if (!live && playlistInfo) {
        const remove = document.createElement('button'); remove.className = 'cx'; remove.title = 'Remove video'; remove.textContent = '✕';
        remove.addEventListener('click', () => Native.removePlaylistEntry(index));
        row.append(remove);
      } else if (live && ['queued', 'run'].includes(st)) {
        const cancel = document.createElement('button'); cancel.className = 'cx'; cancel.title = 'Cancel video'; cancel.textContent = '✕';
        cancel.addEventListener('click', () => Native.cancelPlaylistItem(index)); row.append(cancel);
      }
      const pct = Number(entry.percent || 0);
      row.append(
        st === 'done' ? ring('ok', 100, '✓')
        : st === 'cancel' ? ring('no', 0, '✕')
        : st === 'fail' ? ring('no', 0, '!')
        : st === 'run' ? ring('', pct, Math.round(pct) + '%')
        : ring('', 0, '')
      );
      host.append(row);
    });
    if (!entries || !entries.length) {
      const empty = document.createElement('div'); empty.className = 's'; empty.textContent = 'No playlist entries'; host.append(empty);
    }
  }
  function statusName(status) {
    return ({ queued:'Queued', run:'Downloading', done:'Completed', fail:'Failed', cancel:'Cancelled' })[status] || 'Queued';
  }
  function renderPlaylistJob(state) {
    if (!playlistInfo && !state.items?.length) return;
    const entries = (state.items || []).map(item => ({ ...item }));
    renderPlaylistEntries(entries, true);
    const active = entries.filter(item => item.status !== 'cancel').length;
    const done = entries.filter(item => item.status === 'done').length;
    text($('#pcount'), `${done} of ${active} downloaded`);
    $('#pfill').style.width = `${Math.max(0, Math.min(100, Number(state.percent || 0)))}%`;
    if (['done','failed','cancelled'].includes(state.phase)) {
      const failed = entries.filter(item => item.status === 'fail').length;
      const cancelled = entries.filter(item => item.status === 'cancel').length;
      text($('#psum'), state.phase === 'cancelled' ? `Playlist cancelled · ${done} completed` : `Done · ${done} completed${failed ? ` · ${failed} failed` : ''}${cancelled ? ` · ${cancelled} cancelled` : ''}`);
      goPlaylist('done');
    } else {
      goPlaylist('run');
    }
  }

  $('#ppaste').addEventListener('click', () => {
    const url = $('#purl').value.trim();
    if (url) Native.inspectPlaylist(url); else Native.pastePlaylist();
  });
  $('#purl').addEventListener('input', () => show($('#px'), !!$('#purl').value));
  $('#px').addEventListener('click', () => {
    if (currentJob?.kind === 'playlist' && ['running', 'prompt'].includes(currentJob.phase)) return toast('Cancel the active playlist before clearing it.');
    setInput($('#purl'), ''); Native.clearPlaylist(); goPlaylist('idle');
  });
  $('#pgo').addEventListener('click', () => {
    if (!playlistInfo) return toast('Inspect a playlist first.');
    Native.startPlaylist(playlistQualityIndex, [...playlistSubs].filter(x => x !== 'none').join(','));
  });
  $('#pcancel').addEventListener('click', () => Native.cancelPlaylist());
  $('#popen').addEventListener('click', () => Native.openFolder());
  $('#pnew').addEventListener('click', () => {
    playlistInfo = null; playlistSubs.clear(); setInput($('#purl'), ''); Native.newPlaylist(); goPlaylist('idle'); $('#plist').innerHTML = '';
  });

  // ================== HISTORY ==================
  function renderHistory(items) {
    historyItems = Array.isArray(items) ? items : [];
    text($('#hc'), historyItems.length ? `${historyItems.length} ${historyItems.length === 1 ? 'item' : 'items'}` : '');
    show($('#hclr'), historyItems.length > 0);
    const host = $('#hist'); host.innerHTML = '';
    if (!historyItems.length) {
      const empty = document.createElement('h3'); empty.textContent = 'No downloads yet'; host.append(empty); return;
    }
    historyItems.forEach((record, index) => {
      const row = document.createElement('div'); row.className = 'li';
      const thumb = document.createElement('div'); thumb.className = 'thumb'; setThumb(thumb, record.thumb);
      const meta = document.createElement('div'); meta.className = 'm';
      const titleEl = document.createElement('div'); titleEl.className = 't'; titleEl.textContent = record.title || 'Video';
      const sub = document.createElement('div'); sub.className = 's';
      const date = record.time ? new Date(record.time).toLocaleString([], { day:'numeric', month:'short', hour:'numeric', minute:'2-digit' }) : '';
      sub.textContent = [record.quality, record.sizeText, record.format, date].filter(Boolean).join(' · ');
      const actions = document.createElement('div'); actions.className = 'act';
      const addAction = (label, action) => { const b = document.createElement('button'); b.textContent = label; b.addEventListener('click', action); actions.append(b); };
      if (record.status === 'ok') {
        addAction('Show in folder', () => Native.openRecord(record.id));
        addAction('Copy URL', () => Native.copyText(record.url || ''));
      } else if (record.status === 'fail' || record.status === 'cancelled') {
        addAction('Retry / Resume', () => Native.retryHistory(record.id));
        addAction('Show error', () => toast(record.error || 'No error details were saved.'));
      }
      addAction('Remove record', () => Native.removeHistory(record.id));
      meta.append(titleEl, sub, actions);
      let mark;
      if (record.status === 'ok') mark = ring('ok', 100, '✓');
      else if (record.status === 'run') mark = ring('', Number(record.percent || 0), Math.round(record.percent || 0) + '%');
      else { mark = document.createElement('span'); mark.className = 'pill'; mark.textContent = record.status === 'cancelled' ? 'CANCELLED' : 'FAILED'; }
      row.append(thumb, meta, mark); host.append(row);
    });
  }
  $('#hclr').addEventListener('click', () => ask('Clear all history?', [
    { label: 'Clear history', action: () => Native.clearHistory() }, { label: 'Cancel', action: () => {} }
  ]));

  // ================== SETTINGS ==================
  const tabNames = ['Active Bar', 'Downloads', 'Subtitles', 'Progress Bar', 'Engine'];
  tabNames.forEach((name, index) => {
    const chip = document.createElement('button'); chip.className = 'chip' + (index === 0 ? ' on' : ''); chip.textContent = name;
    chip.addEventListener('click', () => setSettingsTab(index)); $('#tabs').append(chip);
  });
  function setSettingsTab(index) {
    settingsTab = index;
    $$('#tabs .chip').forEach((chip, i) => chip.classList.toggle('on', i === index));
    [0,1,2,3,4].forEach(i => show($('#t' + i), i === index));
  }

  const activePresets = [['Blue','#60A5FA'],['White','#F4F6FB'],['Violet','#8871FF'],['Turquoise','#2DD4BF'],['Amber','#FFB45F'],['Pink','#FF647F']];
  const progressPresets = [['Violet','#8871FF'],['Blue','#4C8DFF'],['Turquoise','#2DD4BF'],['Mint','#55D9A8'],['Amber','#FFB45F'],['Pink','#FF647F']];
  let lastRemove = 0;
  function removeSaved(hex) {
    if (Date.now() - lastRemove < 900) return;
    lastRemove = Date.now(); Native.removeSavedColor(hex);
  }
  function renderSwatches(kind, presets, current, saved) {
    const host = kind === 'ind' ? $('#s-ind') : $('#s-prog');
    const label = kind === 'ind' ? $('#l-ind') : $('#l-prog');
    host.innerHTML = '';
    const all = [...presets, ...(saved || []).map(hex => ['Custom', hex])];
    all.forEach(([name, hex], index) => {
      const b = document.createElement('button'); b.className = 'tile' + (String(hex).toUpperCase() === String(current).toUpperCase() ? ' on' : '');
      b.style.background = hex; b.style.setProperty('--c', hex); b.title = name;
      let pressTimer = 0, longPressed = false;
      b.addEventListener('click', () => { if (longPressed) { longPressed = false; return; } Native.setAccent(kind, hex); });
      if (index >= presets.length) {
        b.addEventListener('contextmenu', e => { e.preventDefault(); removeSaved(hex); });
        b.addEventListener('touchstart', () => { longPressed = false; pressTimer = setTimeout(() => { longPressed = true; removeSaved(hex); }, 600); }, { passive: true });
        ['touchend', 'touchmove', 'touchcancel'].forEach(ev => b.addEventListener(ev, () => clearTimeout(pressTimer), { passive: true }));
      }
      host.append(b);
    });
    const add = document.createElement('button'); add.className = 'plus'; add.textContent = '+';
    add.addEventListener('click', () => {
      if ((saved || []).length >= 5) return toast('Up to 5 saved colours. Long-press one to remove it.');
      openColorSheet(kind);
    });
    host.append(add);
    const selected = all.find(([n, hex]) => String(hex).toUpperCase() === String(current).toUpperCase());
    text(label, `Selected: ${selected?.[0] || 'Custom'}`);
  }

  function hexToHsl(hex) {
    const m = /^#?([0-9a-f]{6})$/i.exec(hex || ''); const n = parseInt(m ? m[1] : '8871FF', 16);
    const r = (n >> 16 & 255) / 255, g = (n >> 8 & 255) / 255, b = (n & 255) / 255;
    const max = Math.max(r, g, b), min = Math.min(r, g, b), l = (max + min) / 2; let h = 0, s = 0;
    if (max !== min) {
      const d = max - min; s = l > .5 ? d / (2 - max - min) : d / (max + min);
      h = max === r ? (g - b) / d + (g < b ? 6 : 0) : max === g ? (b - r) / d + 2 : (r - g) / d + 4; h *= 60;
    }
    return [Math.round(h), Math.round(s * 100), Math.round(l * 100)];
  }
  function hslToHex(h, s, l) {
    s /= 100; l /= 100; const k = n => (n + h / 30) % 12, a = s * Math.min(l, 1 - l);
    const f = n => Math.round(255 * (l - a * Math.max(-1, Math.min(k(n) - 3, Math.min(9 - k(n), 1)))));
    return '#' + [f(0), f(8), f(4)].map(v => v.toString(16).padStart(2, '0')).join('').toUpperCase();
  }
  function openColorSheet(kind) {
    const host = $('#shin'); host.innerHTML = '';
    const title = document.createElement('h3'); title.style.marginBottom = '8px'; title.textContent = 'Custom colour'; host.append(title);
    const hsl = hexToHsl(kind === 'ind' ? settingsState.indHex : settingsState.progHex);
    const prev = document.createElement('div'); prev.style.cssText = 'height:44px;border-radius:13px;margin:6px 0 12px;border:1px solid var(--bd)';
    const hexIn = document.createElement('input'); hexIn.className = 'url'; hexIn.maxLength = 7; hexIn.autocapitalize = 'characters'; hexIn.spellcheck = false; hexIn.style.marginBottom = '10px';
    const sliders = [];
    const paint = () => { const hex = hslToHex(hsl[0], hsl[1], hsl[2]); hexIn.value = hex; prev.style.background = hex; sliders.forEach(([r, i]) => { r.value = hsl[i]; }); };
    host.append(prev, hexIn);
    [['Hue', 0, 360], ['Saturation', 1, 100], ['Lightness', 2, 100]].forEach(([name, i, max]) => {
      const lab = document.createElement('div'); lab.className = 'lbl'; lab.style.margin = '6px 2px 4px'; lab.textContent = name.toUpperCase();
      const r = document.createElement('input'); r.type = 'range'; r.min = 0; r.max = max; r.style.cssText = 'width:100%;accent-color:var(--acc)';
      r.addEventListener('input', () => { hsl[i] = Number(r.value); paint(); });
      sliders.push([r, i]); host.append(lab, r);
    });
    hexIn.addEventListener('input', () => {
      if (/^#[0-9a-f]{6}$/i.test(hexIn.value)) { const v = hexToHsl(hexIn.value); hsl[0] = v[0]; hsl[1] = v[1]; hsl[2] = v[2]; prev.style.background = hexIn.value; sliders.forEach(([r, i]) => { r.value = hsl[i]; }); }
    });
    paint();
    const row = document.createElement('div'); row.className = 'row'; row.style.marginTop = '16px';
    const cancel = document.createElement('button'); cancel.className = 'gh'; cancel.textContent = 'Cancel';
    const save = document.createElement('button'); save.className = 'btn'; save.style.flex = '1'; save.textContent = 'Save colour';
    cancel.addEventListener('click', () => show($('#sheet'), false));
    save.addEventListener('click', () => {
      if (!/^#[0-9a-f]{6}$/i.test(hexIn.value)) return toast('Enter a colour like #3DDC97');
      show($('#sheet'), false); Native.saveAccent(kind, hexIn.value.toUpperCase());
    });
    row.append(cancel, save); host.append(row);
    show($('#sheet'), true);
  }
  function renderPrefs() {
    const phone = $('#ph');
    phone.style.setProperty('--ind', settingsState.indHex || '#FFB45F');
    phone.style.setProperty('--prog', settingsState.progHex || '#8871FF');
    text($('#fpath'), 'Internal storage/' + settingsState.folder);
    $('#mp4').classList.toggle('on', !!settingsState.preferMp4);
    $('#eauto').classList.toggle('on', !!settingsState.autoUpdate);
    text($('#estat'), engineStatusText || (engineReady ? 'Download engine ready' : 'Starting download engine…'));
    text($('#cstat'), settingsState.hasCookies ? 'cookies.txt imported' : 'No file imported');
    $('#cstat').classList.toggle('f', !!settingsState.hasCookies);
    text($('#cimp'), settingsState.hasCookies ? 'Replace' : 'Import');
    show($('#crem'), !!settingsState.hasCookies);
    $('#pref').innerHTML = '';
    [['en','English'],['hi','Hindi'],['mr','Marathi'],['none','None']].forEach(([code,label]) => {
      $('#pref').append(createChip(label, code, settingsState.prefSub === code, code === 'hi' ? 'var(--ind)' : 'var(--prog)', () => Native.setPrefSub(code)));
    });
    renderSwatches('ind', activePresets, settingsState.indHex, settingsState.savedColors);
    renderSwatches('prog', progressPresets, settingsState.progHex, settingsState.savedColors);
  }
  $('#browse').addEventListener('click', () => ask('Choose download folder', [
    { label:'Internal storage/Download/Lumo', action:() => Native.setFolder('Download/Lumo') },
    { label:'Internal storage/Movies/Lumo', action:() => Native.setFolder('Movies/Lumo') },
    { label:'Internal storage/DCIM/Lumo', action:() => Native.setFolder('DCIM/Lumo') },
    { label:'Cancel', action:() => {} }
  ]));
  $('#mp4').addEventListener('click', () => Native.setPreferMp4(!settingsState.preferMp4));
  $('#eauto').addEventListener('click', () => Native.setAutoUpdate(!settingsState.autoUpdate));
  $('#cimp').addEventListener('click', () => Native.pickCookies());
  $('#crem').addEventListener('click', () => Native.removeCookies());
  $('#eup').addEventListener('click', () => { text($('#estat'), 'Updating download engine…'); Native.updateEngine(); });

  // ================== SHEETS & PROMPTS ==================
  function ask(title, options) {
    const host = $('#shin'); host.innerHTML = '';
    const h = document.createElement('h3'); h.style.marginBottom = '8px'; h.textContent = title; host.append(h);
    options.forEach(option => {
      const b = document.createElement('button'); b.className = 'o';
      const span = document.createElement('span'); span.textContent = option.label; b.append(span);
      b.addEventListener('click', () => { show($('#sheet'), false); option.action(); });
      host.append(b);
    });
    show($('#sheet'), true);
  }
  $('#sheet').addEventListener('click', e => {
    if (e.target.id === 'sheet') {
      show($('#sheet'), false);
      if (currentJob?.phase === 'prompt') Native.decideSubtitles('cancel');
    }
  });
  function askSubtitleFallback(message) {
    if ($('#sheet').classList.contains('hide')) {
      ask(message, [
        { label:'Download without subtitles', action:() => Native.decideSubtitles('without') },
        { label:'Cancel download', action:() => Native.decideSubtitles('cancel') }
      ]);
    }
  }

  // Returns true when the page used the Back press; false lets Android leave the app.
  function handleBack() {
    if (!$('#sheet').classList.contains('hide')) {
      show($('#sheet'), false);
      if (currentJob?.phase === 'prompt') Native.decideSubtitles('cancel');
      return true;
    }
    if (activeNav !== 0) { navTo(0); return true; }
    if (!$('#vo').classList.contains('hide')) { Native.backToQuality(); goVideo('quality'); return true; }
    if (!$('#vq').classList.contains('hide')) { videoInfo = null; Native.clearVideo(); goVideo('idle'); return true; }
    if (!$('#pmode').classList.contains('hide') && playlistInfo) {
      if (currentJob?.kind === 'playlist' && ['running', 'prompt'].includes(currentJob.phase)) {
        toast('The playlist is still downloading. Cancel it before leaving this view.');
        return true;
      }
      playlistInfo = null; Native.clearPlaylist(); goPlaylist('idle'); return true;
    }
    return false;
  }

  window.LumoApp = {
    boot(raw) {
      const data = parse(raw);
      settingsState = { ...settingsState, ...(data.settings || {}) };
      engineReady = !!data.engineReady;
      mode(!!data.playlistMode);
      engineStatusText = data.engineStatus || '';
      renderPrefs();
      renderHistory(data.history || []);
      if (data.download) renderDownloadState(data.download);
    },
    onEngine(raw) {
      const data = parse(raw); engineReady = !!data.ready;
      engineStatusText = data.status || (engineReady ? 'Download engine ready' : 'Engine unavailable');
      text($('#estat'), engineStatusText);
    },
    onVideoInspecting(raw) {
      const data = parse(raw); navTo(0); mode(false); setInput($('#url'), data.url || $('#url').value);
      goVideo('inspect');
    },
    onVideoInfo(raw) { renderVideoInfo(parse(raw)); },
    onVideoStep(raw) {
      const step = parse(raw).step;
      goVideo(step === 'options' ? 'options' : step === 'download' ? 'download' : 'quality');
    },
    onVideoError(raw) {
      const data = parse(raw); goVideo('idle');
      toast(data.message || 'Could not inspect this video.');
    },
    onPlaylistInspecting(raw) {
      const data = parse(raw); navTo(0); mode(true); setInput($('#purl'), data.url || $('#purl').value);
      goPlaylist('inspect');
    },
    onPlaylistInfo(raw) { renderPlaylistInfo(parse(raw)); },
    onPlaylistEntryRemoved(raw) {
      const data = parse(raw);
      if (playlistInfo?.entries) {
        playlistInfo.entries.splice(Number(data.index), 1);
        text($('#ptitle'), `${playlistInfo.title || 'Playlist'} · ${playlistInfo.entries.length} videos`);
        renderPlaylistEntries(playlistInfo.entries, false);
      }
    },
    onPlaylistCleared() { playlistInfo = null; goPlaylist('idle'); $('#plist').innerHTML = ''; },
    onPlaylistError(raw) { const data = parse(raw); goPlaylist('idle'); toast(data.message || 'Could not read this playlist.'); },
    onDownloadState(raw) { renderDownloadState(parse(raw)); },
    onHistory(raw) { renderHistory(parse(raw).items || []); },
    onSettings(raw) { settingsState = { ...settingsState, ...parse(raw) }; renderPrefs(); },
    onToast(raw) { const data = parse(raw); toast(data.message || ''); },
    onSystemBack() { return handleBack(); }
  };

  // Initialize the HTML controls without waiting for native state.
  $('#hist').innerHTML = '<h3>No downloads yet</h3>';
  setSettingsTab(0);
  mode(false);
  goVideo('idle');
  goPlaylist('idle');
  renderPrefs();
  if (!Native) toast('Native download bridge is not available.');
})();
