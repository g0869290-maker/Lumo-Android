package com.lumo.android

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.IBinder
import android.os.PowerManager
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import androidx.core.app.NotificationCompat
import androidx.core.content.FileProvider
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest
import java.util.concurrent.Executors
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

data class ItemState(
    val title: String = "",
    val thumb: String = "",
    val duration: String = "",
    val status: String = "queued",   // queued, run, done, fail, cancel
    val percent: Float = 0f,
    val error: String = ""
)

data class JobState(
    val jobId: String = "",
    val kind: String = "video",
    val items: List<ItemState> = emptyList(),
    val phase: String = "idle",      // idle, running, prompt, done, cancelled, failed
    val percent: Float = 0f,
    val speed: String = "",
    val eta: Int = 0,
    val message: String = "",
    val folder: String = "",
    val prompt: String = "",
    val lastUri: String = "",
    val lastPath: String = ""
)

/** Shared download state. The service writes it, the UI reads it. */
object DownloadBus {
    val state = MutableStateFlow(JobState())

    fun update(block: (JobState) -> JobState) {
        state.value = block(state.value)
    }

    fun setItem(index: Int, block: (ItemState) -> ItemState) {
        update { s -> s.copy(items = s.items.mapIndexed { i, it -> if (i == index) block(it) else it }) }
    }
}

class DownloadService : Service() {
    private val executor = Executors.newSingleThreadExecutor()
    private val busy = AtomicBoolean(false)
    private val decisions = LinkedBlockingQueue<String>()
    private val notifId = 701
    private var wakeLock: PowerManager.WakeLock? = null

    @Volatile private var cancelAll = false
    @Volatile private var cancelIndex = -1
    @Volatile private var currentPid = ""
    @Volatile private var currentRecordId = ""
    @Volatile private var jobId = ""
    @Volatile private var lastNotify = 0L
    @Volatile private var skipSubsForRest = false
    @Volatile private var streamsSeen = 0
    @Volatile private var inSubtitleFile = false
    @Volatile private var multiStream = false
    @Volatile private var reportedHeight = 0

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                val payload = intent.getStringExtra(EXTRA_PAYLOAD).orEmpty()
                startForeground(notifId, notification("Starting download…", 0, true))
                acquireWakeLock()
                if (busy.compareAndSet(false, true)) {
                    val job = try { JSONObject(payload) } catch (_: Exception) { JSONObject() }
                    executor.execute { runJob(job) }
                }
            }
            ACTION_CANCEL -> handleCancel(intent.getIntExtra(EXTRA_INDEX, -1))
            ACTION_DECIDE -> decisions.offer(intent.getStringExtra(EXTRA_CHOICE).orEmpty())
        }
        return START_NOT_STICKY
    }

    private fun handleCancel(index: Int) {
        if (index < 0) {
            cancelAll = true
            decisions.offer("cancel")
            killCurrent()
            return
        }
        when (DownloadBus.state.value.items.getOrNull(index)?.status) {
            "run" -> {
                cancelIndex = index
                decisions.offer("cancel")
                killCurrent()
            }
            "queued" -> DownloadBus.setItem(index) { it.copy(status = "cancel") }
            else -> Unit
        }
    }

    private fun killCurrent() {
        val pid = currentPid
        if (pid.isBlank()) return
        try {
            YoutubeDL.getInstance().destroyProcessById(pid)
        } catch (_: Exception) {
            // Process already finished.
        }
    }

    private fun runJob(p: JSONObject) {
        jobId = p.optString("jobId", "job")
        cancelAll = false
        cancelIndex = -1
        currentPid = ""
        decisions.clear()
        skipSubsForRest = false

        val kind = p.optString("kind", "video")
        val format = p.optString("format", "bestvideo+bestaudio/best")
        val want = p.optString("container", "mp4")
        val subs = p.optString("subs", "")
        val folder = p.optString("folder", "Download/Lumo")
        val quality = p.optString("quality", "")
        val arr = p.optJSONArray("items") ?: JSONArray()
        val reqs = (0 until arr.length()).mapNotNull { arr.optJSONObject(it) }

        DownloadBus.state.value = JobState(
            jobId = jobId,
            kind = kind,
            items = reqs.map {
                ItemState(title = it.optString("title"), thumb = it.optString("thumb"), duration = it.optString("duration"))
            },
            phase = "running",
            folder = folder,
            message = "Starting…"
        )

        var ok = 0
        var failed = 0
        try {
            if (!YtEngine.ready) throw IllegalStateException("Download engine is not ready")
            for ((i, req) in reqs.withIndex()) {
                if (cancelAll || DownloadBus.state.value.items[i].status == "cancel") {
                    DownloadBus.setItem(i) { it.copy(status = "cancel") }
                    continue
                }
                val id = req.optString("recordId").ifBlank { "$jobId-$i" }
                val itemSubs = if (skipSubsForRest) "" else subs
                val container = want
                val base = HistoryRecord(
                    id = id,
                    title = req.optString("title"),
                    url = req.optString("url"),
                    thumb = req.optString("thumb"),
                    quality = quality,
                    sizeText = req.optString("size"),
                    format = if (container == "mkv") "MKV" else "MP4",
                    status = "run",
                    percent = 0f,
                    error = "",
                    uri = "",
                    path = "",
                    folder = folder,
                    time = System.currentTimeMillis(),
                    formatSel = format,
                    container = want,
                    subs = itemSubs
                )
                HistoryStore.save(base)
                currentRecordId = id
                DownloadBus.setItem(i) { it.copy(status = "run", percent = 0f) }
                DownloadBus.update { it.copy(message = "Downloading ${req.optString("title")}…") }

                val outcome = try {
                    downloadOne(i, req.optString("url"), format, want, itemSubs, folder, quality)
                } catch (e: Exception) {
                    Outcome.Failed(YtEngine.friendly(e.message))
                }
                when (val out = outcome) {
                    is Outcome.Done -> {
                        ok++
                        val actualFormat = out.extension.ifBlank { base.format }
                        val actualSize = if (out.sizeBytes > 0L) formatFileSize(out.sizeBytes) else base.sizeText
                        HistoryStore.save(base.copy(status = "ok", percent = 100f, uri = out.uri, path = out.path, format = actualFormat + out.subLabel, sizeText = actualSize))
                        DownloadBus.setItem(i) { it.copy(status = "done", percent = 100f) }
                        DownloadBus.update { it.copy(lastUri = out.uri, lastPath = out.path) }
                    }
                    is Outcome.Failed -> {
                        failed++
                        HistoryStore.save(base.copy(status = "fail", error = out.message))
                        DownloadBus.setItem(i) { it.copy(status = "fail", error = out.message) }
                    }
                    is Outcome.Cancelled -> {
                        HistoryStore.save(base.copy(status = "cancelled"))
                        DownloadBus.setItem(i) { it.copy(status = "cancel") }
                        if (cancelIndex == i) cancelIndex = -1
                    }
                }
            }
        } catch (e: Exception) {
            failed++
            DownloadBus.update { it.copy(message = "Failed: ${e.message ?: "unknown error"}") }
        } finally {
            val phase = when {
                cancelAll -> "cancelled"
                failed > 0 && ok == 0 -> "failed"
                ok == 0 && reqs.isNotEmpty() && DownloadBus.state.value.items.all { it.status == "cancel" } -> "cancelled"
                else -> "done"
            }
            val summary = when (phase) {
                "cancelled" -> "Download cancelled"
                "failed" -> DownloadBus.state.value.items.firstOrNull { it.error.isNotBlank() }?.error
                    ?: DownloadBus.state.value.message.ifBlank { "Download failed" }
                else -> when {
                    failed > 0 -> "$ok completed · $failed failed · saved to $folder"
                    ok == 1 && kind == "video" -> "Download completed · saved to $folder"
                    else -> "$ok downloads completed · saved to $folder"
                }
            }
            DownloadBus.update {
                it.copy(phase = phase, percent = if (phase == "done") 100f else it.percent, speed = "", eta = 0, prompt = "", message = summary)
            }
            currentPid = ""
            currentRecordId = ""
            busy.set(false)
            releaseWakeLock()
            getSystemService(NotificationManager::class.java).notify(notifId, notification(summary, 100, false))
            stopForeground(STOP_FOREGROUND_DETACH)
            stopSelf()
        }
    }

    private sealed class Outcome {
        object Cancelled : Outcome()
        class Failed(val message: String) : Outcome()
        class Done(val uri: String, val path: String, val extension: String, val sizeBytes: Long, val subLabel: String = "") : Outcome()
    }

    /** Asks whether to continue without subtitles. Returns true to continue, false if cancelled. */
    private fun askWithoutSubtitles(): Boolean {
        decisions.clear()
        DownloadBus.update { it.copy(phase = "prompt", prompt = "Subtitles failed. Download without them?") }
        val choice = decisions.poll(10, TimeUnit.MINUTES)
        DownloadBus.update { it.copy(phase = "running", prompt = "") }
        if (choice == "without") {
            skipSubsForRest = true
            return true
        }
        if (cancelIndex < 0) cancelAll = true
        return false
    }

    private fun isRateLimit(message: String): Boolean =
        message.contains("429") || message.contains("Too Many Requests", true) ||
            message.contains("rate limit", true) || message.contains("rate-limit", true)

    /**
     * YouTube's 429 "Too Many Requests" clears after a pause. Wait and retry (30s, 60s, 120s) rather than
     * failing immediately, unless the user cancelled.
     */
    private fun <T> retryRateLimited(block: () -> T): T {
        val waits = longArrayOf(30_000L, 60_000L, 120_000L)
        for (attempt in 0..waits.size) {
            try {
                return block()
            } catch (e: Exception) {
                if (!isRateLimit(e.message.orEmpty()) || cancelAll || cancelIndex >= 0 || attempt == waits.size) throw e
                val seconds = waits[attempt] / 1000
                DownloadBus.update { it.copy(message = "YouTube is rate-limiting. Retrying in ${seconds}s…") }
                val until = System.currentTimeMillis() + waits[attempt]
                while (System.currentTimeMillis() < until && !cancelAll && cancelIndex < 0) {
                    Thread.sleep(500)
                }
                if (cancelAll || cancelIndex >= 0) throw e
            }
        }
        throw IllegalStateException("Rate-limit retries exhausted")
    }

    private fun srtFiles(work: File): List<File> =
        work.listFiles()?.filter { it.isFile && it.extension.equals("srt", true) && it.length() > 0L }.orEmpty()

    private fun addSubOptions(req: YoutubeDLRequest, subs: String) {
        val all = subs.split(',').map { it.trim() }.contains("all")
        req.addOption("--write-subs")
        // "All languages" means every real track; auto-translations (~150 requests) would be rate-limited.
        if (!all) req.addOption("--write-auto-subs")
        req.addOption("--sub-langs", if (all) "all,-live_chat" else subs)
        req.addOption("--convert-subs", "srt")
    }

    /**
     * Separate subtitle pass using the default player client (fallback clients carry no captions).
     * Saves .srt files beside the video. Returns null on success, or a failure message.
     */
    private fun runSubtitlePass(i: Int, url: String, subs: String, work: File): String? {
        val req = YoutubeDLRequest(url)
        req.addOption("--skip-download")
        req.addOption("--no-playlist")
        req.addOption("--retries", "3")
        req.addOption("--socket-timeout", "30")
        req.addOption("--sleep-subtitles", "3")
        addSubOptions(req, subs)
        YtEngine.withCookies(req)
        req.addOption("-o", File(work, "%(title).120B [%(id)s].%(ext)s").absolutePath)
        DownloadBus.update { it.copy(message = "Fetching subtitles…") }
        val pid = "lumo-$jobId-$i-subs"
        currentPid = pid
        val stderr = try {
            YoutubeDL.getInstance().execute(req, pid).err.orEmpty()
        } catch (e: Exception) {
            if (cancelAll || cancelIndex == i) return null
            if (isRateLimit(e.message.orEmpty())) throw e
            return e.message?.lineSequence()?.firstOrNull { it.isNotBlank() }?.take(140) ?: "Unable to download subtitles"
        } finally {
            currentPid = ""
        }
        if (srtFiles(work).isNotEmpty()) return null
        return stderr.lineSequence().firstOrNull { it.contains("subtitle", true) }?.take(140)
            ?: "No subtitles are available for the selected languages"
    }

    private fun downloadOne(
        i: Int,
        url: String,
        format: String,
        want: String,
        subsIn: String,
        folder: String,
        quality: String
    ): Outcome {
        var subs = subsIn
        val retryClients = if (isYoutubeUrl(url)) listOf("android_vr", "tv") else emptyList()
        var retryClientIndex = 0
        var playerClient: String? = null
        var sidecarDone = false
        // A separate stable directory per URL makes partial-file resume safe and prevents
        // an old file from another download being mistaken for the current result.
        val work = workFolder(url, format, want, subsIn).apply {
            if (!exists() && !mkdirs()) throw IllegalStateException("Cannot create temporary download folder")
        }
        var embedded = false
        while (true) {
            // MKV on the default player client embeds subtitles in one pass. MP4 (or any fallback client)
            // fetches them separately and saves .srt files next to the video.
            val embed = subs.isNotBlank() && want == "mkv" && playerClient == null
            try {
                if (subs.isNotBlank() && !embed && !sidecarDone) {
                    val failure = try {
                        retryRateLimited { runSubtitlePass(i, url, subs, work) }
                    } catch (e: Exception) {
                        e.message?.lineSequence()?.firstOrNull { it.isNotBlank() }?.take(140) ?: "Unable to download subtitles"
                    }
                    if (cancelAll || cancelIndex == i) return Outcome.Cancelled
                    if (failure != null) {
                        if (!askWithoutSubtitles()) return Outcome.Cancelled
                        subs = ""
                        continue
                    }
                    sidecarDone = true
                }
                val stderr = retryRateLimited {
                    runYtDlp(i, url, format, want, if (embed) subs else "", work, playerClient)
                }
                if (cancelAll || cancelIndex == i) return Outcome.Cancelled
                // yt-dlp treats a failed subtitle fetch (for example HTTP 429) as a warning and still finishes
                // the video, so check for it instead of silently saving a file without subtitles.
                if (embed && SUB_WARN.containsMatchIn(stderr)) {
                    if (!askWithoutSubtitles()) {
                        work.deleteRecursively()
                        return Outcome.Cancelled
                    }
                    subs = ""
                } else {
                    embedded = embed
                }
                break
            } catch (e: Exception) {
                if (cancelAll || cancelIndex == i) {
                    decisions.remove("cancel")
                    return Outcome.Cancelled
                }
                val msg = e.message.orEmpty()
                if (retryClientIndex < retryClients.size && isYoutubeClientFailure(msg)) {
                    playerClient = retryClients[retryClientIndex++]
                    // A partial from another YouTube player client may not be byte-compatible.
                    work.listFiles()?.filter { it.name.endsWith(".part", true) || it.name.endsWith(".ytdl", true) }?.forEach { it.delete() }
                    continue
                }
                if (subs.isNotBlank() && isSubtitleFailure(msg)) {
                    if (!askWithoutSubtitles()) return Outcome.Cancelled
                    subs = ""
                    continue
                }
                return Outcome.Failed(YtEngine.friendly(msg))
            }
        }

        val produced = work.listFiles()
            ?.filter { it.isFile && isMedia(it) && it.length() > 0L }
            ?.sortedByDescending { it.lastModified() }
            .orEmpty()
        val media = produced.firstOrNull() ?: return Outcome.Failed("No completed media file was found. Temporary files were kept for retry.")
        val sidecars = if (subs.isNotBlank() && !embedded) srtFiles(work) else emptyList()
        val subLabel = when {
            subs.isBlank() -> ""
            embedded -> " · ${subs.split(',').count { it.isNotBlank() }} sub"
            sidecars.isNotEmpty() -> " · ${sidecars.size} srt"
            else -> " · no subtitle file saved"
        }
        val wantHeight = quality.removeSuffix("p").toIntOrNull() ?: 0
        val gotHeight = reportedHeight
        val heightNote = when {
            wantHeight > 0 && gotHeight in 1 until wantHeight -> " · ${gotHeight}p (${wantHeight}p not available)"
            gotHeight > 0 -> " · ${gotHeight}p"
            else -> ""
        }

        return try {
            val byteCount = media.length()
            val extension = media.extension.uppercase(java.util.Locale.US)
            val published = publish(media, folder)
            sidecars.forEach { publishSubtitle(it, folder) }
            if (published != null) {
                media.delete()
                work.listFiles()?.filter { it.isFile && !it.name.endsWith(".part", true) }?.forEach { it.delete() }
                work.delete()
                Outcome.Done(published.toString(), "", extension, byteCount, subLabel + heightNote)
            } else {
                Outcome.Done("", media.absolutePath, extension, byteCount, subLabel + heightNote)
            }
        } catch (e: Exception) {
            Outcome.Failed("Could not save the file: ${e.message ?: "unknown error"}")
        }
    }

    /** Saves a subtitle file beside the video; falls back to Download/Lumo if the chosen collection refuses it. */
    private fun publishSubtitle(file: File, folder: String) {
        try {
            publish(file, folder)
        } catch (_: Exception) {
            try { publish(file, "Download/Lumo") } catch (_: Exception) { }
        }
    }

    private fun runYtDlp(i: Int, url: String, format: String, container: String, subs: String, work: File, playerClient: String?): String {
        val req = YoutubeDLRequest(url)
        req.addOption("--no-mtime")
        req.addOption("--newline")
        req.addOption("--no-overwrites")
        req.addOption("--continue")
        req.addOption("--no-playlist")
        req.addOption("--retries", "5")
        req.addOption("--fragment-retries", "5")
        req.addOption("--socket-timeout", "30")
        // Pace the media requests so YouTube is less likely to rate-limit a whole playlist or retry storm.
        req.addOption("--sleep-requests", "1")
        if (!playerClient.isNullOrBlank()) req.addOption("--extractor-args", "youtube:player_client=$playerClient")
        req.addOption("-f", format.ifBlank { "bestvideo+bestaudio/best" })
        req.addOption("--merge-output-format", container)
        // Report the resolution that was really saved, so a silent fallback to a lower quality is visible.
        req.addOption("--no-simulate")
        req.addOption("--print", "after_move:LUMO_H=%(height)s")
        req.addOption("-o", File(work, "%(title).120B [%(id)s].%(ext)s").absolutePath)
        YtEngine.withCookies(req)
        if (subs.isNotBlank()) {
            addSubOptions(req, subs)
            req.addOption("--embed-subs")
            req.addOption("--sleep-subtitles", "5")
            req.addOption("--sleep-requests", "1")
        }
        val pid = "lumo-$jobId-$i"
        currentPid = pid
        reportedHeight = 0
        streamsSeen = 0
        inSubtitleFile = false
        multiStream = format.contains('+')
        try {
            val response = YoutubeDL.getInstance().execute(req, pid) { progress, eta, line ->
                onProgress(i, progress, eta, line)
            }
            reportedHeight = Regex("LUMO_H=(\\d+)").find(response.out.orEmpty())
                ?.groupValues?.get(1)?.toIntOrNull() ?: 0
            return response.err.orEmpty()
        } finally {
            currentPid = ""
        }
    }

    private fun onProgress(i: Int, progress: Float, eta: Long, line: String) {
        // yt-dlp reports 0-100% separately for the video stream, the audio stream and each
        // subtitle file. Track which file is active so the bar never jumps back or spikes.
        if (line.startsWith("[download] Destination:")) {
            inSubtitleFile = SUB_EXT.containsMatchIn(line.trim())
            if (!inSubtitleFile) streamsSeen++
            return
        }
        if (inSubtitleFile || progress < 0f) return
        val raw = progress.coerceIn(0f, 100f)
        val pct = when {
            !multiStream -> raw
            streamsSeen <= 1 -> raw * 0.88f
            else -> 88f + raw * 0.12f
        }
        val speed = SPEED.find(line)?.groupValues?.get(1)?.replace("iB", "B")
        DownloadBus.setItem(i) { it.copy(percent = pct) }
        DownloadBus.update { s ->
            s.copy(percent = overall(s), speed = speed ?: s.speed, eta = eta.toInt().coerceAtLeast(0))
        }
        HistoryStore.live(currentRecordId, pct)
        val now = System.currentTimeMillis()
        if (now - lastNotify > 700) {
            lastNotify = now
            getSystemService(NotificationManager::class.java).notify(
                notifId,
                notification(DownloadBus.state.value.message, pct.toInt(), true)
            )
        }
    }

    private fun overall(s: JobState): Float {
        if (s.items.isEmpty()) return 0f
        val active = s.items.filter { it.status != "cancel" }
        if (active.isEmpty()) return 0f
        val sum = active.sumOf {
            when (it.status) {
                "done" -> 100.0
                "run" -> it.percent.toDouble()
                else -> 0.0
            }
        }
        return (sum / active.size).toFloat()
    }

    private fun isSubtitleFailure(msg: String): Boolean =
        msg.contains("subtitle", ignoreCase = true)

    private fun isYoutubeUrl(url: String): Boolean =
        url.contains("youtube.com", true) || url.contains("youtu.be", true)

    private fun isYoutubeClientFailure(message: String): Boolean =
        message.contains("po token", true) || message.contains("403") ||
            message.contains("forbidden", true) || message.contains("nsig", true) ||
            message.contains("signature extraction", true) ||
            message.contains("requested format is not available", true) ||
            message.contains("no video formats found", true)

    private fun formatFileSize(bytes: Long): String {
        val mb = bytes / (1024.0 * 1024.0)
        return if (mb >= 1024.0) "%.2f GB".format(java.util.Locale.US, mb / 1024.0)
        else "%.1f MB".format(java.util.Locale.US, mb)
    }

    private fun isMedia(file: File): Boolean =
        file.extension.lowercase() in setOf("mp4", "mkv", "webm", "mov", "m4v", "mp3", "m4a", "opus", "ogg", "wav", "flac")

    private fun workFolder(url: String, format: String, container: String, subtitles: String): File {
        val base = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: filesDir
        val key = listOf(url, format, container, subtitles).joinToString("\u0000")
        val digest = MessageDigest.getInstance("SHA-256").digest(key.toByteArray(Charsets.UTF_8))
            .take(12).joinToString("") { "%02x".format(it) }
        return File(File(base, "LumoWork"), digest)
    }

    private fun acquireWakeLock() {
        try {
            val power = getSystemService(PowerManager::class.java)
            val lock = wakeLock ?: power.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Lumo:Download").also { wakeLock = it }
            if (!lock.isHeld) lock.acquire(6 * 60 * 60 * 1000L)
        } catch (_: Exception) {
            // Foreground service still runs; only the extra screen-off CPU hold is unavailable.
        }
    }

    private fun releaseWakeLock() {
        try { wakeLock?.takeIf { it.isHeld }?.release() } catch (_: Exception) { }
    }

    /** Copies a finished file into the user's chosen shared folder. Returns its URI, or null for a plain file path. */
    private fun publish(file: File, folder: String): Uri? {
        val mime = if (file.extension.equals("srt", true)) "application/x-subrip"
        else MimeTypeMap.getSingleton().getMimeTypeFromExtension(file.extension.lowercase())
            ?: "application/octet-stream"

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            val type = when {
                folder.startsWith("Movies") -> Environment.DIRECTORY_MOVIES
                folder.startsWith("DCIM") -> Environment.DIRECTORY_DCIM
                else -> Environment.DIRECTORY_DOWNLOADS
            }
            @Suppress("DEPRECATION")
            val dir = File(Environment.getExternalStoragePublicDirectory(type), "Lumo")
            if (!dir.exists() && !dir.mkdirs()) throw IllegalStateException("Cannot create ${dir.path}")
            val dest = File(dir, file.name)
            file.inputStream().use { input -> dest.outputStream().use { output -> input.copyTo(output) } }
            return FileProvider.getUriForFile(this, "$packageName.fileprovider", dest)
        }

        val collection = when {
            folder.startsWith("Download") -> MediaStore.Downloads.EXTERNAL_CONTENT_URI
            mime.startsWith("video/") -> MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            mime.startsWith("audio/") -> MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
            else -> MediaStore.Files.getContentUri("external")
        }
        val resolver = contentResolver
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, file.name)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, folder.trimEnd('/') + "/")
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val uri = resolver.insert(collection, values) ?: throw IllegalStateException("Cannot create the file in $folder")
        try {
            val out = resolver.openOutputStream(uri, "w") ?: throw IllegalStateException("Cannot open the output stream")
            out.use { o -> file.inputStream().use { it.copyTo(o) } }
            resolver.update(uri, ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }, null, null)
            return uri
        } catch (e: Exception) {
            resolver.delete(uri, null, null)
            throw e
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Lumo downloads", NotificationManager.IMPORTANCE_LOW)
                .apply { description = "Download progress and cancellation" }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun notification(message: String, progress: Int, ongoing: Boolean): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("Lumo")
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setContentIntent(open)
            .setOnlyAlertOnce(true)
            .setOngoing(ongoing)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setProgress(100, progress.coerceIn(0, 100), false)
        if (ongoing) {
            val cancel = PendingIntent.getService(
                this, 2,
                Intent(this, DownloadService::class.java).setAction(ACTION_CANCEL).putExtra(EXTRA_INDEX, -1),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            builder.addAction(android.R.drawable.ic_menu_close_clear_cancel, "Cancel", cancel)
        }
        return builder.build()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        releaseWakeLock()
        executor.shutdown()
        super.onDestroy()
    }

    companion object {
        const val ACTION_START = "com.lumo.android.action.START"
        const val ACTION_CANCEL = "com.lumo.android.action.CANCEL"
        const val ACTION_DECIDE = "com.lumo.android.action.DECIDE"
        const val EXTRA_PAYLOAD = "payload"
        const val EXTRA_INDEX = "index"
        const val EXTRA_CHOICE = "choice"
        private const val CHANNEL_ID = "lumo_downloads"
        private val SPEED = Regex("""at\s+([\d.]+\s*\S+/s)""")
        private val SUB_EXT = Regex("""\.(vtt|srt|ttml|srv\d|json3|ass|lrc)$""", RegexOption.IGNORE_CASE)
        private val SUB_WARN = Regex("""Unable to download.*subtitle|There are no subtitles for the requested languages""", RegexOption.IGNORE_CASE)
    }
}
